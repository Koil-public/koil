# Package Image Asset Placeholder

This markdown file exists so the package tree can show a markdown/text icon in addition to JSON, TXT, and properties/config icons.
