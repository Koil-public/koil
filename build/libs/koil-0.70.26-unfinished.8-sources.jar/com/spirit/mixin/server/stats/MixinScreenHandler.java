package com.spirit.mixin.server.stats;

import com.spirit.koil.api.stats.global.GlobalActivityApi;
import com.spirit.koil.api.stats.global.KoilMarketLedger;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.*;
import net.minecraft.class_1657;
import net.minecraft.class_1703;
import net.minecraft.class_1713;
import net.minecraft.class_1735;
import net.minecraft.class_1747;
import net.minecraft.class_1799;
import net.minecraft.class_2371;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_7923;

@Mixin(class_1703.class)
public abstract class MixinScreenHandler {
    @Shadow @Final public class_2371<class_1735> slots;
    @Unique private static final Map<class_1703, Map<Integer, class_1799>> koil$beforeSlots = new IdentityHashMap<>();

    @Inject(method = "onSlotClick", at = @At("HEAD"))
    private void koil$captureContainerBefore(int slotIndex, int button, class_1713 actionType, class_1657 player, CallbackInfo info) {
        if (!(player instanceof class_3222 serverPlayer) || koil$ignorePlayer(serverPlayer)) {
            return;
        }

        koil$beforeSlots.put((class_1703) (Object) this, koil$snapshotContainerSlots(player));
    }

    @Inject(method = "onSlotClick", at = @At("TAIL"))
    private void koil$captureContainerAfter(int slotIndex, int button, class_1713 actionType, class_1657 player, CallbackInfo info) {
        if (!(player instanceof class_3222 serverPlayer) || serverPlayer.method_5682() == null || koil$ignorePlayer(serverPlayer)) {
            return;
        }

        Map<Integer, class_1799> before = koil$beforeSlots.remove((class_1703) (Object) this);

        if (before == null || before.isEmpty()) {
            return;
        }

        String handlerKey = koil$handlerKey();
        boolean stationHandler = koil$isStationHandler(handlerKey);
        boolean exactBlockEntityHandler = koil$isExactBlockEntityHandler(handlerKey);
        boolean recipeOutputTaken = koil$recipeOutputTaken(slotIndex, before);

        for (Map.Entry<Integer, class_1799> entry : before.entrySet()) {
            int index = entry.getKey();

            if (index < 0 || index >= this.slots.size()) {
                continue;
            }

            class_1735 slot = this.slots.get(index);
            class_1799 oldStack = entry.getValue();
            class_1799 newStack = slot.method_7677();
            koil$recordSlotTransfer(serverPlayer, actionType, handlerKey, index, oldStack, newStack);

            if (!stationHandler || exactBlockEntityHandler) {
                continue;
            }

            if (recipeOutputTaken && koil$decreased(oldStack, newStack) && koil$canInsert(slot, oldStack)) {
                int amount = koil$decreaseAmount(oldStack, newStack);
                GlobalActivityApi.recordStationActivity(serverPlayer, handlerKey, koil$stationInputAction(handlerKey), oldStack, amount);
            }
        }

        if (recipeOutputTaken && slotIndex >= 0 && slotIndex < this.slots.size()) {
            class_1799 output = before.get(slotIndex);

            if (output != null && !output.method_7960()) {
                GlobalActivityApi.recordStationActivity(serverPlayer, handlerKey, koil$stationOutputAction(handlerKey), output, output.method_7947());
            }
        }
    }

    @Unique
    private Map<Integer, class_1799> koil$snapshotContainerSlots(class_1657 player) {
        Map<Integer, class_1799> snapshot = new LinkedHashMap<>();

        for (int i = 0; i < this.slots.size(); i++) {
            class_1735 slot = this.slots.get(i);

            if (slot == null || slot.field_7871 == player.method_31548()) {
                continue;
            }

            snapshot.put(i, slot.method_7677().method_7972());
        }

        return snapshot;
    }

    @Unique
    private void koil$recordSlotTransfer(class_3222 player, class_1713 actionType, String handlerKey, int slotIndex, class_1799 before, class_1799 after) {
        if (before == null) {
            before = class_1799.field_8037;
        }

        if (after == null) {
            after = class_1799.field_8037;
        }

        if (class_1799.method_7984(before, after) && before.method_7947() == after.method_7947()) {
            return;
        }

        if (!before.method_7960() && (after.method_7960() || !class_1799.method_7984(before, after) || before.method_7947() > after.method_7947())) {
            int amount = koil$decreaseAmount(before, after);
            koil$recordTransfer(player, "container_out", actionType, handlerKey, slotIndex, before, amount);
        }

        if (!after.method_7960() && (before.method_7960() || !class_1799.method_7984(before, after) || after.method_7947() > before.method_7947())) {
            int amount = before.method_7960() || !class_1799.method_7984(before, after) ? after.method_7947() : after.method_7947() - before.method_7947();
            koil$recordTransfer(player, "container_in", actionType, handlerKey, slotIndex, after, amount);
        }
    }

    @Unique
    private void koil$recordTransfer(class_3222 player, String action, class_1713 actionType, String handlerKey, int slotIndex, class_1799 stack, int amount) {
        if (amount <= 0 || stack == null || stack.method_7960() || player.method_5682() == null) {
            return;
        }

        class_2960 id = class_7923.field_41178.method_10221(stack.method_7909());
        String type = stack.method_7909() instanceof class_1747 ? "block" : "item";
        String safeAction = koil$containerAction(action);
        String category = "container_in".equals(safeAction) ? KoilMarketLedger.PRODUCTION : KoilMarketLedger.DEMAND;
        String metric = safeAction + "/" + type + "/" + handlerKey + "/" + actionType.name().toLowerCase(Locale.ROOT) + "/slot_" + slotIndex + "/" + id.method_12836() + "/" + id.method_12832();
        GlobalActivityApi.recordLedgerActivity(player.method_5682(), player.method_5667(), player.method_7334().getName(), category, metric, amount);
    }

    @Unique
    private String koil$containerAction(String action) {
        String key = action == null ? "" : action.toLowerCase(Locale.ROOT);
        return "container_in".equals(key) ? "container_in" : "container_out";
    }

    @Unique
    private boolean koil$recipeOutputTaken(int slotIndex, Map<Integer, class_1799> before) {
        if (slotIndex < 0 || slotIndex >= this.slots.size()) {
            return false;
        }

        class_1799 beforeStack = before.get(slotIndex);

        if (beforeStack == null || beforeStack.method_7960()) {
            return false;
        }

        class_1735 slot = this.slots.get(slotIndex);
        return slot != null && !koil$canInsert(slot, beforeStack);
    }

    @Unique
    private boolean koil$canInsert(class_1735 slot, class_1799 stack) {
        try {
            return slot.method_7680(stack);
        } catch (Exception ignored) {
            return true;
        }
    }

    @Unique
    private boolean koil$decreased(class_1799 before, class_1799 after) {
        return koil$decreaseAmount(before, after) > 0;
    }

    @Unique
    private int koil$decreaseAmount(class_1799 before, class_1799 after) {
        if (before == null || before.method_7960()) {
            return 0;
        }

        if (after == null || after.method_7960()) {
            return Math.max(0, before.method_7947());
        }

        if (!class_1799.method_7984(before, after)) {
            return Math.max(0, before.method_7947());
        }

        return Math.max(0, before.method_7947() - after.method_7947());
    }

    @Unique
    private String koil$handlerKey() {
        String name = ((class_1703) (Object) this).getClass().getName().toLowerCase(Locale.ROOT);
        int slash = name.lastIndexOf('.');

        if (slash >= 0 && slash < name.length() - 1) {
            name = name.substring(slash + 1);
        }

        return name.replace('$', '_').replace('/', '_').replace(':', '_');
    }

    @Unique
    private boolean koil$isStationHandler(String handlerKey) {
        String key = handlerKey == null ? "" : handlerKey;
        return key.contains("craft") || key.contains("smith") || key.contains("anvil") || key.contains("grind") || key.contains("stonecut") || key.contains("loom") || key.contains("cartography") || key.contains("beacon") || key.contains("enchant") || key.contains("brew") || key.contains("furnace") || key.contains("smoker") || key.contains("blast") || key.contains("crusher") || key.contains("grinder") || key.contains("macerator") || key.contains("pulverizer") || key.contains("press") || key.contains("sawmill") || key.contains("alloy") || key.contains("machine") || key.contains("processor") || key.contains("assembler") || key.contains("compressor") || key.contains("extractor") || key.contains("separator") || key.contains("mixer") || key.contains("mill");
    }

    @Unique
    private boolean koil$isExactBlockEntityHandler(String handlerKey) {
        String key = handlerKey == null ? "" : handlerKey;
        return key.contains("furnace") || key.contains("smoker") || key.contains("blast") || key.contains("brew");
    }

    @Unique
    private String koil$stationInputAction(String handlerKey) {
        String key = handlerKey == null ? "" : handlerKey;

        if (key.contains("smith")) {
            return "smith_input";
        }

        if (key.contains("stonecut")) {
            return "stonecut_input";
        }

        if (key.contains("craft")) {
            return "craft_input";
        }

        return "station_input_consumed";
    }

    @Unique
    private String koil$stationOutputAction(String handlerKey) {
        String key = handlerKey == null ? "" : handlerKey;

        if (key.contains("smith")) {
            return "smith_output";
        }

        if (key.contains("stonecut")) {
            return "stonecut_output";
        }

        if (key.contains("craft")) {
            return "craft_output";
        }

        return "station_output_taken";
    }

    @Unique
    private boolean koil$ignorePlayer(class_3222 player) {
        try {
            return player.method_7337() || player.method_7325();
        } catch (Exception ignored) {
            return false;
        }
    }
}
