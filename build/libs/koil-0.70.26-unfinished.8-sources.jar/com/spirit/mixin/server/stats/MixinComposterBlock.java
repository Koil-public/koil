package com.spirit.mixin.server.stats;

import com.spirit.koil.api.stats.global.GlobalActivityApi;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_3962;
import net.minecraft.class_3965;
import net.minecraft.server.MinecraftServer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.*;

@Mixin(class_3962.class)
public abstract class MixinComposterBlock {
    @Unique private static final Map<String, Object[]> koil$composterSnapshots = new LinkedHashMap<>();

    @Inject(method = "onUse", at = @At("HEAD"))
    private void koil$captureComposterBefore(class_2680 state, class_1937 world, class_2338 pos, net.minecraft.class_1657 player, class_1268 hand, class_3965 hit, CallbackInfoReturnable<class_1269> info) {
        if (world == null || world.field_9236 || pos == null || player == null || hand == null) {
            return;
        }

        koil$composterSnapshots.put(koil$key(world, pos, player.method_5667(), hand), new Object[]{state, player.method_5998(hand).method_7972()});
    }

    @Inject(method = "onUse", at = @At("TAIL"))
    private void koil$captureComposterAfter(class_2680 state, class_1937 world, class_2338 pos, net.minecraft.class_1657 player, class_1268 hand, class_3965 hit, CallbackInfoReturnable<class_1269> info) {
        if (world == null || world.field_9236 || pos == null || player == null || hand == null || !(player instanceof class_3222 serverPlayer)) {
            return;
        }

        Object[] snapshot = koil$composterSnapshots.remove(koil$key(world, pos, player.method_5667(), hand));

        if (snapshot == null || snapshot.length < 2) {
            return;
        }

        MinecraftServer server = world.method_8503();

        if (server == null) {
            return;
        }

        class_2680 beforeState = (class_2680) snapshot[0];
        class_1799 beforeStack = (class_1799) snapshot[1];
        class_1799 afterStack = player.method_5998(hand);
        int beforeLevel = koil$level(beforeState);
        int afterLevel = koil$level(world.method_8320(pos));
        int consumed = koil$decrease(beforeStack, afterStack);

        if (consumed <= 0 && afterLevel <= beforeLevel) {
            return;
        }

        if (consumed > 0 && !beforeStack.method_7960()) {
            GlobalActivityApi.recordProcessingItem(server, "minecraft:composter @ " + pos.method_10263() + "," + pos.method_10264() + "," + pos.method_10260(), "compost_input", beforeStack, consumed);
        }

        if (afterLevel > beforeLevel) {
            GlobalActivityApi.recordProcessingActivity(server, "minecraft:composter @ " + pos.method_10263() + "," + pos.method_10264() + "," + pos.method_10260(), "compost_level_gain/minecraft/composter", afterLevel - beforeLevel);
        }
    }

    @Unique
    private static int koil$level(class_2680 state) {
        try {
            return state.method_11654(class_3962.field_17565);
        } catch (Exception ignored) {
            return 0;
        }
    }

    @Unique
    private static int koil$decrease(class_1799 before, class_1799 after) {
        if (before == null || before.method_7960()) {
            return 0;
        }

        if (after == null || after.method_7960()) {
            return Math.max(0, before.method_7947());
        }

        if (!class_1799.method_7984(before, after)) {
            return Math.max(0, before.method_7947());
        }

        return Math.max(0, before.method_7947() - after.method_7947());
    }

    @Unique
    private static String koil$key(class_1937 world, class_2338 pos, UUID uuid, class_1268 hand) {
        class_2960 worldId = world.method_27983().method_29177();
        return worldId + ":" + pos.method_10263() + "," + pos.method_10264() + "," + pos.method_10260() + ":" + uuid + ":" + hand.name();
    }
}
