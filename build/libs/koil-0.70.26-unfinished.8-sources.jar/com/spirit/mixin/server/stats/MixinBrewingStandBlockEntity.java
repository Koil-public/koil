package com.spirit.mixin.server.stats;

import com.spirit.koil.api.stats.global.GlobalActivityApi;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2589;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.server.MinecraftServer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.*;

@Mixin(class_2589.class)
public abstract class MixinBrewingStandBlockEntity {
    @Unique private static final Map<class_2589, class_1799[]> koil$brewingSnapshots = new IdentityHashMap<>();

    @Inject(method = "tick", at = @At("HEAD"))
    private static void koil$captureBrewingBefore(class_1937 world, class_2338 pos, class_2680 state, class_2589 blockEntity, CallbackInfo info) {
        if (world == null || world.field_9236 || blockEntity == null) {
            return;
        }

        koil$brewingSnapshots.put(blockEntity, koil$snapshot(blockEntity));
    }

    @Inject(method = "tick", at = @At("TAIL"))
    private static void koil$captureBrewingAfter(class_1937 world, class_2338 pos, class_2680 state, class_2589 blockEntity, CallbackInfo info) {
        if (world == null || world.field_9236 || blockEntity == null) {
            return;
        }

        class_1799[] before = koil$brewingSnapshots.remove(blockEntity);

        if (before == null || before.length < 5) {
            return;
        }

        MinecraftServer server = world.method_8503();

        if (server == null) {
            return;
        }

        class_1799[] after = koil$snapshot(blockEntity);
        String processorName = koil$processorName(state, pos);
        int ingredientConsumed = koil$decrease(before[3], after[3]);
        int fuelConsumed = koil$decrease(before[4], after[4]);

        if (ingredientConsumed > 0) {
            GlobalActivityApi.recordProcessingItem(server, processorName, "brew_ingredient", before[3], ingredientConsumed);
        }

        if (fuelConsumed > 0) {
            GlobalActivityApi.recordProcessingItem(server, processorName, "brew_fuel", before[4], fuelConsumed);
        }

        for (int i = 0; i < 3; i++) {
            if (koil$changed(before[i], after[i]) && !after[i].method_7960()) {
                GlobalActivityApi.recordProcessingItem(server, processorName, "brew_output", after[i], after[i].method_7947());
            }
        }
    }

    @Unique
    private static class_1799[] koil$snapshot(class_2589 blockEntity) {
        class_1799[] stacks = new class_1799[5];

        for (int i = 0; i < stacks.length; i++) {
            stacks[i] = blockEntity.method_5438(i).method_7972();
        }

        return stacks;
    }

    @Unique
    private static boolean koil$changed(class_1799 before, class_1799 after) {
        if (before == null) {
            before = class_1799.field_8037;
        }

        if (after == null) {
            after = class_1799.field_8037;
        }

        return !class_1799.method_7984(before, after) || before.method_7947() != after.method_7947();
    }

    @Unique
    private static int koil$decrease(class_1799 before, class_1799 after) {
        if (before == null || before.method_7960()) {
            return 0;
        }

        if (after == null || after.method_7960()) {
            return Math.max(0, before.method_7947());
        }

        if (!class_1799.method_7984(before, after)) {
            return Math.max(0, before.method_7947());
        }

        return Math.max(0, before.method_7947() - after.method_7947());
    }

    @Unique
    private static String koil$processorName(class_2680 state, class_2338 pos) {
        String blockName = "minecraft:brewing_stand";

        try {
            class_2960 id = net.minecraft.class_7923.field_41175.method_10221(state.method_26204());
            blockName = id.method_12836() + ":" + id.method_12832();
        } catch (Exception ignored) {
        }

        if (pos == null) {
            return blockName;
        }

        return blockName + " @ " + pos.method_10263() + "," + pos.method_10264() + "," + pos.method_10260();
    }
}
