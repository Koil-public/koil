package com.spirit.mixin.server.stats;

import com.spirit.koil.api.stats.global.GlobalActivityApi;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2609;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.server.MinecraftServer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.IdentityHashMap;
import java.util.Map;

@Mixin(class_2609.class)
public abstract class MixinAbstractFurnaceBlockEntity {
    @Unique private static final Map<class_2609, Object[]> koil$furnaceSnapshots = new IdentityHashMap<>();

    @Inject(method = "tick", at = @At("HEAD"))
    private static void koil$captureFurnaceBefore(class_1937 world, class_2338 pos, class_2680 state, class_2609 blockEntity, CallbackInfo info) {
        if (world == null || world.field_9236 || blockEntity == null) {
            return;
        }

        koil$furnaceSnapshots.put(blockEntity, new Object[]{blockEntity.method_5438(0).method_7972(), blockEntity.method_5438(1).method_7972(), blockEntity.method_5438(2).method_7972()});
    }

    @Inject(method = "tick", at = @At("TAIL"))
    private static void koil$captureFurnaceAfter(class_1937 world, class_2338 pos, class_2680 state, class_2609 blockEntity, CallbackInfo info) {
        if (world == null || world.field_9236 || blockEntity == null) {
            return;
        }

        Object[] snapshot = koil$furnaceSnapshots.remove(blockEntity);

        if (snapshot == null || snapshot.length < 3) {
            return;
        }

        MinecraftServer server = world.method_8503();

        if (server == null) {
            return;
        }

        class_1799 beforeInput = (class_1799) snapshot[0];
        class_1799 beforeFuel = (class_1799) snapshot[1];
        class_1799 beforeOutput = (class_1799) snapshot[2];
        class_1799 afterInput = blockEntity.method_5438(0);
        class_1799 afterFuel = blockEntity.method_5438(1);
        class_1799 afterOutput = blockEntity.method_5438(2);
        String processorName = koil$processorName(state, pos);
        int inputConsumed = koil$decrease(beforeInput, afterInput);
        int fuelConsumed = koil$decrease(beforeFuel, afterFuel);
        int outputProduced = koil$increase(beforeOutput, afterOutput);

        if (inputConsumed > 0) {
            GlobalActivityApi.recordProcessingItem(server, processorName, "smelt_input", beforeInput, inputConsumed);
        }

        if (fuelConsumed > 0) {
            GlobalActivityApi.recordProcessingItem(server, processorName, "fuel_burned", beforeFuel, fuelConsumed);
        }

        if (outputProduced > 0) {
            GlobalActivityApi.recordProcessingItem(server, processorName, "smelt_output", afterOutput, outputProduced);
        }

        if (fuelConsumed > 0 && outputProduced > 0) {
            GlobalActivityApi.recordProcessingPair(server, processorName, "fuel_supported_output", beforeFuel, afterOutput, Math.min(fuelConsumed, outputProduced));
        }
    }

    @Unique
    private static int koil$decrease(class_1799 before, class_1799 after) {
        if (before == null || before.method_7960()) {
            return 0;
        }

        if (after == null || after.method_7960()) {
            return Math.max(0, before.method_7947());
        }

        if (!class_1799.method_7984(before, after)) {
            return Math.max(0, before.method_7947());
        }

        return Math.max(0, before.method_7947() - after.method_7947());
    }

    @Unique
    private static int koil$increase(class_1799 before, class_1799 after) {
        if (after == null || after.method_7960()) {
            return 0;
        }

        if (before == null || before.method_7960()) {
            return Math.max(0, after.method_7947());
        }

        if (!class_1799.method_7984(before, after)) {
            return Math.max(0, after.method_7947());
        }

        return Math.max(0, after.method_7947() - before.method_7947());
    }

    @Unique
    private static String koil$processorName(class_2680 state, class_2338 pos) {
        String blockName = "furnace";

        try {
            class_2960 id = net.minecraft.class_7923.field_41175.method_10221(state.method_26204());
            blockName = id.method_12836() + ":" + id.method_12832();
        } catch (Exception ignored) {
        }

        if (pos == null) {
            return blockName;
        }

        return blockName + " @ " + pos.method_10263() + "," + pos.method_10264() + "," + pos.method_10260();
    }
}
