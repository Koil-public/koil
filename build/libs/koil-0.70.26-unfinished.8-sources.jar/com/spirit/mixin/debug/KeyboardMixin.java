package com.spirit.mixin.debug;

import com.spirit.Main;
import com.spirit.koil.api.design.uiColorVal;
import com.spirit.koil.api.design.KoilScreenBackgrounds;
import com.spirit.koil.api.f3.F3Controller;
import com.spirit.koil.api.f3.F3LayoutState;
import com.spirit.koil.api.f3.F3Mode;
import net.minecraft.class_156;
import net.minecraft.class_309;
import net.minecraft.class_310;
import net.minecraft.class_3675;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.lwjgl.glfw.GLFW;

import static com.spirit.Main.reloadDesign;
import static com.spirit.koil.api.design.DesignLoader.reloadLoadingTexture;

@Mixin(class_309.class)
public abstract class KeyboardMixin {
	@Shadow @Final private class_310 client;
	boolean switchF3State;
	long debugCrashStartTime = -1L;

	@Shadow protected abstract void debugLog(String key, Object... args);

	private boolean reloadResources(int key) {
		if (this.debugCrashStartTime > 0L && this.debugCrashStartTime < class_156.method_658() - 100L) {
			return true;
		} else if (key == 84) {
			uiColorVal.reload();
			reloadDesign();
			reloadLoadingTexture();
			this.debugLog("debug.reload_resourcepacks.message");
			this.client.method_1521();
			return true;
		} else {
			return false;
		}
	}

	@Inject(at = @At("HEAD"), method = "Lnet/minecraft/client/Keyboard;onKey(JIIII)V", cancellable = true)
	public void onKey(long window, int key, int scancode, int action, int modifiers, CallbackInfo ci) {
		if (window == this.client.method_22683().method_4490()) {
			boolean koilF3Enabled = KoilScreenBackgrounds.uiRedesignEnabled() && !Main.vanillaF3Design() && !F3Controller.vanillaFallback();
			if (key == GLFW.GLFW_KEY_F3 && koilF3Enabled) {
				this.client.field_1690.field_1866 = false;
				if (action == GLFW.GLFW_RELEASE) {
					ci.cancel();
					return;
				}
			}
			if (key == GLFW.GLFW_KEY_F3 && action == GLFW.GLFW_PRESS && koilF3Enabled) {
				if ((modifiers & GLFW.GLFW_MOD_SHIFT) != 0) {
					F3Controller.setOverlayMode(F3Mode.GRAPHS);
				} else if ((modifiers & GLFW.GLFW_MOD_ALT) != 0) {
					F3Controller.setOverlayMode(F3Mode.FULL);
				} else {
					F3Controller.toggleOverlay();
				}
				ci.cancel();
				return;
			}
			if (class_3675.method_15987(class_310.method_1551().method_22683().method_4490(), GLFW.GLFW_KEY_F3) && action == GLFW.GLFW_PRESS && koilF3Enabled) {
				this.client.field_1690.field_1866 = false;
				if (key == GLFW.GLFW_KEY_M) {
					F3Controller.cycleMode();
					ci.cancel();
					return;
				}
				if (key == GLFW.GLFW_KEY_F) {
					F3LayoutState.toggleFrozen();
					ci.cancel();
					return;
				}
				if (key == GLFW.GLFW_KEY_C) {
					F3Controller.copyTarget();
					ci.cancel();
					return;
				}
				if (key == GLFW.GLFW_KEY_R) {
					F3Controller.writeReport();
					ci.cancel();
					return;
				}
				if (key == GLFW.GLFW_KEY_V) {
					F3Controller.toggleVanillaFallback();
					ci.cancel();
					return;
				}
				if (key == GLFW.GLFW_KEY_UP) {
					F3Controller.scrollOverlay(-3);
					ci.cancel();
					return;
				}
				if (key == GLFW.GLFW_KEY_DOWN) {
					F3Controller.scrollOverlay(3);
					ci.cancel();
					return;
				}
			}
			boolean bl2;
			if (action != 0 && this.client.field_1755 != null) {
				bl2 = class_3675.method_15987(class_310.method_1551().method_22683().method_4490(), 292)
						&& this.reloadResources(key);
				this.switchF3State |= bl2;
			}
		}
	}
}
