package com.spirit.mixin.debug;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

import java.util.List;
import net.minecraft.class_340;

@Mixin(class_340.class)
public interface DebugHudAccessor {
    @Invoker("getLeftText")
    List<String> koil$getLeftText();

    @Invoker("getRightText")
    List<String> koil$getRightText();
}
