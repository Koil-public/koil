package com.spirit.mixin.debug;

import com.llamalad7.mixinextras.sugar.Local;
import com.spirit.Main;
import com.spirit.koil.api.design.KoilScreenBackgrounds;
import com.spirit.koil.api.f3.F3Controller;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Slice;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.List;
import java.util.Locale;
import net.minecraft.class_1268;
import net.minecraft.class_1293;
import net.minecraft.class_1309;
import net.minecraft.class_1324;
import net.minecraft.class_1657;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_340;
import net.minecraft.class_5134;

@Mixin(class_340.class)
public class DebugHudMixin {
    @Shadow @Final private class_310 client;

    @Inject(method = "render", at = @At("HEAD"), cancellable = true)
    private void koil$hideVanillaDebugHud(class_332 context, CallbackInfo ci) {
        if (KoilScreenBackgrounds.uiRedesignEnabled() && !Main.vanillaF3Design() && !F3Controller.vanillaFallback()) {
            ci.cancel();
        }
    }

    @Inject(method = "getLeftText", at = @At(value = "INVOKE", target = "Ljava/util/List;add(Ljava/lang/Object;)Z", ordinal = 0, shift = At.Shift.AFTER), slice = @Slice(from = @At(value = "CONSTANT", args = "stringValue=XYZ: %.3f / %.5f / %.3f")))
    private void appendOverworldCoordinates(CallbackInfoReturnable<List<String>> cir, @Local List<String> list) {
        var coordinateScale = client.field_1687.method_8597().comp_646();
        list.add(String.format(Locale.ROOT, "Overworld: %.3f / %.3f", this.client.method_1560().method_23317() * coordinateScale, this.client.method_1560().method_23321() * coordinateScale));
    }

    @Inject(method = "getRightText", at = @At(value = "INVOKE", target = "Ljava/util/List;add(Ljava/lang/Object;)Z", ordinal = 10, shift = At.Shift.AFTER))
    private void onAdd(CallbackInfoReturnable<List<String>> cir, @Local List<String> list) {
        class_310 client = class_310.method_1551();

        if (client.field_1692 instanceof class_1309 livingEntity) {
            list.add(String.format("Health: %.3f/%.1f", livingEntity.method_6032(), livingEntity.method_6063()));
            list.add(String.format("Absorption: %.3f", livingEntity.method_6067()));

            list.add(String.format("Armor: %d", livingEntity.method_6096()));

            class_1324 maxHealth = livingEntity.method_5996(class_5134.field_23716);
            class_1324 followRange = livingEntity.method_5996(class_5134.field_23717);
            class_1324 knockbackResistance = livingEntity.method_5996(class_5134.field_23718);
            class_1324 movementSpeed = livingEntity.method_5996(class_5134.field_23719);
            class_1324 flyingSpeed = livingEntity.method_5996(class_5134.field_23720);
            class_1324 attackDamage = livingEntity.method_5996(class_5134.field_23721);
            class_1324 attackKnockback = livingEntity.method_5996(class_5134.field_23722);
            class_1324 attackSpeed = livingEntity.method_5996(class_5134.field_23723);
            class_1324 armor = livingEntity.method_5996(class_5134.field_23724);
            class_1324 armorToughness = livingEntity.method_5996(class_5134.field_23725);
            class_1324 luck = livingEntity.method_5996(class_5134.field_23726);
            class_1324 zombieSpawnReinforcements = livingEntity.method_5996(class_5134.field_23727);
            class_1324 horseJumpStrength = livingEntity.method_5996(class_5134.field_23728);

            if (maxHealth != null) {
                list.add(String.format("Max Health: %.3f", maxHealth.method_6194()));
            }
            if (followRange != null) {
                list.add(String.format("Follow Range: %.3f", followRange.method_6194()));
            }
            if (knockbackResistance != null) {
                list.add(String.format("Knockback Resistance: %.3f", knockbackResistance.method_6194()));
            }
            if (movementSpeed != null) {
                list.add(String.format("Movement Speed: %.3f", movementSpeed.method_6194()));
            }
            if (flyingSpeed != null) {
                list.add(String.format("Flying Speed: %.3f", flyingSpeed.method_6194()));
            }
            if (attackDamage != null) {
                list.add(String.format("Attack Damage: %.3f", attackDamage.method_6194()));
            }
            if (attackKnockback != null) {
                list.add(String.format("Attack Knockback: %.3f", attackKnockback.method_6194()));
            }
            if (attackSpeed != null) {
                list.add(String.format("Attack Speed: %.3f", attackSpeed.method_6194()));
            }
            if (armor != null) {
                list.add(String.format("Armor: %.3f", armor.method_6194()));
            }
            if (armorToughness != null) {
                list.add(String.format("Armor Toughness: %.3f", armorToughness.method_6194()));
            }
            if (luck != null) {
                list.add(String.format("Luck: %.3f", luck.method_6194()));
            }
            if (zombieSpawnReinforcements != null) {
                list.add(String.format("Zombie Spawn Reinforcements: %.3f", zombieSpawnReinforcements.method_6194()));
            }
            if (horseJumpStrength != null) {
                list.add(String.format("Horse Jump Strength: %.3f", horseJumpStrength.method_6194()));
            }

            class_1268 activeHand = livingEntity.method_6058();
            list.add(String.format("Active Hand: %s", activeHand));
            if (activeHand != null) {
                list.add(String.format("Active Item: %s", livingEntity.method_5998(activeHand).method_7909().toString()));
            }
            list.add(String.format("Offhand Item: %s", livingEntity.method_6079().method_7909().toString()));

            if (livingEntity.method_6065() != null) {
                list.add(String.format("Attacker: %s", livingEntity.method_6065().method_5477().getString()));
            }

            if (livingEntity.method_6052() != null) {
                list.add(String.format("Target: %s", livingEntity.method_6052().method_5477().getString()));
            }

            if (livingEntity instanceof class_1657 playerEntity) {
                list.add(String.format("Hunger: %d", playerEntity.method_7344().method_7586()));
                list.add(String.format("Saturation: %.3f", playerEntity.method_7344().method_7589()));
                list.add(String.format("Exhaustion: %.3f", playerEntity.method_7344().method_35219()));
                list.add(String.format("Previous Food Level: %d", playerEntity.method_7344().method_35217()));
            }

            if (!livingEntity.method_6026().isEmpty()) {
                list.add("Status Effects:");
                for (class_1293 effect : livingEntity.method_6026()) {
                    list.add(String.format("  - %s (Amplifier: %d, Duration: %d ticks)",
                            effect.method_5579().method_5560().getString(),
                            effect.method_5578(),
                            effect.method_5584()));
                }
            }

            list.add(String.format("Air: %d/%d", livingEntity.method_5669(), livingEntity.method_5748()));
            list.add(String.format("Fall Distance: %.3f", livingEntity.field_6017));
            list.add(String.format("Fire: %d ticks", livingEntity.method_20802()));
            list.add(String.format("No Gravity: %b", livingEntity.method_5740()));

            list.add(String.format("UUID: %s", livingEntity.method_5845()));
            list.add(String.format("Position: [X: %.2f, Y: %.2f, Z: %.2f]", livingEntity.method_23317(), livingEntity.method_23318(), livingEntity.method_23321()));

            list.add(String.format("Bounding Box: [Min: %.2f, %.2f, %.2f | Max: %.2f, %.2f, %.2f]",
                    livingEntity.method_5829().field_1323,
                    livingEntity.method_5829().field_1322,
                    livingEntity.method_5829().field_1321,
                    livingEntity.method_5829().field_1320,
                    livingEntity.method_5829().field_1325,
                    livingEntity.method_5829().field_1324));
        }
    }
}
