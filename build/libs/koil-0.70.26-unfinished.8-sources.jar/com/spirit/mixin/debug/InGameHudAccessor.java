package com.spirit.mixin.debug;

import net.minecraft.class_329;
import net.minecraft.class_340;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_329.class)
public interface InGameHudAccessor {
    @Accessor("debugHud")
    class_340 koil$getDebugHud();
}
