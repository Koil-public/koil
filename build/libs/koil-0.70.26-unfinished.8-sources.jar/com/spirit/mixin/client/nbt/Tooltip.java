package com.spirit.mixin.client.nbt;

import com.spirit.Client;
import com.spirit.koil.api.dev.TooltipChanger;
import com.spirit.koil.api.stats.global.KoilPhysicalMomensCurrency;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.ArrayList;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_3675;

@Mixin(class_1799.class)
public abstract class Tooltip {

	@Inject(method = "getTooltip", at = @At("RETURN"), cancellable = true)
	protected void injectEditTooltipMethod(class_1657 player, class_1836 context, CallbackInfoReturnable<ArrayList<class_2561>> info) {
		int code = class_3675.method_15981(Client.KOIL_UTIL_NBT_KEY.method_1428()).method_1444();
		boolean isKeybindPressed = class_3675.method_15987(class_310.method_1551().method_22683().method_4490(), code);
		class_1799 itemStack = (class_1799) (Object) this;
		ArrayList<class_2561> list = info.getReturnValue();

		if (KoilPhysicalMomensCurrency.isMomens(itemStack) && !koil$hasMomensPortfolio(list)) {
			list.addAll(KoilPhysicalMomensCurrency.sourceTooltip(itemStack));
		}

		if (context.method_8035() && isKeybindPressed) {
			if (itemStack.method_7985()) {
				info.setReturnValue(TooltipChanger.Main(itemStack, list));
			}
		}
	}

	private boolean koil$hasMomensPortfolio(ArrayList<class_2561> list) {
		for (class_2561 line : list) {
			String value = line.getString();

			if (value.contains("Momens Market Note") || value.contains("Momens Portfolio") || value.contains("MOMENS PORTFOLIO")) {
				return true;
			}
		}

		return false;
	}
}
