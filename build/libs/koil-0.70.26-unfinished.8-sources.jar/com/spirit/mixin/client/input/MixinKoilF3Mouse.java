package com.spirit.mixin.client.input;

import com.spirit.client.gui.main.KoilUpdateToast;
import com.spirit.koil.api.f3.F3Controller;
import net.minecraft.class_310;
import net.minecraft.class_312;
import org.lwjgl.glfw.GLFW;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_312.class)
public abstract class MixinKoilF3Mouse {
    @Shadow private double x;
    @Shadow private double y;

    @Inject(method = "onMouseScroll", at = @At("HEAD"), cancellable = true)
    private void koil$scrollF3Overlay(long window, double horizontal, double vertical, CallbackInfo ci) {
        if (F3Controller.handleOverlayMouseScroll(vertical)) {
            ci.cancel();
        }
    }

    @Inject(method = "onMouseButton", at = @At("HEAD"), cancellable = true)
    private void koil$clickUpdateToast(long window, int button, int action, int mods, CallbackInfo ci) {
        if (button != GLFW.GLFW_MOUSE_BUTTON_LEFT || action != GLFW.GLFW_PRESS) {
            return;
        }
        class_310 client = class_310.method_1551();
        if (client == null || client.method_22683() == null || client.method_22683().method_4490() != window) {
            return;
        }
        double scaledX = this.x * client.method_22683().method_4486() / client.method_22683().method_4480();
        double scaledY = this.y * client.method_22683().method_4502() / client.method_22683().method_4507();
        if (KoilUpdateToast.handleClick(client, scaledX, scaledY)) {
            ci.cancel();
        }
    }
}
