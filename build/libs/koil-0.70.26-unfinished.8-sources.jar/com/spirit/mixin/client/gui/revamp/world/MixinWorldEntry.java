package com.spirit.mixin.client.gui.revamp.world;

import com.spirit.client.gui.browser.ContentBrowserListRowRenderer;
import com.spirit.koil.api.design.KoilScreenBackgrounds;
import com.spirit.koil.api.util.file.image.ExternalImageLoader;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_34;
import net.minecraft.class_526;
import net.minecraft.class_528;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.io.File;
import java.io.IOException;

import static com.spirit.Main.uiImageDirectory;
import static com.spirit.koil.api.util.file.image.ExternalImageLoader.loadExternalPngTextureWithColorVariant;

@Environment(EnvType.CLIENT)
@Mixin(class_528.class_4272.class)
public abstract class MixinWorldEntry {
    @Unique private static final class_2960 KOIL_FALLBACK_WORLD_ICON = loadExternalPngTextureWithColorVariant(uiImageDirectory, "image.png");

    @Shadow @Final private class_34 level;

    @Inject(method = "render", at = @At("HEAD"), cancellable = true)
    private void koil$renderWorldRow(class_332 context, int index, int y, int x, int entryWidth, int entryHeight, int mouseX, int mouseY, boolean hovered, float tickDelta, CallbackInfo ci) {
        class_310 client = class_310.method_1551();
        if (client == null
                || !(client.field_1755 instanceof class_526)
                || !KoilScreenBackgrounds.uiRedesignEnabled()) {
            return;
        }

        String title = level.method_252().isBlank() ? level.method_248() : level.method_252();
        class_2561 details = level.method_27429();
        String detailsText = details == null ? "" : details.getString();
        String subLabel = detailsText.isBlank() ? level.method_248() : level.method_248() + "  |  " + detailsText;
        ContentBrowserListRowRenderer.renderModMenuStyleItem(context, client.field_1772, koil$resolveWorldIcon(), KOIL_FALLBACK_WORLD_ICON, x, y, entryWidth, title, subLabel);

        ci.cancel();
    }

    @Unique
    private class_2960 koil$resolveWorldIcon() {
        try {
            File iconFile = this.level.method_27020().toFile();
            if (!iconFile.exists()) {
                return KOIL_FALLBACK_WORLD_ICON;
            }
            class_2960 icon = ExternalImageLoader.registerDynamicTexture("koil", "world_icon/list_" + koil$sanitizeTextureKey(this.level.method_248()), iconFile);
            return icon != null ? icon : KOIL_FALLBACK_WORLD_ICON;
        } catch (IOException | RuntimeException ignored) {
            return KOIL_FALLBACK_WORLD_ICON;
        }
    }

    @Unique
    private String koil$sanitizeTextureKey(String value) {
        if (value == null || value.isBlank()) {
            return "world";
        }
        return value.toLowerCase().replaceAll("[^a-z0-9_./-]", "_");
    }
}
