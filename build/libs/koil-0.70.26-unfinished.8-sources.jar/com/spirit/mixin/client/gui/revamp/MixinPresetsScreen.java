package com.spirit.mixin.client.gui.revamp;

import com.google.gson.JsonElement;
import com.spirit.koil.api.design.DesignLoader;
import com.spirit.koil.api.util.file.json.JSONFileEditor;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_430;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Environment(EnvType.CLIENT)
@Mixin(class_430.class)
public class MixinPresetsScreen {
    @Inject(method = "render", at = @At("HEAD"))
    private void onRender(class_332 context, int mouseX, int mouseY, float delta, CallbackInfo info) {
        class_310 client = class_310.method_1551();
        JsonElement jsonBackgroundElement = JSONFileEditor.getValueFromJson("./koil/sys/config.json", "jsonBackground");
        context.method_25293(DesignLoader.getLoadingTexture(), 0, 0, client.method_22683().method_4486(), client.method_22683().method_4502(), 0.0F, 0.0F, 319, 192, 319, 192);

    }
}
