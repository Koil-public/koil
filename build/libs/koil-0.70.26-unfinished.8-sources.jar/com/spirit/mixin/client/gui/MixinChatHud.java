package com.spirit.mixin.client.gui;

import com.spirit.koil.api.automation.AutomationChatTrigger;
import com.spirit.koil.api.automation.cli.AutomationChatHudRenderer;
import com.spirit.koil.api.stats.global.client.MarketHudRenderer;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_338;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_338.class)
public abstract class MixinChatHud {
    @Shadow @Final private class_310 client;

    private boolean koil$shiftedForAutomationHud;
    private int koil$automationHudReservedHeight;

    @Inject(method = "render", at = @At("HEAD"))
    private void koil$beginAutomationHudRender(class_332 context, int currentTick, int mouseX, int mouseY, CallbackInfo ci) {
        koil$shiftedForAutomationHud = false;
        koil$automationHudReservedHeight = 0;
        int reservedHeight = AutomationChatHudRenderer.reservedHeight(client) + MarketHudRenderer.reservedHeight(client);
        if (reservedHeight > 0) {
            koil$automationHudReservedHeight = reservedHeight;
            koil$shiftedForAutomationHud = true;
            context.method_51448().method_22903();
            context.method_51448().method_46416(0.0F, -koil$automationHudReservedHeight, 0.0F);
        }
    }

    @Inject(method = "render", at = @At("TAIL"))
    private void koil$finishAutomationHudRender(class_332 context, int currentTick, int mouseX, int mouseY, CallbackInfo ci) {
        if (koil$shiftedForAutomationHud) {
            context.method_51448().method_22909();
            koil$shiftedForAutomationHud = false;
        }
    }

    @Inject(method = "addMessage(Lnet/minecraft/text/Text;)V", at = @At("HEAD"))
    private void koil$automationUsernameTrigger(class_2561 message, CallbackInfo ci) {
        AutomationChatTrigger.maybeOpenPrompt(message);
    }
}
