package com.spirit.mixin.client.gui;

import com.google.gson.JsonElement;
import com.spirit.client.gui.InfoPopup;
import com.spirit.client.gui.PopupMenu;
import com.spirit.client.gui.ScreenChromeHost;
import com.spirit.client.gui.VanillaScreenToolResolver;
import com.spirit.client.gui.browser.AbstractModrinthContentScreen;
import com.spirit.client.gui.datapack.DatapackScreen;
import com.spirit.client.gui.ide.FileEditorScreen;
import com.spirit.client.gui.ide.FileExplorerScreen;
import com.spirit.client.gui.main.KoilMenuScreen;
import com.spirit.client.gui.measure.PixelDifferenceOverlay;
import com.spirit.client.gui.mod.ModConfigScreen;
import com.spirit.client.gui.mod.ModMenuScreen;
import com.spirit.client.gui.mod.ModScreen;
import com.spirit.client.gui.resourcepack.ResourcePackMenuScreen;
import com.spirit.client.gui.resourcepack.ResourcepackScreen;
import com.spirit.client.gui.shader.ShaderPackMenuScreen;
import com.spirit.client.gui.shader.ShaderpackScreen;
import com.spirit.client.gui.tool.PerformanceOptimizerScreen;
import com.spirit.client.gui.update.UpdateScreen;
import com.spirit.koil.api.design.KoilScreenBackgrounds;
import com.spirit.koil.api.design.KoilVanillaScreenChrome;
import com.spirit.koil.api.util.file.json.JSONFileEditor;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_350;
import net.minecraft.class_362;
import net.minecraft.class_364;
import net.minecraft.class_3928;
import net.minecraft.class_403;
import net.minecraft.class_404;
import net.minecraft.class_405;
import net.minecraft.class_4068;
import net.minecraft.class_407;
import net.minecraft.class_410;
import net.minecraft.class_412;
import net.minecraft.class_413;
import net.minecraft.class_415;
import net.minecraft.class_4189;
import net.minecraft.class_419;
import net.minecraft.class_420;
import net.minecraft.class_422;
import net.minecraft.class_426;
import net.minecraft.class_4288;
import net.minecraft.class_429;
import net.minecraft.class_430;
import net.minecraft.class_433;
import net.minecraft.class_434;
import net.minecraft.class_435;
import net.minecraft.class_437;
import net.minecraft.class_440;
import net.minecraft.class_442;
import net.minecraft.class_443;
import net.minecraft.class_445;
import net.minecraft.class_446;
import net.minecraft.class_447;
import net.minecraft.class_458;
import net.minecraft.class_4667;
import net.minecraft.class_4749;
import net.minecraft.class_500;
import net.minecraft.class_5235;
import net.minecraft.class_524;
import net.minecraft.class_525;
import net.minecraft.class_526;
import net.minecraft.class_527;
import net.minecraft.class_5375;
import net.minecraft.class_5405;
import net.minecraft.class_5500;
import net.minecraft.class_6599;
import net.minecraft.class_6777;
import net.minecraft.class_7065;
import net.minecraft.class_7745;
import net.minecraft.class_7944;
import net.minecraft.class_8086;
import net.minecraft.class_8219;
import net.minecraft.client.gui.screen.*;
import net.minecraft.client.gui.screen.option.*;
import net.minecraft.client.gui.screen.world.*;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.*;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import static com.spirit.Main.uiImageDirectory;
import static com.spirit.koil.api.util.file.image.ExternalImageLoader.loadExternalPngTexture;

@Environment(EnvType.CLIENT)
@Mixin(class_437.class)
public abstract class MixinScreen extends class_362 implements class_4068, ScreenChromeHost {
    @Unique private static final int KOIL_TOP_BAR_BUTTON_SIZE = 14;
    @Unique private static final int KOIL_TOP_BAR_BUTTON_GAP = 4;
    @Unique private static final int KOIL_TOP_BAR_RIGHT_MARGIN = 10;
    @Unique private static final int KOIL_TOP_BAR_KOIL_SCREEN_LEFT_SHIFT = 4;
    @Unique private static final int KOIL_TOP_BAR_TOP_MARGIN = 6;
    @Unique private static final List<String> KOIL_MACHINE_GENERATED_POPUP = List.of(
            "Machine-generated formatting",
            "Koil may generate previews, grouped controls, metadata, and warning text from local file data.",
            "This can be wrong. Verify important content before acting on it."
    );
    @Unique private final PopupMenu koil$screenToolsMenu = new PopupMenu();
    @Unique private final InfoPopup koil$screenInfoPopup = new InfoPopup();
    @Unique private final InfoPopup koil$machineGeneratedPopup = new InfoPopup();

    @Shadow @Final private List<class_4068> drawables;
    @Shadow @Final private List<class_364> children;
    @Shadow @Nullable protected class_310 client;
    @Mutable @Shadow @Final public static class_2960 OPTIONS_BACKGROUND_TEXTURE;

    @Shadow public abstract void close();
    @Shadow protected abstract void setTooltip(class_2561 tooltip);

    @Shadow public int width;
    @Shadow public int height;

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        for (class_4068 drawable : this.drawables) {
            drawable.method_25394(context, mouseX, mouseY, delta);
        }
    }

    @Inject(method = "render", at = @At("TAIL"))
    private void koil$renderVanillaToolsButton(class_332 context, int mouseX, int mouseY, float delta, CallbackInfo ci) {
        if ((Object) this instanceof ModConfigScreen
                || (Object) this instanceof ModMenuScreen
                || (Object) this instanceof ShaderPackMenuScreen
                || (Object) this instanceof ResourcePackMenuScreen
                || (Object) this instanceof AbstractModrinthContentScreen) {
            return;
        }
        koil$renderScreenChromeLate(context, mouseX, mouseY, delta);
    }

    @Override
    public void koil$renderScreenChromeLate(class_332 context, int mouseX, int mouseY, float delta) {
        boolean showToolsButton = koil$shouldShowToolsButton();
        boolean showMachineGeneratedBadge = koil$showsMachineGeneratedBadge();
        if (!showToolsButton && !showMachineGeneratedBadge) {
            koil$screenToolsMenu.close();
            koil$screenInfoPopup.close();
            koil$machineGeneratedPopup.close();
            PixelDifferenceOverlay.render(context, mouseX, mouseY);
            return;
        }

        int screenWidth = koil$screenWidth();
        int screenHeight = koil$screenHeight();
        int buttonY = koil$topBarButtonY();
        int toolsButtonX = Math.max(8, screenWidth - KOIL_TOP_BAR_RIGHT_MARGIN - KOIL_TOP_BAR_BUTTON_SIZE - koil$topBarButtonLeftShift());
        int infoButtonX = showToolsButton
                ? toolsButtonX - KOIL_TOP_BAR_BUTTON_GAP - KOIL_TOP_BAR_BUTTON_SIZE
                : screenWidth - KOIL_TOP_BAR_RIGHT_MARGIN - KOIL_TOP_BAR_BUTTON_SIZE;
        infoButtonX = Math.max(8, Math.min(infoButtonX, screenWidth - KOIL_TOP_BAR_BUTTON_RIGHT_SAFE_SIZE()));
        boolean toolsHovered = showToolsButton && koil$isInside(mouseX, mouseY, toolsButtonX, buttonY, KOIL_TOP_BAR_BUTTON_SIZE, KOIL_TOP_BAR_BUTTON_SIZE);
        boolean infoHovered = showMachineGeneratedBadge && koil$isInside(mouseX, mouseY, infoButtonX, buttonY, KOIL_TOP_BAR_BUTTON_SIZE, KOIL_TOP_BAR_BUTTON_SIZE);

        context.method_51448().method_22903();
        context.method_51448().method_46416(0.0F, 0.0F, 325.0F);

        if (showMachineGeneratedBadge) {
            koil$drawInfoIcon(context, infoButtonX, buttonY, infoHovered);
            boolean machinePopupHovered = koil$machineGeneratedPopup.isOpen() && koil$machineGeneratedPopup.contains(mouseX, mouseY);
            if (infoHovered || machinePopupHovered) {
                koil$machineGeneratedPopup.openWarningAtPointer(mouseX, mouseY, screenWidth, screenHeight, KOIL_MACHINE_GENERATED_POPUP);
            } else {
                koil$machineGeneratedPopup.close();
            }
        }

        if (showToolsButton) {
            koil$drawTopBarButton(context, toolsButtonX, buttonY, toolsHovered || koil$screenToolsMenu.isOpen(), "...");
        }

        koil$screenToolsMenu.render(context, mouseX, mouseY);
        koil$screenInfoPopup.render(context);
        koil$machineGeneratedPopup.render(context);
        PixelDifferenceOverlay.render(context, mouseX, mouseY);
        context.method_51448().method_22909();
    }

    @Override
    public boolean method_25402(double mouseX, double mouseY, int button) {
        if (PixelDifferenceOverlay.mouseClicked(mouseX, mouseY, button)) {
            return true;
        }
        if (koil$consumeScreenChromeClick(mouseX, mouseY, button)) {
            return true;
        }
        return super.method_25402(mouseX, mouseY, button);
    }

    @Override
    public boolean method_25403(double mouseX, double mouseY, int button, double deltaX, double deltaY) {
        if (PixelDifferenceOverlay.mouseDragged(mouseX, mouseY, button, deltaX, deltaY)) {
            return true;
        }
        return super.method_25403(mouseX, mouseY, button, deltaX, deltaY);
    }

    @Override
    public boolean method_25406(double mouseX, double mouseY, int button) {
        if (PixelDifferenceOverlay.mouseReleased(mouseX, mouseY, button)) {
            return true;
        }
        return super.method_25406(mouseX, mouseY, button);
    }

    @Inject(method = "keyPressed", at = @At("HEAD"), cancellable = true)
    private void koil$consumePixelDifferenceKey(int keyCode, int scanCode, int modifiers, CallbackInfoReturnable<Boolean> cir) {
        if (PixelDifferenceOverlay.keyPressed(keyCode)) {
            cir.setReturnValue(true);
        }
    }

    @Override
    public boolean koil$consumeScreenChromeClick(double mouseX, double mouseY, int button) {
        boolean showToolsButton = koil$shouldShowToolsButton();
        boolean showMachineGeneratedBadge = koil$showsMachineGeneratedBadge();
        if (!showToolsButton && !showMachineGeneratedBadge) {
            return false;
        }

        int screenWidth = koil$screenWidth();
        int screenHeight = koil$screenHeight();
        int buttonY = koil$topBarButtonY();
        int toolsButtonX = Math.max(8, screenWidth - KOIL_TOP_BAR_RIGHT_MARGIN - KOIL_TOP_BAR_BUTTON_SIZE - koil$topBarButtonLeftShift());
        int infoButtonX = showToolsButton
                ? toolsButtonX - KOIL_TOP_BAR_BUTTON_GAP - KOIL_TOP_BAR_BUTTON_SIZE
                : screenWidth - KOIL_TOP_BAR_RIGHT_MARGIN - KOIL_TOP_BAR_BUTTON_SIZE;
        infoButtonX = Math.max(8, Math.min(infoButtonX, screenWidth - KOIL_TOP_BAR_BUTTON_RIGHT_SAFE_SIZE()));
        boolean toolsButtonHovered = showToolsButton && koil$isInside(mouseX, mouseY, toolsButtonX, buttonY, KOIL_TOP_BAR_BUTTON_SIZE, KOIL_TOP_BAR_BUTTON_SIZE);
        boolean infoButtonHovered = showMachineGeneratedBadge && koil$isInside(mouseX, mouseY, infoButtonX, buttonY, KOIL_TOP_BAR_BUTTON_SIZE, KOIL_TOP_BAR_BUTTON_SIZE);

        if (koil$screenInfoPopup.isOpen() && !koil$screenInfoPopup.contains(mouseX, mouseY) && !toolsButtonHovered) {
            koil$screenInfoPopup.close();
        }
        if (koil$machineGeneratedPopup.isOpen() && !koil$machineGeneratedPopup.contains(mouseX, mouseY) && !infoButtonHovered) {
            koil$machineGeneratedPopup.close();
        }

        if (button == 0 && infoButtonHovered) {
            return true;
        }

        if (button == 0 && toolsButtonHovered) {
            VanillaScreenToolResolver.ResolvedScreenTools tools = koil$resolvedTools();
            koil$screenInfoPopup.close();
            if (tools != null) {
                koil$screenToolsMenu.toggleNearAnchor(toolsButtonX, buttonY, KOIL_TOP_BAR_BUTTON_SIZE, screenWidth, screenHeight, tools.actions());
                return true;
            }
        }

        if (button == 0 && koil$screenToolsMenu.isOpen()) {
            VanillaScreenToolResolver.ResolvedScreenTools tools = koil$resolvedTools();
            PopupMenu.MenuEntry selected = koil$screenToolsMenu.click(mouseX, mouseY);
            if (selected != null && tools != null) {
                koil$handleToolAction(selected.id(), tools, mouseX, mouseY);
                return true;
            }
            if (!koil$screenToolsMenu.isOpen()) {
                return true;
            }
        }

        if ((koil$screenToolsMenu.isOpen() && koil$screenToolsMenu.contains(mouseX, mouseY))
                || (koil$screenInfoPopup.isOpen() && koil$screenInfoPopup.contains(mouseX, mouseY))
                || (koil$machineGeneratedPopup.isOpen() && koil$machineGeneratedPopup.contains(mouseX, mouseY))) {
            return true;
        }
        return false;
    }

    @Inject(method = "removed", at = @At("TAIL"))
    private void koil$closeVanillaToolsPopups(CallbackInfo ci) {
        koil$screenToolsMenu.close();
        koil$screenInfoPopup.close();
        koil$machineGeneratedPopup.close();
        PixelDifferenceOverlay.clearForRemovedScreen();
    }

    @Inject(method = "renderBackgroundTexture", at = @At(value = "HEAD"), cancellable = true)
    private void onRenderBackgroundTexture(class_332 context, CallbackInfo ci) {
        if (client == null || client.field_1755 == null) {
            return;
        }
        if (client.field_1755 instanceof class_445 && koil$isUiRedesignEnabled()) {
            int screenWidth = koil$screenWidth();
            int screenHeight = koil$screenHeight();
            koil$setOptionsBackgroundBlank(true);
            KoilScreenBackgrounds.render(context, client, screenWidth, screenHeight);
            if (KoilScreenBackgrounds.canRender(client)) {
                context.method_25294(0, 0, screenWidth, screenHeight, KoilScreenBackgrounds.overlayColor(client));
            }
            KoilVanillaScreenChrome.renderCreditsTextPanel(context, screenWidth, screenHeight);
            ci.cancel();
            return;
        }
        if (client.field_1755 instanceof class_433 && koil$isUiRedesignEnabled()) {
            int screenWidth = koil$screenWidth();
            int screenHeight = koil$screenHeight();
            koil$setOptionsBackgroundBlank(true);
            KoilVanillaScreenChrome.renderOptionsShell(context, client, screenWidth, screenHeight);
            ci.cancel();
            return;
        }
        if (client.field_1755 instanceof class_447 && koil$isUiRedesignEnabled()) {
            int screenWidth = koil$screenWidth();
            int screenHeight = koil$screenHeight();
            koil$setOptionsBackgroundBlank(true);
            KoilVanillaScreenChrome.renderListShell(context, client, screenWidth, screenHeight, KoilVanillaScreenChrome.listTop(false), KoilVanillaScreenChrome.listBottom(screenHeight));
            ci.cancel();
            return;
        }
        if (koil$shouldUseSharedScreenBackground(client.field_1755)) {
            int screenWidth = koil$screenWidth();
            int screenHeight = koil$screenHeight();
            koil$setOptionsBackgroundBlank(true);
            KoilVanillaScreenChrome.renderOptionsShell(context, client, screenWidth, screenHeight);
            ci.cancel();
            return;
        }
        Set<Class<?>> customBackgroundScreens = new HashSet<>();
        List<Class<?>> uiScreens = Arrays.asList(
                class_526.class,
                class_4749.class,
                class_410.class,
                class_407.class,
                class_412.class,
                class_419.class,
                class_525.class,
                class_524.class,
                class_5235.class,
                class_413.class,
                class_415.class,
                class_527.class,
                class_405.class,
                class_430.class,
                class_422.class,
                class_420.class,
                class_3928.class,
                class_434.class,
                class_435.class,
                class_5405.class,
                class_403.class,
                class_4667.class,
                class_404.class,
                class_458.class,
                class_8219.class,
                class_6599.class,
                class_426.class,
                class_4288.class,
                class_6777.class,
                class_429.class,
                class_5500.class,
                class_440.class,
                class_443.class,
                class_7944.class,
                class_447.class,
                class_446.class,
                class_5375.class,
                class_7745.class,
                class_4189.class,
                class_7065.class,
                class_8086.class,
                class_442.class,
                ShaderpackScreen.class
        );

        if (JSONFileEditor.getValueFromJson("./koil/sys/config.json", "uiRedesign").getAsBoolean()) {
            customBackgroundScreens.addAll(uiScreens);
        } else {
            customBackgroundScreens.removeAll(uiScreens);
        }

        customBackgroundScreens.addAll(Arrays.asList(
                KoilMenuScreen.class,
                UpdateScreen.class,
                ModMenuScreen.class,
                ResourcePackMenuScreen.class,
                ShaderPackMenuScreen.class,
                FileEditorScreen.class,
                FileExplorerScreen.class,
                ModConfigScreen.class,
                class_350.class
        ));

        Class<?> currentScreenClass = client.field_1755.getClass();

        koil$setOptionsBackgroundBlank(customBackgroundScreens.contains(currentScreenClass)
                || koil$shouldUseSharedScreenBackground(client.field_1755));
    }

    @Inject(method = "renderBackground", at = @At("HEAD"), cancellable = true)
    private void koil$renderSharedMinecraftBackground(class_332 context, CallbackInfo ci) {
        if (client == null || client.field_1755 == null) {
            return;
        }
        if (client.field_1687 != null && koil$isUiRedesignEnabled() && koil$shouldSuppressInWorldVanillaBackground(client.field_1755)) {
            ci.cancel();
            return;
        }
        if (client.field_1755 instanceof class_445 && koil$isUiRedesignEnabled()) {
            int screenWidth = koil$screenWidth();
            int screenHeight = koil$screenHeight();
            koil$setOptionsBackgroundBlank(true);
            KoilScreenBackgrounds.render(context, client, screenWidth, screenHeight);
            if (KoilScreenBackgrounds.canRender(client)) {
                context.method_25294(0, 0, screenWidth, screenHeight, KoilScreenBackgrounds.overlayColor(client));
            }
            KoilVanillaScreenChrome.renderCreditsTextPanel(context, screenWidth, screenHeight);
            ci.cancel();
            return;
        }
        if (client.field_1755 instanceof class_433 && koil$isUiRedesignEnabled()) {
            int screenWidth = koil$screenWidth();
            int screenHeight = koil$screenHeight();
            koil$setOptionsBackgroundBlank(true);
            KoilVanillaScreenChrome.renderOptionsShell(context, client, screenWidth, screenHeight);
            ci.cancel();
            return;
        }
        if (client.field_1755 instanceof class_447 && koil$isUiRedesignEnabled()) {
            int screenWidth = koil$screenWidth();
            int screenHeight = koil$screenHeight();
            koil$setOptionsBackgroundBlank(true);
            KoilVanillaScreenChrome.renderListShell(context, client, screenWidth, screenHeight, KoilVanillaScreenChrome.listTop(false), KoilVanillaScreenChrome.listBottom(screenHeight));
            ci.cancel();
            return;
        }
        if (!koil$shouldUseSharedScreenBackground(client.field_1755)) {
            return;
        }
        int screenWidth = koil$screenWidth();
        int screenHeight = koil$screenHeight();
        koil$setOptionsBackgroundBlank(true);
        KoilVanillaScreenChrome.renderOptionsShell(context, client, screenWidth, screenHeight);
        ci.cancel();
    }

    @Override
    public List<? extends class_364> method_25396() {
        return this.children;
    }

    @Unique
    private boolean koil$shouldShowToolsButton() {
        if (client != null && koil$isPassiveTransitionScreen(client.field_1755)) {
            return false;
        }
        return koil$resolvedTools() != null;
    }

    @Unique
    private boolean koil$showsMachineGeneratedBadge() {
        if (client == null || client.field_1755 == null) {
            return false;
        }
        class_437 screen = client.field_1755;
        return screen instanceof FileEditorScreen
                || screen instanceof ModConfigScreen
                || screen instanceof class_447;
    }

    @Unique
    private int koil$topBarButtonY() {
        return koil$isKoilChromeScreen() ? 20 : KOIL_TOP_BAR_TOP_MARGIN + 3;
    }

    @Unique
    private int koil$topBarButtonLeftShift() {
        return koil$isKoilChromeScreen() ? KOIL_TOP_BAR_KOIL_SCREEN_LEFT_SHIFT : 0;
    }

    @Unique
    private boolean koil$isKoilChromeScreen() {
        if (client == null || client.field_1755 == null) {
            return false;
        }
        class_437 screen = client.field_1755;
        return screen instanceof ModMenuScreen
                || screen instanceof FileExplorerScreen
                || screen instanceof FileEditorScreen
                || screen instanceof ModConfigScreen
                || screen instanceof KoilMenuScreen
                || screen instanceof UpdateScreen
                || screen instanceof PerformanceOptimizerScreen
                || screen instanceof ResourcePackMenuScreen
                || screen instanceof ShaderPackMenuScreen
                || screen instanceof ShaderpackScreen
                || screen instanceof ModScreen
                || screen instanceof ResourcepackScreen
                || screen instanceof DatapackScreen;
    }

    @Unique
    private void koil$drawTopBarButton(class_332 context, int x, int y, boolean hovered, String label) {
        context.method_25294(x, y, x + KOIL_TOP_BAR_BUTTON_SIZE, y + KOIL_TOP_BAR_BUTTON_SIZE, hovered ? 0x824D5563 : 0x302A303A);
        context.method_49601(x, y, KOIL_TOP_BAR_BUTTON_SIZE, KOIL_TOP_BAR_BUTTON_SIZE, hovered ? 0x9A9AA5B7 : 0x306B7485);
        int textWidth = client.field_1772.method_1727(label);
        int textX = x + (KOIL_TOP_BAR_BUTTON_SIZE - textWidth) / 2;
        int textY = y + 3;
        context.method_51433(client.field_1772, label, textX, textY, hovered ? 0xC8F5F7FA : 0x52F5F7FA, false);
    }

    @Unique
    private void koil$drawInfoIcon(class_332 context, int x, int y, boolean hovered) {
        context.method_25294(x, y, x + KOIL_TOP_BAR_BUTTON_SIZE, y + KOIL_TOP_BAR_BUTTON_SIZE, hovered ? 0x824D5563 : 0x282A303A);
        context.method_49601(x, y, KOIL_TOP_BAR_BUTTON_SIZE, KOIL_TOP_BAR_BUTTON_SIZE, hovered ? 0x9AB8C2D4 : 0x286B7485);
        context.method_51433(client.field_1772, "?", x + 5, y + 3, hovered ? 0xC8FFFFFF : 0x48F5F7FA, false);
    }

    @Unique
    private boolean koil$isUiRedesignEnabled() {
        try {
            JsonElement element = JSONFileEditor.getValueFromJson("./koil/sys/config.json", "uiRedesign");
            return element != null && element.isJsonPrimitive() && element.getAsBoolean();
        } catch (Exception ignored) {
            return false;
        }
    }

    @Unique
    private boolean koil$isMinecraftOrRealmsScreen(class_437 screen) {
        String name = screen.getClass().getName();
        return name.startsWith("net.minecraft.client.gui.screen.")
                || name.startsWith("net.minecraft.client.realms.")
                || name.startsWith("com.mojang.realmsclient.");
    }

    @Unique
    private boolean koil$shouldUseSharedScreenBackground(class_437 screen) {
        if (screen == null || client == null || !koil$isUiRedesignEnabled()) {
            return false;
        }
        if (screen instanceof class_442 || koil$isPassiveTransitionScreen(screen)) {
            return false;
        }
        if (screen instanceof class_433) {
            return true;
        }
        if (client.field_1687 != null) {
            return screen instanceof class_5375;
        }
        if (screen instanceof class_500 || screen instanceof class_422 || screen instanceof class_420) {
            return false;
        }
        return true;
    }

    private boolean koil$shouldSuppressInWorldVanillaBackground(class_437 screen) {
        return screen instanceof class_426
                || screen instanceof class_443
                || screen instanceof class_404
                || screen instanceof class_4189
                || screen instanceof class_5500
                || screen instanceof class_4667
                || screen instanceof class_429
                || screen instanceof class_458
                || screen instanceof class_6599
                || screen instanceof class_7944
                || screen instanceof class_7065;
    }

    @Unique
    private boolean koil$isPassiveTransitionScreen(class_437 screen) {
        return screen instanceof class_3928
                || screen instanceof class_434
                || screen instanceof class_412
                || screen instanceof class_435;
    }

    @Unique
    private boolean koil$isDesignMusicEnabled() {
        try {
            JsonElement element = JSONFileEditor.getValueFromJson("./koil/sys/config.json", "designMusic");
            return element != null && element.isJsonPrimitive() && element.getAsBoolean();
        } catch (Exception ignored) {
            return false;
        }
    }

    @Unique
    private void koil$setOptionsBackgroundBlank(boolean blank) {
        OPTIONS_BACKGROUND_TEXTURE = blank
                ? loadExternalPngTexture(uiImageDirectory, "options_background_blank.png")
                : new class_2960("textures/gui/options_background.png");
    }

    @Unique
    private boolean koil$isInside(double mouseX, double mouseY, int x, int y, int width, int height) {
        return mouseX >= x && mouseX <= x + width && mouseY >= y && mouseY <= y + height;
    }

    @Unique
    private int koil$screenWidth() {
        if (client != null && client.field_1755 != null && client.field_1755.field_22789 > 0) {
            return client.field_1755.field_22789;
        }
        if (client != null && client.method_22683() != null) {
            return Math.max(1, client.method_22683().method_4486());
        }
        return Math.max(1, width);
    }

    @Unique
    private int koil$screenHeight() {
        if (client != null && client.field_1755 != null && client.field_1755.field_22790 > 0) {
            return client.field_1755.field_22790;
        }
        if (client != null && client.method_22683() != null) {
            return Math.max(1, client.method_22683().method_4502());
        }
        return Math.max(1, height);
    }

    @Unique
    private static int KOIL_TOP_BAR_BUTTON_RIGHT_SAFE_SIZE() {
        return KOIL_TOP_BAR_BUTTON_SIZE + KOIL_TOP_BAR_RIGHT_MARGIN;
    }

    @Unique
    private VanillaScreenToolResolver.ResolvedScreenTools koil$resolvedTools() {
        return VanillaScreenToolResolver.resolve((class_437) (Object) this);
    }

    @Unique
    private void koil$handleToolAction(String actionId, VanillaScreenToolResolver.ResolvedScreenTools tools, double mouseX, double mouseY) {
        if (tools.actionHandler() != null) {
            tools.actionHandler().handle(actionId, tools, mouseX, mouseY, koil$screenWidth(), koil$screenHeight(), koil$screenInfoPopup);
        }
    }
}
