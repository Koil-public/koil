package com.spirit.mixin.client.gui.revamp.option;

import com.spirit.koil.api.design.KoilVanillaScreenChrome;
import com.spirit.koil.api.util.file.json.JSONFileEditor;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_353;
import net.minecraft.class_437;
import net.minecraft.class_4667;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Overwrite;

import java.awt.*;

import static com.spirit.koil.api.design.uiColorVal.*;

@Environment(EnvType.CLIENT)
@Mixin(class_4667.class)
public class MixinGameOptionsScreen extends class_437 {

    protected MixinGameOptionsScreen(class_2561 title) {
        super(title);
    }

    /**
     * @author SpiritXIV
     * @reason to make it look better
     */
    @Overwrite
    protected void render(class_332 context, class_353 optionButtons, int mouseX, int mouseY, float tickDelta) {
        if (JSONFileEditor.getValueFromJson("./koil/sys/config.json", "uiRedesign").getAsBoolean()) {
            class_310 client = class_310.method_1551();
            KoilVanillaScreenChrome.renderOptionsShell(context, client, this.field_22789, this.field_22790);


            context.method_51448().method_22903();
            context.method_51448().method_22905(1.5F, 1.5F, 1.0F);
            context.method_51439(this.field_22793, class_2561.method_43470("Options"), 25, 3, new Color(uiColorHeaderTitleText, true).getRGB(), true);
            context.method_51448().method_22909();
            context.method_51439(this.field_22793, this.field_22785, 37, 18, new Color(uiColorHeaderSubTitleText, true).getRGB(), true);
            optionButtons.method_25394(context, mouseX, mouseY, tickDelta);

            super.method_25394(context, mouseX, mouseY, tickDelta);
        } else {
            this.method_25420(context);
            optionButtons.method_25394(context, mouseX, mouseY, tickDelta);
            context.method_27534(this.field_22793, this.field_22785, this.field_22789 / 2, 20, 16777215);
            super.method_25394(context, mouseX, mouseY, tickDelta);
        }
    }
}
