package com.spirit.mixin.client.gui.revamp.accessor;

import net.minecraft.class_34;
import net.minecraft.class_528;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_528.class_4272.class)
public interface WorldListWidgetWorldEntryAccessor {
    @Accessor("level")
    class_34 koil$getLevel();
}
