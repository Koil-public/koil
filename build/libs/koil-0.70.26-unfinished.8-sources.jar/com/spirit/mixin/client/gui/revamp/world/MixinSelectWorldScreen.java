package com.spirit.mixin.client.gui.revamp.world;

import com.spirit.client.gui.BrowserLayoutHelper;
import com.spirit.client.gui.FolderOpenHelper;
import com.spirit.client.gui.PopupMenu;
import com.spirit.client.gui.world.DiscoveredWorldListWidget;
import com.spirit.koil.api.design.DesignLoader;
import com.spirit.koil.api.world.LocalWorldDiscovery;
import com.spirit.koil.api.util.file.image.ExternalImageLoader;
import com.spirit.koil.api.util.file.json.JSONFileEditor;
import com.spirit.mixin.client.gui.revamp.accessor.WorldListWidgetWorldEntryAccessor;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_124;
import net.minecraft.class_156;
import net.minecraft.class_1940;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_3283;
import net.minecraft.class_3286;
import net.minecraft.class_332;
import net.minecraft.class_34;
import net.minecraft.class_342;
import net.minecraft.class_410;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_5244;
import net.minecraft.class_525;
import net.minecraft.class_526;
import net.minecraft.class_528;
import net.minecraft.class_5315;
import net.minecraft.class_5375;
import net.minecraft.class_7712;
import net.minecraft.class_7919;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Overwrite;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.awt.*;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Optional;

import static com.spirit.Main.uiImageDirectory;
import static com.spirit.koil.api.design.uiColorVal.*;

@Environment(EnvType.CLIENT)
@Mixin(class_526.class)
public abstract class MixinSelectWorldScreen extends class_437 {
    private static final int KOIL_WORLD_LIST_WIDTH = BrowserLayoutHelper.LIST_INNER_RIGHT - BrowserLayoutHelper.LIST_INNER_LEFT - 16;
    private static final int KOIL_DISCOVERED_WORLD_LIST_WIDTH = KOIL_WORLD_LIST_WIDTH + 12;
    private static final int KOIL_WORLD_LIST_LEFT = BrowserLayoutHelper.LIST_INNER_LEFT;
    private static final int KOIL_WORLD_LIST_TOP = 39;
    private static final int KOIL_WORLD_LIST_BOTTOM_PADDING = 57;
    private static final int KOIL_WORLD_LIST_ENTRY_HEIGHT = 36;
    private static final class_2960 KOIL_FALLBACK_WORLD_ICON = ExternalImageLoader.loadExternalPngTextureWithColorVariant(uiImageDirectory, "image.png");

    @Shadow protected class_342 searchBox;
    @Shadow private class_528 levelList;
    @Shadow private class_4185 selectButton;
    @Shadow private class_4185 editButton;
    @Shadow private class_4185 deleteButton;
    @Shadow private class_4185 recreateButton;
    private class_4185 openIPButton;
    private class_4185 copyIPButton;
    private class_4185 ipButton;
    private class_4185 inDevButton;
    private class_4185 findWorldsButton;
    private final PopupMenu folderOpenPopup = new PopupMenu();
    private File pendingFolderOpenDirectory;
    private int lastMouseX;
    private int lastMouseY;
    @Shadow @Final protected class_437 parent;
    private class_528.class_4272 selectedWorld;
    private int previewScrollOffset;
    private int previewScrollMax;
    private int previewViewportX = -1;
    private int previewViewportY = -1;
    private int previewViewportWidth;
    private int previewViewportHeight;
    private boolean previewScrollbarDragging;
    private int previewScrollbarDragOffset;
    private String previewSelectionKey;
    private boolean localWorldDiscoveryMode;
    private boolean localWorldShowIncompatible;
    private boolean localWorldDiscoveryLoading;
    private List<LocalWorldDiscovery.DiscoveredWorld> discoveredWorlds = List.of();
    private LocalWorldDiscovery.DiscoveredWorld selectedDiscoveredWorld;
    private DiscoveredWorldListWidget discoveredWorldListWidget;
    private int compatibilityFilterX = -1;
    private int compatibilityFilterWidth = 0;
    private int discoveredViewportX = -1;
    private int discoveredViewportY = -1;
    private int discoveredViewportWidth;
    private int discoveredViewportHeight;

    protected MixinSelectWorldScreen(class_2561 title) {
        super(title);
    }

    @Override
    public void method_25434(class_332 context) {
        context.method_51422(0.25F, 0.25F, 0.25F, 0F);
        context.method_25291(field_44669, 0, 0, 0, 0.0F, 0.0F, this.field_22789, this.field_22790, 32, 32);
        context.method_51422(1.0F, 1.0F, 1.0F, 0F);
    }

    /**
     * @author SpiritXIV
     * @reason button fix
     */
    @Overwrite
    public void worldSelected(boolean buttonsActive, boolean deleteButtonActive) {
        if (this.localWorldDiscoveryMode) {
            boolean discoveredSelected = this.selectedDiscoveredWorld != null;
            this.selectButton.field_22763 = discoveredSelected;
            this.editButton.field_22763 = false;
            this.recreateButton.field_22763 = false;
            this.deleteButton.field_22763 = false;
            if (this.copyIPButton != null) {
                this.copyIPButton.field_22763 = discoveredSelected;
            }
            if (this.openIPButton != null) {
                this.openIPButton.field_22763 = false;
            }
            if (this.ipButton != null) {
                this.ipButton.field_22763 = true;
            }
            if (this.inDevButton != null) {
                this.inDevButton.field_22763 = false;
            }
            return;
        }
        this.selectButton.field_22763 = buttonsActive;
        this.editButton.field_22763 = buttonsActive;
        this.recreateButton.field_22763 = buttonsActive;
        this.deleteButton.field_22763 = deleteButtonActive;
        syncSelectedWorldFromList();
        if (JSONFileEditor.getValueFromJson("./koil/sys/config.json", "uiRedesign").getAsBoolean()) {
            this.openIPButton.field_22763 = buttonsActive;
            this.copyIPButton.field_22763 = buttonsActive;
            this.ipButton.field_22763 = false;
            this.inDevButton.field_22763 = false;
        } else {
            if (this.openIPButton != null) {
                this.openIPButton.field_22763 = buttonsActive;
            }
            if (this.copyIPButton != null) {
                this.copyIPButton.field_22763 = buttonsActive;
            }
            if (this.ipButton != null) {
                this.ipButton.field_22763 = false;
            }
            if (this.inDevButton != null) {
                this.inDevButton.field_22763 = false;
            }
        }
    }

    /**
     * @author SpiritXIV
     * @reason WE BE BALLING
     */
    @Overwrite
    protected void method_25426() {
        if (JSONFileEditor.getValueFromJson("./koil/sys/config.json", "uiRedesign").getAsBoolean()) {
            int x = 37;
            this.searchBox = new class_342(this.field_22793, field_22789 - 210, 10, 200, 20, this.searchBox, class_2561.method_43471("selectWorld.search"));
            this.searchBox.method_47404(class_2561.method_43470("Search Worlds"));
            this.searchBox.method_1863((search) -> {
                if (this.localWorldDiscoveryMode) {
                    syncSelectedDiscoveredWorld();
                    updateDiscoveredWorldList();
                } else {
                    this.levelList.method_44677(search);
                }
            });
            this.levelList = new class_528((class_526) (Object) this, this.field_22787, KOIL_WORLD_LIST_WIDTH, this.field_22790, KOIL_WORLD_LIST_TOP, this.field_22790 - KOIL_WORLD_LIST_BOTTOM_PADDING, KOIL_WORLD_LIST_ENTRY_HEIGHT, this.searchBox.method_1882(), this.levelList);
            this.levelList.method_25333(KOIL_WORLD_LIST_LEFT);
            this.discoveredWorldListWidget = new DiscoveredWorldListWidget(this.field_22787, KOIL_DISCOVERED_WORLD_LIST_WIDTH, this.field_22790, KOIL_WORLD_LIST_TOP, this.field_22790 - KOIL_WORLD_LIST_BOTTOM_PADDING, KOIL_WORLD_LIST_ENTRY_HEIGHT, this::resolveDiscoveredIcon, () -> this.selectedDiscoveredWorld, this::selectDiscoveredWorld);
            this.discoveredWorldListWidget.method_25333(KOIL_WORLD_LIST_LEFT);
            this.method_25429(this.searchBox);
            this.method_25429(this.levelList);
            this.method_25429(this.discoveredWorldListWidget);
            this.selectButton = this.method_37063(class_4185.method_46430(class_2561.method_43471("selectWorld.select"), (button) -> {
                if (this.localWorldDiscoveryMode) {
                    openSelectedDiscoveredWorld();
                } else {
                    this.levelList.method_20159().ifPresent(class_528.class_4272::method_20164);
                }
            }).method_46434(x, this.field_22790 - 52, 150, 20).method_46431());
            this.method_37063(class_4185.method_46430(class_2561.method_43471("selectWorld.create"), (button) -> {
                assert this.field_22787 != null;
                class_525.method_31130(this.field_22787, this);
            }).method_46434(x + 158, this.field_22790 - 52, 150, 20).method_46431());
            this.editButton = this.method_37063(class_4185.method_46430(class_2561.method_43471("selectWorld.edit"), (button) -> this.levelList.method_20159().ifPresent(class_528.class_4272::method_20171)).method_46434(x, this.field_22790 - 28, 74, 20).method_46431());

            this.deleteButton = this.method_37063(class_4185.method_46430(class_2561.method_43471("selectWorld.delete"), (button) -> this.levelList.method_20159().ifPresent(class_528.class_4272::method_20169)).method_46434(x + 78, this.field_22790 - 28, 72, 20).method_46436(class_7919.method_47407(class_2561.method_43470("[!] This cannot be undone!").method_27692(class_124.field_1061))).method_46431());
            this.recreateButton = this.method_37063(class_4185.method_46430(class_2561.method_43471("selectWorld.recreate"), (button) -> this.levelList.method_20159().ifPresent(class_528.class_4272::method_20173)).method_46434(x + 158, this.field_22790 - 28, 73, 20).method_46431());
            this.method_37063(class_4185.method_46430(class_5244.field_24335, (button) -> {
                assert this.field_22787 != null;
                this.field_22787.method_1507(this.parent);
            }).method_46434(x + 235, this.field_22790 - 28, 73, 20).method_46431());
            this.copyIPButton = this.method_37063(class_4185.method_46430(class_2561.method_30163("Open Folder"), (button) -> {
                if (this.localWorldDiscoveryMode) {
                    openSelectedDiscoveredFolder();
                } else {
                    openSelectedWorldFolder();
                }
            }).method_46434(x + 316, this.field_22790 - 52, 74, 20).method_46431());
            this.openIPButton = this.method_37063(class_4185.method_46430(class_2561.method_43470("Datapacks"), (button) -> openVanillaDatapackScreen()).method_46434(x + 316, this.field_22790 - 28, 74, 20).method_46431());
            this.findWorldsButton = this.method_37063(class_4185.method_46430(class_2561.method_30163("Find Worlds"), (button) -> toggleLocalWorldDiscovery()).method_46434(x + 394, this.field_22790 - 52, 120, 20).method_46431());
            this.inDevButton = this.method_37063(class_4185.method_46430(class_2561.method_30163("Indev"), (button) -> {}).method_46434(x + 394, this.field_22790 - 28, 120, 20).method_46431());
            this.inDevButton.field_22763 = false;
            this.ipButton = this.method_37063(class_4185.method_46430(class_2561.method_30163("Compatible Only"), (button) -> toggleLocalWorldFilter()).method_46434(this.field_22789 - 332, 10, 116, 20).method_46431());
            selectFirstWorldEntry();
            this.worldSelected(false, false);
            this.method_48265(this.searchBox);
        } else {
            this.searchBox = new class_342(this.field_22793, this.field_22789 / 2 - 100, 22, 200, 20, this.searchBox, class_2561.method_43471("selectWorld.search"));
            this.searchBox.method_47404(class_2561.method_43470("Search Worlds"));
            this.searchBox.method_1863((search) -> this.levelList.method_44677(search));
            this.levelList = new class_528((class_526) (Object) this, this.field_22787, this.field_22789, this.field_22790, 48, this.field_22790 - 64, 36, this.searchBox.method_1882(), this.levelList);
            this.method_25429(this.searchBox);
            this.method_25429(this.levelList);
            this.selectButton = this.method_37063(class_4185.method_46430(class_2561.method_43471("selectWorld.select"), (button) -> this.levelList.method_20159().ifPresent(class_528.class_4272::method_20164)).method_46434(this.field_22789 / 2 - 154, this.field_22790 - 52, 150, 20).method_46431());
            this.method_37063(class_4185.method_46430(class_2561.method_43471("selectWorld.create"), (button) -> class_525.method_31130(this.field_22787, this)).method_46434(this.field_22789 / 2 + 4, this.field_22790 - 52, 150, 20).method_46431());
            this.editButton = this.method_37063(class_4185.method_46430(class_2561.method_43471("selectWorld.edit"), (button) -> this.levelList.method_20159().ifPresent(class_528.class_4272::method_20171)).method_46434(this.field_22789 / 2 - 154, this.field_22790 - 28, 72, 20).method_46431());
            this.deleteButton = this.method_37063(class_4185.method_46430(class_2561.method_43471("selectWorld.delete"), (button) -> this.levelList.method_20159().ifPresent(class_528.class_4272::method_20169)).method_46434(this.field_22789 / 2 - 76, this.field_22790 - 28, 72, 20).method_46431());
            this.recreateButton = this.method_37063(class_4185.method_46430(class_2561.method_43471("selectWorld.recreate"), (button) -> this.levelList.method_20159().ifPresent(class_528.class_4272::method_20173)).method_46434(this.field_22789 / 2 + 4, this.field_22790 - 28, 72, 20).method_46431());
            this.method_37063(class_4185.method_46430(class_5244.field_24335, (button) -> this.field_22787.method_1507(this.parent)).method_46434(this.field_22789 / 2 + 82, this.field_22790 - 28, 72, 20).method_46431());
            int rightToolX = Math.min(this.field_22789 - 78, this.field_22789 / 2 + 160);
            this.copyIPButton = this.method_37063(class_4185.method_46430(class_2561.method_30163("Open Folder"), (button) -> openSelectedWorldFolder()).method_46434(rightToolX, this.field_22790 - 52, 74, 20).method_46431());
            this.openIPButton = this.method_37063(class_4185.method_46430(class_2561.method_43470("Datapacks"), (button) -> {
                openVanillaDatapackScreen();
            }).method_46434(rightToolX, this.field_22790 - 28, 74, 20).method_46431());
            this.findWorldsButton = this.method_37063(class_4185.method_46430(class_2561.method_30163(""), (button) -> {}).method_46434(-1000, -1000, 1, 20).method_46431());
            this.ipButton = this.method_37063(class_4185.method_46430(class_2561.method_30163(""), (button) -> {}).method_46434(-1000, -1000, 1, 20).method_46431());
            this.inDevButton = this.method_37063(class_4185.method_46430(class_2561.method_30163(""), (button) -> {}).method_46434(-1000, -1000, 1, 20).method_46431());
            this.worldSelected(false, false);
            this.method_48265(this.searchBox);
        }
    }
    
    @Inject(method = "render", at = @At(value = "HEAD"), cancellable = true)
    private void onRender(class_332 context, int mouseX, int mouseY, float delta, CallbackInfo ci) {
        if (JSONFileEditor.getValueFromJson("./koil/sys/config.json", "uiRedesign").getAsBoolean()) {
            this.lastMouseX = mouseX;
            this.lastMouseY = mouseY;
            class_310 client = class_310.method_1551();
            context.method_25293(DesignLoader.getLoadingTexture(), 0, 0, client.method_22683().method_4486(), client.method_22683().method_4502(), 0.0F, 0.0F, 319, 192, 319, 192);

            context.method_25294(0, 0, field_22789, 43, new Color(uiColorHeader, true).getRGB());
            context.method_25294(0, 39, field_22789, 42, new Color(uiColorHeaderStripe, true).getRGB());
            context.method_25294(0, field_22790 - 60, field_22789, field_22790, new Color(uiColorFooter, true).getRGB());
            context.method_25294(0, this.field_22790 - 60, field_22789, this.field_22790 - 57, new Color(uiColorFooterStripe, true).getRGB());
            context.method_25294(35, 39, 350, this.field_22790 - 60, new Color(uiColorContentBase, true).getRGB());
            context.method_25294(37, 39, 39, this.field_22790 - 60, new Color(uiColorContentStripeLeft, true).getRGB());
            context.method_25294(346, 39, 348, this.field_22790 - 60, new Color(uiColorContentStripeRight, true).getRGB());
            context.method_25294(0, 0, field_22789, field_22790, new Color(uiColorBackgroundOverlay, true).getRGB());

            if (this.ipButton != null) {
                this.ipButton.field_22764 = false;
                this.ipButton.field_22763 = false;
            }
            if (this.findWorldsButton != null) {
                this.findWorldsButton.method_25355(class_2561.method_43470(this.localWorldDiscoveryMode ? "Saved Worlds" : "Find Worlds"));
            }

            Optional<class_528.class_4272> selectedWorldOptional = this.localWorldDiscoveryMode ? Optional.empty() : this.levelList.method_20159();
            if (this.localWorldDiscoveryMode) {
                syncSelectedDiscoveredWorld();
                renderDiscoveredWorldList(context, mouseX, mouseY);
                renderSelectedDiscoveredWorldInfo(context);
                this.worldSelected(false, false);
            } else if (selectedWorldOptional.isPresent()) {
                this.selectedWorld = selectedWorldOptional.get();
                this.copyIPButton.field_22763 = true;
                this.openIPButton.field_22763 = true;
                this.ipButton.field_22763 = false;
                this.inDevButton.field_22763 = false;
                syncPreviewSelection();
                renderSelectedWorldInfo(context);
            } else {
                this.selectedWorld = null;
                this.previewSelectionKey = null;
                this.previewScrollOffset = 0;
                this.previewScrollMax = 0;
                this.copyIPButton.field_22763 = false;
                this.openIPButton.field_22763 = false;
                this.ipButton.field_22763 = false;
                this.inDevButton.field_22763 = false;
            }

            if (!this.localWorldDiscoveryMode) {
                this.levelList.method_25394(context, mouseX, mouseY, delta);
            }
            this.searchBox.method_25394(context, mouseX, mouseY, delta);
            renderCompatibilityFilterButton(context);
            context.method_51448().method_22903();
            context.method_51448().method_22905(1.5F, 1.5F, 1.0F);
            context.method_51439(this.field_22793, class_2561.method_43471("menu.singleplayer"), 25, 6, new Color(uiColorHeaderTitleText, true).getRGB(), true);
            context.method_51448().method_22909();
            context.method_51439(this.field_22793, this.field_22785, 37, 23, new Color(uiColorHeaderSubTitleText, true).getRGB(), true);

            super.method_25394(context, mouseX, mouseY, delta);
            this.folderOpenPopup.render(context, mouseX, mouseY);
            ci.cancel();
        } else {
            this.levelList.method_25394(context, mouseX, mouseY, delta);
            this.searchBox.method_25394(context, mouseX, mouseY, delta);
            context.method_27534(this.field_22793, this.field_22785, this.field_22789 / 2, 8, 16777215);
            super.method_25394(context, mouseX, mouseY, delta);
            this.folderOpenPopup.render(context, mouseX, mouseY);
        }
    }

    @SuppressWarnings("unused")
    @Inject(method = "render", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/DrawContext;drawCenteredTextWithShadow(Lnet/minecraft/client/font/TextRenderer;Lnet/minecraft/text/Text;III)V"), cancellable = true)
    private void onDrawCenteredText(class_332 context, int mouseX, int mouseY, float delta, CallbackInfo ci) {
        if (JSONFileEditor.getValueFromJson("./koil/sys/config.json", "uiRedesign").getAsBoolean()) {
            this.levelList.method_25394(context, mouseX, mouseY, delta);
            this.searchBox.method_25394(context, mouseX, mouseY, delta);
            context.method_51448().method_22903();
            context.method_51448().method_22905(1.5F, 1.5F, 1.0F);
            context.method_51439(this.field_22793, class_2561.method_43471("menu.singleplayer"), 25, 6, new Color(uiColorHeaderTitleText, true).getRGB(), true);
            context.method_51448().method_22909();
            context.method_51439(this.field_22793, this.field_22785, 37, 23, new Color(uiColorHeaderSubTitleText, true).getRGB(), true);

            super.method_25394(context, mouseX, mouseY, delta);
            this.folderOpenPopup.render(context, mouseX, mouseY);
            ci.cancel();
        }
    }

    private void renderSelectedWorldInfo(class_332 context) {
        class_34 level = getSelectedLevel();
        if (level == null) {
            return;
        }
        int panelX = BrowserLayoutHelper.previewX(this.field_22789);
        int panelY = BrowserLayoutHelper.previewY();
        int panelWidth = BrowserLayoutHelper.previewWidth(this.field_22789);
        int panelHeight = BrowserLayoutHelper.previewHeight(this.field_22790);
        BrowserLayoutHelper.renderPreviewPanelFrame(context, panelX, panelY, panelWidth, panelHeight);

        class_2960 icon = resolveWorldIcon(level);
        if (icon != null) {
            context.method_25290(icon, panelX + 10, panelY + 10, 0, 0, 64, 64, 64, 64);
        }
        int titleX = panelX + 84;
        context.method_51448().method_22903();
        context.method_51448().method_22905(1.5F, 1.5F, 1.0F);
        context.method_51433(this.field_22793, trimPreview(level.method_252().isBlank() ? level.method_248() : level.method_252(), 170), (int) (titleX / 1.5F), (int) ((panelY + 10) / 1.5F), new Color(uiColorContentBaseTitleText, true).getRGB(), true);
        context.method_51448().method_22909();
        context.method_51433(this.field_22793, level.method_248(), titleX, panelY + 34, 0xFFD8DFE9, false);
        String detailText = level.method_27429().getString();
        if (!detailText.isBlank()) {
            context.method_51433(this.field_22793, trimPreview(detailText, panelWidth - 96), titleX, panelY + 48, 0xFFE9DFC9, false);
        }

        int detailsViewportY = panelY + 86;
        int detailsViewportHeight = Math.max(70, panelHeight - (detailsViewportY - panelY) - 8);
        this.previewViewportX = panelX + 8;
        this.previewViewportY = detailsViewportY;
        this.previewViewportWidth = panelWidth - 16;
        this.previewViewportHeight = detailsViewportHeight;
        context.method_44379(this.previewViewportX, this.previewViewportY, this.previewViewportX + this.previewViewportWidth, this.previewViewportY + this.previewViewportHeight);

        int infoY = detailsViewportY - this.previewScrollOffset;
        int contentHeight = 0;
        BrowserLayoutHelper.renderSectionRule(context, this.field_22793, panelX + 10, panelX + panelWidth - 10, infoY, "Identity");
        infoY += 16;
        contentHeight += 16;
        int nextY = BrowserLayoutHelper.renderInfoLine(context, this.field_22793, panelX + 12, infoY, panelWidth, "Folder", level.method_248(), 0xFFDCE4EE);
        contentHeight += nextY - infoY;
        infoY = nextY;
        nextY = BrowserLayoutHelper.renderInfoLine(context, this.field_22793, panelX + 12, infoY, panelWidth, "Path", describeWorldPath(), 0xFFD8E7DE);
        contentHeight += nextY - infoY;
        infoY = nextY;
        nextY = BrowserLayoutHelper.renderInfoLine(context, this.field_22793, panelX + 12, infoY, panelWidth, "Last Played", formatTimestamp(level.method_249()), 0xFFD9D5E8);
        contentHeight += nextY - infoY;
        infoY = nextY;
        nextY = BrowserLayoutHelper.renderInfoLine(context, this.field_22793, panelX + 12, infoY, panelWidth, "Icon", describeWorldIcon(level), 0xFFD6E5DA);
        contentHeight += nextY - infoY;
        infoY = nextY;
        nextY = BrowserLayoutHelper.renderInfoLine(context, this.field_22793, panelX + 12, infoY, panelWidth, "Summary", detailText.isBlank() ? "No summary" : detailText, 0xFFD8DFE9);
        contentHeight += nextY - infoY;
        infoY = nextY;

        BrowserLayoutHelper.renderSectionRule(context, this.field_22793, panelX + 10, panelX + panelWidth - 10, infoY, "Gameplay");
        infoY += 16;
        contentHeight += 16;
        class_1940 levelInfo = level.method_35505();
        nextY = BrowserLayoutHelper.renderInfoLine(context, this.field_22793, panelX + 12, infoY, panelWidth, "Mode", level.method_247().method_8383().getString(), 0xFFDCE4EE);
        contentHeight += nextY - infoY;
        infoY = nextY;
        nextY = BrowserLayoutHelper.renderInfoLine(context, this.field_22793, panelX + 12, infoY, panelWidth, "Difficulty", levelInfo == null ? "Unknown" : levelInfo.method_27340().method_5463().getString(), 0xFFD8E7DE);
        contentHeight += nextY - infoY;
        infoY = nextY;
        nextY = BrowserLayoutHelper.renderInfoLine(context, this.field_22793, panelX + 12, infoY, panelWidth, "Commands", levelInfo != null && levelInfo.method_8582() ? "Allowed" : "Off", 0xFFD9D5E8);
        contentHeight += nextY - infoY;
        infoY = nextY;
        nextY = BrowserLayoutHelper.renderInfoLine(context, this.field_22793, panelX + 12, infoY, panelWidth, "Flags", buildWorldFlags(level), 0xFFD6E5DA);
        contentHeight += nextY - infoY;
        infoY = nextY;
        nextY = BrowserLayoutHelper.renderInfoLine(context, this.field_22793, panelX + 12, infoY, panelWidth, "Features", levelInfo == null ? "Unknown" : String.valueOf(levelInfo.method_29558()), 0xFFD8DFE9);
        contentHeight += nextY - infoY;
        infoY = nextY;

        BrowserLayoutHelper.renderSectionRule(context, this.field_22793, panelX + 10, panelX + panelWidth - 10, infoY, "Developer Details");
        infoY += 16;
        contentHeight += 16;
        class_5315 versionInfo = level.method_29586();
        nextY = BrowserLayoutHelper.renderInfoLine(context, this.field_22793, panelX + 12, infoY, panelWidth, "Version", level.method_258().getString(), 0xFFDCE4EE);
        contentHeight += nextY - infoY;
        infoY = nextY;
        nextY = BrowserLayoutHelper.renderInfoLine(context, this.field_22793, panelX + 12, infoY, panelWidth, "Save Info", versionInfo == null ? "Unknown" : versionInfo.method_29025() + "  |  format " + versionInfo.method_29022(), 0xFFD8E7DE);
        contentHeight += nextY - infoY;
        infoY = nextY;
        nextY = BrowserLayoutHelper.renderInfoLine(context, this.field_22793, panelX + 12, infoY, panelWidth, "Storage", buildWorldStorageFlags(level, versionInfo), 0xFFD9D5E8);
        contentHeight += nextY - infoY;
        infoY = nextY;
        nextY = BrowserLayoutHelper.renderInfoLine(context, this.field_22793, panelX + 12, infoY, panelWidth, "Conversion", formatConversionWarning(level), 0xFFD6E5DA);
        contentHeight += nextY - infoY;
        infoY = nextY;
        nextY = BrowserLayoutHelper.renderInfoLine(context, this.field_22793, panelX + 12, infoY, panelWidth, "Lifecycle", buildLifecycleFlags(level, levelInfo, versionInfo), 0xFFE4DAC8);
        contentHeight += nextY - infoY;
        infoY = nextY;
        nextY = BrowserLayoutHelper.renderInfoLine(context, this.field_22793, panelX + 12, infoY, panelWidth, "Data Pack", describeDataConfiguration(levelInfo), 0xFFD2E0CF);
        contentHeight += nextY - infoY;
        infoY = nextY;
        nextY = BrowserLayoutHelper.renderInfoLine(context, this.field_22793, panelX + 12, infoY, panelWidth, "Identity", buildIdentityFlags(level), 0xFFD8DFE9);
        contentHeight += nextY - infoY;
        context.method_44380();
        this.previewScrollMax = Math.max(0, contentHeight - detailsViewportHeight + 4);
        if (this.previewScrollOffset > this.previewScrollMax) {
            this.previewScrollOffset = this.previewScrollMax;
        }
        renderPreviewScrollbar(context);
    }

    private class_34 getSelectedLevel() {
        if (this.selectedWorld == null) {
            return null;
        }
        return ((WorldListWidgetWorldEntryAccessor) (Object) this.selectedWorld).koil$getLevel();
    }

    private class_2960 resolveWorldIcon(class_34 level) {
        if (level == null || level.method_27020() == null) {
            return KOIL_FALLBACK_WORLD_ICON;
        }
        File iconFile = level.method_27020().toFile();
        if (!iconFile.exists()) {
            return KOIL_FALLBACK_WORLD_ICON;
        }
        try {
            class_2960 icon = ExternalImageLoader.registerDynamicTexture("koil", "world_icon/" + level.method_248(), iconFile);
            return icon != null ? icon : KOIL_FALLBACK_WORLD_ICON;
        } catch (IOException ignored) {
            return KOIL_FALLBACK_WORLD_ICON;
        }
    }

    private void openSelectedWorldFolder() {
        syncSelectedWorldFromList();
        Path path = getSelectedWorldFolder();
        if (path == null || this.copyIPButton == null) {
            return;
        }
        File folder = path.toFile();
        folder.mkdirs();
        this.pendingFolderOpenDirectory = folder;
        this.folderOpenPopup.toggleAtPointer(this.lastMouseX, this.lastMouseY, this.field_22789, this.field_22790, FolderOpenHelper.menuEntries());
    }

    private void openVanillaDatapackScreen() {
        syncSelectedWorldFromList();
        class_34 level = getSelectedLevel();
        Path worldFolder = getSelectedWorldFolder();
        if (level == null || worldFolder == null || this.field_22787 == null) {
            return;
        }
        Path datapacksFolder = worldFolder.resolve("datapacks");
        try {
            Files.createDirectories(datapacksFolder);
        } catch (IOException e) {
            return;
        }

        class_3283 manager = class_3286.method_45286(datapacksFolder);
        manager.method_14445();
        class_1940 levelInfo = level.method_35505();
        class_7712 dataConfiguration = levelInfo == null ? class_7712.field_40260 : levelInfo.method_29558();
        if (dataConfiguration != null && dataConfiguration.comp_1010() != null) {
            manager.method_14447(dataConfiguration.comp_1010().method_29547());
        }

        class_437 returnScreen = (class_437) (Object) this;
        this.field_22787.method_1507(new class_5375(manager, ignored -> this.field_22787.method_1507(returnScreen), datapacksFolder, class_2561.method_43470("Data Packs")));
    }

    private void toggleLocalWorldDiscovery() {
        this.localWorldDiscoveryMode = !this.localWorldDiscoveryMode;
        this.previewScrollOffset = 0;
        this.previewScrollMax = 0;
        if (this.localWorldDiscoveryMode && this.discoveredWorlds.isEmpty()) {
            refreshDiscoveredWorlds();
        }
        updateDiscoveredWorldList();
        this.worldSelected(false, false);
    }

    private void toggleLocalWorldFilter() {
        this.localWorldShowIncompatible = !this.localWorldShowIncompatible;
        refreshDiscoveredWorlds();
    }

    private void refreshDiscoveredWorlds() {
        this.localWorldDiscoveryLoading = true;
        this.discoveredWorlds = LocalWorldDiscovery.discover(this.localWorldShowIncompatible);
        this.localWorldDiscoveryLoading = false;
        syncSelectedDiscoveredWorld();
        updateDiscoveredWorldList();
    }

    private void syncSelectedDiscoveredWorld() {
        List<LocalWorldDiscovery.DiscoveredWorld> visible = filteredDiscoveredWorlds();
        if (visible.isEmpty()) {
            this.selectedDiscoveredWorld = null;
            return;
        }
        if (this.selectedDiscoveredWorld == null || visible.stream().noneMatch(world -> world.worldPath().equals(this.selectedDiscoveredWorld.worldPath()))) {
            this.selectedDiscoveredWorld = visible.get(0);
        }
    }

    private List<LocalWorldDiscovery.DiscoveredWorld> filteredDiscoveredWorlds() {
        String query = this.searchBox == null ? "" : this.searchBox.method_1882().trim().toLowerCase(Locale.ROOT);
        if (query.isBlank()) {
            return this.discoveredWorlds;
        }
        List<LocalWorldDiscovery.DiscoveredWorld> visible = new ArrayList<>();
        for (LocalWorldDiscovery.DiscoveredWorld world : this.discoveredWorlds) {
            String searchable = (world.displayName() + " " + world.folderName() + " " + world.instanceName() + " " + world.worldVersion() + " " + world.worldPath()).toLowerCase(Locale.ROOT);
            if (searchable.contains(query)) {
                visible.add(world);
            }
        }
        return visible;
    }

    private void updateDiscoveredWorldList() {
        if (this.discoveredWorldListWidget == null) {
            return;
        }
        this.discoveredWorldListWidget.updateEntries(filteredDiscoveredWorlds());
    }

    private void selectDiscoveredWorld(LocalWorldDiscovery.DiscoveredWorld world) {
        this.selectedDiscoveredWorld = world;
        this.previewScrollOffset = 0;
        this.previewScrollMax = 0;
        this.worldSelected(false, false);
    }

    private void renderDiscoveredWorldList(class_332 context, int mouseX, int mouseY) {
        int listX = KOIL_WORLD_LIST_LEFT + 2;
        int listY = KOIL_WORLD_LIST_TOP + 4;
        int listWidth = KOIL_WORLD_LIST_WIDTH - 4;
        int listHeight = this.field_22790 - KOIL_WORLD_LIST_BOTTOM_PADDING - listY - 4;
        this.discoveredViewportX = listX;
        this.discoveredViewportY = listY;
        this.discoveredViewportWidth = listWidth;
        this.discoveredViewportHeight = listHeight;

        if (this.localWorldDiscoveryLoading) {
            context.method_51433(this.field_22793, "Scanning local instances...", listX + 8, listY + 8, 0xFFD8DFE9, false);
            return;
        }
        updateDiscoveredWorldList();
        if (filteredDiscoveredWorlds().isEmpty()) {
            context.method_51433(this.field_22793, "No compatible local worlds found", listX + 8, listY + 8, 0xFFD8DFE9, false);
            context.method_51433(this.field_22793, "Use Show All to include version-mismatched worlds", listX + 8, listY + 21, 0xFF9EACBA, false);
            return;
        }
        if (this.discoveredWorldListWidget != null) {
            this.discoveredWorldListWidget.method_25394(context, mouseX, mouseY, 0.0F);
        }
    }

    private void renderCompatibilityFilterButton(class_332 context) {
        if (!this.localWorldDiscoveryMode) {
            this.compatibilityFilterX = -1;
            this.compatibilityFilterWidth = 0;
            return;
        }
        String label = compatibilityFilterLabel();
        this.compatibilityFilterWidth = BrowserLayoutHelper.getFilterButtonWidth(this.field_22793, label);
        this.compatibilityFilterX = this.searchBox == null ? this.field_22789 - 332 : this.searchBox.method_46426() - BrowserLayoutHelper.FILTER_BUTTON_GAP - this.compatibilityFilterWidth;
        BrowserLayoutHelper.renderFilterButton(context, this.field_22793, this.compatibilityFilterX, label);
    }

    private String compatibilityFilterLabel() {
        return this.localWorldShowIncompatible ? "Version: Show All" : "Version: Compatible";
    }

    private class_2960 resolveDiscoveredIcon(LocalWorldDiscovery.DiscoveredWorld world) {
        if (world == null || world.iconPath() == null || !Files.exists(world.iconPath())) {
            return KOIL_FALLBACK_WORLD_ICON;
        }
        try {
            class_2960 icon = ExternalImageLoader.registerDynamicTexture("koil", "discovered_world_icon/" + Math.abs(world.worldPath().hashCode()), world.iconPath().toFile());
            return icon != null ? icon : KOIL_FALLBACK_WORLD_ICON;
        } catch (IOException ignored) {
            return KOIL_FALLBACK_WORLD_ICON;
        }
    }

    private void renderSelectedDiscoveredWorldInfo(class_332 context) {
        int panelX = BrowserLayoutHelper.previewX(this.field_22789);
        int panelY = BrowserLayoutHelper.previewY();
        int panelWidth = BrowserLayoutHelper.previewWidth(this.field_22789);
        int panelHeight = BrowserLayoutHelper.previewHeight(this.field_22790);
        BrowserLayoutHelper.renderPreviewPanelFrame(context, panelX, panelY, panelWidth, panelHeight);

        if (this.selectedDiscoveredWorld == null) {
            context.method_51433(this.field_22793, "Local World Discovery", panelX + 10, panelY + 10, new Color(uiColorContentBaseTitleText, true).getRGB(), false);
            context.method_51433(this.field_22793, "Scan known Minecraft instances for compatible saves.", panelX + 10, panelY + 26, 0xFFD8DFE9, false);
            return;
        }

        LocalWorldDiscovery.DiscoveredWorld world = this.selectedDiscoveredWorld;
        class_2960 icon = resolveDiscoveredIcon(world);
        context.method_25290(icon, panelX + 10, panelY + 10, 0, 0, 64, 64, 64, 64);
        int titleX = panelX + 84;
        context.method_51448().method_22903();
        context.method_51448().method_22905(1.5F, 1.5F, 1.0F);
        context.method_51433(this.field_22793, trimPreview(world.displayName(), 170), (int) (titleX / 1.5F), (int) ((panelY + 10) / 1.5F), new Color(uiColorContentBaseTitleText, true).getRGB(), true);
        context.method_51448().method_22909();
        context.method_51433(this.field_22793, world.folderName(), titleX, panelY + 34, 0xFFD8DFE9, false);
        context.method_51433(this.field_22793, world.versionCompatible() ? "Compatible with this Minecraft version" : "Version mismatch - warning required", titleX, panelY + 48, world.versionCompatible() ? 0xFF8FEA84 : 0xFFFFD08A, false);

        int detailsViewportY = panelY + 86;
        int detailsViewportHeight = Math.max(70, panelHeight - (detailsViewportY - panelY) - 8);
        this.previewViewportX = panelX + 8;
        this.previewViewportY = detailsViewportY;
        this.previewViewportWidth = panelWidth - 16;
        this.previewViewportHeight = detailsViewportHeight;
        context.method_44379(this.previewViewportX, this.previewViewportY, this.previewViewportX + this.previewViewportWidth, this.previewViewportY + this.previewViewportHeight);

        int infoY = detailsViewportY - this.previewScrollOffset;
        int contentHeight = 0;
        int nextY;
        BrowserLayoutHelper.renderSectionRule(context, this.field_22793, panelX + 10, panelX + panelWidth - 10, infoY, "Identity");
        infoY += 16;
        contentHeight += 16;
        nextY = BrowserLayoutHelper.renderInfoLine(context, this.field_22793, panelX + 12, infoY, panelWidth, "Folder", world.folderName(), 0xFFDCE4EE);
        contentHeight += nextY - infoY;
        infoY = nextY;
        nextY = BrowserLayoutHelper.renderInfoLine(context, this.field_22793, panelX + 12, infoY, panelWidth, "Path", world.worldPath().toAbsolutePath().normalize().toString().replace('\\', '/'), 0xFFD8E7DE);
        contentHeight += nextY - infoY;
        infoY = nextY;
        nextY = BrowserLayoutHelper.renderInfoLine(context, this.field_22793, panelX + 12, infoY, panelWidth, "Last Played", formatTimestamp(world.lastPlayed()), 0xFFD9D5E8);
        contentHeight += nextY - infoY;
        infoY = nextY;
        nextY = BrowserLayoutHelper.renderInfoLine(context, this.field_22793, panelX + 12, infoY, panelWidth, "Icon", world.iconPath() == null ? "Default world icon" : world.iconPath().toAbsolutePath().normalize().toString().replace('\\', '/'), 0xFFD6E5DA);
        contentHeight += nextY - infoY;
        infoY = nextY;
        nextY = BrowserLayoutHelper.renderInfoLine(context, this.field_22793, panelX + 12, infoY, panelWidth, "Summary", world.versionCompatible() ? "Compatible with this Minecraft version" : "Version mismatch - warning required", 0xFFD8DFE9);
        contentHeight += nextY - infoY;
        infoY = nextY;

        BrowserLayoutHelper.renderSectionRule(context, this.field_22793, panelX + 10, panelX + panelWidth - 10, infoY, "Gameplay");
        infoY += 16;
        contentHeight += 16;
        nextY = BrowserLayoutHelper.renderInfoLine(context, this.field_22793, panelX + 12, infoY, panelWidth, "Mode", world.gameMode(), 0xFFDCE4EE);
        contentHeight += nextY - infoY;
        infoY = nextY;
        nextY = BrowserLayoutHelper.renderInfoLine(context, this.field_22793, panelX + 12, infoY, panelWidth, "Difficulty", "Unknown from external save scan", 0xFFD8E7DE);
        contentHeight += nextY - infoY;
        infoY = nextY;
        nextY = BrowserLayoutHelper.renderInfoLine(context, this.field_22793, panelX + 12, infoY, panelWidth, "Commands", world.commandsAllowed() ? "Allowed" : "Off", 0xFFD9D5E8);
        contentHeight += nextY - infoY;
        infoY = nextY;
        nextY = BrowserLayoutHelper.renderInfoLine(context, this.field_22793, panelX + 12, infoY, panelWidth, "Flags", world.hardcore() ? "Hardcore" : "Standard world", 0xFFD6E5DA);
        contentHeight += nextY - infoY;
        infoY = nextY;
        nextY = BrowserLayoutHelper.renderInfoLine(context, this.field_22793, panelX + 12, infoY, panelWidth, "Features", "Read from external level.dat metadata", 0xFFD8DFE9);
        contentHeight += nextY - infoY;
        infoY = nextY;

        BrowserLayoutHelper.renderSectionRule(context, this.field_22793, panelX + 10, panelX + panelWidth - 10, infoY, "Developer Details");
        infoY += 16;
        contentHeight += 16;
        nextY = BrowserLayoutHelper.renderInfoLine(context, this.field_22793, panelX + 12, infoY, panelWidth, "Version", world.worldVersion(), 0xFFDCE4EE);
        contentHeight += nextY - infoY;
        infoY = nextY;
        nextY = BrowserLayoutHelper.renderInfoLine(context, this.field_22793, panelX + 12, infoY, panelWidth, "Save Info", "Data version " + world.dataVersion(), 0xFFD8E7DE);
        contentHeight += nextY - infoY;
        infoY = nextY;
        nextY = BrowserLayoutHelper.renderInfoLine(context, this.field_22793, panelX + 12, infoY, panelWidth, "Storage", "Instance " + world.instanceName(), 0xFFD9D5E8);
        contentHeight += nextY - infoY;
        infoY = nextY;
        nextY = BrowserLayoutHelper.renderInfoLine(context, this.field_22793, panelX + 12, infoY, panelWidth, "Conversion", world.versionCompatible() ? "No version warning expected" : "Opening requires warning confirmation", 0xFFD6E5DA);
        contentHeight += nextY - infoY;
        infoY = nextY;
        nextY = BrowserLayoutHelper.renderInfoLine(context, this.field_22793, panelX + 12, infoY, panelWidth, "Lifecycle", "External save linked into current instance on open", 0xFFE4DAC8);
        contentHeight += nextY - infoY;
        infoY = nextY;
        nextY = BrowserLayoutHelper.renderInfoLine(context, this.field_22793, panelX + 12, infoY, panelWidth, "Data Pack", "Detected after world is opened by Minecraft", 0xFFD2E0CF);
        contentHeight += nextY - infoY;
        infoY = nextY;
        nextY = BrowserLayoutHelper.renderInfoLine(context, this.field_22793, panelX + 12, infoY, panelWidth, "Identity", world.instanceRoot().toAbsolutePath().normalize().toString().replace('\\', '/'), 0xFFD8DFE9);
        contentHeight += nextY - infoY;
        infoY = nextY;

        BrowserLayoutHelper.renderSectionRule(context, this.field_22793, panelX + 10, panelX + panelWidth - 10, infoY, "Compatibility");
        infoY += 16;
        contentHeight += 16;
        nextY = BrowserLayoutHelper.renderInfoLine(context, this.field_22793, panelX + 12, infoY, panelWidth, "Version", world.worldVersion() + "  |  current " + world.currentVersion(), 0xFFDCE4EE);
        contentHeight += nextY - infoY;
        infoY = nextY;
        nextY = BrowserLayoutHelper.renderInfoLine(context, this.field_22793, panelX + 12, infoY, panelWidth, "Data Version", String.valueOf(world.dataVersion()), 0xFFD8E7DE);
        contentHeight += nextY - infoY;
        infoY = nextY;
        nextY = BrowserLayoutHelper.renderInfoLine(context, this.field_22793, panelX + 12, infoY, panelWidth, "Mode", world.gameMode() + (world.hardcore() ? " | Hardcore" : ""), 0xFFD9D5E8);
        contentHeight += nextY - infoY;
        infoY = nextY;

        BrowserLayoutHelper.renderSectionRule(context, this.field_22793, panelX + 10, panelX + panelWidth - 10, infoY, "Mod Comparison");
        infoY += 16;
        contentHeight += 16;
        nextY = BrowserLayoutHelper.renderInfoLine(context, this.field_22793, panelX + 12, infoY, panelWidth, "Source Mods", world.sourceModCount() + " detected in source instance", 0xFFDCE4EE);
        contentHeight += nextY - infoY;
        infoY = nextY;
        nextY = BrowserLayoutHelper.renderInfoLine(context, this.field_22793, panelX + 12, infoY, panelWidth, "Current Instance", world.modComparison().summary(), 0xFFD8E7DE);
        contentHeight += nextY - infoY;
        infoY = nextY;
        nextY = BrowserLayoutHelper.renderInfoLine(context, this.field_22793, panelX + 12, infoY, panelWidth, "Open Method", "Creates a current-instance save link after warning confirmation", 0xFFE4DAC8);
        contentHeight += nextY - infoY;
        context.method_44380();
        this.previewScrollMax = Math.max(0, contentHeight - detailsViewportHeight + 4);
        this.previewScrollOffset = Math.max(0, Math.min(this.previewScrollOffset, this.previewScrollMax));
        renderPreviewScrollbar(context);
    }

    private void openSelectedDiscoveredFolder() {
        if (this.selectedDiscoveredWorld == null) {
            return;
        }
        this.pendingFolderOpenDirectory = this.selectedDiscoveredWorld.worldPath().toFile();
        this.folderOpenPopup.toggleAtPointer(this.lastMouseX, this.lastMouseY, this.field_22789, this.field_22790, FolderOpenHelper.menuEntries());
    }

    private void openSelectedDiscoveredWorld() {
        if (this.selectedDiscoveredWorld == null || this.field_22787 == null) {
            return;
        }
        LocalWorldDiscovery.DiscoveredWorld world = this.selectedDiscoveredWorld;
        class_2561 message = class_2561.method_43470("This world is outside the current instance. Opening it here creates a save link in this instance. Back up the world first, especially when the mod list or version differs. Source: " + world.worldPath().toAbsolutePath().normalize());
        this.field_22787.method_1507(new class_410(confirmed -> {
            if (!confirmed) {
                this.field_22787.method_1507((class_437) (Object) this);
                return;
            }
            try {
                LocalWorldDiscovery.createCurrentInstanceLink(world);
                this.field_22787.method_1507(new class_526(this.parent));
            } catch (Exception exception) {
                class_156.method_668().method_672(world.worldPath().toFile());
                this.field_22787.method_1507((class_437) (Object) this);
            }
        }, class_2561.method_43470("Open external world?"), message, class_2561.method_43470("Open In Place"), class_5244.field_24335));
    }

    private Path getSelectedWorldFolder() {
        class_34 level = getSelectedLevel();
        if (level == null || this.field_22787 == null) {
            return null;
        }
        return this.field_22787.method_1586().method_19636().resolve(level.method_248());
    }

    private void syncSelectedWorldFromList() {
        if (this.levelList == null) {
            this.selectedWorld = null;
            return;
        }
        Optional<class_528.class_4272> selectedWorldOptional = this.levelList.method_20159();
        this.selectedWorld = selectedWorldOptional.orElse(null);
    }

    private String formatTimestamp(long timestamp) {
        if (timestamp <= 0L) {
            return "Unknown";
        }
        return new SimpleDateFormat("yyyy-MM-dd HH:mm").format(new Date(timestamp));
    }

    private String buildWorldFlags(class_34 level) {
        StringBuilder builder = new StringBuilder();
        if (level.method_257()) {
            builder.append("Hardcore");
        }
        if (level.method_45554()) {
            if (!builder.isEmpty()) {
                builder.append(" | ");
            }
            builder.append("Experimental");
        }
        if (level.method_27021()) {
            if (!builder.isEmpty()) {
                builder.append(" | ");
            }
            builder.append("Locked");
        }
        if (level.method_255()) {
            if (!builder.isEmpty()) {
                builder.append(" | ");
            }
            builder.append("Conversion");
        }
        return builder.isEmpty() ? "None" : builder.toString();
    }

    private String describeWorldPath() {
        Path path = getSelectedWorldFolder();
        return path == null ? "Unknown" : path.toAbsolutePath().normalize().toString().replace('\\', '/');
    }

    private String describeWorldIcon(class_34 level) {
        if (level == null || level.method_27020() == null) {
            return "Default icon";
        }
        return level.method_27020().toAbsolutePath().normalize().toString().replace('\\', '/');
    }

    private String buildWorldStorageFlags(class_34 level, class_5315 versionInfo) {
        List<String> flags = new ArrayList<>();
        if (versionInfo != null) {
            flags.add(versionInfo.method_29027() ? "Stable" : "Snapshot");
        }
        if (level.method_256()) {
            flags.add("Different Version");
        }
        if (level.method_260()) {
            flags.add("Future Level");
        }
        if (level.method_33784()) {
            flags.add("Unavailable");
        }
        if (!level.method_38496()) {
            flags.add("Version Missing");
        }
        return flags.isEmpty() ? "None" : String.join(" | ", flags);
    }

    private String buildLifecycleFlags(class_34 level, class_1940 levelInfo, class_5315 versionInfo) {
        List<String> flags = new ArrayList<>();
        if (levelInfo != null) {
            flags.add(levelInfo.method_8583() ? "Hardcore Profile" : "Standard Profile");
        }
        if (versionInfo != null) {
            flags.add(versionInfo.method_29027() ? "Stable Save" : "Snapshot Save");
        }
        if (levelInfo != null && levelInfo.method_8582()) {
            flags.add("Cheats Enabled");
        }
        if (level.method_45554()) {
            flags.add("Experimental Features");
        }
        if (level.method_27021()) {
            flags.add("Session Locked");
        }
        return flags.isEmpty() ? "None" : String.join(" | ", flags);
    }

    private String describeDataConfiguration(class_1940 levelInfo) {
        if (levelInfo == null || levelInfo.method_29558() == null) {
            return "Unknown";
        }
        return levelInfo.method_29558().toString();
    }

    private String buildIdentityFlags(class_34 level) {
        List<String> flags = new ArrayList<>();
        flags.add(level.method_252().isBlank() ? "Folder Name Title" : "Custom Display Name");
        if (level.method_27020() != null) {
            flags.add("Custom Icon");
        } else {
            flags.add("Default Icon");
        }
        if (level.method_255()) {
            flags.add("Needs Conversion");
        }
        return String.join(" | ", flags);
    }

    private String formatConversionWarning(class_34 level) {
        if (level == null) {
            return "None";
        }
        class_34.class_5781 warning = level.method_33405();
        if (warning == null || warning == class_34.class_5781.field_28437) {
            return "None";
        }
        return warning.name() + (warning.method_33406() ? "  |  backup suggested" : "");
    }

    private String trimPreview(String text, int maxWidth) {
        if (text == null) {
            return "";
        }
        String trimmed = this.field_22793.method_27523(text, maxWidth);
        if (trimmed.length() == text.length()) {
            return trimmed;
        }
        return this.field_22793.method_27523(text, Math.max(8, maxWidth - this.field_22793.method_1727("..."))) + "...";
    }

    private void selectFirstWorldEntry() {
        if (this.levelList == null || this.levelList.method_20159().isPresent()) {
            return;
        }
        for (class_528.class_7414 entry : this.levelList.method_25396()) {
            if (entry instanceof class_528.class_4272 worldEntry && worldEntry.method_43465()) {
                this.levelList.method_20157(worldEntry);
                this.selectedWorld = worldEntry;
                this.worldSelected(true, true);
                return;
            }
        }
    }

    private void syncPreviewSelection() {
        class_34 level = getSelectedLevel();
        String selectionKey = level == null ? null : level.method_248() + "|" + level.method_249();
        if (selectionKey != null && !selectionKey.equals(this.previewSelectionKey)) {
            this.previewSelectionKey = selectionKey;
            this.previewScrollOffset = 0;
            this.previewScrollMax = 0;
        }
    }

    private void renderPreviewScrollbar(class_332 context) {
        if (this.previewScrollMax <= 0 || this.previewViewportHeight <= 0) {
            return;
        }
        int trackX = this.previewViewportX + this.previewViewportWidth - 4;
        context.method_25294(trackX, this.previewViewportY, trackX + 2, this.previewViewportY + this.previewViewportHeight, 0x2E67727F);
        int thumbHeight = Math.max(18, (int) ((this.previewViewportHeight / (float) (this.previewViewportHeight + this.previewScrollMax)) * this.previewViewportHeight));
        int thumbTravel = Math.max(1, this.previewViewportHeight - thumbHeight);
        int thumbY = this.previewViewportY + (int) ((this.previewScrollOffset / (float) this.previewScrollMax) * thumbTravel);
        context.method_25294(trackX - 1, thumbY, trackX + 3, thumbY + thumbHeight, 0x9AA9B9CA);
    }

    @Override
    public boolean method_25401(double mouseX, double mouseY, double amount) {
        if (this.localWorldDiscoveryMode && this.discoveredWorldListWidget != null && this.discoveredWorldListWidget.method_25405(mouseX, mouseY)) {
            this.discoveredWorldListWidget.method_25307(Math.max(0.0D, this.discoveredWorldListWidget.method_25341() - (int) amount * 20.0D));
            return true;
        }
        if (mouseX >= this.previewViewportX && mouseX <= this.previewViewportX + this.previewViewportWidth
                && mouseY >= this.previewViewportY && mouseY <= this.previewViewportY + this.previewViewportHeight
                && this.previewScrollMax > 0) {
            this.previewScrollOffset = Math.max(0, Math.min(this.previewScrollMax, this.previewScrollOffset - (int) amount * 12));
            return true;
        }
        if (this.levelList != null && this.levelList.method_25405(mouseX, mouseY)) {
            this.levelList.method_25307(Math.max(0.0D, this.levelList.method_25341() - (int) amount * 20.0D));
            return true;
        }
        return super.method_25401(mouseX, mouseY, amount);
    }

    @Override
    public boolean method_25402(double mouseX, double mouseY, int button) {
        if (button == 0 && this.folderOpenPopup.isOpen()) {
            PopupMenu.MenuEntry selected = this.folderOpenPopup.click(mouseX, mouseY);
            if (selected != null) {
                FolderOpenHelper.handleAction(this.field_22787, this.pendingFolderOpenDirectory, selected.id());
                return true;
            }
            if (!this.folderOpenPopup.isOpen()) {
                return true;
            }
        }
        if (this.folderOpenPopup.isOpen() && this.folderOpenPopup.contains(mouseX, mouseY)) {
            return true;
        }
        if (button == 0 && this.localWorldDiscoveryMode && isOverCompatibilityFilter(mouseX, mouseY)) {
            toggleLocalWorldFilter();
            return true;
        }
        if (this.localWorldDiscoveryMode && this.discoveredWorldListWidget != null && this.discoveredWorldListWidget.method_25405(mouseX, mouseY)
                && this.discoveredWorldListWidget.method_25402(mouseX, mouseY, button)) {
            return true;
        }
        if (button == 0 && this.previewScrollMax > 0 && isOverPreviewScrollbar(mouseX, mouseY)) {
            int thumbY = previewScrollbarThumbY();
            int thumbHeight = previewScrollbarThumbHeight();
            this.previewScrollbarDragging = true;
            this.previewScrollbarDragOffset = mouseY >= thumbY && mouseY <= thumbY + thumbHeight ? (int) mouseY - thumbY : thumbHeight / 2;
            setPreviewScrollFromThumbTop((int) mouseY - this.previewScrollbarDragOffset);
            return true;
        }
        return super.method_25402(mouseX, mouseY, button);
    }

    @Override
    public boolean method_25403(double mouseX, double mouseY, int button, double deltaX, double deltaY) {
        if (this.localWorldDiscoveryMode && this.discoveredWorldListWidget != null
                && this.discoveredWorldListWidget.method_25403(mouseX, mouseY, button, deltaX, deltaY)) {
            return true;
        }
        if (button == 0 && this.previewScrollbarDragging) {
            setPreviewScrollFromThumbTop((int) mouseY - this.previewScrollbarDragOffset);
            return true;
        }
        return super.method_25403(mouseX, mouseY, button, deltaX, deltaY);
    }

    @Override
    public boolean method_25406(double mouseX, double mouseY, int button) {
        if (this.localWorldDiscoveryMode && this.discoveredWorldListWidget != null
                && this.discoveredWorldListWidget.method_25406(mouseX, mouseY, button)) {
            return true;
        }
        if (button == 0 && this.previewScrollbarDragging) {
            this.previewScrollbarDragging = false;
            return true;
        }
        return super.method_25406(mouseX, mouseY, button);
    }

    private boolean isOverPreviewScrollbar(double mouseX, double mouseY) {
        int trackX = this.previewViewportX + this.previewViewportWidth - 4;
        return this.previewViewportX >= 0
                && mouseX >= trackX - 4
                && mouseX <= trackX + 8
                && mouseY >= this.previewViewportY
                && mouseY <= this.previewViewportY + this.previewViewportHeight;
    }

    private boolean isOverCompatibilityFilter(double mouseX, double mouseY) {
        return this.compatibilityFilterX >= 0
                && mouseX >= this.compatibilityFilterX
                && mouseX <= this.compatibilityFilterX + this.compatibilityFilterWidth
                && mouseY >= BrowserLayoutHelper.FILTER_BUTTON_Y
                && mouseY <= BrowserLayoutHelper.FILTER_BUTTON_Y + BrowserLayoutHelper.FILTER_BUTTON_HEIGHT;
    }

    private int previewScrollbarThumbHeight() {
        return Math.max(18, (int) ((this.previewViewportHeight / (float) (this.previewViewportHeight + this.previewScrollMax)) * this.previewViewportHeight));
    }

    private int previewScrollbarThumbY() {
        int thumbTravel = Math.max(1, this.previewViewportHeight - previewScrollbarThumbHeight());
        return this.previewViewportY + (int) ((this.previewScrollOffset / (float) this.previewScrollMax) * thumbTravel);
    }

    private void setPreviewScrollFromThumbTop(int thumbTop) {
        int thumbHeight = previewScrollbarThumbHeight();
        int minTop = this.previewViewportY;
        int maxTop = this.previewViewportY + this.previewViewportHeight - thumbHeight;
        int clampedTop = Math.max(minTop, Math.min(maxTop, thumbTop));
        int travel = Math.max(1, maxTop - minTop);
        float ratio = (clampedTop - minTop) / (float) travel;
        this.previewScrollOffset = Math.max(0, Math.min(this.previewScrollMax, Math.round(ratio * this.previewScrollMax)));
    }

}
