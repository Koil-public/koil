package com.spirit.mixin.client.gui.revamp.option;

import com.spirit.koil.api.design.KoilListBoundsAccess;
import com.spirit.koil.api.design.KoilVanillaScreenChrome;
import com.spirit.koil.api.util.file.json.JSONFileEditor;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_315;
import net.minecraft.class_332;
import net.minecraft.class_364;
import net.minecraft.class_4068;
import net.minecraft.class_426;
import net.minecraft.class_4280;
import net.minecraft.class_437;
import net.minecraft.class_4667;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Overwrite;
import org.spongepowered.asm.mixin.Unique;

@Environment(EnvType.CLIENT)
@Mixin(class_426.class)
public class MixinLanguageOptionsScreen extends class_4667 {
    @Unique
    private static final int KOIL_LANGUAGE_HEADER_OFFSET = 15;
    @Unique
    private static final int KOIL_LANGUAGE_WARNING_CLEARANCE = 8;

    public MixinLanguageOptionsScreen(class_437 parent, class_315 gameOptions, class_2561 title) {
        super(parent, gameOptions, title);
    }

    /**
     * @author SpiritXIV
     * @reason keep Koil option-screen chrome visible on the language screen, which does not use GameOptionsScreen's option-list renderer
     */
    @Overwrite
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        class_4280<?> languageList = koil$getLanguageSelectionList();
        if (languageList == null) {
            super.method_25394(context, mouseX, mouseY, delta);
            return;
        }
        if (JSONFileEditor.getValueFromJson("./koil/sys/config.json", "uiRedesign").getAsBoolean()) {
            koil$syncLanguageListBounds(languageList);
            koil$renderLanguageChrome(context, languageList);
            languageList.method_25394(context, mouseX, mouseY, delta);
            koil$renderNonLanguageDrawables(context, mouseX, mouseY, delta, languageList);
            context.method_27534(this.field_22793, koil$languageWarningText(), this.field_22789 / 2, this.field_22790 - 56, 8421504);
            return;
        }

        languageList.method_25394(context, mouseX, mouseY, delta);
        context.method_27534(this.field_22793, this.field_22785, this.field_22789 / 2, 16, 16777215);
        context.method_27534(this.field_22793, koil$languageWarningText(), this.field_22789 / 2, this.field_22790 - 56, 8421504);
        super.method_25394(context, mouseX, mouseY, delta);
    }

    @Unique
    private void koil$syncLanguageListBounds(class_4280<?> languageList) {
        if (languageList instanceof KoilListBoundsAccess bounds) {
            int top = KoilVanillaScreenChrome.listTop(false) + KOIL_LANGUAGE_HEADER_OFFSET;
            int warningSafeTop = this.field_22790 - 56 - KOIL_LANGUAGE_WARNING_CLEARANCE;
            int bottom = Math.max(top, Math.min(KoilVanillaScreenChrome.languageListBottom(this.field_22790), warningSafeTop));
            bounds.koil$setListBounds(top, bottom);
        }
    }

    @Unique
    private void koil$renderNonLanguageDrawables(class_332 context, int mouseX, int mouseY, float delta, class_4280<?> languageList) {
        for (class_364 child : this.method_25396()) {
            if (child == languageList || !(child instanceof class_4068 drawable)) {
                continue;
            }
            drawable.method_25394(context, mouseX, mouseY, delta);
        }
    }

    private void koil$renderLanguageChrome(class_332 context, class_4280<?> languageList) {
        KoilVanillaScreenChrome.renderListShell(
                context,
                this.field_22787,
                this.field_22789,
                this.field_22790,
                koil$listTop(languageList),
                koil$listBottom(languageList)
        );
        KoilVanillaScreenChrome.renderTitle(context, this.field_22793, class_2561.method_43470("Options"), this.field_22785);
    }

    @Unique
    private int koil$listTop(class_4280<?> languageList) {
        if (languageList instanceof KoilListBoundsAccess bounds) {
            return Math.max(36, bounds.koil$getListTop() + KOIL_LANGUAGE_HEADER_OFFSET);
        }
        return KoilVanillaScreenChrome.listTop(false) + KOIL_LANGUAGE_HEADER_OFFSET;
    }

    @Unique
    private int koil$listBottom(class_4280<?> languageList) {
        int warningSafeTop = this.field_22790 - 56 - KOIL_LANGUAGE_WARNING_CLEARANCE;
        if (languageList instanceof KoilListBoundsAccess bounds) {
            return Math.max(koil$listTop(languageList), Math.min(bounds.koil$getListBottom(), warningSafeTop));
        }
        return Math.max(koil$listTop(languageList), Math.min(KoilVanillaScreenChrome.languageListBottom(this.field_22790), warningSafeTop));
    }

    private class_2561 koil$languageWarningText() {
        return class_2561.method_43470("(")
                .method_10852(class_2561.method_43471("options.languageWarning"))
                .method_27693(")")
                .method_27692(class_124.field_1080);
    }

    @Unique
    private class_4280<?> koil$getLanguageSelectionList() {
        for (var child : this.method_25396()) {
            if (child instanceof class_4280<?> listWidget) {
                return listWidget;
            }
        }
        return null;
    }
}
