package com.spirit.mixin.client.gui.revamp;

import com.spirit.koil.api.design.KoilScreenBackgrounds;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_525;
import net.minecraft.class_8089;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin(class_8089.class)
public class MixinTabNavigationWidget {
    @Redirect(
            method = "render",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/client/gui/DrawContext;fill(IIIII)V"
            )
    )
    private void koil$renderCreateWorldHeaderPanel(class_332 context, int x1, int y1, int x2, int y2, int color) {
        if (!koil$isCreateWorldScreen()) {
            context.method_25294(x1, y1, x2, y2, color);
            return;
        }
        context.method_25294(x1, y1, x2, y2, 0x70000000);
    }

    @Redirect(
            method = "render",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/client/gui/DrawContext;drawTexture(Lnet/minecraft/util/Identifier;IIFFIIII)V"
            )
    )
    private void koil$renderCreateWorldHeaderSeparator(class_332 context, class_2960 texture, int x, int y, float u, float v, int width, int height, int textureWidth, int textureHeight) {
        if (!koil$isCreateWorldScreen()) {
            context.method_25290(texture, x, y, u, v, width, height, textureWidth, textureHeight);
            return;
        }
        context.method_25294(x, y, x + width, y + height, 0x72000000);
        context.method_25294(x, y, x + width, y + 1, 0x88FFFFFF);
    }

    private boolean koil$isCreateWorldScreen() {
        class_310 client = class_310.method_1551();
        return client != null
                && client.field_1687 == null
                && client.field_1755 instanceof class_525
                && KoilScreenBackgrounds.uiRedesignEnabled();
    }
}
