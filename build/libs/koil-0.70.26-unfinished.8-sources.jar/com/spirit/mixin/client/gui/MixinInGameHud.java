package com.spirit.mixin.client.gui;

import com.spirit.Client;
import com.spirit.client.gui.EntityInspectionTooltipBuilder;
import com.spirit.client.gui.debug.F3OverlayRenderer;
import com.spirit.koil.api.automation.cli.AutomationChatHudRenderer;
import com.spirit.koil.api.stats.global.client.MarketHudRenderer;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.List;
import java.util.Optional;
import net.minecraft.class_1297;
import net.minecraft.class_310;
import net.minecraft.class_329;
import net.minecraft.class_332;
import net.minecraft.class_3675;
import net.minecraft.class_3966;

@Mixin(class_329.class)
public abstract class MixinInGameHud {
    @Shadow @Final private class_310 client;

    @Inject(method = "render", at = @At("TAIL"))
    private void koil$renderAutomationChatHud(class_332 context, float tickDelta, CallbackInfo ci) {
        AutomationChatHudRenderer.render(context, client);
        MarketHudRenderer.render(context, client);
        context.method_51448().method_22903();
        context.method_51448().method_46416(0.0F, 0.0F, 800.0F);
        F3OverlayRenderer.render(context, client);
        context.method_51448().method_22909();
        renderEntityInspectionTooltip(context);
    }

    private void renderEntityInspectionTooltip(class_332 context) {
        if (client == null || client.field_1724 == null || client.method_22683() == null) {
            return;
        }
        int code = class_3675.method_15981(Client.KOIL_UTIL_NBT_KEY.method_1428()).method_1444();
        if (!class_3675.method_15987(client.method_22683().method_4490(), code)) {
            return;
        }
        if (!(client.field_1765 instanceof class_3966 hitResult)) {
            return;
        }
        class_1297 entity = hitResult.method_17782();
        if (entity == null) {
            return;
        }
        List<net.minecraft.class_2561> lines = EntityInspectionTooltipBuilder.build(entity);
        if (lines.isEmpty()) {
            return;
        }
        int tooltipX = Math.min(client.method_22683().method_4486() - 340, (client.method_22683().method_4486() / 2) + 18);
        int tooltipY = Math.max(18, (client.method_22683().method_4502() / 2) - 72);
        context.method_51437(client.field_1772, lines, Optional.empty(), tooltipX, tooltipY);
    }
}
