package com.spirit.mixin.client.gui.revamp.multiplayer;

import com.spirit.koil.api.design.KoilScreenBackgrounds;
import com.spirit.koil.api.util.file.audio.AudioManager;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_3928;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_3928.class)
public class MixinLevelLoadingScreen {
    @Inject(method = "render", at = @At("HEAD"))
    private void onRender(class_332 context, int mouseX, int mouseY, float delta, CallbackInfo info) {
        AudioManager.stopAllAudio();
        class_310 client = class_310.method_1551();
        int width = client.method_22683().method_4486();
        int height = client.method_22683().method_4502();
        KoilScreenBackgrounds.render(context, client, width, height);
        context.method_25294(0, 0, width, height, KoilScreenBackgrounds.overlayColor(client));
    }
}
