package com.spirit.mixin.client.gui.revamp.option;

import com.spirit.koil.api.design.KoilVanillaScreenChrome;
import com.spirit.koil.api.util.file.json.JSONFileEditor;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_2561;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_315;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_459;
import net.minecraft.class_4667;
import net.minecraft.class_6599;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Overwrite;
import org.spongepowered.asm.mixin.Shadow;

@Environment(EnvType.CLIENT)
@Mixin(class_6599.class)
public class MixinKeybindsScreen extends class_4667 {
    @Shadow private class_4185 resetAllButton;

    @Shadow private class_459 controlsList;

    public MixinKeybindsScreen(class_437 parent, class_315 gameOptions, class_2561 title) {
        super(parent, gameOptions, title);
    }

    /**
     * @author SpiritXIV
     * @reason to make it look better
     */
    @Overwrite
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        if (JSONFileEditor.getValueFromJson("./koil/sys/config.json", "uiRedesign").getAsBoolean()) {

            class_310 client = class_310.method_1551();
            boolean hasControllingLayout = FabricLoader.getInstance().getModContainer("controlling").isPresent();
            KoilVanillaScreenChrome.renderListShell(
                    context,
                    client,
                    this.field_22789,
                    this.field_22790,
                    KoilVanillaScreenChrome.listTop(hasControllingLayout),
                    KoilVanillaScreenChrome.keybindListBottom(this.field_22790, hasControllingLayout)
            );
            KoilVanillaScreenChrome.renderTitle(context, this.field_22793, class_2561.method_43470("Options"), this.field_22785);

            this.controlsList.method_25394(context, mouseX, mouseY, delta);
            boolean bl = false;
            class_304[] var6 = this.field_21336.field_1839;
            int var7 = var6.length;

            for (int var8 = 0; var8 < var7; ++var8) {
                class_304 keyBinding = var6[var8];
                if (!keyBinding.method_1427()) {
                    bl = true;
                    break;
                }
            }

            this.resetAllButton.field_22763 = bl;
            super.method_25394(context, mouseX, mouseY, delta);
        } else {
            this.method_25420(context);
            this.controlsList.method_25394(context, mouseX, mouseY, delta);
            context.method_27534(this.field_22793, this.field_22785, this.field_22789 / 2, 8, 16777215);
            boolean bl = false;
            class_304[] var6 = this.field_21336.field_1839;
            int var7 = var6.length;

            for(int var8 = 0; var8 < var7; ++var8) {
                class_304 keyBinding = var6[var8];
                if (!keyBinding.method_1427()) {
                    bl = true;
                    break;
                }
            }

            this.resetAllButton.field_22763 = bl;
            super.method_25394(context, mouseX, mouseY, delta);
        }
    }
}
