package com.spirit.mixin.client.gui.revamp.option;

import com.spirit.client.gui.options.ContentOptionsScreen;
import com.spirit.client.gui.options.WorldDatapackScreenHelper;
import com.spirit.client.gui.mod.ModMenuScreen;
import com.spirit.client.gui.skin.ChangeSkinScreen;
import com.spirit.client.gui.skin.EditSkinScreen;
import com.spirit.client.gui.shader.ShaderPackMenuScreen;
import com.spirit.client.gui.tool.PerformanceOptimizerScreen;
import com.spirit.client.gui.video.KoilVideoOptionsScreen;
import com.spirit.koil.api.design.KoilVanillaScreenChrome;
import com.spirit.koil.api.util.file.json.JSONFileEditor;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2561;
import net.minecraft.class_2588;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_364;
import net.minecraft.class_4185;
import net.minecraft.class_429;
import net.minecraft.class_437;
import net.minecraft.class_5375;
import net.minecraft.class_7417;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Overwrite;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;
import java.nio.file.Path;

import static com.spirit.koil.api.design.uiColorVal.*;

@Environment(EnvType.CLIENT)
@Mixin(class_429.class)
public class MixinOptionsScreen extends class_437 {
    private static final String RESOURCE_PACK_TRANSLATION_KEY = "options.resourcepack";
    private static final String SKIN_CUSTOMIZATION_TRANSLATION_KEY = "options.skinCustomisation";
    private static final String VIDEO_OPTIONS_TRANSLATION_KEY = "options.video";

    protected MixinOptionsScreen(class_2561 title) {
        super(title);
    }

    @Inject(method = "init", at = @At("TAIL"))
    private void koil$replaceResourcePackButton(CallbackInfo ci) {
        if (!JSONFileEditor.getValueFromJson("./koil/sys/config.json", "uiRedesign").getAsBoolean()) {
            return;
        }
        List<class_364> snapshot = new ArrayList<>(this.method_25396());
        for (class_364 child : snapshot) {
            if (!(child instanceof class_4185 button)) {
                continue;
            }
            if (!koil$isResourcePackButton(button)) {
                continue;
            }
            int x = button.method_46426();
            int y = button.method_46427();
            int width = button.method_25368();
            int height = button.method_25364();
            this.method_37066(button);
            if (!koil$canFitDirectContentCluster(width)) {
                this.method_37063(class_4185.method_46430(class_2561.method_43470("Content"), pressed -> {
                    if (this.field_22787 != null) {
                        this.field_22787.method_1507(new ContentOptionsScreen(this));
                    }
                }).method_46434(x, y, width, height).method_46431());
                return;
            }
            koil$addContentButtons(x, y, width, height);
            return;
        }
        koil$replaceSkinCustomizationButton(snapshot);
    }

    @Inject(method = "init", at = @At("TAIL"))
    private void koil$replaceSkinCustomizationButton(CallbackInfo ci) {
        if (!JSONFileEditor.getValueFromJson("./koil/sys/config.json", "uiRedesign").getAsBoolean()) {
            return;
        }
        koil$replaceSkinCustomizationButton(new ArrayList<>(this.method_25396()));
    }

    @Inject(method = "init", at = @At("TAIL"))
    private void koil$replaceVideoOptionsButton(CallbackInfo ci) {
        if (!JSONFileEditor.getValueFromJson("./koil/sys/config.json", "uiRedesign").getAsBoolean()) {
            return;
        }
        koil$replaceVideoOptionsButton(new ArrayList<>(this.method_25396()));
    }

    private void koil$replaceSkinCustomizationButton(List<class_364> snapshot) {
        for (class_364 child : snapshot) {
            if (!(child instanceof class_4185 button)) {
                continue;
            }
            if (!koil$isSkinCustomizationButton(button)) {
                continue;
            }
            int x = button.method_46426();
            int y = button.method_46427();
            int width = button.method_25368();
            int height = button.method_25364();
            this.method_37066(button);
            int gap = 2;
            int half = Math.max(1, (width - gap) / 2);
            this.method_37063(class_4185.method_46430(class_2561.method_43470("Change Skin"), pressed -> {
                if (this.field_22787 != null) {
                    this.field_22787.method_1507(new ChangeSkinScreen(this));
                }
            }).method_46434(x, y, half, height).method_46431());
            this.method_37063(class_4185.method_46430(class_2561.method_43470("Edit Skin"), pressed -> {
                if (this.field_22787 != null) {
                    this.field_22787.method_1507(new EditSkinScreen(this));
                }
            }).method_46434(x + half + gap, y, Math.max(1, x + width - (x + half + gap)), height).method_46431());
            return;
        }
    }

    private boolean koil$canFitDirectContentCluster(int width) {
        return width >= 150;
    }

    private boolean koil$isResourcePackButton(class_4185 button) {
        String key = koil$translationKey(button.method_25369());
        if (RESOURCE_PACK_TRANSLATION_KEY.equals(key)) {
            return true;
        }
        String label = button.method_25369().getString();
        if (label == null) {
            return false;
        }
        String normalized = label.toLowerCase().replace(".", "").replace("…", "").trim();
        return normalized.equals("resource packs")
                || normalized.equals("resource pack")
                || normalized.contains("resource packs")
                || normalized.contains("resource pack");
    }

    private boolean koil$isSkinCustomizationButton(class_4185 button) {
        String key = koil$translationKey(button.method_25369());
        if (SKIN_CUSTOMIZATION_TRANSLATION_KEY.equals(key)) {
            return true;
        }
        String label = button.method_25369().getString();
        if (label == null) {
            return false;
        }
        String normalized = label.toLowerCase().replace(".", "").replace("…", "").trim();
        return normalized.equals("skin customization")
                || normalized.equals("skin customisation")
                || normalized.contains("skin customization")
                || normalized.contains("skin customisation");
    }

    private void koil$replaceVideoOptionsButton(List<class_364> snapshot) {
        for (class_364 child : snapshot) {
            if (!(child instanceof class_4185 button)) {
                continue;
            }
            if (!koil$isVideoOptionsButton(button)) {
                continue;
            }
            int x = button.method_46426();
            int y = button.method_46427();
            int width = button.method_25368();
            int height = button.method_25364();
            this.method_37066(button);
            int gap = 2;
            int performanceWidth = Math.min(width - gap - 38, Math.max(70, Math.round(width * 0.66F)));
            int videoWidth = Math.max(1, width - gap - performanceWidth);
            this.method_37063(class_4185.method_46430(class_2561.method_43470("Video"), pressed -> koil$openVideoOptions()).method_46434(x, y, videoWidth, height).method_46431());
            this.method_37063(class_4185.method_46430(class_2561.method_43470("Performance"), pressed -> {
                if (this.field_22787 != null) {
                    this.field_22787.method_1507(new PerformanceOptimizerScreen(this));
                }
            }).method_46434(x + videoWidth + gap, y, Math.max(1, x + width - (x + videoWidth + gap)), height).method_46431());
            return;
        }
    }

    private boolean koil$isVideoOptionsButton(class_4185 button) {
        String key = koil$translationKey(button.method_25369());
        if (VIDEO_OPTIONS_TRANSLATION_KEY.equals(key)) {
            return true;
        }
        String label = button.method_25369().getString();
        if (label == null) {
            return false;
        }
        String normalized = label.toLowerCase().replace(".", "").replace("…", "").trim();
        return normalized.equals("video settings")
                || normalized.equals("video")
                || normalized.contains("video settings");
    }

    private String koil$translationKey(class_2561 text) {
        if (text == null) {
            return "";
        }
        class_7417 content = text.method_10851();
        if (content instanceof class_2588 translatable) {
            return translatable.method_11022();
        }
        return "";
    }

    private void koil$openResourcePackManager() {
        if (this.field_22787 == null) {
            return;
        }
        class_310 minecraft = this.field_22787;
        Path packDir = minecraft.method_1479();
        minecraft.method_1507(new class_5375(minecraft.method_1520(), manager -> {
            minecraft.field_1690.method_49598(manager);
            minecraft.method_1507(this);
        }, packDir, class_2561.method_43471("resourcePack.title")));
    }

    private void koil$openVideoOptions() {
        if (this.field_22787 == null) {
            return;
        }
        this.field_22787.method_1507(new KoilVideoOptionsScreen(this));
    }

    /**
     * @author SpiritXIV
     * @reason to make it look better
     */
    @Overwrite
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        if (JSONFileEditor.getValueFromJson("./koil/sys/config.json", "uiRedesign").getAsBoolean()) {

            class_310 client = class_310.method_1551();
            KoilVanillaScreenChrome.renderOptionsShell(context, client, this.field_22789, this.field_22790);


            context.method_51448().method_22903();
            context.method_51448().method_22905(1.5F, 1.5F, 1.0F);
            context.method_51439(this.field_22793, class_2561.method_43470("Options"), 25, 3, new Color(uiColorHeaderTitleText, true).getRGB(), true);
            context.method_51448().method_22909();
            super.method_25394(context, mouseX, mouseY, delta);
        } else {
            this.method_25420(context);
            context.method_27534(this.field_22793, this.field_22785, this.field_22789 / 2, 15, 16777215);
            super.method_25394(context, mouseX, mouseY, delta);
        }
    }

    private void koil$addContentButtons(int x, int y, int width, int height) {
        List<ContentButtonSpec> specs = new ArrayList<>();
        specs.add(new ContentButtonSpec("Packs", 40, this::koil$openResourcePackManager));
        specs.add(new ContentButtonSpec("Mods", 36, () -> {
            if (this.field_22787 != null) {
                this.field_22787.method_1507(new ModMenuScreen(this));
            }
        }));
        if (WorldDatapackScreenHelper.canOpenDatapackManager()) {
            specs.add(new ContentButtonSpec("Data", 34, () -> {
                WorldDatapackScreenHelper.open(this);
            }));
        }
        specs.add(new ContentButtonSpec("Shaders", 56, () -> {
            if (this.field_22787 != null) {
                this.field_22787.method_1507(new ShaderPackMenuScreen(this));
            }
        }));
        int gap = 2;
        int totalWeight = specs.stream().mapToInt(ContentButtonSpec::weight).sum();
        int available = width - gap * (specs.size() - 1);
        int currentX = x;
        int remainingWidth = available;
        int remainingWeight = totalWeight;
        for (int i = 0; i < specs.size(); i++) {
            ContentButtonSpec spec = specs.get(i);
            int buttonWidth = i == specs.size() - 1 ? Math.max(1, x + width - currentX) : Math.max(1, Math.round(remainingWidth * (spec.weight() / (float) remainingWeight)));
            this.method_37063(class_4185.method_46430(class_2561.method_43470(spec.label()), pressed -> spec.action().run()).method_46434(currentX, y, buttonWidth, height).method_46431());
            currentX += buttonWidth + gap;
            remainingWidth -= buttonWidth;
            remainingWeight -= spec.weight();
        }
    }

    private record ContentButtonSpec(String label, int weight, Runnable action) {
    }
}
