package com.spirit.mixin.client.gui.revamp.world;

import com.spirit.koil.api.design.KoilScreenBackgrounds;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_525;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_525.class)
public class MixinCreateWorldScreen {
    @Inject(method = "render", at = @At("HEAD"))
    private void onRender(class_332 context, int mouseX, int mouseY, float delta, CallbackInfo info) {
        class_310 client = class_310.method_1551();
        KoilScreenBackgrounds.render(context, client, client.method_22683().method_4486(), client.method_22683().method_4502());
        context.method_25294(0, 0, client.method_22683().method_4486(), client.method_22683().method_4502(), KoilScreenBackgrounds.overlayColor(client));
    }

    @Inject(method = "renderBackgroundTexture", at = @At("HEAD"), cancellable = true)
    private void koil$renderSharedBackgroundTexture(class_332 context, CallbackInfo info) {
        class_310 client = class_310.method_1551();
        KoilScreenBackgrounds.render(context, client, client.method_22683().method_4486(), client.method_22683().method_4502());
        context.method_25294(0, 0, client.method_22683().method_4486(), client.method_22683().method_4502(), KoilScreenBackgrounds.overlayColor(client));
        info.cancel();
    }

    @Redirect(
            method = "render",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/client/gui/DrawContext;drawTexture(Lnet/minecraft/util/Identifier;IIFFIIII)V"
            )
    )
    private void koil$renderFooterSeparator(class_332 context, class_2960 texture, int x, int y, float u, float v, int width, int height, int textureWidth, int textureHeight) {
        if (!KoilScreenBackgrounds.uiRedesignEnabled()) {
            context.method_25290(texture, x, y, u, v, width, height, textureWidth, textureHeight);
            return;
        }
        context.method_25294(x, Math.max(0, y - 2), x + width, y + height + 2, 0x72000000);
        context.method_25294(x, y, x + width, y + 1, 0x9AFFFFFF);
    }
}
