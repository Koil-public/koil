package com.spirit.mixin.client.gui.revamp.multiplayer;

import com.spirit.mixin.client.gui.revamp.accessor.MultiplayerServerListWidgetAccessor;
import net.minecraft.class_156;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_4267;
import net.minecraft.class_7413;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_4267.class_4268.class)
public abstract class MixinScanningEntry {

    @Shadow @Final private class_310 client;

    @Inject(method = "render", at = @At("HEAD"), cancellable = true)
    public void render(class_332 context, int index, int y, int x, int entryWidth, int entryHeight, int mouseX, int mouseY, boolean hovered, float tickDelta, CallbackInfo ci) {
        class_2561 lanScanningText = MultiplayerServerListWidgetAccessor.getLanScanningText();
        int adjustedX = 100000;
        int var10000 = y + entryHeight / 2;
        class_327 textRenderer = this.client.field_1772;
        int i = var10000 - 9 / 2;
        context.method_51439(textRenderer, lanScanningText, adjustedX, i, 16777215, false);
        String string = class_7413.method_43449(class_156.method_658());
        context.method_51433(textRenderer, string, adjustedX + textRenderer.method_27525(lanScanningText), i + 9, 8421504, false);
        ci.cancel();
    }
}