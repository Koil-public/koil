
package com.spirit.mixin.client.gui.revamp.pack;

import com.google.gson.JsonElement;
import com.spirit.client.gui.FolderOpenHelper;
import com.spirit.client.gui.PopupMenu;
import com.spirit.client.gui.datapack.DatapackScreen;
import com.spirit.client.gui.resourcepack.ResourcepackScreen;
import com.spirit.client.gui.resourcepack.ResourcePackMenuScreen;
import com.spirit.koil.api.util.file.json.JSONFileEditor;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_156;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_5369;
import net.minecraft.class_5375;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.gen.Invoker;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.io.File;
import java.nio.file.Path;
import java.util.Objects;

@Environment(EnvType.CLIENT)
@Mixin(class_5375.class)
public abstract class MixinPackScreen extends class_437 {
    @Shadow @Final private class_5369 organizer;
    @Shadow @Final private Path file;
    @Unique private final PopupMenu koil$folderOpenPopup = new PopupMenu();
    @Unique private File koil$pendingFolderOpenDirectory;
    @Unique private int koil$lastMouseX;
    @Unique private int koil$lastMouseY;
    @Invoker("closeDirectoryWatcher")
    protected abstract void koil$closeDirectoryWatcher();

    protected MixinPackScreen(class_2561 title) {
        super(title);
    }

    @Inject(method = "init", at = @At("HEAD"), cancellable = true)
    private void koil$redirectToKoilScreen(CallbackInfo ci) {
        if (!this.koil$useRedesign()) {
            return;
        }

        ci.cancel();
        this.koil$closeDirectoryWatcher();
        Objects.requireNonNull(this.field_22787).method_1507(new ResourcePackMenuScreen((class_5375) (Object) this, this.organizer, this.file, this.field_22785));
    }

    @Inject(method = "init", at = @At("TAIL"))
    private void koil$addVanillaModeTools(CallbackInfo ci) {
        if (this.koil$useRedesign() || this.field_22787 == null) {
            return;
        }
        boolean datapack = koil$isDatapackContext();
        int buttonWidth = 150;
        int halfButtonWidth = 73;
        int buttonGap = 4;
        int leftX = Math.max(4, this.field_22789 / 2 - 154);
        int rightX = Math.min(this.field_22789 - buttonWidth - 4, this.field_22789 / 2 + 5);
        int websiteX = leftX + halfButtonWidth + buttonGap;
        int toolsY = this.field_22790 - 24;
        int folderY = this.field_22790 - 24;
        this.method_37063(class_4185.method_46430(class_2561.method_43470(datapack ? "Data Packs" : "Packs"), button -> {
            if (datapack) {
                this.field_22787.method_1507(new DatapackScreen(this, this.file.toFile()));
            } else {
                this.field_22787.method_1507(new ResourcepackScreen(this));
            }
        }).method_46434(leftX, toolsY, halfButtonWidth, 20).method_46431());
        this.method_37063(class_4185.method_46430(class_2561.method_43470("Website"), button -> {
            class_156.method_668().method_670(datapack ? "https://modrinth.com/datapacks" : "https://modrinth.com/resourcepacks");
        }).method_46434(websiteX, toolsY, halfButtonWidth, 20).method_46431());
        this.method_37063(class_4185.method_46430(class_2561.method_43470("Folder"), button -> {
            this.koil$openFolderPopupAtPointer(this.file.toFile());
        }).method_46434(rightX, folderY, buttonWidth, 20).method_46431());
    }

    @Inject(method = "render", at = @At("TAIL"))
    private void koil$renderVanillaModePopups(class_332 context, int mouseX, int mouseY, float delta, CallbackInfo ci) {
        this.koil$lastMouseX = mouseX;
        this.koil$lastMouseY = mouseY;
        if (!this.koil$useRedesign()) {
            this.koil$folderOpenPopup.render(context, mouseX, mouseY);
        }
    }

    @Override
    public boolean method_25402(double mouseX, double mouseY, int button) {
        if (button == 0 && this.koil$folderOpenPopup.isOpen()) {
            PopupMenu.MenuEntry selected = this.koil$folderOpenPopup.click(mouseX, mouseY);
            if (selected != null) {
                FolderOpenHelper.handleAction(this.field_22787, this.koil$pendingFolderOpenDirectory, selected.id());
                return true;
            }
            if (!this.koil$folderOpenPopup.isOpen()) {
                return true;
            }
        }
        if (this.koil$folderOpenPopup.isOpen() && this.koil$folderOpenPopup.contains(mouseX, mouseY)) {
            return true;
        }
        return super.method_25402(mouseX, mouseY, button);
    }

    @Unique
    private void koil$openFolderPopupAtPointer(File folder) {
        if (folder == null) {
            return;
        }
        if (!folder.exists()) {
            folder.mkdirs();
        }
        this.koil$pendingFolderOpenDirectory = folder;
        this.koil$folderOpenPopup.toggleAtPointer(this.koil$lastMouseX, this.koil$lastMouseY, this.field_22789, this.field_22790, FolderOpenHelper.menuEntries());
    }

    private boolean koil$useRedesign() {
        JsonElement element = JSONFileEditor.getValueFromJson("./koil/sys/config.json", "uiRedesign");
        return element != null && element.isJsonPrimitive() && element.getAsJsonPrimitive().isBoolean() && element.getAsBoolean();
    }

    private boolean koil$isDatapackContext() {
        String titleText = this.field_22785 == null ? "" : this.field_22785.getString().toLowerCase(java.util.Locale.ROOT);
        String pathText = this.file == null ? "" : this.file.toString().toLowerCase(java.util.Locale.ROOT);
        return titleText.contains("data pack")
                || titleText.contains("datapack")
                || pathText.contains("datapack")
                || pathText.contains("data-pack");
    }
}
