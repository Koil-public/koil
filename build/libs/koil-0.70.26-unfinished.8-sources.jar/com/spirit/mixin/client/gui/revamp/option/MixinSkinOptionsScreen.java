package com.spirit.mixin.client.gui.revamp.option;

import com.spirit.koil.api.design.KoilVanillaScreenChrome;
import com.spirit.koil.api.util.file.json.JSONFileEditor;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1664;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_315;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_440;
import net.minecraft.class_4667;
import net.minecraft.class_5244;
import net.minecraft.class_5676;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Overwrite;

import java.awt.*;

import static com.spirit.koil.api.design.uiColorVal.*;

@Environment(EnvType.CLIENT)
@Mixin(class_440.class)
public class MixinSkinOptionsScreen extends class_4667 {
    public MixinSkinOptionsScreen(class_437 parent, class_315 gameOptions, class_2561 title) {
        super(parent, gameOptions, title);
    }


    /**
     * @author SpiritXIV
     * @reason to add a button
     */
    @Overwrite
    protected void method_25426() {
        if (JSONFileEditor.getValueFromJson("./koil/sys/config.json", "uiRedesign").getAsBoolean()) {

            int i = 0;
            class_1664[] var2 = class_1664.values();
            int var3 = var2.length;

            for (int var4 = 0; var4 < var3; ++var4) {
                class_1664 playerModelPart = var2[var4];
                this.method_37063(class_5676.method_32613(this.field_21336.method_32594(playerModelPart)).method_32617(this.field_22789 / 2 - 155 + i % 2 * 160, this.field_22790 / 6 + 24 * (i >> 1), 150, 20, playerModelPart.method_7428(), (button, enabled) -> {
                    this.field_21336.method_1631(playerModelPart, enabled);
                }));
                ++i;
            }

            this.method_37063(this.field_21336.method_42552().method_18520(this.field_21336, this.field_22789 / 2 - 155 + i % 2 * 160, this.field_22790 / 6 + 24 * (i >> 1), 150));
            ++i;
            if (i % 2 == 1) {
                ++i;
            }

            this.method_37063(class_4185.method_46430(class_5244.field_24334, (button) -> this.field_22787.method_1507(this.field_21335)).method_46434(this.field_22789 / 2 - 100, this.field_22790 / 6 + 31 * (i >> 1), 200, 20).method_46431());
        } else {
            int i = 0;
            class_1664[] var2 = class_1664.values();
            int var3 = var2.length;

            for(int var4 = 0; var4 < var3; ++var4) {
                class_1664 playerModelPart = var2[var4];
                this.method_37063(class_5676.method_32613(this.field_21336.method_32594(playerModelPart)).method_32617(this.field_22789 / 2 - 155 + i % 2 * 160, this.field_22790 / 6 + 24 * (i >> 1), 150, 20, playerModelPart.method_7428(), (button, enabled) -> {
                    this.field_21336.method_1631(playerModelPart, enabled);
                }));
                ++i;
            }

            this.method_37063(this.field_21336.method_42552().method_18520(this.field_21336, this.field_22789 / 2 - 155 + i % 2 * 160, this.field_22790 / 6 + 24 * (i >> 1), 150));
            ++i;
            if (i % 2 == 1) {
                ++i;
            }

            this.method_37063(class_4185.method_46430(class_5244.field_24334, (button) -> this.field_22787.method_1507(this.field_21335)).method_46434(this.field_22789 / 2 - 100, this.field_22790 / 6 + 24 * (i >> 1), 200, 20).method_46431());
        }
    }

    /**
     * @author SpiritXIV
     * @reason to make it look better
     */
    @Overwrite
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        if (JSONFileEditor.getValueFromJson("./koil/sys/config.json", "uiRedesign").getAsBoolean()) {

            class_310 client = class_310.method_1551();
            KoilVanillaScreenChrome.renderOptionsShell(context, client, this.field_22789, this.field_22790);


            context.method_51448().method_22903();
            context.method_51448().method_22905(1.5F, 1.5F, 1.0F);
            context.method_51439(this.field_22793, class_2561.method_43470("Options"), 25, 3, new Color(uiColorHeaderTitleText, true).getRGB(), true);
            context.method_51448().method_22909();
            context.method_51439(this.field_22793, this.field_22785, 37, 18, new Color(uiColorHeaderSubTitleText, true).getRGB(), true);
            super.method_25394(context, mouseX, mouseY, delta);
        } else {
            this.method_25420(context);
            context.method_27534(this.field_22793, this.field_22785, this.field_22789 / 2, 20, 16777215);
            super.method_25394(context, mouseX, mouseY, delta);
        }
    }
}
