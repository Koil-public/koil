package com.spirit.mixin.client.gui.revamp.pack;

import com.spirit.koil.api.design.KoilScreenBackgrounds;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_7745;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Environment(EnvType.CLIENT)
@Mixin(class_7745.class)
public class MixinExperimentalWarningScreen {
    @Inject(method = "render", at = @At("HEAD"))
    private void onRender(class_332 context, int mouseX, int mouseY, float delta, CallbackInfo info) {
        class_310 client = class_310.method_1551();
        KoilScreenBackgrounds.render(context, client, client.method_22683().method_4486(), client.method_22683().method_4502());
        context.method_25294(0, 0, client.method_22683().method_4486(), client.method_22683().method_4502(), KoilScreenBackgrounds.overlayColor(client));
    }
}
