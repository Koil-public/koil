package com.spirit.mixin.client.gui.revamp.multiplayer;

import com.spirit.client.gui.browser.ContentBrowserListRowRenderer;
import com.spirit.koil.api.design.KoilScreenBackgrounds;
import com.spirit.koil.api.multiplayer.KoilServerAddressMaskAccess;
import com.spirit.koil.api.util.file.image.ExternalImageLoader;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_4267;
import net.minecraft.class_642;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.io.IOException;
import java.util.Locale;

import static com.spirit.Main.uiImageDirectory;
import static com.spirit.koil.api.util.file.image.ExternalImageLoader.loadExternalPngTextureWithColorVariant;

@Environment(EnvType.CLIENT)
@Mixin(class_4267.class_4270.class)
public class MixinServerEntry {
    @Unique private static final class_2960 KOIL_FALLBACK_SERVER_ICON = loadExternalPngTextureWithColorVariant(uiImageDirectory, "image.png");

    @Shadow @Final private class_310 client;
    @Shadow @Final private class_642 server;

    @Inject(method = "render", at = @At("HEAD"), cancellable = true)
    private void koil$renderAlignedServerRow(class_332 context, int index, int y, int x, int entryWidth, int entryHeight, int mouseX, int mouseY, boolean hovered, float delta, CallbackInfo ci) {
        if (!KoilScreenBackgrounds.uiRedesignEnabled()) {
            return;
        }

        ContentBrowserListRowRenderer.renderModMenuStyleItem(context, this.client.field_1772, koil$serverIcon(), KOIL_FALLBACK_SERVER_ICON, x, y, entryWidth, this.server.field_3752, koil$serverDescription());
        ci.cancel();
    }

    @Unique
    private class_2960 koil$serverIcon() {
        byte[] favicon = this.server.method_49306();
        if (favicon != null && favicon.length > 0) {
            try {
                class_2960 icon = ExternalImageLoader.registerDynamicTexture("koil", "server_icon/list_" + koil$sanitizeTextureKey(this.server.field_3761), favicon);
                if (icon != null) {
                    return icon;
                }
            } catch (IOException | RuntimeException ignored) {
            }
        }
        return KOIL_FALLBACK_SERVER_ICON;
    }

    @Unique
    private String koil$serverDescription() {
        String address = koil$displayAddress(this.server.field_3761);
        class_2561 version = this.server.field_3760;
        if (version != null && !version.getString().isBlank()) {
            return address + "  |  " + version.getString();
        }
        if (this.server.field_3757 != null && !this.server.field_3757.getString().isBlank()) {
            return address + "  |  " + this.server.field_3757.getString();
        }
        return address;
    }

    @Unique
    private String koil$displayAddress(String address) {
        if (this.client.field_1755 instanceof KoilServerAddressMaskAccess maskAccess) {
            return maskAccess.koil$displayServerAddress(address);
        }
        return address == null || address.isBlank() ? "No address" : address;
    }

    @Unique
    private String koil$sanitizeTextureKey(String value) {
        if (value == null || value.isBlank()) {
            return "unknown";
        }
        return value.toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9_.-]", "_");
    }
}
