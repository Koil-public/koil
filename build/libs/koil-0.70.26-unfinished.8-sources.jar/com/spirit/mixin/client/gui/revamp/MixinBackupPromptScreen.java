package com.spirit.mixin.client.gui.revamp;

import com.spirit.koil.api.design.DesignLoader;
import com.spirit.koil.api.util.file.json.JSONFileEditor;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_405;
import net.minecraft.class_4185;
import net.minecraft.class_4286;
import net.minecraft.class_437;
import net.minecraft.class_5244;
import net.minecraft.class_5489;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Overwrite;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.awt.*;
import java.util.Objects;

import static com.spirit.koil.api.design.uiColorVal.*;

@Environment(EnvType.CLIENT)
@Mixin(class_405.class)
public class MixinBackupPromptScreen extends class_437 {
    private static final int KOIL_WARNING_LEFT = 38;
    private static final int KOIL_WARNING_TITLE_Y = 70;
    private static final int KOIL_WARNING_BODY_Y = 90;
    private static final int KOIL_WARNING_LINE_HEIGHT = 12;
    private static final int KOIL_WARNING_FOOTER_HEIGHT = 102;
    private static final int KOIL_WARNING_BUTTON_WIDTH = 150;
    private static final int KOIL_WARNING_BUTTON_HEIGHT = 20;
    private static final int KOIL_WARNING_BUTTON_GAP = 10;
    @Shadow private class_5489 wrappedText;
    @Shadow @Final private class_2561 subtitle;
    @Shadow @Final protected class_405.class_406 callback;
    @Shadow private class_4286 eraseCacheCheckbox;
    @Shadow @Final private class_437 parent;
    @Shadow @Final private boolean showEraseCacheCheckbox;

    public MixinBackupPromptScreen(class_2561 title) {
        super(title);
    }

    /**
     * @author SpiritXIV
     * @reason fuck it we ball
     */
    @Overwrite
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        if (JSONFileEditor.getValueFromJson("./koil/sys/config.json", "uiRedesign").getAsBoolean()) {
            int x = KOIL_WARNING_LEFT;
            context.method_51439(this.field_22793, this.field_22785, x, KOIL_WARNING_TITLE_Y, new Color(uiColorBasicTitleText, true).getRGB(), true);
            this.wrappedText.method_30896(context, x, KOIL_WARNING_BODY_Y, KOIL_WARNING_LINE_HEIGHT, new Color(uiColorBasicDescriptionText, true).getRGB());
            super.method_25394(context, mouseX, mouseY, delta);
        } else {
            this.method_25420(context);
            context.method_27534(this.field_22793, this.field_22785, this.field_22789 / 2, 50, 16777215);
            this.wrappedText.method_30888(context, this.field_22789 / 2, 70);
            super.method_25394(context, mouseX, mouseY, delta);
        }
    }

    /**
     * @author SpiritXIV
     * @reason fuck it we ball
     */
    @Overwrite
    protected void method_25426() {
        if (JSONFileEditor.getValueFromJson("./koil/sys/config.json", "uiRedesign").getAsBoolean()) {
            super.method_25426();
            int x = KOIL_WARNING_LEFT;
            int wrapWidth = Math.max(120, this.field_22789 - (x * 2));
            this.wrappedText = class_5489.method_30890(this.field_22793, this.subtitle, wrapWidth);
            int bodyHeight = this.wrappedText.method_30887() * KOIL_WARNING_LINE_HEIGHT;
            int footerTop = Math.max(KOIL_WARNING_BODY_Y + bodyHeight + 16, this.field_22790 - KOIL_WARNING_FOOTER_HEIGHT + 16);
            int firstButtonY = Math.min(this.field_22790 - 56, footerTop);
            int availableButtonWidth = (KOIL_WARNING_BUTTON_WIDTH * 2) + KOIL_WARNING_BUTTON_GAP;
            boolean stackButtons = this.field_22789 < x + availableButtonWidth + 24;
            int firstButtonX = stackButtons ? x : x;
            int secondButtonX = stackButtons ? x : x + KOIL_WARNING_BUTTON_WIDTH + KOIL_WARNING_BUTTON_GAP;
            int secondButtonY = stackButtons ? firstButtonY + KOIL_WARNING_BUTTON_HEIGHT + 4 : firstButtonY;
            this.method_37063(class_4185.method_46430(class_2561.method_43471("selectWorld.backupJoinConfirmButton"), (button) -> this.callback.proceed(true, this.eraseCacheCheckbox.method_20372())).method_46434(firstButtonX, firstButtonY, KOIL_WARNING_BUTTON_WIDTH, KOIL_WARNING_BUTTON_HEIGHT).method_46431());
            this.method_37063(class_4185.method_46430(class_2561.method_43471("selectWorld.backupJoinSkipButton"), (button) -> this.callback.proceed(false, this.eraseCacheCheckbox.method_20372())).method_46434(secondButtonX, secondButtonY, KOIL_WARNING_BUTTON_WIDTH, KOIL_WARNING_BUTTON_HEIGHT).method_46431());
            this.method_37063(class_4185.method_46430(class_5244.field_24335, (button) -> {
                assert this.field_22787 != null;
                this.field_22787.method_1507(this.parent);
            }).method_46434(x, Math.min(this.field_22790 - 28, secondButtonY + KOIL_WARNING_BUTTON_HEIGHT + 8), stackButtons ? KOIL_WARNING_BUTTON_WIDTH : 310, KOIL_WARNING_BUTTON_HEIGHT).method_46431());
            this.eraseCacheCheckbox = new class_4286(x, Math.max(KOIL_WARNING_BODY_Y + bodyHeight + 4, firstButtonY - 24), Math.min(220, this.field_22789 - x - 12), 20, class_2561.method_43471("selectWorld.backupEraseCache"), false);
            if (this.showEraseCacheCheckbox) {
                this.method_37063(this.eraseCacheCheckbox);
            }
        } else {
            super.method_25426();
            this.wrappedText = class_5489.method_30890(this.field_22793, this.subtitle, this.field_22789 - 50);
            int var10000 = this.wrappedText.method_30887() + 1;
            Objects.requireNonNull(this.field_22793);
            int i = var10000 * 9;
            this.method_37063(class_4185.method_46430(class_2561.method_43471("selectWorld.backupJoinConfirmButton"), (button) -> this.callback.proceed(true, this.eraseCacheCheckbox.method_20372())).method_46434(this.field_22789 / 2 - 155, 100 + i, 150, 20).method_46431());
            this.method_37063(class_4185.method_46430(class_2561.method_43471("selectWorld.backupJoinSkipButton"), (button) -> this.callback.proceed(false, this.eraseCacheCheckbox.method_20372())).method_46434(this.field_22789 / 2 - 155 + 160, 100 + i, 150, 20).method_46431());
            this.method_37063(class_4185.method_46430(class_5244.field_24335, (button) -> this.field_22787.method_1507(this.parent)).method_46434(this.field_22789 / 2 - 155 + 80, 124 + i, 150, 20).method_46431());
            this.eraseCacheCheckbox = new class_4286(this.field_22789 / 2 - 155 + 80, 76 + i, 150, 20, class_2561.method_43471("selectWorld.backupEraseCache"), false);
            if (this.showEraseCacheCheckbox) {
                this.method_37063(this.eraseCacheCheckbox);
            }
        }
    }

    @Inject(method = "render", at = @At("HEAD"))
    private void onRender(class_332 context, int mouseX, int mouseY, float delta, CallbackInfo info) {
        if (JSONFileEditor.getValueFromJson("./koil/sys/config.json", "uiRedesign").getAsBoolean()) {
            class_310 client = class_310.method_1551();
            context.method_25293(DesignLoader.getLoadingTexture(), 0, 0, client.method_22683().method_4486(), client.method_22683().method_4502(), 0.0F, 0.0F, 319, 192, 319, 192);

            context.method_51448().method_22903();
            context.method_51448().method_22905(2F, 2F, 1.0F);
            context.method_51439(this.field_22793, class_2561.method_43470("[!] Warning."), 20, 8, new Color(uiColorWarningPromptText, true).getRGB(), true);
            context.method_51448().method_22909();

            context.method_25294(0, 6, this.field_22789, this.field_22790 - KOIL_WARNING_FOOTER_HEIGHT, new Color(uiColorContentBase, true).getRGB());
            context.method_25294(0, 8, this.field_22789, 10, new Color(uiColorContentStripeLeft, true).getRGB());
            context.method_25294(0, this.field_22790 - KOIL_WARNING_FOOTER_HEIGHT - 2, this.field_22789, this.field_22790 - KOIL_WARNING_FOOTER_HEIGHT - 4, new Color(uiColorContentStripeRight, true).getRGB());
        }
    }
}
