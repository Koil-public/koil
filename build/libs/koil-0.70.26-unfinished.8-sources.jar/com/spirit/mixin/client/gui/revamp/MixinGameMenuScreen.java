package com.spirit.mixin.client.gui.revamp;

import com.spirit.koil.api.design.KoilVanillaScreenChrome;
import com.spirit.koil.api.util.file.json.JSONFileEditor;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2561;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_433;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Environment(EnvType.CLIENT)
@Mixin(class_433.class)
public class MixinGameMenuScreen {
    @Unique
    private boolean koil$titleRendered;

    @Inject(method = "render", at = @At("HEAD"))
    private void koil$beginGameMenuRender(class_332 context, int mouseX, int mouseY, float delta, CallbackInfo ci) {
        this.koil$titleRendered = false;
    }

    @Redirect(
            method = "render",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/client/gui/DrawContext;drawCenteredTextWithShadow(Lnet/minecraft/client/font/TextRenderer;Lnet/minecraft/text/Text;III)V"
            ),
            require = 0
    )
    private void koil$renderTopBarGameMenuTitle(class_332 context, class_327 textRenderer, class_2561 text, int centerX, int y, int color) {
        if (JSONFileEditor.getValueFromJson("./koil/sys/config.json", "uiRedesign").getAsBoolean()) {
            KoilVanillaScreenChrome.renderTitle(context, textRenderer, class_2561.method_43470("Game Menu"), null);
            this.koil$titleRendered = true;
            return;
        }
        context.method_27534(textRenderer, text, centerX, y, color);
    }

    @Redirect(
            method = "render",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/client/gui/DrawContext;drawTextWithShadow(Lnet/minecraft/client/font/TextRenderer;Lnet/minecraft/text/Text;III)I"
            ),
            require = 0
    )
    private int koil$suppressVanillaTopTitle(class_332 context, class_327 textRenderer, class_2561 text, int x, int y, int color) {
        if (JSONFileEditor.getValueFromJson("./koil/sys/config.json", "uiRedesign").getAsBoolean() && y <= 32) {
            if (!this.koil$titleRendered) {
                KoilVanillaScreenChrome.renderTitle(context, textRenderer, class_2561.method_43470("Game Menu"), null);
                this.koil$titleRendered = true;
            }
            return textRenderer.method_27525(text);
        }
        return context.method_27535(textRenderer, text, x, y, color);
    }

    @Inject(method = "render", at = @At("RETURN"))
    private void koil$renderFallbackTopBarGameMenuTitle(class_332 context, int mouseX, int mouseY, float delta, CallbackInfo ci) {
        if (JSONFileEditor.getValueFromJson("./koil/sys/config.json", "uiRedesign").getAsBoolean() && !this.koil$titleRendered) {
            class_327 textRenderer = net.minecraft.class_310.method_1551().field_1772;
            KoilVanillaScreenChrome.renderTitle(context, textRenderer, class_2561.method_43470("Game Menu"), null);
            this.koil$titleRendered = true;
        }
    }
}
