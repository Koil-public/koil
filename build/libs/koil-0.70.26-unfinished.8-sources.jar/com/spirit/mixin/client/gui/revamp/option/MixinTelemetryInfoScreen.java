package com.spirit.mixin.client.gui.revamp.option;

import com.spirit.koil.api.design.KoilVanillaScreenChrome;
import com.spirit.koil.api.util.file.json.JSONFileEditor;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_155;
import net.minecraft.class_2561;
import net.minecraft.class_2583;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_339;
import net.minecraft.class_364;
import net.minecraft.class_4068;
import net.minecraft.class_437;
import net.minecraft.class_5250;
import net.minecraft.class_5251;
import net.minecraft.class_5481;
import net.minecraft.class_7941;
import net.minecraft.class_7944;
import net.minecraft.class_7966;
import net.minecraft.class_7969;
import net.minecraft.text.*;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.awt.Color;
import java.lang.reflect.*;
import java.util.*;

import static com.spirit.koil.api.design.uiColorVal.*;

@Environment(EnvType.CLIENT)
@Mixin(class_7944.class)
public class MixinTelemetryInfoScreen extends class_437 {
    @Shadow @Final private static class_2561 DESCRIPTION_TEXT;

    private static final int DESCRIPTION_DASH_COLOR = 0xFF3C434D;
    private static final int DESCRIPTION_SEPARATOR_COLOR = 0xFF59626E;
    private static final int DESCRIPTION_HEADER_COLOR = 0xFF9DADBF;
    private static final int DESCRIPTION_IDENTIFIER_COLOR = 0xFFD7E1EC;
    private static final int DESCRIPTION_ID_VALUE_COLOR = 0xFF8FD5D0;
    private static final int DESCRIPTION_VERSION_VALUE_COLOR = 0xFF94C7FF;
    private static final int DESCRIPTION_SYSTEM_VALUE_COLOR = 0xFFAEC6E8;
    private static final int DESCRIPTION_NUMBER_VALUE_COLOR = 0xFFE8C86F;
    private static final int DESCRIPTION_RUNTIME_VALUE_COLOR = 0xFFB7A8FF;
    private static final int DESCRIPTION_SUCCESS_VALUE_COLOR = 0xFFA6D989;
    private static final int DESCRIPTION_WARNING_VALUE_COLOR = 0xFFE6A15C;
    private static final int DESCRIPTION_DEFAULT_VALUE_COLOR = 0xFFC8D6E4;

    private final Map<class_339, WidgetPosition> originalWidgetPositions = new IdentityHashMap<>();
    private int telemetryScrollOffset;
    private int telemetryScrollMax;
    private int telemetryViewportX = -1;
    private int telemetryViewportY = -1;
    private int telemetryViewportWidth;
    private int telemetryViewportHeight;
    private boolean telemetryScrollbarDragging;
    private int telemetryScrollbarDragOffset;
    private int telemetryFooterTop = -1;

    protected MixinTelemetryInfoScreen(class_2561 title) {
        super(title);
    }

    @Inject(method = "render", at = @At("HEAD"), cancellable = true)
    private void onRender(class_332 context, int mouseX, int mouseY, float delta, CallbackInfo info) {
        if (!isKoilRedesignEnabled()) {
            restoreVanillaWidgetPositions();
            this.telemetryScrollbarDragging = false;
            return;
        }

        class_310 client = class_310.method_1551();
        positionRedesignButtons();
        KoilVanillaScreenChrome.renderOptionsShell(context, client, this.field_22789, this.field_22790);
        KoilVanillaScreenChrome.renderTitle(context, this.field_22793, class_2561.method_43470("Options"), this.field_22785);
        renderTelemetryPanel(context, client);
        renderVanillaRedesignChildren(context, mouseX, mouseY, delta);
        info.cancel();
    }

    private boolean isKoilRedesignEnabled() {
        try {
            return JSONFileEditor.getValueFromJson("./koil/sys/config.json", "uiRedesign").getAsBoolean();
        } catch (Exception ignored) {
            return false;
        }
    }

    private void positionRedesignButtons() {
        List<class_339> widgets = new ArrayList<>();

        for (class_364 child : this.method_25396()) {
            if (!(child instanceof class_339 widget) || child instanceof class_7941 || !widget.field_22764) {
                continue;
            }

            this.originalWidgetPositions.putIfAbsent(widget, new WidgetPosition(widget.method_46426(), widget.method_46427()));
            widgets.add(widget);
        }

        if (widgets.isEmpty()) {
            this.telemetryFooterTop = this.field_22790 - 8;
            return;
        }

        int gap = 8;
        int maxRowWidth = Math.max(120, this.field_22789 - 104);
        List<List<class_339>> rows = new ArrayList<>();
        List<class_339> currentRow = new ArrayList<>();
        int currentWidth = 0;

        for (class_339 widget : widgets) {
            int widgetWidth = widget.method_25368();
            int nextWidth = currentRow.isEmpty() ? widgetWidth : currentWidth + gap + widgetWidth;

            if (!currentRow.isEmpty() && nextWidth > maxRowWidth) {
                rows.add(currentRow);
                currentRow = new ArrayList<>();
                currentWidth = 0;
            }

            currentRow.add(widget);
            currentWidth = currentWidth == 0 ? widgetWidth : currentWidth + gap + widgetWidth;
        }

        if (!currentRow.isEmpty()) {
            rows.add(currentRow);
        }

        int rowHeight = 20;

        for (class_339 widget : widgets) {
            rowHeight = Math.max(rowHeight, widget.method_25364());
        }

        int totalHeight = rows.size() * rowHeight + Math.max(0, rows.size() - 1) * gap;
        int startY = Math.max(8, this.field_22790 - 6 - totalHeight);
        this.telemetryFooterTop = Math.max(8, startY - 8);

        for (int rowIndex = 0; rowIndex < rows.size(); rowIndex++) {
            List<class_339> row = rows.get(rowIndex);
            int rowWidth = -gap;

            for (class_339 widget : row) {
                rowWidth += widget.method_25368() + gap;
            }

            int x = Math.max(8, (this.field_22789 - rowWidth) / 2);
            int y = startY + rowIndex * (rowHeight + gap);

            for (class_339 widget : row) {
                widget.method_46421(x);
                widget.method_46419(y);
                x += widget.method_25368() + gap;
            }
        }
    }

    private void restoreVanillaWidgetPositions() {
        for (Map.Entry<class_339, WidgetPosition> entry : this.originalWidgetPositions.entrySet()) {
            class_339 widget = entry.getKey();
            WidgetPosition position = entry.getValue();
            widget.method_46421(position.x());
            widget.method_46419(position.y());
        }
    }

    private void renderVanillaRedesignChildren(class_332 context, int mouseX, int mouseY, float delta) {
        for (class_364 child : this.method_25396()) {
            if (child instanceof class_7941) {
                continue;
            }

            if (child instanceof class_4068 drawable) {
                drawable.method_25394(context, mouseX, mouseY, delta);
            }
        }
    }

    private void renderTelemetryPanel(class_332 context, class_310 client) {
        int x = 52;
        int y = 52;
        int width = this.field_22789 - 104;
        int footerTop = this.telemetryFooterTop <= 0 ? this.field_22790 - 38 : this.telemetryFooterTop;
        int bottom = Math.max(y + 140, footerTop - 4);
        int height = Math.max(140, bottom - y);

        context.method_25294(x, y, x + width, y + height, new Color(uiColorContentBase, true).getRGB());
        context.method_49601(x, y, width, height, new Color(uiColorBackgroundBorder, true).getRGB());
        context.method_25294(x + 2, y + 2, x + 5, y + height - 2, new Color(uiColorContentStripeLeft, true).getRGB());

        int contentX = x + 12;
        int contentWidth = width - 24;
        int headerBottom = renderTelemetryHeader(context, contentX, y + 10, contentWidth);

        this.telemetryViewportX = contentX;
        this.telemetryViewportY = headerBottom + 8;
        this.telemetryViewportWidth = contentWidth;
        this.telemetryViewportHeight = Math.max(44, y + height - 12 - this.telemetryViewportY);

        context.method_44379(this.telemetryViewportX, this.telemetryViewportY, this.telemetryViewportX + this.telemetryViewportWidth, this.telemetryViewportY + this.telemetryViewportHeight);

        int rowY = this.telemetryViewportY - this.telemetryScrollOffset;
        int contentHeight = 0;

        for (TelemetryRow row : telemetryRows(client)) {
            int nextY = drawTelemetryRow(context, row, this.telemetryViewportX + 2, rowY, this.telemetryViewportWidth - 12) + 8;
            contentHeight += nextY - rowY;
            rowY = nextY;
        }

        context.method_44380();

        this.telemetryScrollMax = Math.max(0, contentHeight - this.telemetryViewportHeight);

        if (this.telemetryScrollOffset > this.telemetryScrollMax) {
            this.telemetryScrollOffset = this.telemetryScrollMax;
        }

        renderTelemetryScrollbar(context);
    }

    private int renderTelemetryHeader(class_332 context, int x, int y, int width) {
        class_2561 titleText = this.field_22785 == null || this.field_22785.getString().isBlank() ? class_2561.method_43470("Telemetry Data Collection") : this.field_22785;
        List<class_5481> descriptionLines = this.field_22793.method_1728(DESCRIPTION_TEXT, Math.max(80, width - 8));

        context.method_51439(this.field_22793, titleText, x + 2, y, new Color(uiColorContentBaseTitleText, true).getRGB(), false);

        int lineY = y + 14;

        for (class_5481 line : descriptionLines) {
            context.method_51430(this.field_22793, line, x + 2, lineY, new Color(uiColorContentBaseDescriptionText, true).getRGB(), false);
            lineY += 10;
        }

        return lineY;
    }

    private int drawTelemetryRow(class_332 context, TelemetryRow row, int x, int y, int width) {
        int reasonWidth = Math.max(80, width - 18);
        List<class_5481> reason = wrapDescriptionLines(row.reason(), reasonWidth);
        int height = Math.max(34, 22 + reason.size() * 10);

        context.method_25294(x, y, x + width, y + height, 0x4A000000);
        context.method_49601(x, y, width, height, new Color(uiColorBackgroundBorder, true).getRGB());
        context.method_51433(this.field_22793, row.label(), x + 8, y + 6, new Color(uiColorContentBaseTitleText, true).getRGB(), false);
        context.method_51433(this.field_22793, row.value(), x + 128, y + 6, row.valueColor(), false);

        int lineY = y + 18;

        for (class_5481 line : reason) {
            context.method_51430(this.field_22793, line, x + 8, lineY, new Color(uiColorContentBaseDescriptionText, true).getRGB(), false);
            lineY += 10;
        }

        return y + height;
    }

    private List<class_5481> wrapDescriptionLines(String value, int width) {
        List<class_5481> lines = new ArrayList<>();
        String safeValue = value == null ? "" : value;
        String[] literalLines = safeValue.split("\\R", -1);

        for (String literalLine : literalLines) {
            if (literalLine.isBlank()) {
                continue;
            }

            lines.addAll(this.field_22793.method_1728(descriptionTextForLine(literalLine), width));
        }

        return lines;
    }

    private class_5250 descriptionTextForLine(String value) {
        if ("Fields:".equals(value)) {
            return coloredText(value, DESCRIPTION_HEADER_COLOR);
        }

        if (value.startsWith("- ")) {
            return fieldDescriptionText(value.substring(2));
        }

        return coloredText(value, new Color(uiColorContentBaseDescriptionText, true).getRGB());
    }

    private class_5250 fieldDescriptionText(String value) {
        int separator = value.indexOf(':');

        if (separator < 0) {
            return class_2561.method_43473()
                    .method_10852(coloredText("-", DESCRIPTION_DASH_COLOR))
                    .method_10852(coloredText(" ", DESCRIPTION_SEPARATOR_COLOR))
                    .method_10852(coloredText(value, DESCRIPTION_IDENTIFIER_COLOR));
        }

        String identifier = value.substring(0, separator).trim();
        String fieldValue = value.substring(separator + 1).trim();

        return class_2561.method_43473()
                .method_10852(coloredText("-", DESCRIPTION_DASH_COLOR))
                .method_10852(coloredText(" ", DESCRIPTION_SEPARATOR_COLOR))
                .method_10852(coloredText(identifier, DESCRIPTION_IDENTIFIER_COLOR))
                .method_10852(coloredText(": ", DESCRIPTION_SEPARATOR_COLOR))
                .method_10852(coloredText(fieldValue, descriptionValueColor(identifier, fieldValue)));
    }

    private class_5250 coloredText(String value, int color) {
        return class_2561.method_43470(value).method_10862(class_2583.field_24360.method_27703(class_5251.method_27717(color & 0xFFFFFF)));
    }

    private int descriptionValueColor(String identifier, String value) {
        String key = (identifier == null ? "" : identifier).toLowerCase(Locale.ROOT);
        String lowerValue = (value == null ? "" : value).toLowerCase(Locale.ROOT);

        if (lowerValue.contains("unknown") || lowerValue.contains("unavailable") || lowerValue.contains("not currently exposed")) {
            return DESCRIPTION_WARNING_VALUE_COLOR;
        }

        if (lowerValue.equals("true") || lowerValue.equals("yes") || lowerValue.equals("active") || lowerValue.equals("enabled")) {
            return DESCRIPTION_SUCCESS_VALUE_COLOR;
        }

        if (lowerValue.equals("false") || lowerValue.equals("no") || lowerValue.equals("disabled")) {
            return DESCRIPTION_WARNING_VALUE_COLOR;
        }

        if (lowerValue.contains("generated when") || lowerValue.contains("sampled by") || lowerValue.contains("runtime")) {
            return DESCRIPTION_RUNTIME_VALUE_COLOR;
        }

        if (key.contains("id") || key.contains("identifier") || lowerValue.matches(".*[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}.*")) {
            return DESCRIPTION_ID_VALUE_COLOR;
        }

        if (key.contains("version") || key.contains("java") || key.contains("game version")) {
            return DESCRIPTION_VERSION_VALUE_COLOR;
        }

        if (key.contains("memory") || key.contains("distance") || key.contains("samples") || key.contains("time") || lowerValue.matches(".*\\d+.*")) {
            return DESCRIPTION_NUMBER_VALUE_COLOR;
        }

        if (key.contains("system") || key.contains("operating") || key.contains("platform") || key.contains("arch") || key.contains("client")) {
            return DESCRIPTION_SYSTEM_VALUE_COLOR;
        }

        if (key.contains("server") || key.contains("world") || key.contains("mode") || key.contains("session")) {
            return DESCRIPTION_WARNING_VALUE_COLOR;
        }

        return DESCRIPTION_DEFAULT_VALUE_COLOR;
    }

    private List<TelemetryRow> telemetryRows(class_310 client) {
        List<TelemetryRow> rows = new ArrayList<>();
        String username = client == null || client.method_1548() == null ? "unknown" : client.method_1548().method_1676();
        String uuid = client == null || client.method_1548() == null ? "unknown" : client.method_1548().method_1673();
        String world = client == null || client.field_1687 == null ? "menu" : client.method_1542() ? "singleplayer" : "multiplayer server";

        rows.add(new TelemetryRow("Minecraft summary", "active", 0xFF8FC5FF, nonBlank(DESCRIPTION_TEXT.getString(), "Minecraft can collect required telemetry for diagnostics and optional telemetry if the player enables it. The rows below expand that into the values this client can see and the fields each vanilla telemetry event can include.")));
        rows.add(new TelemetryRow("User ID", uuid, 0xFF7FC8C2, "Account identifier used to attach telemetry to the signed-in Minecraft session. This is not chat text or a display name; it is the account/session id visible to the client."));
        rows.add(new TelemetryRow("Username", username, 0xFFE6EDF5, "Display name for proof of the currently active local session. Mojang telemetry generally uses stable ids instead of relying on a changeable display name."));
        rows.add(new TelemetryRow("Telemetry opt-in", telemetryOptionValue(client), 0xFFE3B735, "Shows whether optional telemetry is enabled. Optional events are only intended to send when this value allows them; required events may still be sent for diagnostics and service operation."));
        rows.add(new TelemetryRow("Game version", class_155.method_16673().method_48019(), 0xFF0085A4, "Version data helps Mojang understand which Minecraft build produced a report or performance sample."));
        rows.add(new TelemetryRow("Session context", world, 0xFFE6862C, "World/server context explains whether telemetry comes from menus, local worlds, or multiplayer play."));
        rows.add(new TelemetryRow("Language", Locale.getDefault().toLanguageTag(), 0xFFE6EDF5, "Locale helps diagnose language, region, and text issues without exposing chat or private messages."));
        rows.add(new TelemetryRow("Java runtime", System.getProperty("java.version", "unknown"), 0xFF8FC5FF, "Runtime details help explain crashes, startup failures, and client compatibility issues."));
        rows.add(new TelemetryRow("Operating system", System.getProperty("os.name", "unknown") + " " + System.getProperty("os.arch", ""), 0xFF8FC5FF, "OS and architecture are needed for platform-specific crash and driver diagnosis."));
        rows.add(new TelemetryRow("Client modded", FabricLoader.getInstance().isModLoaded("fabricloader") ? "yes" : "no", 0xFFE6862C, "Minecraft's telemetry model can include whether the client is modded. The system reports this locally as yes because Fabric Loader is present in this instance."));        rows.addAll(vanillaTelemetryEventRows());

        return rows;
    }

    private List<TelemetryRow> vanillaTelemetryEventRows() {
        List<TelemetryRow> rows = new ArrayList<>();

        try {
            for (Field field : class_7966.class.getDeclaredFields()) {
                if (!Modifier.isStatic(field.getModifiers()) || field.getType() != class_7966.class) {
                    continue;
                }

                field.setAccessible(true);
                class_7966 event = (class_7966) field.get(null);

                if (event == null) {
                    continue;
                }

                String title = event.method_47730().getString();
                String description = event.method_47731().getString();
                String value = event.method_47729() ? "optional" : "required";
                String eventName = nonBlank(title, formatTelemetryFieldName(field.getName()));

                rows.add(new TelemetryRow(eventName, value, event.method_47729() ? 0xFFE3B735 : 0xFF7FC8C2, eventReason(event, description)));
            }
        } catch (Exception ignored) {
            rows.add(new TelemetryRow("Telemetry events", "unavailable", 0xFFE06A21, "Minecraft's telemetry event registry could not be read from this runtime, so The system is showing the live account, version, system, and opt-in values only."));
        }

        return rows;
    }

    private String eventReason(class_7966 event, String description) {
        StringBuilder builder = new StringBuilder();
        builder.append(nonBlank(description, "Vanilla telemetry event registered by Minecraft."));

        List<class_7969<?>> properties = event.method_47726();

        if (!properties.isEmpty()) {
            builder.append('\n').append("Fields:");

            for (class_7969<?> property : properties) {
                builder.append('\n').append("- ").append(property.method_47743().getString()).append(": ").append(livePropertyValue(property));
            }
        }

        return builder.toString();
    }

    private String livePropertyValue(class_7969<?> property) {
        String id = property.comp_1171();
        class_310 client = class_310.method_1551();

        if ("user_id".equals(id)) {
            return client == null || client.method_1548() == null ? "unknown" : client.method_1548().method_1673();
        }

        if ("game_version".equals(id)) {
            return class_155.method_16673().method_48019();
        }

        if ("operating_system".equals(id)) {
            return System.getProperty("os.name", "unknown");
        }

        if ("platform".equals(id)) {
            return System.getProperty("os.arch", "unknown");
        }

        if ("client_modded".equals(id)) {
            return FabricLoader.getInstance().isModLoaded("fabricloader") ? "true" : "false";
        }

        if ("server_type".equals(id)) {
            return client == null || client.field_1687 == null ? "menu" : client.method_1542() ? "singleplayer" : "multiplayer";
        }

        if ("opt_in".equals(id)) {
            return telemetryOptionValue(client);
        }

        if ("event_timestamp_utc".equals(id)) {
            return "generated when event is sent";
        }

        if ("render_distance".equals(id) && client != null) {
            return String.valueOf(client.field_1690.method_42503().method_41753());
        }

        if ("dedicated_memory_kb".equals(id)) {
            return Runtime.getRuntime().maxMemory() / 1024L + " KB max heap";
        }

        if ("game_mode".equals(id) && client != null && client.field_1761 != null) {
            return client.field_1761.method_2920().method_8381();
        }

        if ("number_of_samples".equals(id) || id.endsWith("_samples") || id.endsWith("_ms") || id.endsWith("_time_ms")) {
            return "sampled by Minecraft during runtime";
        }

        if ("advancement_id".equals(id)) {
            return "advancement identifier when earned";
        }

        if ("advancement_game_time".equals(id)) {
            return "world game time when advancement is earned";
        }

        return "not currently exposed as a stable live client value";
    }

    private String nonBlank(String value, String fallback) {
        return value == null || value.isBlank() ? fallback : value;
    }

    private String formatTelemetryFieldName(String value) {
        if (value == null || value.isBlank()) {
            return "Telemetry event";
        }

        String[] parts = value.toLowerCase(Locale.ROOT).split("_");
        StringBuilder builder = new StringBuilder();

        for (String part : parts) {
            if (part.isBlank()) {
                continue;
            }

            if (!builder.isEmpty()) {
                builder.append(' ');
            }

            builder.append(Character.toUpperCase(part.charAt(0))).append(part.substring(1));
        }

        return builder.isEmpty() ? value : builder.toString();
    }

    private String telemetryOptionValue(class_310 client) {
        if (client == null || client.field_1690 == null) {
            return "unknown";
        }

        try {
            Method method = client.field_1690.getClass().getMethod("getTelemetryOptInExtra");
            Object option = method.invoke(client.field_1690);
            Method getValue = option.getClass().getMethod("getValue");
            return String.valueOf(getValue.invoke(option));
        } catch (Exception ignored) {
            return "unavailable";
        }
    }

    private void renderTelemetryScrollbar(class_332 context) {
        if (this.telemetryScrollMax <= 0 || this.telemetryViewportHeight <= 0) {
            return;
        }

        int trackX = telemetryScrollbarTrackX();
        int thumbHeight = telemetryScrollbarThumbHeight();
        int thumbY = telemetryScrollbarThumbY();

        context.method_25294(trackX, this.telemetryViewportY, trackX + 2, this.telemetryViewportY + this.telemetryViewportHeight, 0x2E67727F);
        context.method_25294(trackX - 1, thumbY, trackX + 3, thumbY + thumbHeight, 0x9AA9B9CA);
    }

    private int telemetryScrollbarTrackX() {
        return this.telemetryViewportX + this.telemetryViewportWidth - 4;
    }



    private int telemetryScrollbarThumbHeight() {
        if (this.telemetryScrollMax <= 0 || this.telemetryViewportHeight <= 0) {
            return this.telemetryViewportHeight;
        }

        return Math.max(18, (int) ((this.telemetryViewportHeight / (float) (this.telemetryViewportHeight + this.telemetryScrollMax)) * this.telemetryViewportHeight));
    }

    private int telemetryScrollbarThumbY() {
        if (this.telemetryScrollMax <= 0 || this.telemetryViewportHeight <= 0) {
            return this.telemetryViewportY;
        }

        int thumbHeight = telemetryScrollbarThumbHeight();
        int thumbTravel = Math.max(1, this.telemetryViewportHeight - thumbHeight);

        return this.telemetryViewportY + (int) ((this.telemetryScrollOffset / (float) this.telemetryScrollMax) * thumbTravel);
    }

    private boolean isMouseOverTelemetryScrollbar(double mouseX, double mouseY) {
        if (this.telemetryScrollMax <= 0 || this.telemetryViewportHeight <= 0) {
            return false;
        }

        int trackX = telemetryScrollbarTrackX();

        return mouseX >= trackX - 3
                && mouseX <= trackX + 5
                && mouseY >= this.telemetryViewportY
                && mouseY <= this.telemetryViewportY + this.telemetryViewportHeight;
    }

    private boolean isMouseOverTelemetryScrollbarThumb(double mouseX, double mouseY) {
        if (!isMouseOverTelemetryScrollbar(mouseX, mouseY)) {
            return false;
        }

        int thumbY = telemetryScrollbarThumbY();
        int thumbHeight = telemetryScrollbarThumbHeight();

        return mouseY >= thumbY && mouseY <= thumbY + thumbHeight;
    }

    private void setTelemetryScrollFromThumbY(double thumbY) {
        if (this.telemetryScrollMax <= 0 || this.telemetryViewportHeight <= 0) {
            this.telemetryScrollOffset = 0;
            return;
        }

        int thumbHeight = telemetryScrollbarThumbHeight();
        int thumbTravel = Math.max(1, this.telemetryViewportHeight - thumbHeight);
        int clampedThumbY = Math.max(this.telemetryViewportY, Math.min(this.telemetryViewportY + thumbTravel, (int) thumbY));
        float progress = (clampedThumbY - this.telemetryViewportY) / (float) thumbTravel;

        this.telemetryScrollOffset = Math.max(0, Math.min(this.telemetryScrollMax, Math.round(progress * this.telemetryScrollMax)));
    }

    @Override
    public boolean method_25402(double mouseX, double mouseY, int button) {
        if (!isKoilRedesignEnabled()) {
            return super.method_25402(mouseX, mouseY, button);
        }

        if (button == 0 && isMouseOverTelemetryScrollbar(mouseX, mouseY)) {
            int thumbY = telemetryScrollbarThumbY();

            if (isMouseOverTelemetryScrollbarThumb(mouseX, mouseY)) {
                this.telemetryScrollbarDragOffset = (int) mouseY - thumbY;
            } else {
                this.telemetryScrollbarDragOffset = telemetryScrollbarThumbHeight() / 2;
                setTelemetryScrollFromThumbY(mouseY - this.telemetryScrollbarDragOffset);
            }

            this.telemetryScrollbarDragging = true;
            return true;
        }

        return super.method_25402(mouseX, mouseY, button);
    }

    @Override
    public boolean method_25406(double mouseX, double mouseY, int button) {
        if (!isKoilRedesignEnabled()) {
            this.telemetryScrollbarDragging = false;
            return super.method_25406(mouseX, mouseY, button);
        }

        if (button == 0 && this.telemetryScrollbarDragging) {
            this.telemetryScrollbarDragging = false;
            return true;
        }

        return super.method_25406(mouseX, mouseY, button);
    }

    @Override
    public boolean method_25403(double mouseX, double mouseY, int button, double deltaX, double deltaY) {
        if (!isKoilRedesignEnabled()) {
            this.telemetryScrollbarDragging = false;
            return super.method_25403(mouseX, mouseY, button, deltaX, deltaY);
        }

        if (button == 0 && this.telemetryScrollbarDragging) {
            setTelemetryScrollFromThumbY(mouseY - this.telemetryScrollbarDragOffset);
            return true;
        }

        return super.method_25403(mouseX, mouseY, button, deltaX, deltaY);
    }

    @Override
    public boolean method_25401(double mouseX, double mouseY, double amount) {
        if (!isKoilRedesignEnabled()) {
            return super.method_25401(mouseX, mouseY, amount);
        }

        if (mouseX >= this.telemetryViewportX && mouseX <= this.telemetryViewportX + this.telemetryViewportWidth
                && mouseY >= this.telemetryViewportY && mouseY <= this.telemetryViewportY + this.telemetryViewportHeight
                && this.telemetryScrollMax > 0) {
            this.telemetryScrollOffset = Math.max(0, Math.min(this.telemetryScrollMax, this.telemetryScrollOffset - (int) amount * 18));
            return true;
        }

        return super.method_25401(mouseX, mouseY, amount);
    }

    private record WidgetPosition(int x, int y) {
    }

    private record TelemetryRow(String label, String value, int valueColor, String reason) {
    }
}