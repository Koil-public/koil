package com.spirit.mixin.client.gui.revamp.multiplayer;

import com.spirit.client.gui.browser.ContentBrowserListRowRenderer;
import com.spirit.koil.api.design.KoilScreenBackgrounds;
import com.spirit.koil.api.multiplayer.KoilServerAddressMaskAccess;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1131;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_4267;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import static com.spirit.Main.uiImageDirectory;
import static com.spirit.koil.api.util.file.image.ExternalImageLoader.loadExternalPngTextureWithColorVariant;

@Environment(EnvType.CLIENT)
@Mixin(class_4267.class_4269.class)
public class MixinLanServerEntry {
    @Unique private static final class_2960 KOIL_FALLBACK_SERVER_ICON = loadExternalPngTextureWithColorVariant(uiImageDirectory, "image.png");

    @Shadow @Final protected class_310 client;
    @Shadow @Final protected class_1131 server;

    @Inject(method = "render", at = @At("HEAD"), cancellable = true)
    private void koil$renderAlignedLanServerRow(class_332 context, int index, int y, int x, int entryWidth, int entryHeight, int mouseX, int mouseY, boolean hovered, float delta, CallbackInfo ci) {
        if (!KoilScreenBackgrounds.uiRedesignEnabled()) {
            return;
        }

        ContentBrowserListRowRenderer.renderModMenuStyleItem(context, this.client.field_1772, koil$lanServerIcon(), KOIL_FALLBACK_SERVER_ICON, x, y, entryWidth, koil$lanTitle(), koil$lanDescription());
        ci.cancel();
    }

    @Unique
    private class_2960 koil$lanServerIcon() {
        return KOIL_FALLBACK_SERVER_ICON;
    }

    @Unique
    private String koil$lanTitle() {
        String motd = this.server.method_4813();
        return motd == null || motd.isBlank() ? "LAN Server" : motd;
    }

    @Unique
    private String koil$lanDescription() {
        String address = this.server.method_4812();
        if (this.client.field_1755 instanceof KoilServerAddressMaskAccess maskAccess) {
            return maskAccess.koil$displayServerAddress(address);
        }
        return address == null || address.isBlank() ? "Local network" : address;
    }
}
