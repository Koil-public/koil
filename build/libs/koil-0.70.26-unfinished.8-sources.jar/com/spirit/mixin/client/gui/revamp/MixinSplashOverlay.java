package com.spirit.mixin.client.gui.revamp;

import com.spirit.koil.api.design.DesignLoader;
import com.spirit.koil.api.util.file.json.JSONFileEditor;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.class_1041;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_4011;
import net.minecraft.class_425;
import net.minecraft.class_5253;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.awt.*;
import java.util.function.IntSupplier;

import static com.spirit.Main.*;
import static com.spirit.koil.api.design.uiColorVal.uiColorSplashLoadingBar;

@Mixin(class_425.class)
public abstract class MixinSplashOverlay {
    private static final int MOJANG_RED = class_5253.class_5254.method_27764(255, 239, 50, 61);
    private static final int MONOCHROME_BLACK = class_5253.class_5254.method_27764(255, 0, 0, 0);
    private static final IntSupplier BRAND_ARGB = () -> class_310.method_1551().field_1690.method_41772().method_41753() ? MONOCHROME_BLACK : MOJANG_RED;
    private boolean titleSet = false;

    @Shadow @Final private class_4011 reload;
    @Shadow @Final private class_310 client;
    private float previousProgress = 0.0f;
    private long lastUpdateTime;
    private int dotCount;

    @Inject(method = "<init>*", at = @At("RETURN"))
    private void onInit(CallbackInfo ci) {
        if (JSONFileEditor.getValueFromJson("./koil/sys/config.json", "uiRedesign").getAsBoolean()) {
            ClientTickEvents.END_CLIENT_TICK.register(client -> {
                if (!titleSet && client != null && client.method_22683() != null) {
                    class_1041 window = client.method_22683();
                    window.method_24286("Loading...");
                    titleSet = true;
                }
            });
            class_310 client = class_310.method_1551();
            if (client != null) {
                this.lastUpdateTime = System.currentTimeMillis();
                this.dotCount = 0;
            }
        }
    }

    @Inject(method = "render", at = @At("RETURN"))
    public void onRender(class_332 context, int mouseX, int mouseY, float delta, CallbackInfo ci) {
        if (JSONFileEditor.getValueFromJson("./koil/sys/config.json", "uiRedesign").getAsBoolean()) {
            class_310 client = class_310.method_1551();
            if (client == null) return;
            int width = client.method_22683().method_4486();
            int height = client.method_22683().method_4502();
            float progress = this.reload.method_18229();
            int alpha = (int) (255 * (1.0f - progress));

            if (progress >= 1.0f) {
                alpha = 0;
            }

            context.method_25296(0, 0, width, height - 5, (alpha << 24) | BRAND_ARGB.getAsInt(), (alpha << 24) | BRAND_ARGB.getAsInt());
            context.method_25293(DesignLoader.getLoadingTexture(), 0, 0, client.method_22683().method_4486(), client.method_22683().method_4502(), 0.0F, 0.0F, 319, 192, 319, 192);

            client.method_1531().method_22813(LOGO_TEXTURE);
            context.method_25290(LOGO_TEXTURE, width - 50, height - 50, 0, 0, 35, 35, 35, 35);
            client.method_1531().method_22813(AUTOMATION_TEXTURE);
            context.method_25290(AUTOMATION_TEXTURE, width - 100, height - 50, 0, 0, 35, 35, 35, 35);
            client.method_1531().method_22813(MOJANG_LOGO);
            context.method_25290(MOJANG_LOGO, width - 150, height - 50, 0, 0, 35, 35, 35, 35);
            //client.getTextureManager().bindTexture(MOJANG_LOGO);
            //context.drawTexture(MOJANG_LOGO, width - 200, height - 50, 0, 0, 35, 35, 35, 35);

            // Update dot animation
            long currentTime = System.currentTimeMillis();
            if (currentTime - lastUpdateTime >= 500) {
                lastUpdateTime = currentTime;
                dotCount = (dotCount + 1) % 4;
            }

            int loadingImageWidth = 184 + (dotCount == 0 ? 0 : (dotCount == 1 ? 15 : (dotCount == 2 ? 30 : 44)));
            int loadingImageHeight = 35;

            client.method_1531().method_22813(LOADING_TEXT_TEXTURE);
            context.method_25290(LOADING_TEXT_TEXTURE, 10, height - 30, 0, 0, loadingImageWidth / 2, loadingImageHeight / 2, 228 / 2, loadingImageHeight / 2);
        }
    }

    @Inject(method = "renderProgressBar", at = @At("HEAD"), cancellable = true)
    private void renderProgressBar(class_332 context, int minX, int minY, int maxX, int maxY, float opacity, CallbackInfo ci) {
        if (JSONFileEditor.getValueFromJson("./koil/sys/config.json", "uiRedesign").getAsBoolean()) {
            float progress = this.reload.method_18229();
            int width = this.client.method_22683().method_4486();
            int height = this.client.method_22683().method_4502();

            float interpolatedProgress = this.previousProgress + (progress - this.previousProgress) * this.client.method_1488();
            this.previousProgress = interpolatedProgress;

            int filledWidth = (int) (width * interpolatedProgress);
            int barX = 0;
            int barY = height - 5;
            int barHeight = 5;
            context.method_51737(barX, barY, barX + filledWidth, barY + barHeight, 255, new Color(uiColorSplashLoadingBar, true).getRGB());

            if (progress >= 1.0f) {
                this.client.method_18502(null);
            }

            ci.cancel();
        }
    }
}
