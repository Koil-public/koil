package com.spirit.mixin.client.gui.revamp.option;

import com.spirit.client.gui.video.KoilVideoOptionsScreen;
import com.spirit.koil.api.design.KoilVanillaScreenChrome;
import com.spirit.koil.api.util.file.json.JSONFileEditor;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_315;
import net.minecraft.class_332;
import net.minecraft.class_437;
import net.minecraft.class_446;
import net.minecraft.class_4667;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.awt.*;

import static com.spirit.koil.api.design.uiColorVal.*;

@Environment(EnvType.CLIENT)
@Mixin(class_446.class)
public class MixinVideoOptionsScreen extends class_4667 {
    public MixinVideoOptionsScreen(class_437 parent, class_315 gameOptions, class_2561 title) {
        super(parent, gameOptions, title);
    }

    @Inject(method = "render", at = @At("HEAD"))
    private void onRender(class_332 context, int mouseX, int mouseY, float delta, CallbackInfo info) {
        if ((Object) this instanceof KoilVideoOptionsScreen) {
            return;
        }
        if (JSONFileEditor.getValueFromJson("./koil/sys/config.json", "uiRedesign").getAsBoolean()) {
            class_310 client = class_310.method_1551();
            KoilVanillaScreenChrome.renderOptionsShell(context, client, this.field_22789, this.field_22790);


            context.method_51448().method_22903();
            context.method_51448().method_22905(1.5F, 1.5F, 1.0F);
            context.method_51439(this.field_22793, class_2561.method_43470("Options"), 25, 3, new Color(uiColorHeaderTitleText, true).getRGB(), true);
            context.method_51448().method_22909();
            context.method_51439(this.field_22793, this.field_22785, 37, 18, new Color(uiColorHeaderSubTitleText, true).getRGB(), true);
        }
    }
}
