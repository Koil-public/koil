package com.spirit.mixin.client.gui.revamp.listWidget;

import com.spirit.koil.api.util.file.json.JSONFileEditor;
import com.spirit.koil.api.design.KoilListBoundsAccess;
import com.spirit.koil.api.design.KoilScreenBackgrounds;
import com.spirit.koil.api.design.KoilVanillaScreenChrome;
import com.spirit.client.gui.browser.AbstractModrinthContentScreen;
import com.spirit.client.gui.datapack.DatapackScreen;
import com.spirit.client.gui.mod.ModMenuScreen;
import com.spirit.client.gui.resourcepack.ResourcePackMenuScreen;
import com.spirit.client.gui.resourcepack.ResourcepackScreen;
import com.spirit.client.gui.shader.ShaderPackMenuScreen;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_350;
import net.minecraft.class_362;
import net.minecraft.class_404;
import net.minecraft.class_413;
import net.minecraft.class_415;
import net.minecraft.class_4189;
import net.minecraft.class_426;
import net.minecraft.class_4267;
import net.minecraft.class_4280;
import net.minecraft.class_4288;
import net.minecraft.class_429;
import net.minecraft.class_437;
import net.minecraft.class_440;
import net.minecraft.class_443;
import net.minecraft.class_446;
import net.minecraft.class_458;
import net.minecraft.class_4667;
import net.minecraft.class_500;
import net.minecraft.class_5235;
import net.minecraft.class_525;
import net.minecraft.class_526;
import net.minecraft.class_528;
import net.minecraft.class_5375;
import net.minecraft.class_5500;
import net.minecraft.class_6599;
import net.minecraft.class_6777;
import net.minecraft.class_7745;
import net.minecraft.class_7944;
import net.minecraft.class_8134;
import net.minecraft.class_8219;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Overwrite;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.awt.*;

import static com.spirit.koil.api.design.uiColorVal.uiColorNonSelectionHighlight;
import static com.spirit.koil.api.design.uiColorVal.uiColorSelectionHighlight;

@Environment(EnvType.CLIENT)
@Mixin(class_350.class)
public abstract class MixinEntryListWidget<E extends class_4280.class_4281<E>> extends class_362 implements KoilListBoundsAccess {
    @Unique private static final int KOIL_LANGUAGE_HEADER_OFFSET = 15;
    @Unique private static final int KOIL_LANGUAGE_WARNING_CLEARANCE = 8;
    @Shadow protected int left;
    @Shadow protected int width;
    @Shadow protected int top;
    @Shadow protected int bottom;
    @Shadow public abstract int getMaxScroll();
    @Shadow public abstract double getScrollAmount();
    @Shadow public abstract void setScrollAmount(double amount);
    @Shadow protected abstract int getScrollbarPositionX();
    @Unique private boolean koil$draggingScrollbar;
    @Unique private int koil$scrollbarDragOffset;

    @Override
    public int koil$getListTop() {
        return this.top;
    }

    @Override
    public int koil$getListBottom() {
        return this.bottom;
    }

    @Override
    public void koil$setListBounds(int top, int bottom) {
        this.top = top;
        this.bottom = Math.max(top, bottom);
        this.setScrollAmount(Math.min(this.getScrollAmount(), this.getMaxScroll()));
    }

    /**
     * @author SpiritXIV
     * @reason to remove black
     */
    @Overwrite
    protected void drawSelectionHighlight(class_332 context, int y, int entryWidth, int entryHeight, int borderColor, int fillColor) {
        if (JSONFileEditor.getValueFromJson("./koil/sys/config.json", "uiRedesign").getAsBoolean()) {
            if (!koil$usesKoilListRowHighlights()) {
                if (koil$isLanguageOptionsScreen()) {
                    int i = this.left + (this.width - entryWidth) / 2;
                    int j = this.left + (this.width + entryWidth) / 2;
                    context.method_25294(i, y - 2, j, y + entryHeight + 2, borderColor);
                    context.method_25294(i + 1, y - 1, j - 1, y + entryHeight + 1, fillColor);
                }
                return;
            }
            int i = this.left + (this.width - entryWidth) / 2;
            int j = this.left + (this.width + entryWidth) / 2;

            context.method_25294(i - 2, y - 2, j - 10, y + Math.min(entryHeight - 2, 38), new Color(uiColorSelectionHighlight, true).getRGB());
        } else {
            int i = this.left + (this.width - entryWidth) / 2;
            int j = this.left + (this.width + entryWidth) / 2;
            context.method_25294(i, y - 2, j, y + entryHeight + 2, borderColor);
            context.method_25294(i + 1, y - 1, j - 1, y + entryHeight + 1, fillColor);
        }
    }

    protected void drawNonSelectionHighlight(class_332 context, int y, int entryWidth, int entryHeight) {
        if (JSONFileEditor.getValueFromJson("./koil/sys/config.json", "uiRedesign").getAsBoolean()
                && koil$usesKoilListRowHighlights()) {
            int i = this.left + (this.width - entryWidth) / 2;
            int j = this.left + (this.width + entryWidth) / 2;

            context.method_25294(i - 2, y - 2, j - 10, y + Math.min(entryHeight - 2, 38), new Color(uiColorNonSelectionHighlight, true).getRGB());
        }
    }

    @Inject(method = "renderEntry", at = @At("HEAD"))
    protected void onRenderEntry(class_332 context, int mouseX, int mouseY, float delta, int index, int x, int y, int entryWidth, int entryHeight, CallbackInfo ci) {
        if (JSONFileEditor.getValueFromJson("./koil/sys/config.json", "uiRedesign").getAsBoolean()
                && koil$usesKoilListRowHighlights()
                && koil$shouldDrawNonSelectionRow(index)) {
            this.drawNonSelectionHighlight(context, y, entryWidth, entryHeight);
        }
    }

    @Inject(method = "mouseClicked", at = @At("HEAD"), cancellable = true)
    private void koil$beginScrollbarDrag(double mouseX, double mouseY, int button, CallbackInfoReturnable<Boolean> cir) {
        if (button == 0 && koil$canDragScrollbar() && koil$isOverScrollbar(mouseX, mouseY)) {
            this.koil$draggingScrollbar = true;
            int thumbTop = koil$scrollbarThumbTop();
            int thumbHeight = koil$scrollbarThumbHeight();
            if (mouseY >= thumbTop && mouseY <= thumbTop + thumbHeight) {
                this.koil$scrollbarDragOffset = (int) mouseY - thumbTop;
            } else {
                this.koil$scrollbarDragOffset = thumbHeight / 2;
                koil$scrollToThumbTop((int) mouseY - this.koil$scrollbarDragOffset);
            }
            cir.setReturnValue(true);
        }
    }

    @Inject(method = "mouseDragged", at = @At("HEAD"), cancellable = true)
    private void koil$dragScrollbar(double mouseX, double mouseY, int button, double deltaX, double deltaY, CallbackInfoReturnable<Boolean> cir) {
        if (button == 0 && this.koil$draggingScrollbar && koil$canDragScrollbar()) {
            koil$scrollToThumbTop((int) mouseY - this.koil$scrollbarDragOffset);
            cir.setReturnValue(true);
        }
    }

    @Inject(method = "mouseReleased", at = @At("HEAD"))
    private void koil$endScrollbarDrag(double mouseX, double mouseY, int button, CallbackInfoReturnable<Boolean> cir) {
        if (button == 0) {
            this.koil$draggingScrollbar = false;
        }
    }

    @Redirect(
            method = "render",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/client/gui/DrawContext;drawTexture(Lnet/minecraft/util/Identifier;IIFFIIII)V"
            )
    )
    private void koil$renderWorldCreationListPanel(class_332 context, class_2960 texture, int x, int y, float u, float v, int width, int height, int textureWidth, int textureHeight) {
        if (koil$isOptionListPanelScreen()) {
            return;
        }
        if (koil$usesOwnListPanelBackground()) {
            return;
        }
        if (!koil$usesSharedListPanelBackground()) {
            context.method_25290(texture, x, y, u, v, width, height, textureWidth, textureHeight);
            return;
        }
        context.method_25294(x, y, x + width, y + height, 0x65000000);
    }

    @Inject(method = "render", at = @At("HEAD"))
    private void koil$alignOptionListBounds(class_332 context, int mouseX, int mouseY, float delta, CallbackInfo ci) {
        class_310 client = class_310.method_1551();
        if (client == null || client.field_1755 == null || !KoilScreenBackgrounds.uiRedesignEnabled()) {
            return;
        }
        class_437 screen = client.field_1755;
        if (screen instanceof class_6599) {
            boolean hasControllingLayout = FabricLoader.getInstance().getModContainer("controlling").isPresent();
            this.top = Math.max(this.top, KoilVanillaScreenChrome.listTop(hasControllingLayout));
            this.bottom = Math.min(this.bottom, KoilVanillaScreenChrome.keybindListBottom(screen.field_22790, hasControllingLayout));
        } else if (screen instanceof class_426) {
            this.top = Math.max(this.top, KoilVanillaScreenChrome.listTop(false) + KOIL_LANGUAGE_HEADER_OFFSET);
            this.bottom = Math.min(this.bottom, Math.min(KoilVanillaScreenChrome.languageListBottom(screen.field_22790), screen.field_22790 - 56 - KOIL_LANGUAGE_WARNING_CLEARANCE));
        }
    }

    @Inject(method = "getRowWidth", at = @At("HEAD"), cancellable = true)
    private void koil$getSingleplayerWorldRowWidth(CallbackInfoReturnable<Integer> cir) {
        class_310 client = class_310.method_1551();
        if (client != null
                && client.field_1755 instanceof class_526
                && KoilScreenBackgrounds.uiRedesignEnabled()
                && (Object) this instanceof class_528) {
            cir.setReturnValue(this.width - 12);
        }
    }

    @Inject(method = "getRowLeft", at = @At("HEAD"), cancellable = true)
    private void koil$getSingleplayerWorldRowLeft(CallbackInfoReturnable<Integer> cir) {
        class_310 client = class_310.method_1551();
        if (client != null
                && client.field_1755 instanceof class_526
                && KoilScreenBackgrounds.uiRedesignEnabled()
                && (Object) this instanceof class_528) {
            cir.setReturnValue(this.left + 2);
        }
    }

    @Inject(method = "getScrollbarPositionX", at = @At("HEAD"), cancellable = true)
    private void koil$getSingleplayerWorldScrollbarX(CallbackInfoReturnable<Integer> cir) {
        class_310 client = class_310.method_1551();
        if (client != null
                && client.field_1755 instanceof class_526
                && KoilScreenBackgrounds.uiRedesignEnabled()
                && (Object) this instanceof class_528) {
            cir.setReturnValue(this.left + this.width - 11);
        }
    }

    private boolean koil$usesSharedListPanelBackground() {
        class_310 client = class_310.method_1551();
        if (client == null || !KoilScreenBackgrounds.uiRedesignEnabled()) {
            return false;
        }
        class_437 screen = client.field_1755;
        return screen instanceof class_525
                || screen instanceof class_5235
                || screen instanceof class_8134
                || screen instanceof class_413
                || screen instanceof class_415;
    }

    private boolean koil$isOptionListPanelScreen() {
        class_310 client = class_310.method_1551();
        if (client == null || !KoilScreenBackgrounds.uiRedesignEnabled()) {
            return false;
        }
        class_437 screen = client.field_1755;
        return screen instanceof class_429
                || screen instanceof class_4667
                || screen instanceof class_5500
                || screen instanceof class_426
                || screen instanceof class_4189
                || screen instanceof class_404
                || screen instanceof class_458
                || screen instanceof class_6599
                || screen instanceof class_4288
                || screen instanceof class_6777
                || screen instanceof class_440
                || screen instanceof class_443
                || screen instanceof class_446
                || screen instanceof class_7944
                || screen instanceof class_8219;
    }

    private boolean koil$isLanguageOptionsScreen() {
        class_310 client = class_310.method_1551();
        return client != null
                && KoilScreenBackgrounds.uiRedesignEnabled()
                && client.field_1755 instanceof class_426;
    }

    private boolean koil$usesOwnListPanelBackground() {
        class_310 client = class_310.method_1551();
        if (client == null || !KoilScreenBackgrounds.uiRedesignEnabled()) {
            return false;
        }
        class_437 screen = client.field_1755;
        return screen instanceof AbstractModrinthContentScreen
                || screen instanceof class_526
                || screen instanceof class_500
                || screen instanceof ModMenuScreen
                || screen instanceof ResourcePackMenuScreen
                || screen instanceof ShaderPackMenuScreen
                || screen instanceof ResourcepackScreen
                || screen instanceof DatapackScreen
                || screen instanceof class_5375;
    }

    private boolean koil$usesKoilListRowHighlights() {
        class_310 client = class_310.method_1551();
        if (client == null || !KoilScreenBackgrounds.uiRedesignEnabled()) {
            return false;
        }
        class_437 screen = client.field_1755;
        return screen instanceof ModMenuScreen
                || screen instanceof ResourcePackMenuScreen
                || screen instanceof ShaderPackMenuScreen
                || screen instanceof class_500
                || screen instanceof class_526
                || screen instanceof class_525
                || screen instanceof class_5235
                || screen instanceof class_8134
                || screen instanceof class_413
                || screen instanceof class_415
                || screen instanceof class_5375
                || screen instanceof class_7745;
    }

    private boolean koil$usesDraggableScrollbar() {
        class_310 client = class_310.method_1551();
        if (client == null) {
            return false;
        }
        class_437 screen = client.field_1755;
        return screen instanceof AbstractModrinthContentScreen
                || screen instanceof ResourcepackScreen
                || screen instanceof DatapackScreen
                || screen instanceof class_526
                || screen instanceof class_500
                || screen instanceof ResourcePackMenuScreen
                || screen instanceof class_5375
                || screen instanceof ShaderPackMenuScreen
                || screen instanceof ModMenuScreen;
    }

    private boolean koil$canDragScrollbar() {
        return koil$usesDraggableScrollbar() && this.getMaxScroll() > 0;
    }

    private boolean koil$isOverScrollbar(double mouseX, double mouseY) {
        int scrollbarX = this.getScrollbarPositionX();
        return mouseY >= this.top
                && mouseY <= this.bottom
                && mouseX >= scrollbarX - 6
                && mouseX <= scrollbarX + 12;
    }

    private int koil$scrollbarThumbHeight() {
        int trackHeight = Math.max(1, this.bottom - this.top);
        int maxScroll = Math.max(1, this.getMaxScroll());
        return Math.max(18, (int) ((trackHeight / (float) (trackHeight + maxScroll)) * trackHeight));
    }

    private int koil$scrollbarThumbTop() {
        int trackHeight = Math.max(1, this.bottom - this.top);
        int thumbHeight = koil$scrollbarThumbHeight();
        int thumbTravel = Math.max(1, trackHeight - thumbHeight);
        return this.top + (int) ((this.getScrollAmount() / (float) this.getMaxScroll()) * thumbTravel);
    }

    private void koil$scrollToThumbTop(int thumbTop) {
        int trackHeight = Math.max(1, this.bottom - this.top);
        int thumbHeight = koil$scrollbarThumbHeight();
        int minTop = this.top;
        int maxTop = this.bottom - thumbHeight;
        int clampedTop = Math.max(minTop, Math.min(maxTop, thumbTop));
        int thumbTravel = Math.max(1, trackHeight - thumbHeight);
        double progress = (clampedTop - minTop) / (double) thumbTravel;
        this.setScrollAmount(progress * this.getMaxScroll());
    }

    private boolean koil$isMultiplayerScreen() {
        class_310 client = class_310.method_1551();
        return client != null && client.field_1755 instanceof class_500;
    }

    private boolean koil$shouldDrawNonSelectionRow(int index) {
        class_350<?> list = (class_350<?>) (Object) this;
        if (index < 0 || index >= list.method_25396().size()) {
            return false;
        }
        Object entry = list.method_25396().get(index);
        class_310 client = class_310.method_1551();
        if (client != null && client.field_1755 instanceof class_500) {
            return entry instanceof class_4267.class_4270
                    || entry instanceof class_4267.class_4269;
        }
        return true;
    }
}
