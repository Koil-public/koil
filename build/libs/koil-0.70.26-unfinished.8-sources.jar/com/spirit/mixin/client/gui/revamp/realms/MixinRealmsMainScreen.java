package com.spirit.mixin.client.gui.revamp.realms;

import com.google.gson.JsonElement;
import com.spirit.koil.api.design.KoilScreenBackgrounds;
import com.spirit.koil.api.util.file.json.JSONFileEditor;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_4325;
import net.minecraft.class_437;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Environment(EnvType.CLIENT)
@Mixin(class_4325.class)
public abstract class MixinRealmsMainScreen extends class_437 {
    protected MixinRealmsMainScreen(class_2561 title) {
        super(title);
    }

    @Inject(
            method = "render",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/client/realms/gui/screen/RealmsMainScreen;renderBackground(Lnet/minecraft/client/gui/DrawContext;)V",
                    shift = At.Shift.AFTER
            )
    )
    private void koil$renderRealmsBackground(class_332 context, int mouseX, int mouseY, float delta, CallbackInfo ci) {
        if (!koil$isUiRedesignEnabled()) {
            return;
        }
        class_310 client = class_310.method_1551();
        KoilScreenBackgrounds.render(context, client, this.field_22789, this.field_22790);
        context.method_25294(0, 0, this.field_22789, this.field_22790, KoilScreenBackgrounds.overlayColor(client));
    }

    private boolean koil$isUiRedesignEnabled() {
        try {
            JsonElement element = JSONFileEditor.getValueFromJson("./koil/sys/config.json", "uiRedesign");
            return element != null && element.isJsonPrimitive() && element.getAsBoolean();
        } catch (Exception ignored) {
            return false;
        }
    }
}
