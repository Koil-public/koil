package com.spirit.mixin.client.gui.revamp;

import com.spirit.koil.api.design.DesignLoader;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_7065;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_7065.class)
public class MixinWarningScreen {
    @Inject(method = "render", at = @At("HEAD"))
    private void onRender(class_332 context, int mouseX, int mouseY, float delta, CallbackInfo info) {
        class_310 client = class_310.method_1551();
        if (client == null || client.field_1687 != null) {
            return;
        }
        context.method_25293(DesignLoader.getLoadingTexture(), 0, 0, client.method_22683().method_4486(), client.method_22683().method_4502(), 0.0F, 0.0F, 319, 192, 319, 192);


    }
}
