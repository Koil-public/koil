package com.spirit.mixin.client.gui.revamp.multiplayer;

import com.spirit.koil.api.design.DesignLoader;
import it.unimi.dsi.fastutil.booleans.BooleanConsumer;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_4185;
import net.minecraft.class_420;
import net.minecraft.class_437;
import net.minecraft.class_5244;
import net.minecraft.class_642;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Overwrite;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_420.class)
public abstract class MixinDirectConnectScreen extends class_437 {
    @Shadow private class_342 addressField;
    @Shadow protected abstract void onAddressFieldChanged();
    @Shadow private class_4185 selectServerButton;
    @Shadow protected abstract void saveAndClose();
    @Shadow @Final private BooleanConsumer callback;
    @Shadow @Final private class_642 serverEntry;

    protected MixinDirectConnectScreen(class_2561 title) {
        super(title);
    }

    /**
     * @author SpiritXIV
     * @reason a :)
     */
    @Overwrite
    protected void method_25426() {
        this.addressField = new class_342(this.field_22793, this.field_22789 / 2 - 100, 116, 200, 20, class_2561.method_43471("addServer.enterIp"));
        this.addressField.method_1880(128);
        assert this.field_22787 != null;
        this.addressField.method_1852(this.field_22787.field_1690.field_1864);
        this.addressField.method_1863((text) -> this.onAddressFieldChanged());
        this.method_25429(this.addressField);
        this.selectServerButton = this.method_37063(class_4185.method_46430(class_2561.method_43471("selectServer.select"), (button) -> this.saveAndClose()).method_46434(this.field_22789 / 2 - 100, this.field_22790 / 4 + 76 + 12, 200, 20).method_46431());
        this.method_37063(class_4185.method_46430(class_2561.method_43470("Join from Clipboard"), (button) -> this.joinFromClipboard()).method_46434(this.field_22789 / 2 - 100, this.field_22790 / 4 + 100 + 12, 200, 20).method_46431());
        this.method_37063(class_4185.method_46430(class_5244.field_24335, (button) -> this.callback.accept(false)).method_46434(this.field_22789 / 2 - 100, this.field_22790 / 4 + 134 + 12, 200, 20).method_46431());
        this.method_48265(this.addressField);
        this.onAddressFieldChanged();
    }

    private void joinFromClipboard() {
        this.serverEntry.field_3761 = class_310.method_1551().field_1774.method_1460();
        this.callback.accept(true);
    }

    @Inject(method = "render", at = @At("HEAD"))
    private void onRender(class_332 context, int mouseX, int mouseY, float delta, CallbackInfo info) {
        class_310 client = class_310.method_1551();
        client.method_1531().method_22813(DesignLoader.getLoadingTexture());
        context.method_25293(DesignLoader.getLoadingTexture(), 0, 0, client.method_22683().method_4486(), client.method_22683().method_4502(), 0.0F, 0.0F, 319, 192, 319, 192);
    }
}
