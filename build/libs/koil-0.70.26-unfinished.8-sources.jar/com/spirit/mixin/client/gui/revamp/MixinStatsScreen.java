package com.spirit.mixin.client.gui.revamp;

import com.spirit.koil.api.design.KoilVanillaScreenChrome;
import com.spirit.koil.api.stats.global.*;
import com.spirit.koil.api.util.file.json.JSONFileEditor;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1074;
import net.minecraft.class_1109;
import net.minecraft.class_1299;
import net.minecraft.class_156;
import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_1802;
import net.minecraft.class_2248;
import net.minecraft.class_2561;
import net.minecraft.class_2799;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_339;
import net.minecraft.class_3417;
import net.minecraft.class_342;
import net.minecraft.class_3445;
import net.minecraft.class_3448;
import net.minecraft.class_3468;
import net.minecraft.class_3469;
import net.minecraft.class_364;
import net.minecraft.class_4068;
import net.minecraft.class_4185;
import net.minecraft.class_4280;
import net.minecraft.class_437;
import net.minecraft.class_447;
import net.minecraft.class_5250;
import net.minecraft.class_7923;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.awt.*;
import java.util.*;

import static com.spirit.koil.api.design.uiColorVal.*;
import static net.minecraft.class_452.field_2668;

@Environment(EnvType.CLIENT)
@Mixin(class_447.class)
public abstract class MixinStatsScreen extends class_437 {
    @Unique private static final class_2561 KOIL_DOWNLOADING_STATS_TEXT = class_2561.method_43471("multiplayer.downloadingStats");
    @Unique private static final String KOIL_PAGE_GENERAL = "general";
    @Unique private static final String KOIL_PAGE_ITEMS = "items";
    @Unique private static final String KOIL_PAGE_MOBS = "mobs";
    @Unique private static final String KOIL_PAGE_GLOBAL = "global";
    @Unique private static final int KOIL_HEADER_HEIGHT = 36;
    @Unique private static final int KOIL_FOOTER_HEIGHT = 35;
    @Unique private static final int KOIL_CONTENT_INSET = 35;
    @Unique private static final class_2960 KOIL_PLAY_TIME_ID = new class_2960("minecraft", "play_time");
    @Unique private static final class_2960 KOIL_DEATHS_ID = new class_2960("minecraft", "deaths");
    @Unique private static final class_2960 KOIL_MOB_KILLS_ID = new class_2960("minecraft", "mob_kills");
    @Unique private static final class_2960 KOIL_PLAYER_KILLS_ID = new class_2960("minecraft", "player_kills");
    @Unique private static final class_2960 KOIL_DAMAGE_DEALT_ID = new class_2960("minecraft", "damage_dealt");
    @Unique private static final class_2960 KOIL_DAMAGE_TAKEN_ID = new class_2960("minecraft", "damage_taken");
    @Unique private static final class_2960 KOIL_JUMP_ID = new class_2960("minecraft", "jump");
    @Unique private static final class_2960 KOIL_WALK_ONE_CM_ID = new class_2960("minecraft", "walk_one_cm");
    @Unique private static final class_2960 KOIL_CROUCH_ONE_CM_ID = new class_2960("minecraft", "crouch_one_cm");
    @Unique private static final class_2960 KOIL_SPRINT_ONE_CM_ID = new class_2960("minecraft", "sprint_one_cm");
    @Unique private static final class_2960 KOIL_SWIM_ONE_CM_ID = new class_2960("minecraft", "swim_one_cm");
    @Unique private static final class_2960 KOIL_FALL_ONE_CM_ID = new class_2960("minecraft", "fall_one_cm");
    @Unique private static final class_2960 KOIL_CLIMB_ONE_CM_ID = new class_2960("minecraft", "climb_one_cm");
    @Unique private static final class_2960 KOIL_FLY_ONE_CM_ID = new class_2960("minecraft", "fly_one_cm");
    @Unique private static final class_2960 KOIL_WALK_ON_WATER_ONE_CM_ID = new class_2960("minecraft", "walk_on_water_one_cm");
    @Unique private static final class_2960 KOIL_WALK_UNDER_WATER_ONE_CM_ID = new class_2960("minecraft", "walk_under_water_one_cm");
    @Unique private static final class_2960 KOIL_MINECART_ONE_CM_ID = new class_2960("minecraft", "minecart_one_cm");
    @Unique private static final class_2960 KOIL_BOAT_ONE_CM_ID = new class_2960("minecraft", "boat_one_cm");
    @Unique private static final class_2960 KOIL_PIG_ONE_CM_ID = new class_2960("minecraft", "pig_one_cm");
    @Unique private static final class_2960 KOIL_HORSE_ONE_CM_ID = new class_2960("minecraft", "horse_one_cm");
    @Unique private static final class_2960 KOIL_AVIATE_ONE_CM_ID = new class_2960("minecraft", "aviate_one_cm");
    @Unique private static final class_2960 KOIL_STRIDER_ONE_CM_ID = new class_2960("minecraft", "strider_one_cm");

    @Shadow @Final class_3469 statHandler;
    @Shadow private boolean downloadingStats;

    @Unique private final Map<class_339, int[]> koil$originalWidgetPositions = new IdentityHashMap<>();
    @Unique private final Map<String, Boolean> koil$expandedGlobalRows = new HashMap<>();
    @Unique private final Map<String, int[]> koil$globalRowRects = new HashMap<>();
    @Unique private final Map<String, Boolean> koil$expandedGlobalGroups = new HashMap<>();
    @Unique private final Map<String, int[]> koil$globalGroupHeaderRects = new HashMap<>();
    @Unique private final Map<String, int[]> koil$stockFilterRects = new LinkedHashMap<>();
    @Unique private final Map<String, int[]> koil$stockDropdownOptionRects = new LinkedHashMap<>();
    @Unique private int koil$statsScrollOffset;
    @Unique private int koil$statsScrollMax;
    @Unique private int koil$statsViewportX = -1;
    @Unique private int koil$statsViewportY = -1;
    @Unique private int koil$statsViewportWidth;
    @Unique private int koil$statsViewportHeight;
    @Unique private boolean koil$statsScrollbarDragging;
    @Unique private int koil$statsScrollbarDragOffset;
    @Unique private int koil$statsFooterTop = -1;
    @Unique private String koil$activePage = KOIL_PAGE_GENERAL;
    @Unique private class_4185 koil$globalButton;
    @Unique private class_342 koil$searchBox;
    @Unique private List<class_2561> koil$hoverTooltipLines = Collections.emptyList();
    @Unique private long koil$rowCacheTimeMs;
    @Unique private String koil$rowCacheKey = "";
    @Unique private List<Object[]> koil$cachedGeneralRows = Collections.emptyList();
    @Unique private List<Object[]> koil$cachedItemRows = Collections.emptyList();
    @Unique private List<Object[]> koil$cachedEntityRows = Collections.emptyList();
    @Unique private List<KoilGlobalActivityRow> koil$cachedMarketRows = Collections.emptyList();
    @Unique private List<KoilGlobalActivityRow> koil$cachedImportantRows = Collections.emptyList();
    @Unique private List<KoilGlobalActivityRow> koil$cachedDeveloperRows = Collections.emptyList();
    @Unique private List<KoilGlobalMarketViewRow> koil$cachedHeadMarketRows = Collections.emptyList();
    @Unique private List<KoilGlobalMarketViewRow> koil$cachedSubMarketRows = Collections.emptyList();
    @Unique private List<KoilGlobalMarketViewRow> koil$cachedRawMarketRows = Collections.emptyList();
    @Unique private List<KoilGlobalMarketViewRow> koil$cachedDevMarketRows = Collections.emptyList();
    @Unique private List<KoilGlobalMarketViewRow> koil$cachedAllMarketValueRows = Collections.emptyList();
    @Unique private Map<String, KoilGlobalActivityRow> koil$cachedGlobalRowsByMetric = Collections.emptyMap();
    @Unique private Map<String, KoilMarketValueQuote> koil$cachedMarketQuotes = Collections.emptyMap();
    @Unique private Map<String, List<KoilGlobalActivityRow>> koil$cachedMarketComponents = Collections.emptyMap();
    @Unique private Map<String, int[]> koil$cachedMarketPressureSeries = Collections.emptyMap();
    @Unique private Map<String, List<Object[]>> koil$cachedSyntheticSeries = Collections.emptyMap();
    @Unique private Map<String, int[]> koil$cachedMiniPreviewSeries = Collections.emptyMap();
    @Unique private List<Object[]> koil$cachedOverviewCards = Collections.emptyList();
    @Unique private String koil$generalCacheKey = "";
    @Unique private String koil$itemCacheKey = "";
    @Unique private String koil$entityCacheKey = "";
    @Unique private String koil$globalCacheKey = "";
    @Unique private long koil$lastFingerprintScanMs;
    @Unique private int koil$cachedLiveVanillaStatsFingerprint = Integer.MIN_VALUE;
    @Unique private int koil$cachedGeneralCount;
    @Unique private int koil$cachedItemCount;
    @Unique private int koil$cachedEntityCount;
    @Unique private int koil$cachedGlobalCount;
    @Unique private int koil$cachedGeneralMax = 1;
    @Unique private int koil$cachedItemMax = 1;
    @Unique private int koil$cachedEntityMax = 1;
    @Unique private long koil$lastLiveVanillaStatsRequestMs;
    @Unique private long koil$lastGlobalSnapshotRequestMs;
    @Unique private String koil$stockGraphInterval = KoilMarketSeriesWindow.activeKey();
    @Unique private int koil$stockDropdownX = -1;
    @Unique private int koil$stockDropdownY = -1;
    @Unique private int koil$stockDropdownWidth = 0;
    @Unique private int koil$stockDropdownHeight = 20;
    @Unique private int koil$stockDropdownPopupX = -1;
    @Unique private int koil$stockDropdownPopupY = -1;
    @Unique private boolean koil$stockDropdownOpen;
    @Unique private int koil$lastLiveVanillaStatsFingerprint = Integer.MIN_VALUE;

    protected MixinStatsScreen(class_2561 title) {
        super(title);
    }

    @Shadow
    @Nullable
    public abstract class_4280<?> getSelectedStatList();

    @Inject(method = "createButtons", at = @At("TAIL"))
    private void koil$addGlobalButton(CallbackInfo info) {
        if (this.koil$searchBox == null) {
            this.koil$searchBox = this.method_37063(new class_342(this.field_22793, this.field_22789 - 210, 8, 176, 20, class_2561.method_43470("Search")));
            this.koil$searchBox.method_1880(128);
            this.koil$searchBox.method_1863(value -> {
                this.koil$statsScrollOffset = 0;
                koil$invalidateRowCache();
            });
        }

        if (this.koil$globalButton != null) {
            return;
        }

        this.koil$globalButton = this.method_37063(class_4185.method_46430(class_2561.method_43470("Global"), button -> {
            this.koil$activePage = KOIL_PAGE_GLOBAL;
            this.koil$statsScrollOffset = 0;
            this.koil$statsScrollbarDragging = false;
            koil$invalidateRowCache();
        }).method_46434(this.field_22789 / 2 + 126, this.field_22790 - 52, 80, 20).method_46431());
    }

    @Inject(method = "shouldPause", at = @At("HEAD"), cancellable = true)
    private void koil$statsShouldNotPause(CallbackInfoReturnable<Boolean> info) {
        if (koil$isKoilRedesignEnabled()) {
            info.setReturnValue(false);
        }
    }

    @Inject(method = "selectStatList", at = @At("TAIL"))
    private void koil$captureSelectedStatList(@Nullable class_4280<?> list, CallbackInfo info) {
        String detectedPage = koil$pageFromList(list);

        if (!detectedPage.isBlank()) {
            this.koil$activePage = detectedPage;
            this.koil$statsScrollOffset = 0;
            this.koil$statsScrollbarDragging = false;
            koil$invalidateRowCache();
        }
    }

    @Inject(method = "render", at = @At("HEAD"), cancellable = true)
    private void koil$renderStatsRedesign(class_332 context, int mouseX, int mouseY, float delta, CallbackInfo info) {
        if (!koil$isKoilRedesignEnabled()) {
            koil$restoreVanillaWidgetPositions();
            if (this.koil$searchBox != null) {
                this.koil$searchBox.field_22764 = false;
            }
            this.koil$statsScrollbarDragging = false;
            return;
        }

        if (this.koil$searchBox != null) {
            this.koil$searchBox.field_22764 = true;
        }
        koil$positionRedesignButtons();
        koil$positionSearchBox();
        koil$positionStockDropdown();
        koil$renderFrameOnly(context);
        KoilVanillaScreenChrome.renderTitle(context, this.field_22793, class_2561.method_43470("Statistics"), null);

        if (this.downloadingStats) {
            koil$renderDownloadingStats(context);
        } else {
            koil$requestLiveVanillaStatsIfNeeded();
            koil$renderStatsPanel(context, class_310.method_1551(), mouseX, mouseY);
            koil$renderRedesignChildren(context, mouseX, mouseY, delta);
            koil$renderStockDropdown(context, mouseX, mouseY);
            koil$renderStockDropdownOptions(context, mouseX, mouseY);
            koil$renderHoverTooltip(context, mouseX, mouseY);
        }

        info.cancel();
    }

    @Unique
    private boolean koil$isKoilRedesignEnabled() {
        try {
            return JSONFileEditor.getValueFromJson("./koil/sys/config.json", "uiRedesign").getAsBoolean();
        } catch (Exception ignored) {
            return false;
        }
    }

    @Unique
    private void koil$renderFrameOnly(class_332 context) {
        int footerTop = Math.max(KOIL_HEADER_HEIGHT, this.field_22790 - KOIL_FOOTER_HEIGHT);
        int headerColor = koil$color(uiColorHeader);
        int headerStripe = koil$color(uiColorHeaderStripe);
        int footerColor = koil$color(uiColorFooter);
        int footerStripe = koil$color(uiColorFooterStripe);
        int panelColor = koil$color(uiColorContentBase);
        int borderColor = koil$color(uiColorBackgroundBorder);
        int stripeLeft = koil$color(uiColorContentStripeLeft);
        int stripeRight = koil$color(uiColorContentStripeRight);

        context.method_25294(0, 0, this.field_22789, KOIL_HEADER_HEIGHT, headerColor);
        context.method_25294(0, KOIL_HEADER_HEIGHT - 3, this.field_22789, KOIL_HEADER_HEIGHT, headerStripe);
        context.method_25294(0, footerTop, this.field_22789, this.field_22790, footerColor);
        context.method_25294(0, footerTop, this.field_22789, Math.min(this.field_22790, footerTop + 3), footerStripe);

        if (this.field_22789 > KOIL_CONTENT_INSET * 2 && footerTop > KOIL_HEADER_HEIGHT) {
            int left = KOIL_CONTENT_INSET;
            int right = this.field_22789 - KOIL_CONTENT_INSET;
            context.method_25294(left, KOIL_HEADER_HEIGHT, right, footerTop, panelColor);
            context.method_49601(left, KOIL_HEADER_HEIGHT, right - left, footerTop - KOIL_HEADER_HEIGHT, borderColor);
            context.method_25294(left + 2, KOIL_HEADER_HEIGHT, left + 4, footerTop, stripeLeft);
            context.method_25294(right - 4, KOIL_HEADER_HEIGHT, right - 2, footerTop, stripeRight);
        }
    }

    @Unique
    private void koil$positionRedesignButtons() {
        List<class_339> widgets = new ArrayList<>();

        for (class_364 child : this.method_25396()) {
            if (!(child instanceof class_339 widget) || !widget.field_22764 || widget == this.koil$searchBox) {
                continue;
            }

            this.koil$originalWidgetPositions.putIfAbsent(widget, new int[]{widget.method_46426(), widget.method_46427()});
            widgets.add(widget);
        }

        if (widgets.isEmpty()) {
            this.koil$statsFooterTop = this.field_22790 - KOIL_FOOTER_HEIGHT;
            return;
        }

        if (this.koil$globalButton != null) {
            this.koil$globalButton.field_22763 = !KOIL_PAGE_GLOBAL.equals(this.koil$activePage);
        }

        int gap = 8;
        int maxRowWidth = Math.max(120, this.field_22789 - 76);
        List<List<class_339>> rows = new ArrayList<>();
        List<class_339> currentRow = new ArrayList<>();
        int currentWidth = 0;

        for (class_339 widget : widgets) {
            int nextWidth = currentRow.isEmpty() ? widget.method_25368() : currentWidth + gap + widget.method_25368();

            if (!currentRow.isEmpty() && nextWidth > maxRowWidth) {
                rows.add(currentRow);
                currentRow = new ArrayList<>();
                currentWidth = 0;
            }

            currentRow.add(widget);
            currentWidth = currentWidth == 0 ? widget.method_25368() : currentWidth + gap + widget.method_25368();
        }

        if (!currentRow.isEmpty()) {
            rows.add(currentRow);
        }

        int rowHeight = 20;

        for (class_339 widget : widgets) {
            rowHeight = Math.max(rowHeight, widget.method_25364());
        }

        int totalHeight = rows.size() * rowHeight + Math.max(0, rows.size() - 1) * gap;
        int footerTop = Math.max(KOIL_HEADER_HEIGHT, this.field_22790 - KOIL_FOOTER_HEIGHT);
        int startY = Math.max(footerTop + 7, this.field_22790 - 7 - totalHeight);
        this.koil$statsFooterTop = footerTop;

        for (int rowIndex = 0; rowIndex < rows.size(); rowIndex++) {
            List<class_339> row = rows.get(rowIndex);
            int rowWidth = -gap;

            for (class_339 widget : row) {
                rowWidth += widget.method_25368() + gap;
            }

            int x = Math.max(8, (this.field_22789 - rowWidth) / 2);
            int y = startY + rowIndex * (rowHeight + gap);

            for (class_339 widget : row) {
                widget.method_46421(x);
                widget.method_46419(y);
                x += widget.method_25368() + gap;
            }
        }
    }

    @Unique
    private void koil$positionSearchBox() {
        if (this.koil$searchBox == null) {
            return;
        }

        int boxWidth = Math.min(180, Math.max(96, this.field_22789 / 4));
        this.koil$searchBox.method_46421(this.field_22789 - boxWidth - 35);
        this.koil$searchBox.method_46419(8);
        this.koil$searchBox.method_25358(boxWidth);
    }

    @Unique
    private void koil$positionStockDropdown() {
        this.koil$stockGraphInterval = KoilMarketSeriesWindow.activeKey();
        int labelWidth = this.field_22793 == null ? 116 : this.field_22793.method_1727(koil$stockDropdownLabel()) + 14;
        int buttonWidth = Math.max(92, labelWidth);
        int searchX = this.koil$searchBox == null ? this.field_22789 - 215 : this.koil$searchBox.method_46426();
        this.koil$stockDropdownWidth = Math.min(142, buttonWidth);
        this.koil$stockDropdownHeight = 20;
        this.koil$stockDropdownX = Math.max(8, searchX - this.koil$stockDropdownWidth - 6);
        this.koil$stockDropdownY = 8;
    }

    @Unique
    private String koil$stockDropdownLabel() {
        return "Range: " + KoilMarketSeriesWindow.label(this.koil$stockGraphInterval);
    }

    @Unique
    private void koil$renderStockDropdown(class_332 context, int mouseX, int mouseY) {
        if (!KOIL_PAGE_GLOBAL.equals(this.koil$activePage) || this.koil$stockDropdownX < 0 || this.koil$stockDropdownWidth <= 0) {
            this.koil$stockDropdownOpen = false;
            this.koil$stockDropdownPopupX = -1;
            this.koil$stockDropdownPopupY = -1;
            return;
        }

        boolean hovered = koil$isMouseInsideRawRect(mouseX, mouseY, this.koil$stockDropdownX, this.koil$stockDropdownY, this.koil$stockDropdownWidth, this.koil$stockDropdownHeight);
        int fill = hovered || this.koil$stockDropdownOpen ? koil$withAlpha(uiColorContentBase, 245) : koil$color(uiColorContentBase);
        int border = koil$color(uiColorBackgroundBorder);
        int text = koil$color(uiColorContentBaseTitleText);
        String label = koil$ellipsize(koil$stockDropdownLabel(), this.koil$stockDropdownWidth - 14);
        context.method_25294(this.koil$stockDropdownX, this.koil$stockDropdownY, this.koil$stockDropdownX + this.koil$stockDropdownWidth, this.koil$stockDropdownY + this.koil$stockDropdownHeight, fill);
        context.method_49601(this.koil$stockDropdownX, this.koil$stockDropdownY, this.koil$stockDropdownWidth, this.koil$stockDropdownHeight, border);
        context.method_51439(this.field_22793, class_2561.method_43470(label), this.koil$stockDropdownX + 7, this.koil$stockDropdownY + 6, text, false);
    }

    @Unique
    private String[] koil$stockFilterKeys() {
        return new String[]{KoilMarketSeriesWindow.TODAY, KoilMarketSeriesWindow.THREE_DAYS, KoilMarketSeriesWindow.SEVEN_DAYS, KoilMarketSeriesWindow.ALL};
    }

    @Unique
    private void koil$renderStockDropdownOptions(class_332 context, int mouseX, int mouseY) {
        this.koil$stockDropdownOptionRects.clear();

        if (!KOIL_PAGE_GLOBAL.equals(this.koil$activePage) || !this.koil$stockDropdownOpen || this.koil$stockDropdownX < 0) {
            return;
        }

        String[] keys = koil$stockFilterKeys();
        int menuWidth = this.koil$stockDropdownWidth;

        for (String key : keys) {
            menuWidth = Math.max(menuWidth, this.field_22793.method_1727(KoilMarketSeriesWindow.label(key)) + 16);
        }

        menuWidth = Math.min(164, Math.max(92, menuWidth));
        int rowHeight = 18;
        int menuHeight = keys.length * rowHeight + 8;
        int anchorX = this.koil$stockDropdownPopupX >= 0 ? this.koil$stockDropdownPopupX : this.koil$stockDropdownX;
        int anchorY = this.koil$stockDropdownPopupY >= 0 ? this.koil$stockDropdownPopupY : this.koil$stockDropdownY + this.koil$stockDropdownHeight + 3;
        int menuX = Math.max(8, Math.min(anchorX, this.field_22789 - menuWidth - 8));
        int menuY = Math.max(8, Math.min(anchorY, this.field_22790 - menuHeight - 8));

        context.method_51448().method_22903();
        context.method_51448().method_46416(0.0F, 0.0F, 4096.0F);
        context.method_25294(menuX + 2, menuY + 3, menuX + menuWidth + 3, menuY + menuHeight + 4, 0x66000000);
        context.method_25294(menuX, menuY, menuX + menuWidth, menuY + menuHeight, koil$withAlpha(uiColorContentBase, 245));
        context.method_49601(menuX, menuY, menuWidth, menuHeight, koil$color(uiColorBackgroundBorder));

        for (int i = 0; i < keys.length; i++) {
            String key = keys[i];
            String normalized = KoilMarketSeriesWindow.normalize(key);
            String label = KoilMarketSeriesWindow.label(key);
            int rowY = menuY + 4 + i * rowHeight;
            int rowText = koil$color(uiColorContentBaseTitleText);

            context.method_51439(this.field_22793, class_2561.method_43470(label), menuX + 7, rowY + 5, rowText, false);
            this.koil$stockDropdownOptionRects.put(normalized, new int[]{menuX + 1, rowY, menuWidth - 2, rowHeight});
        }

        context.method_51448().method_22909();
    }

    @Unique
    private boolean koil$applyStockDropdownSelection(@Nullable String key) {
        if (key == null || key.isBlank()) {
            return false;
        }

        this.koil$stockGraphInterval = KoilMarketSeriesWindow.normalize(key);
        KoilMarketSeriesWindow.setActiveKey(this.koil$stockGraphInterval);
        this.koil$stockDropdownOpen = false;
        this.koil$stockDropdownPopupX = -1;
        this.koil$stockDropdownPopupY = -1;
        this.koil$statsScrollOffset = 0;
        koil$invalidateRowCache();
        return true;
    }

    @Unique
    private void koil$restoreVanillaWidgetPositions() {
        for (Map.Entry<class_339, int[]> entry : this.koil$originalWidgetPositions.entrySet()) {
            class_339 widget = entry.getKey();
            int[] position = entry.getValue();
            widget.method_46421(position[0]);
            widget.method_46419(position[1]);
        }
    }

    @Unique
    private void koil$renderRedesignChildren(class_332 context, int mouseX, int mouseY, float delta) {
        for (class_364 child : this.method_25396()) {
            if (child instanceof class_4280) {
                continue;
            }

            if (child instanceof class_4068 drawable) {
                drawable.method_25394(context, mouseX, mouseY, delta);
            }
        }
    }

    @Unique
    private void koil$renderDownloadingStats(class_332 context) {
        int x = KOIL_CONTENT_INSET + 12;
        int y = KOIL_HEADER_HEIGHT + 24;
        int width = Math.max(120, this.field_22789 - KOIL_CONTENT_INSET * 2 - 24);
        String stage = field_2668[(int) (class_156.method_658() / 150L % field_2668.length)];

        context.method_27534(this.field_22793, KOIL_DOWNLOADING_STATS_TEXT, this.field_22789 / 2, y + 6, 0xFFFFFFFF);
        context.method_25300(this.field_22793, stage, this.field_22789 / 2, y + 24, 0xFFB8C7D6);

        int barX = x + 12;
        int barY = y + 44;
        int barWidth = width - 24;
        int filled = (int) ((class_156.method_658() % 1600L) / 1600.0F * barWidth);

        context.method_25294(barX, barY, barX + barWidth, barY + 4, 0x88000000);
        context.method_25294(barX, barY, barX + Math.max(6, filled), barY + 4, 0xFF8FC5FF);
    }


    @Unique
    private void koil$requestGlobalSnapshotIfNeeded() {
        if (!KOIL_PAGE_GLOBAL.equals(this.koil$activePage)) {
            return;
        }

        long now = class_156.method_658();

        if (now - this.koil$lastGlobalSnapshotRequestMs < 1500L) {
            return;
        }

        this.koil$lastGlobalSnapshotRequestMs = now;
        GlobalActivityClient.requestServerSnapshot();
    }

    @Unique
    private void koil$renderStatsPanel(class_332 context, class_310 client, int mouseX, int mouseY) {
        this.koil$hoverTooltipLines = Collections.emptyList();
        koil$requestGlobalSnapshotIfNeeded();
        koil$refreshRowCache();
        int panelLeft = KOIL_CONTENT_INSET;
        int panelRight = this.field_22789 - KOIL_CONTENT_INSET;
        int panelTop = KOIL_HEADER_HEIGHT;
        int panelBottom = Math.max(panelTop + 80, this.koil$statsFooterTop);
        int contentX = panelLeft + 12;
        int contentWidth = Math.max(80, panelRight - panelLeft - 24);
        int cursorY = panelTop + 8;

        this.koil$globalRowRects.clear();
        this.koil$globalGroupHeaderRects.clear();
        this.koil$stockFilterRects.clear();
        this.koil$stockGraphInterval = KoilMarketSeriesWindow.activeKey();
        cursorY = koil$renderContextLine(context, contentX, cursorY, contentWidth, client);
        cursorY = koil$renderSummaryStrip(context, contentX, cursorY + 6, contentWidth);
        cursorY = koil$renderSectionHeader(context, contentX, cursorY + 7, contentWidth);

        this.koil$statsViewportX = contentX;
        this.koil$statsViewportY = cursorY + 5;
        this.koil$statsViewportWidth = contentWidth;
        this.koil$statsViewportHeight = Math.max(34, panelBottom - 8 - this.koil$statsViewportY);

        context.method_44379(this.koil$statsViewportX, this.koil$statsViewportY, this.koil$statsViewportX + this.koil$statsViewportWidth, this.koil$statsViewportY + this.koil$statsViewportHeight);

        int contentHeight;

        if (KOIL_PAGE_ITEMS.equals(this.koil$activePage)) {
            contentHeight = koil$renderItemRows(context, this.koil$statsViewportX, this.koil$statsViewportY - this.koil$statsScrollOffset, this.koil$statsViewportWidth - 8, mouseX, mouseY);
        } else if (KOIL_PAGE_MOBS.equals(this.koil$activePage)) {
            contentHeight = koil$renderEntityRows(context, this.koil$statsViewportX, this.koil$statsViewportY - this.koil$statsScrollOffset, this.koil$statsViewportWidth - 8, mouseX, mouseY);
        } else if (KOIL_PAGE_GLOBAL.equals(this.koil$activePage)) {
            contentHeight = koil$renderGlobalRows(context, this.koil$statsViewportX, this.koil$statsViewportY - this.koil$statsScrollOffset, this.koil$statsViewportWidth - 8, mouseX, mouseY);
        } else {
            contentHeight = koil$renderGeneralRows(context, this.koil$statsViewportX, this.koil$statsViewportY - this.koil$statsScrollOffset, this.koil$statsViewportWidth - 8, mouseX, mouseY);
        }

        context.method_44380();
        this.koil$statsScrollMax = Math.max(0, contentHeight - this.koil$statsViewportHeight);

        if (this.koil$statsScrollOffset > this.koil$statsScrollMax) {
            this.koil$statsScrollOffset = this.koil$statsScrollMax;
        }

        koil$renderStatsScrollbar(context);
    }

    @Unique
    private int koil$renderContextLine(class_332 context, int x, int y, int width, class_310 client) {
        String world = client == null || client.field_1687 == null ? "menu" : client.method_1542() ? "singleplayer" : "multiplayer";
        String globalState = GlobalActivityClient.hasServerData() ? "server synced" : GlobalActivityClient.hasObservedData() ? "client observed" : "waiting for activity";
        String line = "World: " + world + "  |  Context: " + GlobalActivityClient.contextKey() + "  |  Sources: " + koil$sourceSummary() + "  |  Global: " + globalState;
        String baseLine = KoilMarketValueEngine.baseExchangeLine(koil$allMarketValueRows());
        context.method_51439(this.field_22793, class_2561.method_43470(koil$ellipsize(line, width - 4)), x + 2, y, 0xFFB8C7D6, false);
        context.method_51439(this.field_22793, class_2561.method_43470(koil$ellipsize(baseLine, width - 4)), x + 2, y + 11, 0xFFE8C86F, false);
        return y + 22;
    }

    @Unique
    private int koil$renderSummaryStrip(class_332 context, int x, int y, int width) {
        List<Object[]> cards = koil$overviewCards();
        int columns = width < 560 ? 3 : 7;
        int gap = 5;
        int cellWidth = Math.max(42, (width - gap * (columns - 1)) / columns);
        int cellHeight = 29;

        for (int i = 0; i < cards.size(); i++) {
            Object[] card = cards.get(i);
            int column = i % columns;
            int row = i / columns;
            int cellX = x + column * (cellWidth + gap);
            int cellY = y + row * (cellHeight + gap);
            String name = (String) card[0];
            String value = (String) card[1];
            float progress = (Float) card[2];
            int color = (Integer) card[3];

            context.method_25294(cellX, cellY, cellX + cellWidth, cellY + cellHeight, 0x22000000);
            context.method_49601(cellX, cellY, cellWidth, cellHeight, 0x443D4A56);
            koil$drawSummaryIcon(context, name, cellX + 3, cellY + 6);
            context.method_51439(this.field_22793, class_2561.method_43470(koil$ellipsize(name, cellWidth - 25)), cellX + 22, cellY + 4, 0xFFE7EDF4, false);
            context.method_51439(this.field_22793, class_2561.method_43470(koil$ellipsize(value, cellWidth - 25)), cellX + 22, cellY + 15, color, false);
            koil$drawBar(context, cellX + 4, cellY + 25, cellWidth - 8, 2, progress, color);
        }

        int rows = (int) Math.ceil(cards.size() / (float) columns);
        return y + rows * cellHeight + Math.max(0, rows - 1) * gap;
    }

    @Unique
    private int koil$renderSectionHeader(class_332 context, int x, int y, int width) {
        String left = koil$pageTitle(this.koil$activePage);
        String right = koil$pageCount(this.koil$activePage);
        String hint = koil$pageHint(this.koil$activePage);

        context.method_25294(x, y, x + width, y + 24, 0x16000000);
        context.method_51439(this.field_22793, class_2561.method_43470(left), x + 3, y + 3, 0xFFE7EDF4, false);

        context.method_51439(this.field_22793, class_2561.method_43470(right), x + width - 3 - this.field_22793.method_1727(right), y + 3, 0xFFE8C86F, false);

        context.method_51439(this.field_22793, class_2561.method_43470(koil$ellipsize(hint, width - 6)), x + 3, y + 14, 0xFF8E9AA8, false);

        return y + 24;
    }

    @Unique
    private int koil$renderGeneralRows(class_332 context, int x, int y, int width, int mouseX, int mouseY) {
        List<Object[]> rows = this.koil$cachedGeneralRows;
        int max = this.koil$cachedGeneralMax;
        int rowY = y;

        for (int i = 0; i < rows.size(); i++) {
            Object[] row = rows.get(i);
            String label = (String) row[0];
            String formatted = (String) row[1];
            int raw = (Integer) row[2];
            String category = (String) row[3];
            int color = (Integer) row[4];
            String source = (String) row[5];
            int height = 29;

            if (!koil$isRenderRowVisible(rowY, height)) {
                rowY += height + 3;
                continue;
            }

            koil$drawLightRow(context, x, rowY, width, height, i);
            context.method_25294(x + 4, rowY + 5, x + 7, rowY + height - 5, color);
            context.method_51439(this.field_22793, class_2561.method_43470(koil$ellipsize(label, Math.max(70, width / 2))), x + 12, rowY + 4, 0xFFE7EDF4, false);
            context.method_51439(this.field_22793, class_2561.method_43470(koil$ellipsize(category + " | " + source, Math.max(70, width / 2))), x + 12, rowY + 15, 0xFF8E9AA8, false);
            context.method_51439(this.field_22793, class_2561.method_43470(formatted), x + width - 8 - this.field_22793.method_1727(formatted), rowY + 4, 0xFFFFFFFF, false);
            koil$drawBar(context, x + width - Math.max(82, width / 4) - 8, rowY + 19, Math.max(72, width / 4), 3, raw / (float) max, color);

            if (koil$inside(mouseX, mouseY, x, rowY, width, height)) {
                koil$setHoverTooltip(
                        koil$tooltipLine(label, 0xFFE7EDF4),
                        koil$tooltipLine("Category: " + category, color),
                        koil$tooltipLine("Source: " + source, 0xFF8E9AA8),
                        koil$tooltipLine("Value: " + formatted, 0xFFFFFFFF)
                );
            }

            rowY += height + 3;
        }

        if (rows.isEmpty()) {
            koil$drawEmptyState(context, x, rowY, width, "No general statistics are available yet.");
            rowY += 38;
        }

        return rowY - y;
    }

    @Unique
    private int koil$renderItemRows(class_332 context, int x, int y, int width, int mouseX, int mouseY) {
        List<Object[]> rows = this.koil$cachedItemRows;
        int max = this.koil$cachedItemMax;
        int rowY = y;

        for (int i = 0; i < rows.size(); i++) {
            Object[] row = rows.get(i);
            class_1792 item = (class_1792) row[0];
            String name = (String) row[1];
            int mined = (Integer) row[2];
            int used = (Integer) row[3];
            int crafted = (Integer) row[4];
            int pickedUp = (Integer) row[5];
            int dropped = (Integer) row[6];
            int broken = (Integer) row[7];
            int total = (Integer) row[8];
            String source = (String) row[9];
            int height = width < 430 ? 48 : 34;

            if (!koil$isRenderRowVisible(rowY, height)) {
                rowY += height + 3;
                continue;
            }

            koil$drawLightRow(context, x, rowY, width, height, i);
            context.method_25294(x + 4, rowY + 5, x + 7, rowY + height - 5, 0xFFE8C86F);
            context.method_51445(item.method_7854(), x + 11, rowY + 8);

            if (width < 430) {
                context.method_51439(this.field_22793, class_2561.method_43470(koil$ellipsize(name, width - 42)), x + 31, rowY + 4, 0xFFE7EDF4, false);
                context.method_51439(this.field_22793, class_2561.method_43470(koil$ellipsize(source + " | " + koil$itemDominantMetric(mined, used, crafted, pickedUp, dropped, broken), width - 42)), x + 31, rowY + 15, 0xFF8E9AA8, false);
                String detail = "T " + koil$compact(total) + "  M " + koil$compact(mined) + "  U " + koil$compact(used) + "  C " + koil$compact(crafted) + "  P " + koil$compact(pickedUp) + "  D " + koil$compact(dropped) + "  B " + koil$compact(broken);
                context.method_51439(this.field_22793, class_2561.method_43470(koil$ellipsize(detail, width - 42)), x + 31, rowY + 26, 0xFFC7D3E0, false);
                koil$drawMiniSpark(context, x + 31, rowY + 39, width - 39, 6, new int[]{mined, used, crafted, pickedUp, dropped, broken}, 0xFFE8C86F);
            } else {
                context.method_51439(this.field_22793, class_2561.method_43470(koil$ellipsize(name, Math.max(80, width - 328))), x + 31, rowY + 4, 0xFFE7EDF4, false);
                context.method_51439(this.field_22793, class_2561.method_43470(koil$ellipsize(source + " | " + koil$itemDominantMetric(mined, used, crafted, pickedUp, dropped, broken), Math.max(80, width - 328))), x + 31, rowY + 15, 0xFF8E9AA8, false);
                int startX = x + width - 276;
                koil$drawMetric(context, "M", mined, startX, rowY + 5, 0xFF8FC5FF);
                koil$drawMetric(context, "U", used, startX + 45, rowY + 5, 0xFFA6D989);
                koil$drawMetric(context, "C", crafted, startX + 90, rowY + 5, 0xFFE8C86F);
                koil$drawMetric(context, "P", pickedUp, startX + 135, rowY + 5, 0xFF8FD5D0);
                koil$drawMetric(context, "D", dropped, startX + 180, rowY + 5, 0xFFE6A15C);
                koil$drawMetric(context, "B", broken, startX + 225, rowY + 5, 0xFFE06A6A);
                koil$drawBar(context, x + 31, rowY + 27, width - 39, 3, total / (float) max, 0xFFE8C86F);
            }

            if (koil$inside(mouseX, mouseY, x, rowY, width, height)) {
                koil$setHoverTooltip(
                        koil$tooltipLine(name, 0xFFE7EDF4),
                        koil$tooltipLine("Total activity: " + total, 0xFFE8C86F),
                        koil$tooltipLine("Pattern: " + koil$itemDominantMetric(mined, used, crafted, pickedUp, dropped, broken), 0xFF8FD5D0),
                        koil$tooltipLine("Source: " + source, 0xFF8E9AA8)
                );
            }

            rowY += height + 3;
        }

        if (rows.isEmpty()) {
            koil$drawEmptyState(context, x, rowY, width, "No item or block statistics have been recorded yet.");
            rowY += 38;
        }

        return rowY - y;
    }

    @Unique
    private int koil$renderEntityRows(class_332 context, int x, int y, int width, int mouseX, int mouseY) {
        List<Object[]> rows = this.koil$cachedEntityRows;
        int max = this.koil$cachedEntityMax;
        int rowY = y;

        for (int i = 0; i < rows.size(); i++) {
            Object[] row = rows.get(i);
            String name = (String) row[0];
            int killed = (Integer) row[1];
            int killedBy = (Integer) row[2];
            String source = (String) row[3];
            int threatColor = koil$threatColor(killed, killedBy);
            int height = 38;

            if (!koil$isRenderRowVisible(rowY, height)) {
                rowY += height + 3;
                continue;
            }

            koil$drawLightRow(context, x, rowY, width, height, i);
            context.method_25294(x + 4, rowY + 5, x + 7, rowY + height - 5, threatColor);
            context.method_51439(this.field_22793, class_2561.method_43470(koil$ellipsize(name, Math.max(70, width - 230))), x + 12, rowY + 4, 0xFFE7EDF4, false);
            context.method_51439(this.field_22793, class_2561.method_43470(koil$ellipsize(source + " | " + koil$threatLabel(killed, killedBy), Math.max(70, width - 230))), x + 12, rowY + 15, 0xFF8E9AA8, false);
            context.method_51439(this.field_22793, class_2561.method_43470("K " + killed), x + width - 178, rowY + 5, 0xFFA6D989, false);
            context.method_51439(this.field_22793, class_2561.method_43470("D " + killedBy), x + width - 118, rowY + 5, threatColor, false);
            context.method_51439(this.field_22793, class_2561.method_43470("R " + koil$ratio(killed, killedBy)), x + width - 58, rowY + 5, 0xFFE8C86F, false);
            koil$drawDualBar(context, x + 12, rowY + 28, width - 20, killed / (float) max, killedBy / (float) max, 0xFFA6D989, threatColor);

            if (koil$inside(mouseX, mouseY, x, rowY, width, height)) {
                koil$setHoverTooltip(
                        koil$tooltipLine(name, 0xFFE7EDF4),
                        koil$tooltipLine("Kills: " + killed, 0xFFA6D989),
                        koil$tooltipLine("Killed by: " + killedBy, koil$threatColor(killed, killedBy)),
                        koil$tooltipLine("Ratio: " + koil$ratio(killed, killedBy), 0xFFE8C86F),
                        koil$tooltipLine("Source: " + source, 0xFF8E9AA8)
                );
            }

            rowY += height + 3;
        }

        if (rows.isEmpty()) {
            koil$drawEmptyState(context, x, rowY, width, "No mob statistics have been recorded yet.");
            rowY += 38;
        }

        return rowY - y;
    }

    @Unique
    private int koil$renderGlobalRows(class_332 context, int x, int y, int width, int mouseX, int mouseY) {
        List<KoilGlobalMarketViewRow> head = this.koil$cachedHeadMarketRows;
        List<KoilGlobalMarketViewRow> sub = this.koil$cachedSubMarketRows;
        List<KoilGlobalMarketViewRow> raw = this.koil$cachedRawMarketRows;
        List<KoilGlobalMarketViewRow> dev = this.koil$cachedDevMarketRows;
        int rowY = y;

        if (head.isEmpty() && sub.isEmpty() && raw.isEmpty() && dev.isEmpty()) {
            return koil$renderGlobalEmpty(context, x, rowY, width) - y;
        }

        rowY = koil$renderGlobalMarketGroup(context, x, rowY, width, "head", "Head Markets", head.size() + " combined summary markets", "Combined category markets are open by default.", head, true, mouseX, mouseY);
        rowY += 4;
        rowY = koil$renderGlobalMarketGroup(context, x, rowY, width, "sub", "Sub Markets", sub.size() + " item/block/entity grouped markets", "Grouped markets stay hidden until opened.", sub, false, mouseX, mouseY);
        rowY += 4;
        rowY = koil$renderGlobalMarketGroup(context, x, rowY, width, "raw", "Raw Markets", raw.size() + " exact watched signals", "Exact signal markets stay hidden until opened.", raw, false, mouseX, mouseY);

        if (!dev.isEmpty()) {
            rowY += 4;
            rowY = koil$renderGlobalMarketGroup(context, x, rowY, width, "dev", "Dev Market", dev.size() + " unprocessed fallback signals", "Unclassified developer feed stays hidden until opened.", dev, false, mouseX, mouseY);
        }

        return rowY - y;
    }

    @Unique
    private int koil$renderGlobalMarketGroup(class_332 context, int x, int y, int width, String groupKey, String title, String value, String emptyText, List<KoilGlobalMarketViewRow> rows, boolean defaultOpen, int mouseX, int mouseY) {
        boolean open = koil$isGlobalGroupOpen(groupKey, defaultOpen);
        int rowY = koil$drawGlobalSubHeader(context, x, y, width, groupKey, title, value, open);

        if (!open) {
            return rowY;
        }

        if (rows.isEmpty()) {
            koil$drawEmptyState(context, x, rowY, width, emptyText);
            return rowY + 38;
        }

        for (int i = 0; i < rows.size(); i++) {
            rowY = koil$renderGlobalMarketViewRow(context, x, rowY, width, rows.get(i), i, mouseX, mouseY);
        }

        return rowY;
    }

    @Unique
    private int koil$drawGlobalSubHeader(class_332 context, int x, int y, int width, String groupKey, String title, String value, boolean open) {
        this.koil$globalGroupHeaderRects.put(groupKey, new int[]{x, y, width, 21});
        context.method_25294(x, y, x + width, y + 21, 0x18000000);
        context.method_25294(x + 2, y + 4, x + 5, y + 17, open ? 0xFF8FC5FF : 0x668FC5FF);
        context.method_51439(this.field_22793, class_2561.method_43470(title), x + 11, y + 6, open ? 0xFFE7EDF4 : 0xFF8E9AA8, false);
        String state = open ? "open" : "collapsed";
        String right = state + "  |  " + value;
        context.method_51439(this.field_22793, class_2561.method_43470(right), x + width - 4 - this.field_22793.method_1727(right), y + 6, open ? 0xFFB8C7D6 : 0xFF718091, false);
        return y + 24;
    }

    @Unique
    private boolean koil$isGlobalGroupOpen(String groupKey, boolean defaultOpen) {
        return this.koil$expandedGlobalGroups.getOrDefault(groupKey, defaultOpen);
    }

    @Unique
    private int koil$renderGlobalMarketViewRow(class_332 context, int x, int y, int width, KoilGlobalMarketViewRow view, int index, int mouseX, int mouseY) {
        KoilGlobalActivityRow row = view.chartRow();
        String key = view.tier() + ":" + view.id();
        boolean expanded = this.koil$expandedGlobalRows.getOrDefault(key, false);
        int height = expanded ? 432 : 46;

        if (!koil$isRenderRowVisible(y, height)) {
            return y + height + 4;
        }

        int color = koil$globalMarketDomainColor(view);
        KoilMarketValueQuote quote = koil$quoteForView(view);
        int changeColor = row.change() > 0 ? 0xFFA6D989 : row.change() < 0 ? 0xFFE06A6A : 0xFF8E9AA8;
        int iconX = x + 11;
        int titleX = x + 34;
        this.koil$globalRowRects.put(key, new int[]{x, y, width, 46});
        koil$drawLightRow(context, x, y, width, height, index);
        context.method_25294(x + 4, y + 5, x + 7, y + height - 5, color);
        koil$drawMarketViewIcon(context, view, iconX, y + 11);
        context.method_51439(this.field_22793, class_2561.method_43470(koil$ellipsize(view.title(), Math.max(80, width - 320))), titleX, y + 4, 0xFFE7EDF4, false);
        context.method_51439(this.field_22793, class_2561.method_43470(koil$ellipsize(view.description(), Math.max(80, width - 320))), titleX, y + 15, 0xFF8E9AA8, false);
        context.method_51439(this.field_22793, class_2561.method_43470(koil$ellipsize(koil$marketDataSourcesLine(view), Math.max(80, width - 320))), titleX, y + 28, 0xFFB8C7D6, false);

        String value = "total " + koil$compact(view.value());
        String change = (row.change() >= 0 ? "+" : "") + row.change();
        String source = view.authoritative() ? "server" : "observed " + view.confidence() + "%";
        String momens = quote.compactMomens();
        String exchange = quote.compactExchange(view.subject());
        context.method_51439(this.field_22793, class_2561.method_43470(momens), x + width - 196, y + 4, 0xFFE8C86F, false);
        context.method_51439(this.field_22793, class_2561.method_43470(change), x + width - 116, y + 4, changeColor, false);
        context.method_51439(this.field_22793, class_2561.method_43470(source), x + width - 76, y + 4, view.authoritative() ? 0xFFA6D989 : 0xFFE6A15C, false);
        context.method_51439(this.field_22793, class_2561.method_43470(koil$ellipsize(exchange, 190)), x + width - 196, y + 17, 0xFFB7A8FF, false);
        context.method_51439(this.field_22793, class_2561.method_43470(koil$ellipsize(value + "  |  " + koil$marketTopInputsLine(view), 190)), x + width - 196, y + 30, 0xFF8FD5D0, false);

        if (expanded) {
            int chartX = x + 12;
            int chartY = y + 59;
            int dataWidth = width >= 620 ? Math.min(236, Math.max(198, width / 3)) : 0;
            int chartWidth = dataWidth > 0 ? Math.max(120, width - dataWidth - 32) : Math.max(90, width - 24);
            int chartHeight = dataWidth > 0 ? 246 : 254;
            koil$drawStockChart(context, chartX, chartY, chartWidth, chartHeight, row, view, color, mouseX, mouseY);

            if (dataWidth > 0) {
                int dataX = chartX + chartWidth + 8;
                koil$drawMarketValuePanel(context, dataX, chartY, dataWidth, view, quote, row, changeColor);
                koil$drawStockDataRibbon(context, dataX, chartY + 101, dataWidth, row, view, color, changeColor);
                koil$drawMarketComponentPanel(context, dataX, chartY + 209, dataWidth, view);
                int rankingY = chartY + chartHeight + 8;
                int rankingHeight = Math.max(56, y + height - rankingY - 10);
                koil$drawMarketRankingsPanel(context, chartX, rankingY, Math.max(90, width - 24), rankingHeight, view, quote, row);
            } else {
                koil$drawStockDataRibbon(context, chartX, chartY + chartHeight + 6, chartWidth, row, view, color, changeColor);
                koil$drawMarketComponentPanel(context, chartX, chartY + chartHeight + 56, chartWidth, view);
            }
        } else {
            koil$drawMiniStockPreview(context, x + width - 196, y + 34, 184, 8, koil$miniPreviewSeriesForView(view), color);
        }

        if (koil$inside(mouseX, mouseY, x, y, width, 46) && this.koil$hoverTooltipLines.isEmpty()) {
            List<class_2561> lines = new ArrayList<>();
            lines.add(koil$tooltipLine(view.title(), 0xFFE7EDF4));
            lines.add(koil$tooltipLine("Tier: " + koil$tierLabel(view.tier()) + "  |  Domain: " + view.domain(), color));
            lines.add(koil$tooltipLine(view.description(), 0xFFB8C7D6));
            lines.add(koil$tooltipLine(view.authoritative() ? "Source: server exact, per world/server" : "Source: client observed, per world/server", view.authoritative() ? 0xFFA6D989 : 0xFFE6A15C));
            lines.add(koil$tooltipLine("Confidence: " + view.confidence() + "%", view.authoritative() ? 0xFFA6D989 : 0xFFE6A15C));
            lines.add(koil$tooltipLine("Leader: " + view.leader() + " (" + view.leaderValue() + ")", 0xFF8FD5D0));
            lines.add(koil$tooltipLine("Total: " + view.value() + "   Change: " + koil$signed(row.change()), row.change() >= 0 ? 0xFFA6D989 : 0xFFE06A6A));
            lines.add(koil$tooltipLine("Momens value: " + quote.compactMomens(), 0xFFE8C86F));
            lines.add(koil$tooltipLine(quote.longExchange(view.subject()), 0xFFB7A8FF));
            lines.add(koil$tooltipLine(quote.scoreSummary(), 0xFF8FD5D0));
            lines.add(koil$tooltipLine("Inputs: " + Math.max(0, view.rawMetrics().size()) + " raw signals", 0xFFE8C86F));

            for (String component : view.componentTooltipLines(10)) {
                int lineColor = component.contains("Broken") || component.contains("Damage") || component.contains("Deaths") ? 0xFFE06A6A : component.contains("Placed") || component.contains("Used") ? 0xFFA6D989 : component.contains("Crafted") || component.contains("Traded") ? 0xFFE8C86F : 0xFFB8C7D6;
                lines.add(koil$tooltipLine(component, lineColor));
            }

            for (String sourceLine : koil$marketRawSourceTooltipLines(view, 6)) {
                lines.add(koil$tooltipLine(sourceLine, 0xFF8E9AA8));
            }

            lines.add(koil$tooltipLine("Click to " + (expanded ? "collapse" : "expand"), 0xFFB8C7D6));
            koil$setHoverTooltip(lines.toArray(new class_2561[0]));
        }

        return y + height + 4;
    }

    @Unique
    private void koil$drawMarketComponentPanel(class_332 context, int x, int y, int width, KoilGlobalMarketViewRow view) {
        KoilMarketValueQuote quote = koil$quoteForView(view);
        int panelHeight = 48;
        context.method_25294(x, y, x + width, y + panelHeight, 0x12000000);
        context.method_49601(x, y, width, panelHeight, 0x223D4A56);
        context.method_51439(this.field_22793, class_2561.method_43470("market inputs + Momens value"), x + 5, y + 4, 0xFF718091, false);
        context.method_51439(this.field_22793, class_2561.method_43470(koil$ellipsize(view.compactComponentSummary(), width - 10)), x + 5, y + 15, 0xFFE7EDF4, false);
        context.method_51439(this.field_22793, class_2561.method_43470(koil$ellipsize(quote.compactMomens() + "  |  " + quote.compactExchange(view.subject()) + "  |  " + koil$marketDataSourcesLine(view), width - 10)), x + 5, y + 26, 0xFF8FD5D0, false);
        String footer = "raw signals: " + view.rawMetrics().size() + "  |  hover candles, lines, averages, components, and Momens value data";
        context.method_51439(this.field_22793, class_2561.method_43470(koil$ellipsize(footer, width - 10)), x + 5, y + 37, 0xFF8E9AA8, false);
    }

    @Unique
    private void koil$drawMarketValuePanel(class_332 context, int x, int y, int width, KoilGlobalMarketViewRow view, KoilMarketValueQuote quote, KoilGlobalActivityRow row, int changeColor) {
        int panelHeight = 92;
        context.method_25294(x, y, x + width, y + panelHeight, 0x16000000);
        context.method_49601(x, y, width, panelHeight, 0x223D4A56);
        context.method_51439(this.field_22793, class_2561.method_43470("live market value"), x + 5, y + 4, 0xFF718091, false);
        context.method_51439(this.field_22793, class_2561.method_43470(koil$ellipsize(quote.compactMomens(), width - 10)), x + 5, y + 16, 0xFFE8C86F, false);
        context.method_51439(this.field_22793, class_2561.method_43470(koil$ellipsize(quote.compactExchange(view.subject()), width - 10)), x + 5, y + 28, 0xFFB7A8FF, false);
        context.method_51439(this.field_22793, class_2561.method_43470(koil$ellipsize("reserve: " + quote.reserveTitle(), width - 10)), x + 5, y + 40, 0xFF8FD5D0, false);
        context.method_51439(this.field_22793, class_2561.method_43470(koil$ellipsize(quote.oneMomenReserveLine(), width - 10)), x + 5, y + 52, 0xFFB8C7D6, false);
        context.method_51439(this.field_22793, class_2561.method_43470(koil$ellipsize("change: " + koil$signed(row.change()) + "  trend: " + koil$signed(row.trend()), width - 10)), x + 5, y + 64, changeColor, false);
        context.method_51439(this.field_22793, class_2561.method_43470(koil$ellipsize("source: " + (view.authoritative() ? "server exact" : "observed " + view.confidence() + "%"), width - 10)), x + 5, y + 76, view.authoritative() ? 0xFFA6D989 : 0xFFE6A15C, false);
    }

    @Unique
    private void koil$drawMarketRankingsPanel(class_332 context, int x, int y, int width, int height, KoilGlobalMarketViewRow view, KoilMarketValueQuote quote, KoilGlobalActivityRow row) {
        int safeHeight = Math.max(44, height);
        context.method_25294(x, y, x + width, y + safeHeight, 0x14000000);
        context.method_49601(x, y, width, safeHeight, 0x223D4A56);
        int gap = 6;
        int columns = width >= 560 ? 3 : 2;
        int columnWidth = Math.max(74, (width - gap * (columns - 1)) / columns);
        koil$drawMarketRankingColumn(context, x + 5, y + 5, columnWidth - 10, safeHeight - 10, "player ranking", koil$marketLeaderRankingLines(view, 5));
        koil$drawMarketRankingColumn(context, x + columnWidth + gap + 5, y + 5, columnWidth - 10, safeHeight - 10, "stat ranking", koil$marketStatRankingLines(view, 5));

        if (columns > 2) {
            koil$drawMarketRankingColumn(context, x + (columnWidth + gap) * 2 + 5, y + 5, columnWidth - 10, safeHeight - 10, "price checks", koil$marketScoreLines(view, quote, row, 5));
        }
    }

    @Unique
    private void koil$drawMarketRankingColumn(class_332 context, int x, int y, int width, int height, String title, List<Object[]> rows) {
        context.method_51439(this.field_22793, class_2561.method_43470(koil$ellipsize(title, width)), x, y, 0xFF718091, false);
        int rowY = y + 12;
        int limit = Math.max(1, Math.min(rows.size(), Math.max(1, (height - 12) / 11)));

        for (int i = 0; i < limit; i++) {
            Object[] row = rows.get(i);
            String label = String.valueOf(row[0]);
            String value = koil$ellipsize(String.valueOf(row[1]), Math.max(18, width / 2));
            int color = row.length > 2 && row[2] instanceof Integer ? (Integer) row[2] : 0xFFB8C7D6;
            String prefix = rows.size() > 1 ? (i + 1) + ". " : "";
            int valueWidth = this.field_22793.method_1727(value);
            context.method_51439(this.field_22793, class_2561.method_43470(koil$ellipsize(prefix + label, Math.max(20, width - valueWidth - 8))), x, rowY, color, false);
            context.method_51439(this.field_22793, class_2561.method_43470(value), x + Math.max(0, width - valueWidth), rowY, color, false);
            rowY += 11;
        }
    }

    @Unique
    private List<Object[]> koil$marketLeaderRankingLines(KoilGlobalMarketViewRow view, int limit) {
        Map<String, Integer> totals = new LinkedHashMap<>();

        for (KoilGlobalActivityRow row : koil$componentRowsForView(view, 64)) {
            String leader = row.leader() == null || row.leader().isBlank() ? "none" : row.leader();
            int value = row.leaderValue() > 0 ? row.leaderValue() : row.value();

            if (!"none".equalsIgnoreCase(leader) && value > 0) {
                totals.put(leader, totals.getOrDefault(leader, 0) + value);
            }
        }

        if (totals.isEmpty() && view.leader() != null && !view.leader().isBlank() && view.leaderValue() > 0) {
            totals.put(view.leader(), view.leaderValue());
        }

        List<Map.Entry<String, Integer>> entries = new ArrayList<>(totals.entrySet());
        entries.sort((a, b) -> Integer.compare(b.getValue(), a.getValue()));
        List<Object[]> rows = new ArrayList<>();

        for (Map.Entry<String, Integer> entry : entries) {
            if (rows.size() >= Math.max(1, limit)) {
                break;
            }

            rows.add(new Object[]{entry.getKey(), koil$compact(entry.getValue()), 0xFF8FD5D0});
        }

        if (rows.isEmpty()) {
            rows.add(new Object[]{"not enough player data", "0", 0xFF718091});
        }

        return rows;
    }

    @Unique
    private List<Object[]> koil$marketStatRankingLines(KoilGlobalMarketViewRow view, int limit) {
        List<Map.Entry<String, Integer>> entries = new ArrayList<>(view.components().entrySet());
        entries.sort((a, b) -> Integer.compare(Math.max(0, b.getValue()), Math.max(0, a.getValue())));
        List<Object[]> rows = new ArrayList<>();

        for (Map.Entry<String, Integer> entry : entries) {
            if (rows.size() >= Math.max(1, limit)) {
                break;
            }

            rows.add(new Object[]{koil$formatIdentifierName(entry.getKey()), koil$compact(entry.getValue()), 0xFFB8C7D6});
        }

        if (rows.isEmpty()) {
            rows.add(new Object[]{"no component data", "0", 0xFF718091});
        }

        return rows;
    }

    @Unique
    private List<Object[]> koil$marketScoreLines(KoilGlobalMarketViewRow view, KoilMarketValueQuote quote, KoilGlobalActivityRow row, int limit) {
        List<Object[]> rows = new ArrayList<>();
        rows.add(new Object[]{"value", quote.compactMomens(), 0xFFE8C86F});
        rows.add(new Object[]{"exchange", quote.compactExchange(view.subject()), 0xFFB7A8FF});
        rows.add(new Object[]{"samples", String.valueOf(Math.max(0, row.pointsView().length)), 0xFF55DDE8});
        rows.add(new Object[]{"confidence", view.confidence() + "%", view.authoritative() ? 0xFFA6D989 : 0xFFE6A15C});
        rows.add(new Object[]{"raw signals", String.valueOf(Math.max(0, view.rawMetrics().size())), 0xFF8FD5D0});
        rows.add(new Object[]{"demand", KoilMarketValueQuote.compactDecimal(quote.demandScore()), 0xFFA6D989});
        rows.add(new Object[]{"supply", KoilMarketValueQuote.compactDecimal(quote.supplyScore()), 0xFF8FC5FF});
        rows.add(new Object[]{"scarcity", KoilMarketValueQuote.compactDecimal(quote.scarcityScore()), 0xFFE6A15C});
        return rows.subList(0, Math.min(rows.size(), Math.max(1, limit)));
    }


    @Unique
    private List<KoilGlobalMarketViewRow> koil$allMarketValueRows() {
        return this.koil$cachedAllMarketValueRows;
    }

    @Unique
    private KoilMarketValueQuote koil$quoteForView(KoilGlobalMarketViewRow view) {
        String key = koil$marketCacheKey(view);
        KoilMarketValueQuote cached = this.koil$cachedMarketQuotes.get(key);

        if (cached != null) {
            return cached;
        }

        KoilMarketValueQuote quote = KoilMarketValueEngine.quote(view, koil$allMarketValueRows());
        this.koil$cachedMarketQuotes.put(key, quote);
        return quote;
    }

    @Unique
    private String koil$marketDataSourcesLine(KoilGlobalMarketViewRow view) {
        List<KoilGlobalActivityRow> rows = koil$componentRowsForView(view, 4);

        if (rows.isEmpty()) {
            return view.compactComponentSummary();
        }

        StringBuilder builder = new StringBuilder("uses ");

        for (int i = 0; i < rows.size(); i++) {
            KoilGlobalActivityRow row = rows.get(i);

            if (i > 0) {
                builder.append("  |  ");
            }

            builder.append(koil$marketMetricShortTitle(row.metric())).append(": ").append(koil$compact(row.value())).append(" from ").append(row.leader());
        }

        int remaining = Math.max(0, view.rawMetrics().size() - rows.size());

        if (remaining > 0) {
            builder.append("  +").append(remaining).append(" more");
        }

        return builder.toString();
    }

    @Unique
    private String koil$marketTopInputsLine(KoilGlobalMarketViewRow view) {
        List<KoilGlobalActivityRow> rows = koil$componentRowsForView(view, 3);

        if (rows.isEmpty()) {
            return "inputs " + view.rawMetrics().size();
        }

        StringBuilder builder = new StringBuilder("top ");

        for (int i = 0; i < rows.size(); i++) {
            KoilGlobalActivityRow row = rows.get(i);

            if (i > 0) {
                builder.append(", ");
            }

            builder.append(koil$marketMetricShortTitle(row.metric()));
        }

        return builder.toString();
    }

    @Unique
    private List<String> koil$marketRawSourceTooltipLines(KoilGlobalMarketViewRow view, int limit) {
        List<String> lines = new ArrayList<>();
        List<KoilGlobalActivityRow> rows = koil$componentRowsForView(view, limit);

        if (rows.isEmpty()) {
            lines.add("Raw inputs: none loaded");
            return lines;
        }

        lines.add("Raw inputs:");

        for (KoilGlobalActivityRow row : rows) {
            String source = row.authoritative() ? "server" : "observed " + row.confidence() + "%";
            lines.add("- " + koil$marketMetricShortTitle(row.metric()) + ": " + row.value() + "  leader " + row.leader() + "  " + source);
        }

        int remaining = Math.max(0, view.rawMetrics().size() - rows.size());

        if (remaining > 0) {
            lines.add("+ " + remaining + " more raw signals");
        }

        return lines;
    }

    @Unique
    private List<KoilGlobalActivityRow> koil$componentRowsForView(KoilGlobalMarketViewRow view, int limit) {
        String cacheKey = koil$marketCacheKey(view) + "|" + Math.max(0, limit);
        List<KoilGlobalActivityRow> cached = this.koil$cachedMarketComponents.get(cacheKey);

        if (cached != null) {
            return cached;
        }

        List<KoilGlobalActivityRow> rows = new ArrayList<>();

        for (String metric : view.rawMetrics()) {
            KoilGlobalActivityRow row = this.koil$cachedGlobalRowsByMetric.get(koil$normalizeGlobalMetric(metric));

            if (row != null) {
                rows.add(row);
            }
        }

        rows.sort((a, b) -> Integer.compare(b.value(), a.value()));
        List<KoilGlobalActivityRow> result;

        if (rows.size() > Math.max(0, limit)) {
            result = Collections.unmodifiableList(new ArrayList<>(rows.subList(0, Math.max(0, limit))));
        } else {
            result = Collections.unmodifiableList(rows);
        }

        this.koil$cachedMarketComponents.put(cacheKey, result);
        return result;
    }

    @Unique
    private String koil$marketCacheKey(KoilGlobalMarketViewRow view) {
        if (view == null) {
            return "null";
        }

        KoilGlobalActivityRow row = view.chartRow();
        int[] points = row == null ? new int[0] : row.pointsView();
        int last = points.length == 0 ? 0 : points[points.length - 1];
        int change = row == null ? 0 : row.change();
        return view.tier() + ":" + view.id() + ":" + view.value() + ":" + view.leaderValue() + ":" + view.confidence() + ":" + view.authoritative() + ":" + points.length + ":" + last + ":" + change;
    }

    @Unique
    private String koil$normalizeGlobalMetric(String metric) {
        return metric == null ? "" : metric.trim().toLowerCase(Locale.ROOT).replace(' ', '_');
    }

    @Unique
    private String koil$marketMetricShortTitle(String metric) {
        String value = koil$normalizeGlobalMetric(metric);

        if (value.startsWith("block_broken/")) {
            return koil$formatIdentifierName(value.substring("block_broken/".length()).replace('/', ' ')) + " broken";
        }

        if (value.startsWith("block_place_intent/")) {
            return koil$formatIdentifierName(value.substring("block_place_intent/".length()).replace('/', ' ')) + " placed";
        }

        if (value.startsWith("block_placed/")) {
            return koil$formatIdentifierName(value.substring("block_placed/".length()).replace('/', ' ')) + " placed";
        }

        if (value.startsWith("block_used/")) {
            return koil$formatIdentifierName(value.substring("block_used/".length()).replace('/', ' ')) + " used";
        }

        if (value.startsWith("item_use_intent/")) {
            return koil$formatIdentifierName(value.substring("item_use_intent/".length()).replace('/', ' ')) + " used";
        }

        if (value.startsWith("item_crafted/")) {
            return koil$formatIdentifierName(value.substring("item_crafted/".length()).replace('/', ' ')) + " crafted";
        }

        if (value.startsWith("item_picked_up/")) {
            return koil$formatIdentifierName(value.substring("item_picked_up/".length()).replace('/', ' ')) + " picked up";
        }

        if (value.startsWith("item_dropped/")) {
            return koil$formatIdentifierName(value.substring("item_dropped/".length()).replace('/', ' ')) + " dropped";
        }

        if (value.startsWith("mob_killed/")) {
            return koil$formatIdentifierName(value.substring("mob_killed/".length()).replace('/', ' ')) + " killed";
        }

        if (value.startsWith("entity_killed/")) {
            return koil$formatIdentifierName(value.substring("entity_killed/".length()).replace('/', ' ')) + " killed";
        }

        if (value.startsWith("food_eaten/")) {
            return koil$formatIdentifierName(value.substring("food_eaten/".length()).replace('/', ' ')) + " eaten";
        }

        return koil$formatIdentifierName(value.replace('/', ' '));
    }

    @Unique
    private int koil$componentLineColor(int index, String metric) {
        int metricColor = koil$globalMetricColor(metric, false);

        if (index == 0) {
            return metricColor | 0xFF000000;
        }

        int[] colors = new int[]{0xCC8FC5FF, 0xCCA6D989, 0xCCE8C86F, 0xCCB7A8FF, 0xCCE6A15C, 0xCC8FD5D0};
        return colors[Math.abs(index) % colors.length];
    }

    @Unique
    private void koil$drawComponentLegend(class_332 context, int x, int y, List<KoilGlobalActivityRow> components, int maxWidth) {
        int cursorX = x;
        int count = Math.min(3, components.size());

        for (int i = 0; i < count; i++) {
            KoilGlobalActivityRow component = components.get(i);
            int color = koil$componentLineColor(i, component.metric());
            String label = koil$ellipsize(koil$marketMetricShortTitle(component.metric()), 70);
            int labelWidth = this.field_22793.method_1727(label) + 14;

            if (cursorX + labelWidth > x + maxWidth) {
                break;
            }

            context.method_25294(cursorX, y + 2, cursorX + 8, y + 4, color);
            context.method_51439(this.field_22793, class_2561.method_43470(label), cursorX + 11, y - 1, 0xCCB8C7D6, false);
            cursorX += labelWidth + 8;
        }
    }

    @Unique
    private String koil$tierLabel(String tier) {
        if ("head".equals(tier)) {
            return "Head Market";
        }

        if ("sub".equals(tier)) {
            return "Sub Market";
        }

        if ("raw".equals(tier)) {
            return "Raw Market";
        }

        return "Dev Market";
    }

    @Unique
    private int koil$renderGlobalEmpty(class_332 context, int x, int y, int width) {
        int height = 96;
        context.method_25294(x, y, x + width, y + height, 0x16000000);
        context.method_49601(x, y, width, height, 0x443D4A56);
        context.method_25294(x + 4, y + 6, x + 7, y + height - 6, 0xFF8FC5FF);
        context.method_51439(this.field_22793, class_2561.method_43470("Waiting for server or observed global activity."), x + 14, y + 8, 0xFFE7EDF4, false);
        context.method_51439(this.field_22793, class_2561.method_43470(koil$ellipsize("With Koil on the server this page is authoritative. Without Koil on the server it falls back to per-server/per-world client-observed packet-visible activity.", width - 28)), x + 14, y + 22, 0xFFB8C7D6, false);
        context.method_51439(this.field_22793, class_2561.method_43470(koil$ellipsize("The fallback never mixes worlds or servers and marks confidence so estimated data is not mistaken for exact server data.", width - 28)), x + 14, y + 34, 0xFF8E9AA8, false);
        koil$drawPreviewStockChart(context, x + 14, y + 52, width - 28, 36, new int[]{100, 102, 99, 108, 112, 117, 113, 121}, 0xFF8FC5FF);
        return y + height + 4;
    }

    @Unique
    private void koil$drawLightRow(class_332 context, int x, int y, int width, int height, int index) {
        int fill = index % 2 == 0 ? 0x12000000 : 0x22000000;
        context.method_25294(x, y, x + width, y + height, fill);
        context.method_49601(x, y, width, height, 0x263D4A56);
    }

    @Unique
    private void koil$drawMetric(class_332 context, String label, int value, int x, int y, int color) {
        context.method_51439(this.field_22793, class_2561.method_43470(label), x, y, 0xFF718091, false);
        context.method_51439(this.field_22793, class_2561.method_43470(koil$compact(value)), x + 10, y, color, false);
    }

    @Unique
    private void koil$drawEmptyState(class_332 context, int x, int y, int width, String text) {
        context.method_25294(x, y, x + width, y + 34, 0x16000000);
        context.method_49601(x, y, width, 34, 0x443D4A56);
        context.method_25294(x + 4, y + 5, x + 7, y + 29, 0xFF8E9AA8);
        context.method_51439(this.field_22793, class_2561.method_43470(text), x + 14, y + 12, 0xFFB8C7D6, false);
    }

    @Unique
    private void koil$drawBar(class_332 context, int x, int y, int width, int height, float progress, int fillColor) {
        int clampedWidth = Math.max(0, width);
        int filled = Math.max(0, Math.min(clampedWidth, Math.round(clampedWidth * Math.max(0.0F, Math.min(1.0F, progress)))));
        context.method_25294(x, y, x + clampedWidth, y + height, 0x44000000);

        if (filled > 0) {
            context.method_25294(x, y, x + filled, y + height, fillColor);
        }
    }

    @Unique
    private void koil$drawDualBar(class_332 context, int x, int y, int width, float first, float second, int firstColor, int secondColor) {
        int half = Math.max(1, width / 2);
        koil$drawBar(context, x, y, half - 1, 3, first, firstColor);
        koil$drawBar(context, x + half + 1, y, half - 1, 3, second, secondColor);
    }

    @Unique
    private void koil$drawMiniSpark(class_332 context, int x, int y, int width, int height, int[] points, int color) {
        context.method_25294(x, y, x + width, y + height, 0x22000000);
        koil$drawLineChart(context, x + 1, y + 1, width - 2, height - 2, points, color);
    }

    @Unique
    private void koil$drawStockChart(class_332 context, int x, int y, int width, int height, KoilGlobalActivityRow row, int color, int mouseX, int mouseY) {
        koil$drawStockChart(context, x, y, width, height, row, null, color, mouseX, mouseY);
    }

    @Unique
    private void koil$drawStockChart(class_332 context, int x, int y, int width, int height, KoilGlobalActivityRow row, @Nullable KoilGlobalMarketViewRow view, int color, int mouseX, int mouseY) {
        int[] rawOpen = row.candleOpenView();
        int[] rawHigh = row.candleHighView();
        int[] rawLow = row.candleLowView();
        int[] rawClose = row.candleCloseView();
        int[] rawAverage = row.movingAverageView();
        int[] rawPoints = row.pointsView();
        List<KoilGlobalActivityRow> components = view == null ? Collections.emptyList() : koil$componentRowsForView(view, 5);
        List<Object[]> syntheticComponents = view == null ? Collections.emptyList() : koil$syntheticComponentSeries(view);
        int[] rawDisplayPoints = view == null ? koil$visualSeries(row.metric(), rawPoints) : koil$marketMainPressureSeries(view, rawPoints);
        KoilMarketSeriesWindow.Window stockWindow = koil$stockWindowInfo(rawDisplayPoints);
        int plotWidth = koil$stockPlotWidth(width, stockWindow);
        int[] points = koil$renderSeriesForWidth(stockWindow.points(), plotWidth);
        int plotX = koil$stockPlotX(x, width, plotWidth);
        int[] average = koil$movingAverageFromSeries(points);
        int[][] derivedCandles = koil$candlesFromSeries(points);
        int[] open = derivedCandles[0];
        int[] high = derivedCandles[1];
        int[] low = derivedCandles[2];
        int[] close = derivedCandles[3];

        context.method_25294(x, y, x + width, y + height, 0x1A000000);
        context.method_49601(x, y, width, height, 0x443D4A56);
        koil$drawDashedHorizontal(context, x + 1, y + height / 4, width - 2, 0x228E9AA8);
        koil$drawDashedHorizontal(context, x + 1, y + height / 2, width - 2, 0x448E9AA8);
        koil$drawDashedHorizontal(context, x + 1, y + height * 3 / 4, width - 2, 0x228E9AA8);
        koil$drawVerticalGuideLines(context, x + 1, y + 1, width - 2, height - 2, 0x148E9AA8);
        String windowLabel = KoilMarketSeriesWindow.label(this.koil$stockGraphInterval) + " | previous close baseline";
        context.method_51439(this.field_22793, class_2561.method_43470(windowLabel), x + width - 7 - this.field_22793.method_1727(windowLabel), y + 5, 0xFF718091, false);

        int chartHeight = Math.max(52, height - 42);
        int volumeY = y + chartHeight + 4;
        int volumeHeight = Math.max(24, height - chartHeight - 6);
        koil$drawVolumeBars(context, plotX, volumeY, plotWidth, volumeHeight, points, 0xAA718091, row, mouseX, mouseY);
        context.method_51439(this.field_22793, class_2561.method_43470("VOL"), x + 5, volumeY + 2, 0xFF718091, false);

        int[] rangeValues = koil$chartRangeValues(points, open, high, low, close, components, syntheticComponents, plotWidth);
        int min = rangeValues[0];
        int max = rangeValues[1];
        int range = Math.max(1, max - min);
        int highLineY = koil$chartY(y + 1, chartHeight - 2, max, min, range);
        int lowLineY = koil$chartY(y + 1, chartHeight - 2, min, min, range);
        koil$drawDashedHorizontal(context, x + 1, highLineY, width - 2, 0x448FC5FF);
        koil$drawDashedHorizontal(context, x + 1, lowLineY, width - 2, 0x44E06A6A);
        koil$drawChartValueTag(context, x + width - 46, highLineY - 5, "H " + koil$compact(max), 0xFF8FC5FF);
        koil$drawChartValueTag(context, x + width - 46, lowLineY - 5, "L " + koil$compact(min), 0xFFE06A6A);

        if (min < 0 && max > 0) {
            int zeroLineY = koil$chartY(y + 1, chartHeight - 2, 0, min, range);
            koil$drawDashedHorizontal(context, x + 1, zeroLineY, width - 2, 0x66FFFFFF);
            koil$drawChartValueTag(context, x + 4, zeroLineY - 5, "0", 0xFFFFFFFF);
        }

        koil$drawSyntheticComponentStockLines(context, plotX, y + 1, plotWidth, chartHeight - 2, syntheticComponents, min, range, mouseX, mouseY);
        koil$drawComponentStockLines(context, plotX, y + 1, plotWidth, chartHeight - 2, components, min, range, mouseX, mouseY);
        koil$drawCandles(context, plotX, y + 1, plotWidth, chartHeight - 2, open, high, low, close, min, range, mouseX, mouseY, row, view, components, syntheticComponents, points);

        if (average.length > 1) {
            koil$drawIndicatorLineFixedRange(context, plotX, y + 1, plotWidth, chartHeight - 2, average, min, range, 0xCCE8C86F, true);
            if (koil$isMajorMarketMove(average, range)) {
                koil$drawEndpointArrow(context, plotX, y + 1, plotWidth, chartHeight - 2, average, min, range, 0xCCE8C86F);
            }
        }

        if (points.length > 1) {
            koil$drawMainMarketLine(context, plotX, y + 1, plotWidth, chartHeight - 2, points, min, range);
        }

        koil$updateStockChartHover(context, row, view, plotX, y + 1, plotWidth, chartHeight - 2, points, average, components, syntheticComponents, min, range, mouseX, mouseY);
        koil$drawChartLegend(context, x + 5, y + 5, row, color);
        koil$drawSyntheticLegend(context, x + 5, y + 18, syntheticComponents, width - 10);
        koil$drawComponentLegend(context, x + 5, y + 30, components, width - 10);
    }


    @Unique
    private long koil$worldTimeForStockWindow() {
        class_310 client = class_310.method_1551();
        if (client == null || client.field_1687 == null) {
            return 0L;
        }
        return client.field_1687.method_8532();
    }

    @Unique
    private int[] koil$stockWindow(int[] source) {
        return koil$stockWindowInfo(source).points();
    }

    @Unique
    private KoilMarketSeriesWindow.Window koil$stockWindowInfo(int[] source) {
        this.koil$stockGraphInterval = KoilMarketSeriesWindow.activeKey();
        return KoilMarketSeriesWindow.filter(source, this.koil$stockGraphInterval, koil$worldTimeForStockWindow());
    }

    @Unique
    private int[] koil$stockRenderWindow(int[] source, int width) {
        return koil$renderSeriesForWidth(koil$stockWindow(source), width);
    }

    @Unique
    private int[] koil$renderSeriesForWidth(int[] source, int width) {
        if (source == null || source.length == 0) {
            return new int[0];
        }

        int safeWidth = Math.max(2, width);
        int bucketCount = Math.max(2, Math.min(source.length, safeWidth / 2));

        if (source.length <= Math.max(2, safeWidth)) {
            return Arrays.copyOf(source, source.length);
        }

        List<Integer> values = new ArrayList<>();

        for (int bucket = 0; bucket < bucketCount; bucket++) {
            int start = Math.max(0, Math.min(source.length - 1, (int) Math.floor(bucket * (source.length / (double) bucketCount))));
            int end = Math.max(start + 1, Math.min(source.length, (int) Math.floor((bucket + 1) * (source.length / (double) bucketCount))));
            int minIndex = start;
            int maxIndex = start;

            for (int i = start; i < end; i++) {
                if (source[i] < source[minIndex]) {
                    minIndex = i;
                }

                if (source[i] > source[maxIndex]) {
                    maxIndex = i;
                }
            }

            if (minIndex <= maxIndex) {
                koil$appendRenderPoint(values, source[minIndex]);
                koil$appendRenderPoint(values, source[maxIndex]);
            } else {
                koil$appendRenderPoint(values, source[maxIndex]);
                koil$appendRenderPoint(values, source[minIndex]);
            }
        }

        koil$appendRenderPoint(values, source[source.length - 1]);

        if (values.size() == 1) {
            values.add(values.get(0));
        }

        int[] out = new int[values.size()];

        for (int i = 0; i < values.size(); i++) {
            out[i] = values.get(i);
        }

        return out;
    }

    @Unique
    private void koil$appendRenderPoint(List<Integer> values, int value) {
        if (values.isEmpty() || !Objects.equals(values.get(values.size() - 1), value)) {
            values.add(value);
        }
    }

    @Unique
    private int koil$stockPlotWidth(int width, KoilMarketSeriesWindow.Window window) {
        return Math.max(1, width - 2);
    }

    @Unique
    private int koil$stockPlotX(int x, int width, int plotWidth) {
        return x + 1;
    }

    @Unique
    private boolean koil$shouldUseDerivedCandles(@Nullable KoilGlobalMarketViewRow view, String metric, int[] open, int[] high, int[] low, int[] close, int[] points) {
        if (points == null || points.length == 0) {
            return false;
        }

        if (view != null) {
            return true;
        }

        if (!koil$hasUsableCandles(open, high, low, close)) {
            return true;
        }

        String value = koil$normalizeGlobalMetric(metric);

        return value.contains("market")
                || value.contains("block_broken")
                || value.contains("block_place")
                || value.contains("block_used")
                || value.contains("item_")
                || value.contains("entity_")
                || koil$isNegativePressureMetric(value)
                || koil$isDemandPressureMetric(value);
    }

    @Unique
    private boolean koil$hasUsableCandles(int[] open, int[] high, int[] low, int[] close) {
        if (open == null || high == null || low == null || close == null) {
            return false;
        }

        int count = Math.min(Math.min(open.length, high.length), Math.min(low.length, close.length));

        if (count <= 0) {
            return false;
        }

        for (int i = 0; i < count; i++) {
            if (open[i] != 0 || high[i] != 0 || low[i] != 0 || close[i] != 0) {
                return true;
            }
        }

        return false;
    }

    @Unique
    private int[] koil$visualOpen(String metric, int[] open, int[] high, int[] low, int[] close) {
        return koil$isDownPressureMetric(metric) ? koil$visualSeries(metric, open) : koil$copySeries(open);
    }

    @Unique
    private int[] koil$visualHigh(String metric, int[] open, int[] high, int[] low, int[] close) {
        return koil$isDownPressureMetric(metric) ? koil$visualSeries(metric, low) : koil$copySeries(high);
    }

    @Unique
    private int[] koil$visualLow(String metric, int[] open, int[] high, int[] low, int[] close) {
        return koil$isDownPressureMetric(metric) ? koil$visualSeries(metric, high) : koil$copySeries(low);
    }

    @Unique
    private int[] koil$visualClose(String metric, int[] open, int[] high, int[] low, int[] close) {
        return koil$isDownPressureMetric(metric) ? koil$visualSeries(metric, close) : koil$copySeries(close);
    }

    @Unique
    private int[] koil$visualSeries(String metric, int[] source) {
        if (source == null || source.length == 0) {
            return new int[0];
        }

        int[] copy = koil$copySeries(source);

        if (!koil$isDownPressureMetric(metric)) {
            return copy;
        }

        int base = copy[0];

        for (int i = 0; i < copy.length; i++) {
            copy[i] = base - Math.max(0, copy[i] - base);
        }

        return copy;
    }

    @Unique
    private int[] koil$copySeries(int[] source) {
        if (source == null || source.length == 0) {
            return new int[0];
        }

        return Arrays.copyOf(source, source.length);
    }

    @Unique
    private boolean koil$isDownPressureMetric(String metric) {
        return koil$isNegativePressureMetric(metric) || koil$isSupplyPressureMetric(metric);
    }

    @Unique
    private int[] koil$marketMainPressureSeries(KoilGlobalMarketViewRow view, int[] fallback) {
        String cacheKey = koil$marketCacheKey(view);
        int[] cached = this.koil$cachedMarketPressureSeries.get(cacheKey);

        if (cached != null) {
            return cached;
        }

        List<KoilGlobalActivityRow> rows = koil$componentRowsForView(view, 64);

        if (rows.isEmpty()) {
            int[] copy = koil$copySeries(fallback);
            this.koil$cachedMarketPressureSeries.put(cacheKey, copy);
            return copy;
        }

        int maxLength = 0;

        for (KoilGlobalActivityRow row : rows) {
            maxLength = Math.max(maxLength, row.pointsView().length);
        }

        if (maxLength <= 0) {
            int[] copy = koil$copySeries(fallback);
            this.koil$cachedMarketPressureSeries.put(cacheKey, copy);
            return copy;
        }

        int[] out = new int[maxLength];
        out[0] = 0;

        for (int i = 1; i < maxLength; i++) {
            int delta = 0;

            for (KoilGlobalActivityRow row : rows) {
                int[] points = row.pointsView();

                if (points.length == 0) {
                    continue;
                }

                int current = koil$alignedSeriesValue(points, i, maxLength);
                int previous = koil$alignedSeriesValue(points, i - 1, maxLength);
                int movement = Math.max(0, current - previous);

                if (koil$isNegativePressureMetric(row.metric()) || koil$isSupplyPressureMetric(row.metric())) {
                    delta -= movement;
                } else if (koil$isDemandPressureMetric(row.metric())) {
                    delta += movement;
                } else {
                    delta += Math.round(movement * 0.20F);
                }
            }

            out[i] = out[i - 1] + delta;
        }

        this.koil$cachedMarketPressureSeries.put(cacheKey, out);
        return out;
    }

    @Unique
    private int koil$alignedSeriesValue(int[] points, int targetIndex, int targetLength) {
        if (points == null || points.length == 0) {
            return 0;
        }

        int offset = Math.max(0, targetLength - points.length);
        int sourceIndex = targetIndex - offset;

        if (sourceIndex < 0) {
            return points[0];
        }

        if (sourceIndex >= points.length) {
            return points[points.length - 1];
        }

        return points[sourceIndex];
    }

    @Unique
    private int[] koil$movingAverageFromSeries(int[] points) {
        if (points == null || points.length == 0) {
            return new int[0];
        }

        int[] out = new int[points.length];
        int window = 4;

        for (int i = 0; i < points.length; i++) {
            int start = Math.max(0, i - window + 1);
            int total = 0;
            int count = 0;

            for (int j = start; j <= i; j++) {
                total += points[j];
                count++;
            }

            out[i] = count <= 0 ? points[i] : Math.round(total / (float) count);
        }

        return out;
    }

    @Unique
    private int[][] koil$candlesFromSeries(int[] points) {
        if (points == null || points.length == 0) {
            return new int[][]{new int[0], new int[0], new int[0], new int[0]};
        }

        int[] open = new int[points.length];
        int[] high = new int[points.length];
        int[] low = new int[points.length];
        int[] close = new int[points.length];

        for (int i = 0; i < points.length; i++) {
            int previous = i == 0 ? points[i] : points[i - 1];
            int current = points[i];
            open[i] = previous;
            close[i] = current;
            high[i] = Math.max(previous, current);
            low[i] = Math.min(previous, current);
        }

        return new int[][]{open, high, low, close};
    }

    @Unique
    private boolean koil$isNegativePressureMetric(String metric) {
        String value = koil$normalizeGlobalMetric(metric);
        return value.contains("dropped")
                || value.contains("death")
                || value.contains("killed_by")
                || value.contains("damage_taken")
                || value.contains("loss")
                || value.contains("spent")
                || value.contains("removed");
    }

    @Unique
    private boolean koil$isSupplyPressureMetric(String metric) {
        String value = koil$normalizeGlobalMetric(metric);
        return value.contains("container_in/")
                || value.contains("broken")
                || value.contains("break")
                || value.contains("mined")
                || value.contains("harvest")
                || value.contains("produced")
                || value.contains("smelt_output")
                || value.contains("compost_output")
                || value.contains("station_output");
    }

    @Unique
    private boolean koil$isDemandPressureMetric(String metric) {
        String value = koil$normalizeGlobalMetric(metric);
        return value.contains("container_out/")
                || value.contains("mob_killed")
                || value.contains("entity_killed")
                || value.equals("mobs_killed")
                || value.contains("place")
                || value.contains("placed")
                || value.contains("used")
                || value.contains("use_intent")
                || value.contains("crafted")
                || value.contains("picked_up")
                || value.contains("traded")
                || value.contains("eaten")
                || value.contains("mainhand")
                || value.contains("offhand");
    }

    @Unique
    private List<Object[]> koil$syntheticComponentSeries(KoilGlobalMarketViewRow view) {
        String cacheKey = koil$marketCacheKey(view);
        List<Object[]> cached = this.koil$cachedSyntheticSeries.get(cacheKey);

        if (cached != null) {
            return cached;
        }

        List<KoilGlobalActivityRow> rows = koil$componentRowsForView(view, 64);
        List<Object[]> out = new ArrayList<>();

        if (rows.isEmpty()) {
            List<Object[]> empty = Collections.emptyList();
            this.koil$cachedSyntheticSeries.put(cacheKey, empty);
            return empty;
        }

        int maxLength = 0;

        for (KoilGlobalActivityRow row : rows) {
            maxLength = Math.max(maxLength, row.pointsView().length);
        }

        if (maxLength <= 0) {
            List<Object[]> empty = Collections.emptyList();
            this.koil$cachedSyntheticSeries.put(cacheKey, empty);
            return empty;
        }

        int[] allActivity = new int[maxLength];
        int[] demand = new int[maxLength];
        int[] supply = new int[maxLength];
        int[] loss = new int[maxLength];
        int[] ratio = new int[maxLength];

        for (KoilGlobalActivityRow row : rows) {
            int[] points = row.pointsView();

            if (points.length == 0) {
                continue;
            }

            for (int i = 0; i < maxLength; i++) {
                int value = koil$alignedSeriesValue(points, i, maxLength);
                allActivity[i] += Math.abs(value);

                if (koil$isNegativePressureMetric(row.metric())) {
                    loss[i] += Math.abs(value);
                } else if (koil$isSupplyPressureMetric(row.metric())) {
                    supply[i] += Math.abs(value);
                } else if (koil$isDemandPressureMetric(row.metric())) {
                    demand[i] += Math.abs(value);
                }
            }
        }

        int base = loss.length == 0 ? 0 : loss[0];
        int supplyBase = supply.length == 0 ? 0 : supply[0];

        for (int i = 0; i < maxLength; i++) {
            ratio[i] = demand[i] - loss[i] - supply[i];
            loss[i] = base - Math.max(0, loss[i] - base);
            supply[i] = supplyBase - Math.max(0, supply[i] - supplyBase);
        }

        if (koil$seriesHasSignal(allActivity)) {
            out.add(new Object[]{"total activity line", 0xCC8FC5FF, allActivity, "all raw inputs combined without changing the place/break ratio"});
        }

        if (koil$seriesHasSignal(demand)) {
            out.add(new Object[]{"demand/use/place pressure", 0xCCA6D989, demand, "positive pressure from placed, used, crafted, picked up, traded, and held items"});
        }

        if (koil$seriesHasSignal(supply)) {
            out.add(new Object[]{"supply/production pressure", 0xCCE8C86F, supply, "value-down pressure from broken, mined, harvested, smelted, and produced resources"});
        }

        if (koil$seriesHasSignal(loss)) {
            out.add(new Object[]{"loss/destruction pressure", 0xCCE06A6A, loss, "scarcity pressure from dropped, deaths, damage taken, destroyed, and loss signals"});
        }

        if (koil$seriesHasSignal(ratio)) {
            out.add(new Object[]{"net value pressure", 0xCCFFB86F, ratio, "demand pressure minus production supply and loss pressure"});
        }

        List<Object[]> result = Collections.unmodifiableList(out);
        this.koil$cachedSyntheticSeries.put(cacheKey, result);
        return result;
    }

    @Unique
    private boolean koil$seriesHasSignal(int[] points) {
        if (points == null || points.length == 0) {
            return false;
        }

        for (int point : points) {
            if (point != 0) {
                return true;
            }
        }

        return false;
    }

    @Unique
    private void koil$appendCandleCauseTooltipLines(List<class_2561> lines, KoilGlobalActivityRow row, @Nullable KoilGlobalMarketViewRow view, List<KoilGlobalActivityRow> components, List<Object[]> syntheticComponents, int[] mainPoints, int candleIndex, int candleCount, int open, int close) {
        int netMove = close - open;
        int positive = 0;
        int negative = 0;
        int neutral = 0;
        List<Object[]> top = new ArrayList<>();

        for (KoilGlobalActivityRow component : components) {
            int[] points = component.pointsView();

            if (points.length == 0) {
                continue;
            }

            int current = koil$alignedSeriesValue(points, candleIndex, candleCount);
            int previous = candleIndex <= 0 ? current : koil$alignedSeriesValue(points, candleIndex - 1, candleCount);
            int movement = current - previous;

            if (movement == 0) {
                continue;
            }

            int amount = Math.abs(movement);
            int color;
            String prefix;

            if (koil$isNegativePressureMetric(component.metric())) {
                negative += amount;
                color = 0xFFE06A6A;
                prefix = "negative";
            } else if (koil$isSupplyPressureMetric(component.metric())) {
                negative += amount;
                color = 0xFFE8C86F;
                prefix = "supply";
            } else if (koil$isDemandPressureMetric(component.metric())) {
                positive += amount;
                color = 0xFFA6D989;
                prefix = "positive";
            } else {
                neutral += amount;
                color = 0xFFB8C7D6;
                prefix = "neutral";
            }

            top.add(new Object[]{component.title(), amount, color, prefix});
        }

        for (Object[] synthetic : syntheticComponents) {
            if (synthetic.length < 3 || !(synthetic[2] instanceof int[] points) || points.length == 0) {
                continue;
            }

            int current = koil$alignedSeriesValue(points, candleIndex, candleCount);
            int previous = candleIndex <= 0 ? current : koil$alignedSeriesValue(points, candleIndex - 1, candleCount);
            int movement = current - previous;

            if (movement == 0) {
                continue;
            }

            String name = String.valueOf(synthetic[0]);
            int amount = Math.abs(movement);
            int color = synthetic.length > 1 && synthetic[1] instanceof Integer ? (Integer) synthetic[1] : 0xFFB8C7D6;
            String prefix = movement > 0 ? "up" : "down";
            top.add(new Object[]{name, amount, color, prefix});
        }

        if (view != null && components.isEmpty()) {
            positive = Math.max(0, netMove);
            negative = Math.max(0, -netMove);
        }

        top.sort((a, b) -> Integer.compare((Integer) b[1], (Integer) a[1]));
        lines.add(koil$tooltipLine("Movement cause", 0xFFE7EDF4));
        lines.add(koil$tooltipLine("Positive pressure: +" + positive, 0xFFA6D989));
        lines.add(koil$tooltipLine("Negative pressure: -" + negative, 0xFFE06A6A));
        lines.add(koil$tooltipLine("Neutral activity: " + neutral, 0xFFB8C7D6));
        lines.add(koil$tooltipLine("Net pressure shown: " + koil$signed(netMove), netMove >= 0 ? 0xFFA6D989 : 0xFFE06A6A));

        int limit = Math.min(6, top.size());

        if (limit > 0) {
            lines.add(koil$tooltipLine("Top candle inputs", 0xFFE8C86F));
        }

        for (int i = 0; i < limit; i++) {
            Object[] item = top.get(i);
            String name = koil$ellipsize(String.valueOf(item[0]), 180);
            int amount = (Integer) item[1];
            int color = (Integer) item[2];
            String prefix = String.valueOf(item[3]);
            lines.add(koil$tooltipLine(prefix + ": " + name + "  " + amount, color));
        }
    }

    @Unique
    private void koil$drawSeriesNodes(class_332 context, int x, int y, int width, int height, int[] points, int min, int range, int color, int radius) {
        if (points == null || points.length == 0) {
            return;
        }

        int step = Math.max(1, points.length / 24);

        for (int i = 0; i < points.length; i += step) {
            int pointX = x + 1 + Math.round(i / (float) Math.max(1, points.length - 1) * Math.max(1, width - 2));
            int pointY = koil$chartY(y, height, points[i], min, range);
            context.method_25294(pointX - radius, pointY - radius, pointX + radius + 1, pointY + radius + 1, color | 0xFF000000);
            context.method_49601(pointX - radius - 1, pointY - radius - 1, radius * 2 + 3, radius * 2 + 3, 0xAA000000);
        }
    }

    @Unique
    @Nullable
    private Object[] koil$syntheticLineAt(List<Object[]> components, int x, int y, int width, int height, int min, int range, int mouseX, int mouseY) {
        for (Object[] component : components) {
            if (component.length < 3 || !(component[2] instanceof int[] points) || points.length < 2) {
                continue;
            }

            int previousX = x + 1;
            int previousY = koil$chartY(y, height, points[0], min, range);

            for (int pointIndex = 1; pointIndex < points.length; pointIndex++) {
                int nextX = x + 1 + Math.round(pointIndex / (float) (points.length - 1) * Math.max(1, width - 2));
                int nextY = koil$chartY(y, height, points[pointIndex], min, range);

                if (koil$distanceToSegment(mouseX, mouseY, previousX, previousY, nextX, nextY) <= 5.5D) {
                    return component;
                }

                previousX = nextX;
                previousY = nextY;
            }
        }

        return null;
    }

    @Unique
    private void koil$drawSyntheticLegend(class_332 context, int x, int y, List<Object[]> components, int maxWidth) {
        int cursorX = x;
        int count = Math.min(3, components.size());

        for (int i = 0; i < count; i++) {
            Object[] component = components.get(i);
            String label = String.valueOf(component[0]);
            int color = component.length > 1 && component[1] instanceof Integer ? (Integer) component[1] : 0xCC8FC5FF;
            label = koil$ellipsize(label, 86);
            int labelWidth = this.field_22793.method_1727(label) + 14;

            if (cursorX + labelWidth > x + maxWidth) {
                break;
            }

            context.method_25294(cursorX, y + 2, cursorX + 8, y + 4, color);
            context.method_51439(this.field_22793, class_2561.method_43470(label), cursorX + 11, y - 1, 0xCCB8C7D6, false);
            cursorX += labelWidth + 8;
        }
    }

    @Unique
    private int[] koil$chartRangeValues(int[] points, int[] open, int[] high, int[] low, int[] close, List<KoilGlobalActivityRow> components, List<Object[]> syntheticComponents, int width) {
        int min = Integer.MAX_VALUE;
        int max = 1;
        int[][] arrays = new int[][]{points, open, high, low, close};

        for (int[] array : arrays) {
            if (array == null) {
                continue;
            }

            for (int value : array) {
                min = Math.min(min, value);
                max = Math.max(max, value);
            }
        }

        for (KoilGlobalActivityRow component : components) {
            int[] componentPoints = koil$stockRenderWindow(koil$visualSeries(component.metric(), component.pointsView()), width);

            for (int value : componentPoints) {
                min = Math.min(min, value);
                max = Math.max(max, value);
            }
        }

        for (Object[] synthetic : syntheticComponents) {
            if (synthetic.length < 3 || !(synthetic[2] instanceof int[] syntheticPoints)) {
                continue;
            }

            int[] displaySyntheticPoints = koil$stockRenderWindow(syntheticPoints, width);

            for (int value : displaySyntheticPoints) {
                min = Math.min(min, value);
                max = Math.max(max, value);
            }
        }

        if (min == Integer.MAX_VALUE) {
            min = 0;
        }

        return new int[]{min, max};
    }

    @Unique
    private void koil$drawCandles(class_332 context, int x, int y, int width, int height, int[] open, int[] high, int[] low, int[] close, int min, int range, int mouseX, int mouseY, KoilGlobalActivityRow row, @Nullable KoilGlobalMarketViewRow view, List<KoilGlobalActivityRow> components, List<Object[]> syntheticComponents, int[] mainPoints) {
        if (open.length == 0 || high.length == 0 || low.length == 0 || close.length == 0) {
            return;
        }

        int count = Math.min(Math.min(open.length, high.length), Math.min(low.length, close.length));
        int candleWidth = Math.max(4, Math.min(10, width / Math.max(1, count) - 2));

        for (int i = 0; i < count; i++) {
            int centerX = x + Math.round(i / (float) Math.max(1, count - 1) * Math.max(1, width));
            int bodyLeft = Math.max(x, centerX - candleWidth / 2);
            int bodyRight = Math.min(x + width, centerX + candleWidth / 2);
            int openY = koil$chartY(y, height, open[i], min, range);
            int highY = koil$chartY(y, height, high[i], min, range);
            int lowY = koil$chartY(y, height, low[i], min, range);
            int closeY = koil$chartY(y, height, close[i], min, range);
            boolean up = close[i] >= open[i];
            int candleColor = up ? 0xFFA6D989 : 0xFFE06A6A;
            int bodyTop = Math.max(y, Math.min(openY, closeY));
            int bodyBottom = Math.min(y + height, Math.max(openY, closeY));
            int wickTop = Math.max(y, Math.min(highY, lowY));
            int wickBottom = Math.min(y + height, Math.max(highY, lowY));
            int tailLeft = Math.max(x, centerX - Math.max(2, candleWidth / 2));
            int tailRight = Math.min(x + width, centerX + Math.max(3, candleWidth / 2));
            context.method_25294(centerX - 1, wickTop, centerX + 1, wickBottom + 1, candleColor);
            context.method_25294(tailLeft, wickTop, tailRight, wickTop + 1, candleColor);
            context.method_25294(tailLeft, wickBottom, tailRight, wickBottom + 1, candleColor);
            context.method_25294(bodyLeft, bodyTop, Math.max(bodyLeft + 4, bodyRight), Math.max(bodyTop + 4, bodyBottom + 1), candleColor);
            context.method_49601(bodyLeft, bodyTop, Math.max(4, bodyRight - bodyLeft), Math.max(4, bodyBottom - bodyTop + 1), 0xCC000000);

            if (koil$isMouseInsideStatsViewport(mouseX, mouseY) && mouseX >= tailLeft - 2 && mouseX <= tailRight + 2 && mouseY >= wickTop - 2 && mouseY <= wickBottom + 2 && this.koil$hoverTooltipLines.isEmpty()) {
                context.method_25294(centerX - 1, wickTop, centerX + 2, wickBottom + 1, koil$withAlpha(candleColor, 255));
                context.method_49601(bodyLeft - 1, bodyTop - 1, Math.max(6, bodyRight - bodyLeft + 2), Math.max(6, bodyBottom - bodyTop + 3), 0xFFFFFFFF);
                koil$drawHoverNode(context, centerX, closeY, candleColor);
                List<class_2561> lines = new ArrayList<>();
                lines.add(koil$tooltipLine(row.title(), 0xFFE7EDF4));
                lines.add(koil$tooltipLine("Feature: candle " + (i + 1) + " / " + count, candleColor));
                lines.add(koil$tooltipLine("Open: " + open[i], 0xFFB8C7D6));
                lines.add(koil$tooltipLine("High: " + high[i], 0xFFA6D989));
                lines.add(koil$tooltipLine("Low: " + low[i], 0xFFE06A6A));
                lines.add(koil$tooltipLine("Close: " + close[i], candleColor));
                lines.add(koil$tooltipLine("Net candle move: " + koil$signed(close[i] - open[i]), close[i] >= open[i] ? 0xFFA6D989 : 0xFFE06A6A));
                lines.add(koil$tooltipLine("Body: " + Math.abs(close[i] - open[i]) + "  Tail/Wick: " + Math.max(0, Math.abs(high[i] - low[i])), 0xFF8FD5D0));
                koil$appendCandleCauseTooltipLines(lines, row, view, components, syntheticComponents, mainPoints, i, count, open[i], close[i]);
                lines.add(koil$tooltipLine(up ? "Meaning: this capture closed above its open" : "Meaning: this capture closed below its open", up ? 0xFFA6D989 : 0xFFE06A6A));
                koil$setHoverTooltip(lines.toArray(new class_2561[0]));
            }
        }
    }

    @Unique
    private void koil$drawSyntheticComponentStockLines(class_332 context, int x, int y, int width, int height, List<Object[]> components, int min, int range, int mouseX, int mouseY) {
        for (int i = 0; i < components.size(); i++) {
            Object[] component = components.get(i);

            if (component.length < 3 || !(component[2] instanceof int[] points)) {
                continue;
            }

            int color = component.length > 1 && component[1] instanceof Integer ? (Integer) component[1] : 0xCC8FC5FF;
            int[] displayPoints = koil$stockRenderWindow(points, width);
            int adjustedColor = koil$impactAdjustedColor(color, displayPoints, range);
            boolean dashed = i % 2 == 1;
            koil$drawPressureLineWithArrow(context, x, y, width, height, displayPoints, min, range, adjustedColor, dashed, koil$isMajorMarketMove(displayPoints, range));
        }
    }

    @Unique
    private void koil$drawComponentStockLines(class_332 context, int x, int y, int width, int height, List<KoilGlobalActivityRow> components, int min, int range, int mouseX, int mouseY) {
        for (int i = 0; i < components.size(); i++) {
            KoilGlobalActivityRow component = components.get(i);
            int color = koil$componentLineColor(i, component.metric());
            int[] visualPoints = koil$stockRenderWindow(koil$visualSeries(component.metric(), component.pointsView()), width);
            int adjustedColor = koil$impactAdjustedColor(color, visualPoints, range);
            boolean strong = koil$seriesImpact(visualPoints, range) > 0.34F;
            koil$drawPressureLineWithArrow(context, x, y, width, height, visualPoints, min, range, adjustedColor, i % 2 == 1, koil$isMajorMarketMove(visualPoints, range));
        }
    }

    @Unique
    private void koil$drawMainMarketLine(class_332 context, int x, int y, int width, int height, int[] points, int min, int range) {
        if (points == null || points.length < 2) {
            return;
        }

        int softWhite = 0xAAFFFFFF;
        int fullWhite = 0xFFFFFFFF;
        koil$drawIndicatorLineFixedRange(context, x, y, width, height, points, min, range, softWhite, false);
        koil$drawIndicatorLineFixedRange(context, x, y + 1, width, height, points, min, range, fullWhite, false);
        koil$drawIndicatorLineFixedRange(context, x, y - 1, width, height, points, min, range, 0x66FFFFFF, false);

        if (koil$isMajorMarketMove(points, range)) {
            koil$drawEndpointArrow(context, x, y, width, height, points, min, range, fullWhite);
        }
    }

    @Unique
    private void koil$drawPressureLineWithArrow(class_332 context, int x, int y, int width, int height, int[] points, int min, int range, int color, boolean dashed, boolean strong) {
        if (points == null || points.length < 2) {
            return;
        }

        koil$drawIndicatorLineFixedRange(context, x, y, width, height, points, min, range, color, dashed);

        if (strong) {
            koil$drawIndicatorLineFixedRange(context, x, y + 1, width, height, points, min, range, color, dashed);
        }

        if (strong) {
            koil$drawEndpointArrow(context, x, y, width, height, points, min, range, color);
        }
    }

    @Unique
    private boolean koil$isMajorMarketMove(int[] points, int range) {
        if (points == null || points.length < 2) {
            return false;
        }

        int start = points[0];
        int end = points[points.length - 1];
        int latestDelta = Math.abs(end - points[Math.max(0, points.length - 2)]);
        int totalDelta = Math.abs(end - start);
        float impact = koil$seriesImpact(points, range);

        return impact >= 0.38F || latestDelta >= Math.max(2, Math.round(range * 0.14F)) || totalDelta >= Math.max(3, Math.round(range * 0.28F));
    }

    @Unique
    private int koil$impactAdjustedColor(int color, int[] points, int range) {
        int rgb = color & 0x00FFFFFF;
        int alpha = Math.max(84, Math.min(242, Math.round(82.0F + koil$seriesImpact(points, range) * 170.0F)));
        return (alpha << 24) | rgb;
    }

    @Unique
    private float koil$seriesImpact(int[] points, int range) {
        if (points == null || points.length < 2) {
            return 0.0F;
        }

        int min = Integer.MAX_VALUE;
        int max = Integer.MIN_VALUE;

        for (int point : points) {
            min = Math.min(min, point);
            max = Math.max(max, point);
        }

        return Math.max(0.0F, Math.min(1.0F, (max - min) / (float) Math.max(1, range)));
    }

    @Unique
    private void koil$drawEndpointArrow(class_332 context, int x, int y, int width, int height, int[] points, int min, int range, int color) {
        if (points == null || points.length < 2) {
            return;
        }

        int endIndex = points.length - 1;
        int previousIndex = Math.max(0, endIndex - 1);

        while (previousIndex > 0 && points[previousIndex] == points[endIndex]) {
            previousIndex--;
        }

        int endX = x + 1 + Math.round(endIndex / (float) Math.max(1, points.length - 1) * Math.max(1, width - 2));
        int endY = koil$chartY(y, height, points[endIndex], min, range);
        int previousX = x + 1 + Math.round(previousIndex / (float) Math.max(1, points.length - 1) * Math.max(1, width - 2));
        int previousY = koil$chartY(y, height, points[previousIndex], min, range);
        int dx = endX - previousX;
        int dy = endY - previousY;

        if (dx == 0 && dy == 0) {
            return;
        }

        int dirX = Integer.compare(dx, 0);
        int dirY = Integer.compare(dy, 0);
        if (Math.abs(dx) >= Math.abs(dy)) {
            if (dirX == 0) {
                dirX = 1;
            }

            koil$drawLine(context, endX, endY, endX - dirX * 5, endY - 3, color, x, y, x + width - 1, y + height - 1);
            koil$drawLine(context, endX, endY, endX - dirX * 5, endY + 3, color, x, y, x + width - 1, y + height - 1);
        } else {
            if (dirY == 0) {
                dirY = -1;
            }

            koil$drawLine(context, endX, endY, endX - 3, endY - dirY * 5, color, x, y, x + width - 1, y + height - 1);
            koil$drawLine(context, endX, endY, endX + 3, endY - dirY * 5, color, x, y, x + width - 1, y + height - 1);
        }
    }

    @Unique
    private void koil$drawIndicatorLineFixedRange(class_332 context, int x, int y, int width, int height, int[] points, int min, int range, int color, boolean dashed) {
        if (points == null || points.length < 2) {
            return;
        }

        int previousX = x + 1;
        int previousY = koil$chartY(y, height, points[0], min, range);

        for (int i = 1; i < points.length; i++) {
            int nextX = x + 1 + Math.round(i / (float) (points.length - 1) * Math.max(1, width - 2));
            int nextY = koil$chartY(y, height, points[i], min, range);

            if (dashed && i % 2 == 0) {
                previousX = nextX;
                previousY = nextY;
                continue;
            }

            koil$drawLine(context, previousX, previousY, nextX, nextY, color, x, y, x + width - 1, y + height - 1);
            previousX = nextX;
            previousY = nextY;
        }
    }

    @Unique
    private void koil$updateStockChartHover(class_332 context, KoilGlobalActivityRow row, @Nullable KoilGlobalMarketViewRow view, int x, int y, int width, int height, int[] points, int[] average, List<KoilGlobalActivityRow> components, List<Object[]> syntheticComponents, int min, int range, int mouseX, int mouseY) {
        if (!koil$isMouseInsideStatsViewport(mouseX, mouseY) || mouseX < x || mouseX > x + width || mouseY < y || mouseY > y + height || points == null || points.length == 0 || !this.koil$hoverTooltipLines.isEmpty()) {
            return;
        }

        String feature = "";
        int featureColor = 0xFFFFFFFF;
        int[] featurePoints = null;
        int[] hover = null;
        Object[] syntheticHit = null;
        KoilGlobalActivityRow componentHit = null;
        int featurePriority = Integer.MAX_VALUE;

        for (Object[] synthetic : syntheticComponents) {
            if (synthetic.length < 3 || !(synthetic[2] instanceof int[] syntheticPoints)) {
                continue;
            }

            syntheticPoints = koil$stockRenderWindow(syntheticPoints, width);

            if (syntheticPoints.length < 2) {
                continue;
            }

            int[] hit = koil$nearestSeriesHover(syntheticPoints, x, y, width, height, min, range, mouseX, mouseY, 6.0D);

            if (hit != null && hit[4] < featurePriority) {
                featurePriority = hit[4];
                hover = hit;
                syntheticHit = synthetic;
                componentHit = null;
                featurePoints = syntheticPoints;
                feature = String.valueOf(synthetic[0]);
                featureColor = synthetic.length > 1 && synthetic[1] instanceof Integer ? (Integer) synthetic[1] : 0xFF8FC5FF;
            }
        }

        for (int i = 0; i < components.size(); i++) {
            KoilGlobalActivityRow component = components.get(i);
            int[] componentPoints = koil$stockRenderWindow(koil$visualSeries(component.metric(), component.pointsView()), width);
            int[] hit = koil$nearestSeriesHover(componentPoints, x, y, width, height, min, range, mouseX, mouseY, 5.5D);

            if (hit != null && hit[4] < featurePriority) {
                featurePriority = hit[4];
                hover = hit;
                syntheticHit = null;
                componentHit = component;
                featurePoints = componentPoints;
                feature = "component line: " + koil$marketMetricShortTitle(component.metric());
                featureColor = koil$componentLineColor(i, component.metric());
            }
        }

        int[] averageHit = koil$nearestSeriesHover(average, x, y, width, height, min, range, mouseX, mouseY, 5.0D);

        if (averageHit != null && averageHit[4] < featurePriority) {
            featurePriority = averageHit[4];
            hover = averageHit;
            syntheticHit = null;
            componentHit = null;
            featurePoints = average;
            feature = "moving average line";
            featureColor = 0xFFE8C86F;
        }

        int[] mainHit = koil$nearestSeriesHover(points, x, y, width, height, min, range, mouseX, mouseY, 6.0D);

        if (mainHit != null && mainHit[4] < featurePriority) {
            hover = mainHit;
            syntheticHit = null;
            componentHit = null;
            featurePoints = points;
            feature = "main market line";
            featureColor = 0xFFFFFFFF;
        }

        if (hover == null || featurePoints == null) {
            return;
        }

        int safeIndex = Math.max(0, Math.min(points.length - 1, Math.round((hover[0] / (float) Math.max(1, featurePoints.length - 1)) * Math.max(1, points.length - 1))));
        int featureIndex = Math.max(0, Math.min(featurePoints.length - 1, hover[0]));
        int point = points[safeIndex];
        int avg = average == null || average.length == 0 ? point : average[Math.max(0, Math.min(average.length - 1, safeIndex))];
        int pointX = hover[1];
        int hoverPointY = hover[2];
        int featureValue = hover[3];
        int highlightColor = koil$withAlpha(featureColor, 255);

        if ("main market line".equals(feature)) {
            koil$drawIndicatorLineFixedRange(context, x, y, width, height, points, min, range, 0xFFFFFFFF, false);
            koil$drawIndicatorLineFixedRange(context, x, y + 1, width, height, points, min, range, 0xFFFFFFFF, false);
        } else if ("moving average line".equals(feature)) {
            koil$drawIndicatorLineFixedRange(context, x, y, width, height, average, min, range, 0xFFE8C86F, true);
            koil$drawIndicatorLineFixedRange(context, x, y + 1, width, height, average, min, range, 0xCCE8C86F, true);
        } else {
            koil$drawIndicatorLineFixedRange(context, x, y, width, height, featurePoints, min, range, highlightColor, false);
            koil$drawIndicatorLineFixedRange(context, x, y + 1, width, height, featurePoints, min, range, koil$withAlpha(featureColor, 190), false);
        }

        koil$drawDashedVertical(context, pointX, y, height, 0x668FC5FF);
        koil$drawDashedHorizontal(context, x, hoverPointY, width, 0x668FC5FF);
        koil$drawHoverNode(context, pointX, hoverPointY, highlightColor);

        List<class_2561> lines = new ArrayList<>();
        lines.add(koil$tooltipLine(row.title(), 0xFFE7EDF4));
        lines.add(koil$tooltipLine("Feature: " + feature, highlightColor));
        lines.add(koil$tooltipLine("Feature capture: " + (featureIndex + 1) + " / " + featurePoints.length, 0xFFB8C7D6));
        lines.add(koil$tooltipLine("Feature value: " + featureValue, highlightColor));
        lines.add(koil$tooltipLine("Main capture: " + (safeIndex + 1) + " / " + points.length, 0xFFB8C7D6));
        lines.add(koil$tooltipLine("Main market line: " + point, 0xFFFFFFFF));
        lines.add(koil$tooltipLine("Moving average: " + avg, 0xFFE8C86F));
        lines.add(koil$tooltipLine("Volume: " + row.volume(), 0xFFE6A15C));
        lines.add(koil$tooltipLine("Trend: " + koil$signed(row.trend()), row.trend() >= 0 ? 0xFFA6D989 : 0xFFE06A6A));
        lines.add(koil$tooltipLine("Volatility: " + row.volatility(), 0xFFB7A8FF));
        lines.add(koil$tooltipLine("Leader: " + row.leader() + " (" + row.leaderValue() + ")", 0xFF8FD5D0));

        if (syntheticHit != null) {
            lines.add(koil$tooltipLine("Component role: " + String.valueOf(syntheticHit[3]), 0xFFB8C7D6));
            lines.add(koil$tooltipLine("Used for: separating activity, demand, and loss pressure", 0xFF8FD5D0));
        }

        if (componentHit != null) {
            lines.add(koil$tooltipLine("Component source: " + componentHit.source(), componentHit.authoritative() ? 0xFFA6D989 : 0xFFE6A15C));
            lines.add(koil$tooltipLine("Component confidence: " + componentHit.confidence() + "%", componentHit.authoritative() ? 0xFFA6D989 : 0xFFE6A15C));
            lines.add(koil$tooltipLine("Component leader: " + componentHit.leader() + " (" + componentHit.leaderValue() + ")", 0xFF8FD5D0));
        }

        if (view != null) {
            for (String sourceLine : koil$marketRawSourceTooltipLines(view, 5)) {
                lines.add(koil$tooltipLine(sourceLine, 0xFF8E9AA8));
            }
        }

        lines.add(koil$tooltipLine(row.authoritative() ? "Source: server exact, per world/server" : "Source: client observed " + row.confidence() + "%, per world/server", row.authoritative() ? 0xFFA6D989 : 0xFFE6A15C));
        koil$setHoverTooltip(lines.toArray(new class_2561[0]));
    }

    @Unique
    @Nullable
    private int[] koil$nearestSeriesHover(int[] points, int x, int y, int width, int height, int min, int range, int mouseX, int mouseY, double threshold) {
        if (points == null || points.length < 2) {
            return null;
        }

        double bestDistance = Double.MAX_VALUE;
        int bestIndex = 0;
        int bestX = x;
        int bestY = y;
        int bestValue = points[0];

        int previousX = x + 1;
        int previousY = koil$chartY(y, height, points[0], min, range);

        for (int i = 1; i < points.length; i++) {
            int nextX = x + 1 + Math.round(i / (float) (points.length - 1) * Math.max(1, width - 2));
            int nextY = koil$chartY(y, height, points[i], min, range);
            double[] closest = koil$closestPointOnSegment(mouseX, mouseY, previousX, previousY, nextX, nextY);
            double distance = closest[2];

            if (distance < bestDistance) {
                bestDistance = distance;
                bestIndex = Math.abs(closest[0] - previousX) <= Math.abs(closest[0] - nextX) ? i - 1 : i;
                bestX = (int) Math.round(closest[0]);
                bestY = (int) Math.round(closest[1]);
                float progress = Math.max(0.0F, Math.min(1.0F, (float) closest[3]));
                bestValue = Math.round(points[i - 1] + (points[i] - points[i - 1]) * progress);
            }

            previousX = nextX;
            previousY = nextY;
        }

        if (bestDistance > threshold) {
            return null;
        }

        return new int[]{bestIndex, bestX, bestY, bestValue, Math.round((float) bestDistance * 100.0F)};
    }

    @Unique
    private double[] koil$closestPointOnSegment(int px, int py, int x1, int y1, int x2, int y2) {
        double dx = x2 - x1;
        double dy = y2 - y1;

        if (dx == 0.0D && dy == 0.0D) {
            double singleDx = px - x1;
            double singleDy = py - y1;
            return new double[]{x1, y1, Math.sqrt(singleDx * singleDx + singleDy * singleDy), 0.0D};
        }

        double t = ((px - x1) * dx + (py - y1) * dy) / (dx * dx + dy * dy);
        t = Math.max(0.0D, Math.min(1.0D, t));
        double closestX = x1 + t * dx;
        double closestY = y1 + t * dy;
        double outX = px - closestX;
        double outY = py - closestY;
        return new double[]{closestX, closestY, Math.sqrt(outX * outX + outY * outY), t};
    }

    @Unique
    private void koil$drawHoverNode(class_332 context, int x, int y, int color) {
        context.method_25294(x - 2, y - 2, x + 3, y + 3, color);
        context.method_49601(x - 3, y - 3, 7, 7, 0xDD000000);
        context.method_49601(x - 4, y - 4, 9, 9, koil$withAlpha(color, 130));
    }

    @Unique
    private int koil$withAlpha(int color, int alpha) {
        return (Math.max(0, Math.min(255, alpha)) << 24) | (color & 0x00FFFFFF);
    }

    @Unique
    @Nullable
    private KoilGlobalActivityRow koil$componentLineAt(List<KoilGlobalActivityRow> components, int x, int y, int width, int height, int min, int range, int mouseX, int mouseY) {
        for (int i = 0; i < components.size(); i++) {
            KoilGlobalActivityRow component = components.get(i);
            int[] points = koil$stockRenderWindow(koil$visualSeries(component.metric(), component.pointsView()), width);

            if (points == null || points.length < 2) {
                continue;
            }

            int previousX = x + 1;
            int previousY = koil$chartY(y, height, points[0], min, range);

            for (int pointIndex = 1; pointIndex < points.length; pointIndex++) {
                int nextX = x + 1 + Math.round(pointIndex / (float) (points.length - 1) * Math.max(1, width - 2));
                int nextY = koil$chartY(y, height, points[pointIndex], min, range);

                if (koil$distanceToSegment(mouseX, mouseY, previousX, previousY, nextX, nextY) <= 4.5D) {
                    return component;
                }

                previousX = nextX;
                previousY = nextY;
            }
        }

        return null;
    }

    @Unique
    private double koil$distanceToSegment(int px, int py, int x1, int y1, int x2, int y2) {
        double dx = x2 - x1;
        double dy = y2 - y1;

        if (dx == 0.0D && dy == 0.0D) {
            double singleDx = px - x1;
            double singleDy = py - y1;
            return Math.sqrt(singleDx * singleDx + singleDy * singleDy);
        }

        double t = ((px - x1) * dx + (py - y1) * dy) / (dx * dx + dy * dy);
        t = Math.max(0.0D, Math.min(1.0D, t));
        double closestX = x1 + t * dx;
        double closestY = y1 + t * dy;
        double outX = px - closestX;
        double outY = py - closestY;
        return Math.sqrt(outX * outX + outY * outY);
    }

    @Unique
    private void koil$drawPreviewStockChart(class_332 context, int x, int y, int width, int height, int[] points, int color) {
        KoilGlobalActivityRow row = new KoilGlobalActivityRow("market", "preview", "preview", "Preview", points == null || points.length == 0 ? 0 : points[points.length - 1], "server", 0, points, "preview", 100, 0, 0);
        koil$drawStockChart(context, x, y, width, height, row, color, -1, -1);
    }

    @Unique
    private void koil$drawIndicatorLine(class_332 context, int x, int y, int width, int height, int[] points, int color, boolean dashed) {
        if (points == null || points.length < 2) {
            return;
        }

        int max = 1;
        int min = Integer.MAX_VALUE;

        for (int point : points) {
            max = Math.max(max, point);
            min = Math.min(min, point);
        }

        if (min == Integer.MAX_VALUE) {
            min = 0;
        }

        int spread = Math.max(1, Math.max(Math.abs(min), Math.abs(max)));
        min = -spread;
        max = spread;
        int range = Math.max(1, max - min);
        int zeroY = koil$chartY(y, height, 0, min, range);
        if (zeroY > y && zeroY < y + height) {
            koil$drawDashedHorizontal(context, x, zeroY, width, 0x338E9AA8);
        }
        int previousX = x + 1;
        int previousY = koil$chartY(y, height, points[0], min, range);

        for (int i = 1; i < points.length; i++) {
            int nextX = x + 1 + Math.round(i / (float) (points.length - 1) * Math.max(1, width - 2));
            int nextY = koil$chartY(y, height, points[i], min, range);

            if (dashed && i % 2 == 0) {
                previousX = nextX;
                previousY = nextY;
                continue;
            }

            koil$drawLine(context, previousX, previousY, nextX, nextY, color, x, y, x + width - 1, y + height - 1);
            previousX = nextX;
            previousY = nextY;
        }
    }

    @Unique
    private void koil$drawDashedHorizontal(class_332 context, int x, int y, int width, int color) {
        for (int i = 0; i < width; i += 6) {
            context.method_25294(x + i, y, Math.min(x + width, x + i + 3), y + 1, color);
        }

        if (width > 8) {
            int endX = x + width - 1;
            context.method_25294(endX - 3, y - 2, endX, y - 1, color);
            context.method_25294(endX - 3, y + 2, endX, y + 3, color);
            context.method_25294(endX - 1, y - 1, endX + 1, y + 2, color);
        }
    }

    @Unique
    private void koil$drawDashedVertical(class_332 context, int x, int y, int height, int color) {
        for (int i = 0; i < height; i += 6) {
            context.method_25294(x, y + i, x + 1, Math.min(y + height, y + i + 3), color);
        }

        if (height > 8) {
            int endY = y + height - 1;
            context.method_25294(x - 2, endY - 3, x - 1, endY, color);
            context.method_25294(x + 2, endY - 3, x + 3, endY, color);
            context.method_25294(x - 1, endY - 1, x + 2, endY + 1, color);
        }
    }

    @Unique
    private int koil$chartY(int y, int height, int value, int min, int range) {
        return y + height - 2 - Math.round((value - min) / (float) Math.max(1, range) * Math.max(1, height - 3));
    }

    @Unique
    private void koil$drawLineChart(class_332 context, int x, int y, int width, int height, int[] points, int color) {
        context.method_25294(x, y, x + width, y + height, 0x22000000);
        context.method_49601(x, y, width, height, 0x443D4A56);

        if (points == null || points.length == 0 || width <= 1 || height <= 1) {
            return;
        }

        points = koil$renderSeriesForWidth(points, width);
        int max = 1;
        int min = Integer.MAX_VALUE;

        for (int point : points) {
            max = Math.max(max, point);
            min = Math.min(min, point);
        }

        if (min == Integer.MAX_VALUE) {
            min = 0;
        }

        int range = Math.max(1, max - min);
        int previousX = x + 1;
        int previousY = y + height - 2 - Math.round((points[0] - min) / (float) range * Math.max(1, height - 3));

        for (int i = 1; i < points.length; i++) {
            int nextX = x + 1 + Math.round(i / (float) (points.length - 1) * Math.max(1, width - 2));
            int nextY = y + height - 2 - Math.round((points[i] - min) / (float) range * Math.max(1, height - 3));
            koil$drawLine(context, previousX, previousY, nextX, nextY, color, x, y, x + width - 1, y + height - 1);
            previousX = nextX;
            previousY = nextY;
        }
    }

    @Unique
    private void koil$drawLine(class_332 context, int x1, int y1, int x2, int y2, int color, int minX, int minY, int maxX, int maxY) {
        x1 = Math.max(minX, Math.min(maxX, x1));
        x2 = Math.max(minX, Math.min(maxX, x2));
        y1 = Math.max(minY, Math.min(maxY, y1));
        y2 = Math.max(minY, Math.min(maxY, y2));

        if (y1 == y2) {
            int left = Math.max(minX, Math.min(x1, x2));
            int right = Math.min(maxX, Math.max(x1, x2));

            if (y1 >= minY && y1 <= maxY && right >= left) {
                context.method_25294(left, y1, right + 1, y1 + 1, color);
            }

            return;
        }

        if (x1 == x2) {
            int top = Math.max(minY, Math.min(y1, y2));
            int bottom = Math.min(maxY, Math.max(y1, y2));

            if (x1 >= minX && x1 <= maxX && bottom >= top) {
                context.method_25294(x1, top, x1 + 1, bottom + 1, color);
            }

            return;
        }

        int dx = Math.abs(x2 - x1);
        int dy = Math.abs(y2 - y1);
        int sx = x1 < x2 ? 1 : -1;
        int sy = y1 < y2 ? 1 : -1;
        int err = dx - dy;
        int px = x1;
        int py = y1;
        int guard = 0;
        int limit = Math.max(1, (maxX - minX + 1) * (maxY - minY + 1));

        while (guard++ < limit) {
            if (px >= minX && px <= maxX && py >= minY && py <= maxY) {
                context.method_25294(px, py, px + 1, py + 1, color);
            }

            if (px == x2 && py == y2) {
                break;
            }

            int e2 = err * 2;

            if (e2 > -dy) {
                err -= dy;
                px += sx;
            }

            if (e2 < dx) {
                err += dx;
                py += sy;
            }
        }
    }


    @Unique
    private void koil$setHoverTooltip(class_2561... lines) {
        this.koil$hoverTooltipLines = Arrays.asList(lines);
    }

    @Unique
    private class_5250 koil$tooltipLine(String value, int color) {
        return class_2561.method_43470(value == null ? "" : value).method_27694(style -> style.method_36139(color & 0xFFFFFF));
    }

    @Unique
    private String koil$searchQuery() {
        return this.koil$searchBox == null ? "" : this.koil$searchBox.method_1882().trim().toLowerCase(Locale.ROOT);
    }

    @Unique
    private boolean koil$matchesSearch(String... values) {
        String query = koil$searchQuery();

        if (query.isBlank()) {
            return true;
        }

        for (String value : values) {
            if (value != null && value.toLowerCase(Locale.ROOT).contains(query)) {
                return true;
            }
        }

        return false;
    }

    @Unique
    private List<Object[]> koil$filterGeneralRows(List<Object[]> rows) {
        String query = koil$searchQuery();

        if (query.isBlank()) {
            return rows;
        }

        List<Object[]> filtered = new ArrayList<>();

        for (Object[] row : rows) {
            if (koil$matchesSearch(String.valueOf(row[0]), String.valueOf(row[1]), String.valueOf(row[3]), String.valueOf(row[5]))) {
                filtered.add(row);
            }
        }

        return filtered;
    }

    @Unique
    private List<Object[]> koil$filterItemRows(List<Object[]> rows) {
        String query = koil$searchQuery();

        if (query.isBlank()) {
            return rows;
        }

        List<Object[]> filtered = new ArrayList<>();

        for (Object[] row : rows) {
            if (koil$matchesSearch(String.valueOf(row[1]), String.valueOf(row[9]), koil$itemDominantMetric((Integer) row[2], (Integer) row[3], (Integer) row[4], (Integer) row[5], (Integer) row[6], (Integer) row[7]))) {
                filtered.add(row);
            }
        }

        return filtered;
    }

    @Unique
    private List<Object[]> koil$filterEntityRows(List<Object[]> rows) {
        String query = koil$searchQuery();

        if (query.isBlank()) {
            return rows;
        }

        List<Object[]> filtered = new ArrayList<>();

        for (Object[] row : rows) {
            if (koil$matchesSearch(String.valueOf(row[0]), String.valueOf(row[3]), koil$threatLabel((Integer) row[1], (Integer) row[2]))) {
                filtered.add(row);
            }
        }

        return filtered;
    }

    @Unique
    private List<KoilGlobalActivityRow> koil$filterGlobalRows(List<KoilGlobalActivityRow> rows) {
        String query = koil$searchQuery();

        if (query.isBlank()) {
            return rows;
        }

        List<KoilGlobalActivityRow> filtered = new ArrayList<>();

        for (KoilGlobalActivityRow row : rows) {
            if (koil$matchesSearch(row.title(), row.metric(), row.id(), row.leader(), row.source(), koil$marketDisplayName(row), koil$globalMetricGroup(row.metric()))) {
                filtered.add(row);
            }
        }

        return filtered;
    }

    @Unique
    private void koil$renderHoverTooltip(class_332 context, int mouseX, int mouseY) {
        if (this.koil$hoverTooltipLines.isEmpty()) {
            return;
        }

        context.method_51437(this.field_22793, this.koil$hoverTooltipLines, Optional.empty(), mouseX, mouseY);
    }

    @Unique
    private void koil$drawSummaryIcon(class_332 context, String name, int x, int y) {
        context.method_51445(koil$summaryIconItem(name).method_7854(), x, y);
    }

    @Unique
    private class_1792 koil$summaryIconItem(String name) {
        String value = name == null ? "" : name.toLowerCase(Locale.ROOT);

        if (value.contains("time")) {
            return class_1802.field_8557;
        }

        if (value.contains("travel")) {
            return class_1802.field_8251;
        }

        if (value.contains("combat")) {
            return class_1802.field_8371;
        }

        if (value.contains("item")) {
            return class_1802.field_8106;
        }

        if (value.contains("mob")) {
            return class_1802.field_8398;
        }

        if (value.contains("jump")) {
            return class_1802.field_8153;
        }

        if (value.contains("global")) {
            return class_1802.field_8687;
        }

        return class_1802.field_8407;
    }


    @Unique
    private void koil$drawMarketViewIcon(class_332 context, KoilGlobalMarketViewRow view, int x, int y) {
        class_1792 icon = class_1802.field_8407;

        for (String metric : view.rawMetrics()) {
            class_1792 parsed = koil$registryItemFromMetric(koil$normalizeGlobalMetric(metric));

            if (parsed != class_1802.field_8162) {
                icon = parsed;
                break;
            }
        }

        if (icon == class_1802.field_8407 || icon == class_1802.field_8162) {
            String domain = view.domain() == null ? "" : view.domain().toLowerCase(Locale.ROOT);

            if ("block".equals(domain)) {
                icon = class_1802.field_8270;
            } else if ("item".equals(domain)) {
                icon = class_1802.field_8106;
            } else if ("resource".equals(domain)) {
                icon = class_1802.field_8477;
            } else if ("entity".equals(domain)) {
                icon = class_1802.field_8398;
            } else if ("combat".equals(domain)) {
                icon = class_1802.field_8371;
            } else if ("food".equals(domain)) {
                icon = class_1802.field_8229;
            } else if ("trade".equals(domain)) {
                icon = class_1802.field_8687;
            } else if ("equipment".equals(domain)) {
                icon = class_1802.field_8255;
            }
        }

        context.method_51445(icon.method_7854(), x, y);
    }
    @Unique
    private void koil$drawMetricIcon(class_332 context, KoilGlobalActivityRow row, int x, int y) {
        class_1792 icon = koil$metricIconItem(row);
        context.method_51445(icon.method_7854(), x, y);
    }

    @Unique
    private class_1792 koil$metricIconItem(KoilGlobalActivityRow row) {
        if (row == null) {
            return class_1802.field_8407;
        }

        String value = (row.metric() + " " + row.id() + " " + row.title()).toLowerCase(Locale.ROOT);
        class_1792 parsed = koil$registryItemFromMetric(value);

        if (parsed != class_1802.field_8162) {
            return parsed;
        }

        if (value.contains("mainhand") || value.contains("main hand")) {
            return class_1802.field_8371;
        }

        if (value.contains("offhand") || value.contains("off hand")) {
            return class_1802.field_8255;
        }

        if (row.market() || value.contains("market") || value.contains("trade") || value.contains("buy") || value.contains("sell")) {
            return class_1802.field_8687;
        }

        if (value.contains("break") || value.contains("mine")) {
            return class_1802.field_8403;
        }

        if (value.contains("place") || value.contains("build")) {
            return class_1802.field_20391;
        }

        if (value.contains("craft")) {
            return class_1802.field_8465;
        }

        if (koil$isFoodMetricText(value)) {
            return class_1802.field_8229;
        }

        if (value.contains("kill") || value.contains("damage")) {
            return class_1802.field_8371;
        }

        if (value.contains("death")) {
            return class_1802.field_8398;
        }

        if (value.contains("item")) {
            return class_1802.field_8106;
        }

        if (value.contains("block")) {
            return class_1802.field_8270;
        }

        return class_1802.field_8407;
    }

    @Unique
    private class_1792 koil$registryItemFromMetric(String metric) {
        String[] prefixes = new String[]{"block_broken/", "block_place_intent/", "block_placed/", "block_used/", "block_use/", "item_use_intent/", "item_used/", "item_crafted/", "item_picked_up/", "item_dropped/", "item_traded/", "food_eaten/", "item_eaten/", "mob_killed/", "entity_killed/", "killed_by/", "mainhand/", "offhand/", "self_mainhand/", "self_offhand/"};

        for (String prefix : prefixes) {
            int prefixIndex = metric.indexOf(prefix);

            if (prefixIndex < 0) {
                continue;
            }

            String rest = metric.substring(prefixIndex + prefix.length());
            int separator = rest.indexOf('/');

            if (separator <= 0 || separator >= rest.length() - 1) {
                class_2960 simpleId = koil$registryIdFromLooseName(rest);

                if (simpleId == null) {
                    return class_1802.field_8162;
                }

                if (prefix.startsWith("block_")) {
                    class_2248 block = class_7923.field_41175.method_10223(simpleId);
                    class_1792 item = block.method_8389();
                    return item == class_1802.field_8162 ? class_1802.field_8162 : item;
                }

                class_1792 item = class_7923.field_41178.method_10223(simpleId);
                return item == null || item == class_1802.field_8162 ? class_1802.field_8162 : item;
            }

            class_2960 id;

            try {
                id = new class_2960(rest.substring(0, separator), rest.substring(separator + 1));
            } catch (Exception ignored) {
                return class_1802.field_8162;
            }

            if (prefix.startsWith("block_")) {
                class_2248 block = class_7923.field_41175.method_10223(id);
                class_1792 item = block.method_8389();
                return item == class_1802.field_8162 ? class_1802.field_20391 : item;
            }

            class_1792 item = class_7923.field_41178.method_10223(id);
            return item == null || item == class_1802.field_8162 ? class_1802.field_8162 : item;
        }

        return class_1802.field_8162;
    }


    @Unique
    @Nullable
    private class_2960 koil$registryIdFromLooseName(String value) {
        if (value == null || value.isBlank()) {
            return null;
        }

        String clean = value.trim().toLowerCase(Locale.ROOT).replace(' ', '_');

        try {
            class_2960 minecraft = new class_2960("minecraft", clean);

            if (class_7923.field_41178.method_10223(minecraft) != class_1802.field_8162 || class_7923.field_41175.method_10223(minecraft).method_8389() != class_1802.field_8162) {
                return minecraft;
            }
        } catch (Exception ignored) {
        }

        return null;
    }
    @Unique
    private int[] koil$miniPreviewSeriesForView(KoilGlobalMarketViewRow view) {
        if (view == null || view.chartRow() == null) {
            return new int[0];
        }

        String cacheKey = koil$marketCacheKey(view) + "|" + this.koil$stockGraphInterval + "|" + KoilMarketSeriesWindow.daySampleIndex(koil$worldTimeForStockWindow());
        int[] cached = this.koil$cachedMiniPreviewSeries.get(cacheKey);

        if (cached != null) {
            return cached;
        }

        KoilGlobalActivityRow row = view.chartRow();
        int[] result = koil$stockRenderWindow(koil$marketMainPressureSeries(view, row.pointsView()), 184);
        this.koil$cachedMiniPreviewSeries.put(cacheKey, result);
        return result;
    }

    @Unique
    private void koil$drawMiniStockPreview(class_332 context, int x, int y, int width, int height, int[] points, int color) {
        context.method_25294(x, y, x + width, y + height, 0x18000000);
        koil$drawIndicatorLine(context, x + 1, y + 1, width - 2, height - 2, points, color, false);
    }

    @Unique
    private void koil$drawStockDataRibbon(class_332 context, int x, int y, int width, KoilGlobalActivityRow row, @Nullable KoilGlobalMarketViewRow view, int color, int changeColor) {
        int cellGap = 5;
        int cellCount = width < 520 ? 3 : 6;
        int cellWidth = Math.max(58, (width - cellGap * (cellCount - 1)) / cellCount);
        int[] displayPoints = view == null ? koil$stockWindow(koil$visualSeries(row.metric(), row.pointsView())) : koil$stockWindow(koil$marketMainPressureSeries(view, row.pointsView()));
        int[][] displayCandles = koil$candlesFromSeries(displayPoints);
        Object[][] cells = new Object[][]{
                {"open", String.valueOf(koil$latest(displayCandles[0])), 0xFFB8C7D6},
                {"high", String.valueOf(koil$latest(displayCandles[1])), 0xFFA6D989},
                {"low", String.valueOf(koil$latest(displayCandles[2])), 0xFFE06A6A},
                {"close", String.valueOf(koil$latest(displayCandles[3])), color},
                {"window", KoilMarketSeriesWindow.label(this.koil$stockGraphInterval), 0xFF55DDE8},
                {"trend", koil$signed(row.trend()), changeColor},
                {"volatility", koil$compact(row.volatility()), 0xFFB7A8FF},
                {"leader", koil$ellipsize(row.leader(), 54), 0xFF8FD5D0},
                {"conf", row.confidence() + "%", row.authoritative() ? 0xFFA6D989 : 0xFFE6A15C}
        };

        for (int i = 0; i < cells.length; i++) {
            int column = i % cellCount;
            int rowIndex = i / cellCount;
            int cellX = x + column * (cellWidth + cellGap);
            int cellY = y + rowIndex * 22;
            context.method_25294(cellX, cellY, cellX + cellWidth, cellY + 18, 0x14000000);
            context.method_51439(this.field_22793, class_2561.method_43470((String) cells[i][0]), cellX + 4, cellY + 2, 0xFF718091, false);
            context.method_51439(this.field_22793, class_2561.method_43470(String.valueOf(cells[i][1])), cellX + 4, cellY + 10, (Integer) cells[i][2], false);
        }
    }

    @Unique
    private void koil$drawChartValueTag(class_332 context, int x, int y, String value, int color) {
        int width = this.field_22793.method_1727(value) + 5;
        context.method_25294(x, y, x + width, y + 10, 0x66000000);
        context.method_51439(this.field_22793, class_2561.method_43470(value), x + 2, y + 1, color, false);
    }

    @Unique
    private void koil$drawChartLegend(class_332 context, int x, int y, KoilGlobalActivityRow row, int color) {
        int labelColor = 0xCCB8C7D6;
        context.method_25294(x, y, x + 7, y + 2, 0xFFFFFFFF);
        context.method_51439(this.field_22793, class_2561.method_43470("main"), x + 10, y - 3, labelColor, false);
        context.method_25294(x + 44, y, x + 49, y + 2, 0x99E8C86F);
        context.method_51439(this.field_22793, class_2561.method_43470("avg"), x + 52, y - 3, labelColor, false);
        context.method_25294(x + 82, y, x + 87, y + 2, 0x55718091);
        context.method_51439(this.field_22793, class_2561.method_43470("volume"), x + 90, y - 3, labelColor, false);
        String state = row.change() > 0 ? "rising" : row.change() < 0 ? "falling" : "flat";
        int stateColor = row.change() > 0 ? 0xFFA6D989 : row.change() < 0 ? 0xFFE06A6A : 0xFF8E9AA8;
        context.method_51439(this.field_22793, class_2561.method_43470(state), x + 146, y - 3, stateColor, false);
    }

    @Unique
    private void koil$drawVerticalGuideLines(class_332 context, int x, int y, int width, int height, int color) {
        int segments = 6;

        for (int i = 1; i < segments; i++) {
            int lineX = x + Math.round(i / (float) segments * width);

            for (int py = y; py < y + height; py += 6) {
                context.method_25294(lineX, py, lineX + 1, Math.min(y + height, py + 3), color);
            }
        }
    }

    @Unique
    private void koil$drawVolumeBars(class_332 context, int x, int y, int width, int height, int[] points, int color, KoilGlobalActivityRow row, int mouseX, int mouseY) {
        if (points == null || points.length == 0 || width <= 1 || height <= 1) {
            return;
        }

        context.method_25294(x, y, x + width, y + height, 0x26000000);
        context.method_49601(x, y, width, height, 0x223D4A56);

        int max = 1;

        for (int i = 1; i < points.length; i++) {
            max = Math.max(max, Math.abs(points[i] - points[i - 1]));
        }

        int barWidth = Math.max(2, width / Math.max(1, points.length) - 1);

        for (int i = 1; i < points.length; i++) {
            int delta = points[i] - points[i - 1];
            int volume = Math.abs(delta);
            int barHeight = Math.max(2, Math.round(volume / (float) max * Math.max(2, height - 3)));
            int barX = x + Math.round(i / (float) Math.max(1, points.length - 1) * Math.max(1, width - barWidth));
            int barTop = y + height - barHeight - 1;
            int barColor = delta >= 0 ? 0xBBA6D989 : 0xBBE06A6A;
            context.method_25294(barX, barTop, barX + barWidth, y + height - 1, barColor);

            if (koil$isMouseInsideStatsViewport(mouseX, mouseY) && mouseX >= barX - 1 && mouseX <= barX + barWidth + 1 && mouseY >= barTop - 1 && mouseY <= y + height && this.koil$hoverTooltipLines.isEmpty()) {
                context.method_25294(barX - 1, barTop - 1, barX + barWidth + 1, y + height, koil$withAlpha(barColor, 255));
                context.method_49601(barX - 2, barTop - 2, barWidth + 4, Math.max(4, y + height - barTop + 2), 0xFFFFFFFF);
                koil$setHoverTooltip(
                        koil$tooltipLine(row.title(), 0xFFE7EDF4),
                        koil$tooltipLine("Feature: volume bar", 0xFFE6A15C),
                        koil$tooltipLine("Capture: " + (i + 1) + " / " + points.length, 0xFFB8C7D6),
                        koil$tooltipLine("Activity volume: " + volume, 0xFFE6A15C),
                        koil$tooltipLine("Movement: " + koil$signed(delta), delta >= 0 ? 0xFFA6D989 : 0xFFE06A6A),
                        koil$tooltipLine(delta >= 0 ? "Meaning: positive market pressure" : "Meaning: negative market pressure", delta >= 0 ? 0xFFA6D989 : 0xFFE06A6A),
                        koil$tooltipLine(row.authoritative() ? "Source: server exact" : "Source: client observed " + row.confidence() + "%", row.authoritative() ? 0xFFA6D989 : 0xFFE6A15C)
                );
            }
        }
    }

    @Unique
    private void koil$requestLiveVanillaStatsIfNeeded() {
        long now = class_156.method_658();

        if (now - this.koil$lastLiveVanillaStatsRequestMs >= 2000L) {
            this.koil$lastLiveVanillaStatsRequestMs = now;

            try {
                class_310 client = class_310.method_1551();

                if (client != null && client.method_1562() != null) {
                    client.method_1562().method_2883(new class_2799(class_2799.class_2800.field_12775));
                }
            } catch (Exception ignored) {
            }
        }

        int fingerprint = koil$liveVanillaStatsFingerprint();

        if (fingerprint != this.koil$lastLiveVanillaStatsFingerprint) {
            this.koil$lastLiveVanillaStatsFingerprint = fingerprint;
            koil$invalidateRowCache();
        }
    }

    @Unique
    private int koil$liveVanillaStatsFingerprint() {
        long now = class_156.method_658();

        if (this.koil$cachedLiveVanillaStatsFingerprint != Integer.MIN_VALUE && now - this.koil$lastFingerprintScanMs < 850L) {
            return this.koil$cachedLiveVanillaStatsFingerprint;
        }

        this.koil$lastFingerprintScanMs = now;
        this.koil$cachedLiveVanillaStatsFingerprint = koil$computeLiveVanillaStatsFingerprint();
        return this.koil$cachedLiveVanillaStatsFingerprint;
    }

    @Unique
    private int koil$computeLiveVanillaStatsFingerprint() {
        int result = 1;
        result = 31 * result + koil$summaryPlayTimeTicks();
        result = 31 * result + koil$summaryTravelCm();
        result = 31 * result + koil$summaryJumps();
        result = 31 * result + koil$summaryDeaths();
        result = 31 * result + koil$summaryMobKills();
        result = 31 * result + koil$summaryPlayerKills();
        result = 31 * result + koil$summaryDamageDealt();
        result = 31 * result + koil$summaryDamageTaken();
        result = 31 * result + koil$liveGeneralStatsFingerprint();
        result = 31 * result + koil$liveItemStatsFingerprint();
        result = 31 * result + koil$liveEntityStatsFingerprint();
        return result;
    }

    @Unique
    private int koil$liveGeneralStatsFingerprint() {
        int result = 1;

        for (class_3445<class_2960> stat : class_3468.field_15419) {
            try {
                int value = this.statHandler.method_15025(stat);

                if (value != 0) {
                    result = 31 * result + stat.method_14951().hashCode();
                    result = 31 * result + value;
                }
            } catch (Exception ignored) {
            }
        }

        return result;
    }

    @Unique
    private int koil$liveItemStatsFingerprint() {
        int result = 1;

        for (class_1792 item : class_7923.field_41178) {
            if (item == class_1802.field_8162) {
                continue;
            }

            int total = 0;

            if (item instanceof class_1747 blockItem) {
                total += koil$blockStatValue(class_3468.field_15427, blockItem.method_7711());
            }

            total += koil$itemStatValue(class_3468.field_15383, item);
            total += koil$itemStatValue(class_3468.field_15370, item);
            total += koil$itemStatValue(class_3468.field_15372, item);
            total += koil$itemStatValue(class_3468.field_15392, item);
            total += koil$itemStatValue(class_3468.field_15405, item);

            if (total != 0) {
                result = 31 * result + class_1792.method_7880(item);
                result = 31 * result + total;
            }
        }

        return result;
    }

    @Unique
    private int koil$liveEntityStatsFingerprint() {
        int result = 1;

        for (class_1299<?> entityType : class_7923.field_41177) {
            int killed = 0;
            int killedBy = 0;

            try {
                killed = this.statHandler.method_15025(class_3468.field_15403.method_14956(entityType));
                killedBy = this.statHandler.method_15025(class_3468.field_15411.method_14956(entityType));
            } catch (Exception ignored) {
            }

            if (killed != 0 || killedBy != 0) {
                result = 31 * result + class_7923.field_41177.method_10206(entityType);
                result = 31 * result + killed;
                result = 31 * result + killedBy;
            }
        }

        return result;
    }

    @Unique
    private List<Object[]> koil$overviewCards() {
        koil$refreshRowCache();
        return this.koil$cachedOverviewCards;
    }

    @Unique
    private void koil$invalidateRowCache() {
        this.koil$rowCacheTimeMs = 0L;
        this.koil$rowCacheKey = "";
        this.koil$generalCacheKey = "";
        this.koil$itemCacheKey = "";
        this.koil$entityCacheKey = "";
        this.koil$globalCacheKey = "";
        this.koil$cachedLiveVanillaStatsFingerprint = Integer.MIN_VALUE;
        this.koil$cachedMarketPressureSeries = new HashMap<>();
        this.koil$cachedSyntheticSeries = new HashMap<>();
        this.koil$cachedMiniPreviewSeries = new HashMap<>();
    }

    @Unique
    private void koil$refreshRowCache() {
        long now = class_156.method_658();
        String query = koil$searchQuery();
        int liveFingerprint = koil$liveVanillaStatsFingerprint();
        String sizeKey = this.field_22789 + "|" + this.field_22790;
        String vanillaKey = query + "|" + liveFingerprint + "|" + sizeKey;
        String globalKey = query + "|" + GlobalActivityClient.updatedAt() + "|" + GlobalActivityClient.contextKey() + "|" + sizeKey;
        boolean changed = false;

        if (KOIL_PAGE_GENERAL.equals(this.koil$activePage) && !vanillaKey.equals(this.koil$generalCacheKey)) {
            this.koil$generalCacheKey = vanillaKey;
            this.koil$cachedGeneralRows = koil$filterGeneralRows(koil$generalRows());
            this.koil$cachedGeneralMax = koil$maxIntColumn(this.koil$cachedGeneralRows, 2);
            this.koil$cachedGeneralCount = this.koil$cachedGeneralRows.size();
            changed = true;
        }

        if (KOIL_PAGE_ITEMS.equals(this.koil$activePage) && !vanillaKey.equals(this.koil$itemCacheKey)) {
            this.koil$itemCacheKey = vanillaKey;
            this.koil$cachedItemRows = koil$filterItemRows(koil$itemRows());
            this.koil$cachedItemMax = koil$maxIntColumn(this.koil$cachedItemRows, 8);
            this.koil$cachedItemCount = this.koil$cachedItemRows.size();
            changed = true;
        }

        if (KOIL_PAGE_MOBS.equals(this.koil$activePage) && !vanillaKey.equals(this.koil$entityCacheKey)) {
            this.koil$entityCacheKey = vanillaKey;
            this.koil$cachedEntityRows = koil$filterEntityRows(koil$entityRows());
            this.koil$cachedEntityMax = koil$maxEntityColumn(this.koil$cachedEntityRows);
            this.koil$cachedEntityCount = this.koil$cachedEntityRows.size();
            changed = true;
        }

        if ((KOIL_PAGE_GLOBAL.equals(this.koil$activePage) || this.koil$cachedAllMarketValueRows.isEmpty()) && !globalKey.equals(this.koil$globalCacheKey)) {
            this.koil$globalCacheKey = globalKey;
            this.koil$cachedMarketRows = koil$sortGlobalRows(koil$filterGlobalRows(GlobalActivityClient.marketRows()));
            List<KoilGlobalActivityRow> activityRows = koil$sortGlobalRows(koil$filterGlobalRows(GlobalActivityClient.activityRows()));
            List<KoilGlobalActivityRow> importantRows = new ArrayList<>();
            List<KoilGlobalActivityRow> developerRows = new ArrayList<>();

            for (KoilGlobalActivityRow row : activityRows) {
                if (koil$isImportantGlobalMetric(row.metric())) {
                    importantRows.add(row);
                } else {
                    developerRows.add(row);
                }
            }

            this.koil$cachedImportantRows = importantRows;
            this.koil$cachedDeveloperRows = developerRows;
            List<KoilGlobalActivityRow> hierarchySourceRows = koil$globalHierarchySourceRows();
            Map<String, KoilGlobalActivityRow> globalRowsByMetric = new LinkedHashMap<>();

            for (KoilGlobalActivityRow row : hierarchySourceRows) {
                if (row == null || row.metric() == null || row.metric().isBlank()) {
                    continue;
                }

                globalRowsByMetric.putIfAbsent(koil$normalizeGlobalMetric(row.metric()), row);
            }

            this.koil$cachedGlobalRowsByMetric = globalRowsByMetric;
            Map<String, List<KoilGlobalMarketViewRow>> hierarchy = KoilGlobalMarketViewRow.buildHierarchy(hierarchySourceRows, query);
            this.koil$cachedHeadMarketRows = hierarchy.getOrDefault("head", Collections.emptyList());
            this.koil$cachedSubMarketRows = hierarchy.getOrDefault("sub", Collections.emptyList());
            this.koil$cachedRawMarketRows = hierarchy.getOrDefault("raw", Collections.emptyList());
            this.koil$cachedDevMarketRows = hierarchy.getOrDefault("dev", Collections.emptyList());
            List<KoilGlobalMarketViewRow> allMarketRows = new ArrayList<>();
            allMarketRows.addAll(this.koil$cachedHeadMarketRows);
            allMarketRows.addAll(this.koil$cachedSubMarketRows);
            allMarketRows.addAll(this.koil$cachedRawMarketRows);
            allMarketRows.addAll(this.koil$cachedDevMarketRows);
            this.koil$cachedAllMarketValueRows = Collections.unmodifiableList(allMarketRows);
            this.koil$cachedMarketQuotes = new HashMap<>();
            this.koil$cachedMarketComponents = new HashMap<>();
            this.koil$cachedMarketPressureSeries = new HashMap<>();
            this.koil$cachedSyntheticSeries = new HashMap<>();
            this.koil$cachedMiniPreviewSeries = new HashMap<>();
            this.koil$cachedGlobalCount = allMarketRows.size();
            changed = true;
        }

        if (changed || this.koil$cachedOverviewCards.isEmpty() || now - this.koil$rowCacheTimeMs > 1000L) {
            this.koil$rowCacheTimeMs = now;
            this.koil$cachedOverviewCards = koil$buildOverviewCards();
        }
    }

    @Unique
    private int koil$maxIntColumn(List<Object[]> rows, int column) {
        int max = 1;

        for (Object[] row : rows) {
            max = Math.max(max, (Integer) row[column]);
        }

        return max;
    }

    @Unique
    private int koil$maxEntityColumn(List<Object[]> rows) {
        int max = 1;

        for (Object[] row : rows) {
            max = Math.max(max, Math.max((Integer) row[1], (Integer) row[2]));
        }

        return max;
    }

    @Unique
    private List<Object[]> koil$buildOverviewCards() {
        int playTicks = koil$summaryPlayTimeTicks();
        int deaths = koil$summaryDeaths();
        int kills = koil$summaryMobKills();
        int playerKills = koil$summaryPlayerKills();
        int distanceCm = koil$summaryTravelCm();
        int jumps = koil$summaryJumps();
        int globalCount = Math.max(this.koil$cachedGlobalCount, this.koil$cachedHeadMarketRows.size() + this.koil$cachedSubMarketRows.size() + this.koil$cachedRawMarketRows.size() + this.koil$cachedDevMarketRows.size());
        int damageDealt = koil$summaryDamageDealt();
        int damageTaken = koil$summaryDamageTaken();
        int combatTotal = koil$summaryCombatActivity(kills, playerKills, deaths, damageDealt, damageTaken);
        List<Object[]> cards = new ArrayList<>();
        cards.add(new Object[]{"Time", koil$formatTime(playTicks), Math.min(1.0F, playTicks / 360000.0F), 0xFF8FC5FF});
        cards.add(new Object[]{"Travel", koil$formatDistance(distanceCm), Math.min(1.0F, distanceCm / 1000000.0F), 0xFFA6D989});
        cards.add(new Object[]{"Combat", kills + "M/" + playerKills + "P/" + deaths + "D", Math.min(1.0F, combatTotal / 5000.0F), deaths > kills + playerKills ? 0xFFE06A6A : 0xFFA6D989});
        cards.add(new Object[]{"Items", String.valueOf(Math.max(this.koil$cachedItemCount, this.koil$cachedItemRows.size())), Math.min(1.0F, Math.max(this.koil$cachedItemCount, this.koil$cachedItemRows.size()) / 128.0F), 0xFFE8C86F});
        cards.add(new Object[]{"Mobs", String.valueOf(Math.max(this.koil$cachedEntityCount, this.koil$cachedEntityRows.size())), Math.min(1.0F, Math.max(this.koil$cachedEntityCount, this.koil$cachedEntityRows.size()) / 64.0F), 0xFFE6A15C});
        cards.add(new Object[]{"Jumps", koil$compact(jumps), Math.min(1.0F, jumps / 10000.0F), 0xFF8FD5D0});
        cards.add(new Object[]{"Global", String.valueOf(globalCount), Math.min(1.0F, globalCount / 64.0F), globalCount > 0 ? 0xFFB7A8FF : 0xFF718091});
        return cards;
    }

    @Unique
    private boolean koil$isRenderRowVisible(int y, int height) {
        return y + height >= this.koil$statsViewportY - 8 && y <= this.koil$statsViewportY + this.koil$statsViewportHeight + 8;
    }

    @Unique
    private List<Object[]> koil$generalRows() {
        List<Object[]> rows = new ArrayList<>();

        for (class_3445<class_2960> stat : class_3468.field_15419) {
            class_2960 id = stat.method_14951();
            int raw = this.statHandler.method_15025(stat);
            String translationKey = "stat." + id.toString().replace(':', '.');
            String translated = class_1074.method_4662(translationKey);
            String label = translated.equals(translationKey) ? koil$formatIdentifierName(id.method_12832()) : translated;
            String category = koil$generalCategory(id);
            int color = koil$categoryColor(category);
            String source = id.method_12836().equals("minecraft") ? "minecraft" : "modded: " + id.method_12836();
            rows.add(new Object[]{label, stat.method_14953(raw), raw, category, color, source});
        }

        rows.sort((a, b) -> {
            int active = Boolean.compare((Integer) a[2] <= 0, (Integer) b[2] <= 0);

            if (active != 0) {
                return active;
            }

            int category = ((String) a[3]).compareToIgnoreCase((String) b[3]);

            if (category != 0) {
                return category;
            }

            return ((String) a[0]).compareToIgnoreCase((String) b[0]);
        });
        return rows;
    }

    @Unique
    private List<Object[]> koil$itemRows() {
        List<Object[]> rows = new ArrayList<>();

        for (class_1792 item : class_7923.field_41178) {
            if (item == class_1802.field_8162) {
                continue;
            }

            int mined = 0;
            class_2960 id = class_7923.field_41178.method_10221(item);

            if (item instanceof class_1747 blockItem) {
                mined = koil$blockStatValue(class_3468.field_15427, blockItem.method_7711());
            }

            int broken = koil$itemStatValue(class_3468.field_15383, item);
            int crafted = koil$itemStatValue(class_3468.field_15370, item);
            int used = koil$itemStatValue(class_3468.field_15372, item);
            int pickedUp = koil$itemStatValue(class_3468.field_15392, item);
            int dropped = koil$itemStatValue(class_3468.field_15405, item);
            int total = mined + broken + crafted + used + pickedUp + dropped;

            if (total <= 0) {
                continue;
            }

            String source = id.method_12836().equals("minecraft") ? "minecraft" : "modded: " + id.method_12836();
            rows.add(new Object[]{item, item.method_7848().getString(), mined, used, crafted, pickedUp, dropped, broken, total, source});
        }

        rows.sort((a, b) -> {
            int total = Integer.compare((Integer) b[8], (Integer) a[8]);

            if (total != 0) {
                return total;
            }

            return ((String) a[1]).compareToIgnoreCase((String) b[1]);
        });
        return rows;
    }

    @Unique
    private List<Object[]> koil$entityRows() {
        List<Object[]> rows = new ArrayList<>();

        for (class_1299<?> entityType : class_7923.field_41177) {
            int killed = this.statHandler.method_15025(class_3468.field_15403.method_14956(entityType));
            int killedBy = this.statHandler.method_15025(class_3468.field_15411.method_14956(entityType));

            if (killed <= 0 && killedBy <= 0) {
                continue;
            }

            class_2960 id = class_7923.field_41177.method_10221(entityType);
            String source = id.method_12836().equals("minecraft") ? "minecraft" : "modded: " + id.method_12836();
            rows.add(new Object[]{entityType.method_5897().getString(), killed, killedBy, source});
        }

        rows.sort((a, b) -> {
            int total = Integer.compare((Integer) b[1] + (Integer) b[2], (Integer) a[1] + (Integer) a[2]);

            if (total != 0) {
                return total;
            }

            return ((String) a[0]).compareToIgnoreCase((String) b[0]);
        });
        return rows;
    }

    @Unique
    private String koil$pageFromList(@Nullable class_4280<?> selectedList) {
        if (selectedList == null) {
            return "";
        }

        String className = selectedList.getClass().getName().toLowerCase(Locale.ROOT);

        if (className.contains("item")) {
            return KOIL_PAGE_ITEMS;
        }

        if (className.contains("entity") || className.contains("mob")) {
            return KOIL_PAGE_MOBS;
        }

        if (className.contains("general")) {
            return KOIL_PAGE_GENERAL;
        }

        return "";
    }

    @Unique
    private String koil$pageFromButton(class_339 widget) {
        String label = widget.method_25369().getString().toLowerCase(Locale.ROOT);

        if (label.contains("item")) {
            return KOIL_PAGE_ITEMS;
        }

        if (label.contains("mob") || label.contains("entity")) {
            return KOIL_PAGE_MOBS;
        }

        if (label.contains("general")) {
            return KOIL_PAGE_GENERAL;
        }

        if (label.contains("global")) {
            return KOIL_PAGE_GLOBAL;
        }

        return "";
    }

    @Unique
    private int koil$totalDistanceCm() {
        return koil$summaryTravelCm();
    }

    @Unique
    private int koil$summaryPlayTimeTicks() {
        return Math.max(koil$customRaw(KOIL_PLAY_TIME_ID), koil$customRawByPath("play_time", "total_world_time"));
    }

    @Unique
    private int koil$summaryDeaths() {
        return Math.max(koil$customRaw(KOIL_DEATHS_ID), koil$customRawByPath("deaths"));
    }

    @Unique
    private int koil$summaryMobKills() {
        return Math.max(koil$customRaw(KOIL_MOB_KILLS_ID), koil$customRawByPath("mob_kills", "mobs_killed"));
    }

    @Unique
    private int koil$summaryPlayerKills() {
        return Math.max(koil$customRaw(KOIL_PLAYER_KILLS_ID), koil$customRawByPath("player_kills"));
    }

    @Unique
    private int koil$summaryDamageDealt() {
        return Math.max(koil$customRaw(KOIL_DAMAGE_DEALT_ID), koil$customRawByPath("damage_dealt"));
    }

    @Unique
    private int koil$summaryDamageTaken() {
        return Math.max(koil$customRaw(KOIL_DAMAGE_TAKEN_ID), koil$customRawByPath("damage_taken"));
    }

    @Unique
    private int koil$summaryJumps() {
        return Math.max(koil$customRaw(KOIL_JUMP_ID), koil$customRawByPath("jump", "jumps"));
    }

    @Unique
    private int koil$summaryTravelCm() {
        int direct = koil$customRawByPath("walk_one_cm", "crouch_one_cm", "sprint_one_cm", "swim_one_cm", "fall_one_cm", "climb_one_cm", "fly_one_cm", "walk_on_water_one_cm", "walk_under_water_one_cm", "minecart_one_cm", "boat_one_cm", "pig_one_cm", "horse_one_cm", "aviate_one_cm", "strider_one_cm");
        int old = koil$customRaw(KOIL_WALK_ONE_CM_ID)
                + koil$customRaw(KOIL_CROUCH_ONE_CM_ID)
                + koil$customRaw(KOIL_SPRINT_ONE_CM_ID)
                + koil$customRaw(KOIL_SWIM_ONE_CM_ID)
                + koil$customRaw(KOIL_FALL_ONE_CM_ID)
                + koil$customRaw(KOIL_CLIMB_ONE_CM_ID)
                + koil$customRaw(KOIL_FLY_ONE_CM_ID)
                + koil$customRaw(KOIL_WALK_ON_WATER_ONE_CM_ID)
                + koil$customRaw(KOIL_WALK_UNDER_WATER_ONE_CM_ID)
                + koil$customRaw(KOIL_MINECART_ONE_CM_ID)
                + koil$customRaw(KOIL_BOAT_ONE_CM_ID)
                + koil$customRaw(KOIL_PIG_ONE_CM_ID)
                + koil$customRaw(KOIL_HORSE_ONE_CM_ID)
                + koil$customRaw(KOIL_AVIATE_ONE_CM_ID)
                + koil$customRaw(KOIL_STRIDER_ONE_CM_ID);
        return Math.max(direct, old);
    }

    @Unique
    private int koil$summaryCombatActivity(int kills, int playerKills, int deaths, int damageDealt, int damageTaken) {
        return Math.max(0, kills) + Math.max(0, playerKills) + Math.max(0, deaths) + Math.max(0, damageDealt) + Math.max(0, damageTaken);
    }

    @Unique
    private int koil$customRawByPath(String... paths) {
        int total = 0;
        Set<String> wanted = new HashSet<>();

        for (String path : paths) {
            if (path != null && !path.isBlank()) {
                wanted.add(path);
            }
        }

        for (class_3445<class_2960> stat : class_3468.field_15419) {
            class_2960 value = stat.method_14951();

            if (value == null || !wanted.contains(value.method_12832())) {
                continue;
            }

            try {
                total += Math.max(0, this.statHandler.method_15025(stat));
            } catch (Exception ignored) {
            }
        }

        return total;
    }

    @Unique
    private int koil$customRaw(class_2960 id) {
        try {
            class_3445<class_2960> stat = class_3468.field_15419.method_14956(id);
            return this.statHandler.method_15025(stat);
        } catch (Exception ignored) {
            return 0;
        }
    }

    @Unique
    private int koil$itemStatValue(class_3448<class_1792> statType, class_1792 item) {
        try {
            return this.statHandler.method_15025(statType.method_14956(item));
        } catch (Exception ignored) {
            return 0;
        }
    }

    @Unique
    private int koil$blockStatValue(class_3448<class_2248> statType, class_2248 block) {
        try {
            return this.statHandler.method_15025(statType.method_14956(block));
        } catch (Exception ignored) {
            return 0;
        }
    }

    @Unique
    private List<KoilGlobalActivityRow> koil$globalHierarchySourceRows() {
        List<KoilGlobalActivityRow> rows = new ArrayList<>();

        if (GlobalActivityClient.hasServerData()) {
            rows.addAll(GlobalActivityClient.activityRows());
            rows.addAll(GlobalActivityClient.marketRows());
            return koil$dedupeGlobalRows(rows, true);
        }

        rows.addAll(koil$localStoredGlobalRows());
        rows.addAll(GlobalActivityClient.activityRows());
        rows.addAll(GlobalActivityClient.marketRows());
        return rows;
    }

    @Unique
    private List<KoilGlobalActivityRow> koil$dedupeGlobalRows(List<KoilGlobalActivityRow> rows, boolean preferAuthoritative) {
        Map<String, KoilGlobalActivityRow> byKey = new LinkedHashMap<>();

        for (KoilGlobalActivityRow row : rows) {
            if (row == null || row.metric() == null || row.metric().isBlank()) {
                continue;
            }

            String key = row.type() + "|" + koil$normalizeGlobalMetric(row.metric());
            KoilGlobalActivityRow existing = byKey.get(key);

            if (existing == null) {
                byKey.put(key, row);
                continue;
            }

            if (preferAuthoritative && row.authoritative() && !existing.authoritative()) {
                byKey.put(key, row);
            } else if (row.confidence() > existing.confidence() && row.value() >= existing.value()) {
                byKey.put(key, row);
            }
        }

        return new ArrayList<>(byKey.values());
    }

    @Unique
    private List<KoilGlobalActivityRow> koil$localStoredGlobalRows() {
        List<KoilGlobalActivityRow> rows = new ArrayList<>();
        String playerName = koil$localPlayerName();
        int blocksBroken = 0;
        int blocksPlaced = 0;
        int itemsUsed = 0;
        int itemsCrafted = 0;
        int itemsPickedUp = 0;
        int itemsDropped = 0;
        int foodEaten = 0;
        int mobsKilled = 0;
        int entityDeaths = 0;

        for (class_2248 block : class_7923.field_41175) {
            int broken = koil$blockStatValue(class_3468.field_15427, block);

            if (broken > 0) {
                class_2960 id = class_7923.field_41175.method_10221(block);
                String metric = "block_broken/" + id.method_12836() + "/" + id.method_12832();
                rows.add(koil$localStoredRow(metric, broken, playerName));
                blocksBroken += broken;
            }
        }

        for (class_1792 item : class_7923.field_41178) {
            if (item == class_1802.field_8162) {
                continue;
            }

            class_2960 itemId = class_7923.field_41178.method_10221(item);
            int used = koil$itemStatValue(class_3468.field_15372, item);
            int crafted = koil$itemStatValue(class_3468.field_15370, item);
            int pickedUp = koil$itemStatValue(class_3468.field_15392, item);
            int dropped = koil$itemStatValue(class_3468.field_15405, item);

            if (item instanceof class_1747 blockItem && used > 0) {
                class_2960 blockId = class_7923.field_41175.method_10221(blockItem.method_7711());
                String metric = "block_placed/" + blockId.method_12836() + "/" + blockId.method_12832();
                rows.add(koil$localStoredRow(metric, used, playerName));
                blocksPlaced += used;
            }

            if (used > 0) {
                rows.add(koil$localStoredRow("item_used/" + itemId.method_12836() + "/" + itemId.method_12832(), used, playerName));
                itemsUsed += used;
            }

            if (crafted > 0) {
                rows.add(koil$localStoredRow("item_crafted/" + itemId.method_12836() + "/" + itemId.method_12832(), crafted, playerName));
                itemsCrafted += crafted;
            }

            if (pickedUp > 0) {
                rows.add(koil$localStoredRow("item_picked_up/" + itemId.method_12836() + "/" + itemId.method_12832(), pickedUp, playerName));
                itemsPickedUp += pickedUp;
            }

            if (dropped > 0) {
                rows.add(koil$localStoredRow("item_dropped/" + itemId.method_12836() + "/" + itemId.method_12832(), dropped, playerName));
                itemsDropped += dropped;
            }

            try {
                if (item.method_19264() != null && used > 0) {
                    rows.add(koil$localStoredRow("food_eaten/" + itemId.method_12836() + "/" + itemId.method_12832(), used, playerName));
                    foodEaten += used;
                }
            } catch (Exception ignored) {
            }
        }

        for (class_1299<?> entityType : class_7923.field_41177) {
            int killed = this.statHandler.method_15025(class_3468.field_15403.method_14956(entityType));
            int killedBy = this.statHandler.method_15025(class_3468.field_15411.method_14956(entityType));
            class_2960 id = class_7923.field_41177.method_10221(entityType);

            if (killed > 0) {
                rows.add(koil$localStoredRow("mob_killed/" + id.method_12836() + "/" + id.method_12832(), killed, playerName));
                mobsKilled += killed;
            }

            if (killedBy > 0) {
                rows.add(koil$localStoredRow("killed_by/" + id.method_12836() + "/" + id.method_12832(), killedBy, playerName));
                entityDeaths += killedBy;
            }
        }

        koil$addLocalAggregateRow(rows, "blocks_broken", blocksBroken, playerName);
        koil$addLocalAggregateRow(rows, "blocks_placed", blocksPlaced, playerName);
        koil$addLocalAggregateRow(rows, "items_used", itemsUsed, playerName);
        koil$addLocalAggregateRow(rows, "items_crafted", itemsCrafted, playerName);
        koil$addLocalAggregateRow(rows, "items_picked_up", itemsPickedUp, playerName);
        koil$addLocalAggregateRow(rows, "items_dropped", itemsDropped, playerName);
        koil$addLocalAggregateRow(rows, "food_eaten", foodEaten, playerName);
        koil$addLocalAggregateRow(rows, "mobs_killed", mobsKilled, playerName);
        koil$addLocalAggregateRow(rows, "entity_deaths", entityDeaths, playerName);
        koil$addLocalAggregateRow(rows, "deaths", koil$summaryDeaths(), playerName);
        koil$addLocalAggregateRow(rows, "damage_dealt", koil$summaryDamageDealt(), playerName);
        koil$addLocalAggregateRow(rows, "damage_taken", koil$summaryDamageTaken(), playerName);
        koil$addLocalAggregateRow(rows, "play_time", koil$summaryPlayTimeTicks(), playerName);
        koil$addLocalAggregateRow(rows, "travel_distance", koil$summaryTravelCm(), playerName);
        koil$addLocalAggregateRow(rows, "jumps", koil$summaryJumps(), playerName);
        koil$addLocalAggregateRow(rows, "combat_activity", koil$summaryCombatActivity(mobsKilled, koil$summaryPlayerKills(), koil$summaryDeaths(), koil$summaryDamageDealt(), koil$summaryDamageTaken()), playerName);
        return rows;
    }

    @Unique
    private void koil$addLocalAggregateRow(List<KoilGlobalActivityRow> rows, String metric, int value, String playerName) {
        if (value > 0) {
            rows.add(koil$localStoredRow(metric, value, playerName));
        }
    }

    @Unique
    private KoilGlobalActivityRow koil$localStoredRow(String metric, int value, String playerName) {
        int[] points = koil$localStoredPoints(value);
        int change = points.length < 2 ? 0 : points[points.length - 1] - points[points.length - 2];
        return new KoilGlobalActivityRow("activity", "local_stored/" + metric, metric, koil$marketMetricShortTitle(metric), value, playerName, value, points, "local stored player stats", 0, change, Math.max(0, change), GlobalActivityClient.contextKey(), 90, false);
    }

    @Unique
    private int[] koil$localStoredPoints(int value) {
        int safe = Math.max(0, value);

        if (safe <= 0) {
            return new int[0];
        }

        int count = 16;
        int[] points = new int[count];

        for (int i = 0; i < count; i++) {
            points[i] = Math.round(safe * (i + 1) / (float) count);
        }

        return points;
    }

    @Unique
    private String koil$localPlayerName() {
        class_310 client = class_310.method_1551();

        if (client == null || client.method_1548() == null) {
            return "local player";
        }

        return client.method_1548().method_1676();
    }

    @Unique
    private List<KoilGlobalActivityRow> koil$sortGlobalRows(List<KoilGlobalActivityRow> rows) {
        List<KoilGlobalActivityRow> sorted = new ArrayList<>(rows);
        sorted.sort((a, b) -> {
            int priority = Integer.compare(koil$globalMetricPriority(b.metric()), koil$globalMetricPriority(a.metric()));

            if (priority != 0) {
                return priority;
            }

            return Integer.compare(b.value(), a.value());
        });
        return sorted;
    }

    @Unique
    private boolean koil$isImportantGlobalMetric(String metric) {
        return koil$globalMetricPriority(metric) >= 70;
    }

    @Unique
    private int koil$globalMetricPriority(String metric) {
        String value = metric == null ? "" : metric.toLowerCase(Locale.ROOT);

        if (value.contains("block_broken") || value.contains("blocks_broken") || value.contains("mine")) {
            return 100;
        }

        if (value.contains("block_place") || value.contains("blocks_placed")) {
            return 95;
        }

        if (value.contains("container_in") || value.contains("container_out")) {
            return 92;
        }

        if (value.contains("item_use") || value.contains("item_used")) {
            return 90;
        }

        if (koil$isFoodMetricText(value)) {
            return 86;
        }

        if (value.contains("mob") || value.contains("kill") || value.contains("death") || value.contains("damage")) {
            return 84;
        }

        if (value.contains("mainhand") || value.contains("offhand") || value.contains("main_hand") || value.contains("off_hand")) {
            return 76;
        }

        if (value.contains("craft") || value.contains("picked") || value.contains("dropped")) {
            return 72;
        }

        if (value.contains("player_presence") || value.contains("player_visible")) {
            return 20;
        }

        return 10;
    }

    @Unique
    private String koil$globalMetricGroup(String metric) {
        String value = metric == null ? "" : metric.toLowerCase(Locale.ROOT);

        if (value.contains("block_broken") || value.contains("blocks_broken") || value.contains("mine")) {
            return "block break demand";
        }

        if (value.contains("block_place") || value.contains("blocks_placed")) {
            return "block placement demand";
        }

        if (value.contains("item_use") || value.contains("item_used")) {
            return "item use demand";
        }

        if (koil$isFoodMetricText(value)) {
            return "food demand";
        }

        if (value.contains("mob") || value.contains("kill") || value.contains("death") || value.contains("damage")) {
            return "combat activity";
        }

        if (value.contains("mainhand") || value.contains("offhand") || value.contains("main_hand") || value.contains("off_hand")) {
            return "held item pressure";
        }

        if (value.contains("craft")) {
            return "crafting demand";
        }

        if (value.contains("picked") || value.contains("dropped")) {
            return "inventory flow";
        }

        return "developer signal";
    }

    @Unique
    private String koil$pageTitle(String page) {
        if (KOIL_PAGE_ITEMS.equals(page)) {
            return "Item & Block Activity";
        }

        if (KOIL_PAGE_MOBS.equals(page)) {
            return "Mob Activity";
        }

        if (KOIL_PAGE_GLOBAL.equals(page)) {
            return "Global Market Activity";
        }

        return "General Activity";
    }

    @Unique
    private String koil$pageCount(String page) {
        koil$refreshRowCache();

        if (KOIL_PAGE_ITEMS.equals(page)) {
            return this.koil$cachedItemRows.size() + " entries";
        }

        if (KOIL_PAGE_MOBS.equals(page)) {
            return this.koil$cachedEntityRows.size() + " entities";
        }

        if (KOIL_PAGE_GLOBAL.equals(page)) {
            return this.koil$cachedHeadMarketRows.size() + " head / " + this.koil$cachedSubMarketRows.size() + " sub / " + this.koil$cachedRawMarketRows.size() + " raw";
        }

        return this.koil$cachedGeneralRows.size() + " stats";
    }

    @Unique
    private String koil$pageHint(String page) {
        if (KOIL_PAGE_ITEMS.equals(page)) {
            return "M mined, U used, C crafted, P picked up, D dropped, B broken.";
        }

        if (KOIL_PAGE_MOBS.equals(page)) {
            return "Kills, deaths, ratio, and risk are shown with dual combat bars.";
        }

        if (KOIL_PAGE_GLOBAL.equals(page)) {
            return "Head markets summarize categories; sub markets group one block/item/entity; raw markets show exact signals like Sand Block Broken.";
        }

        return "Shows vanilla and modded custom stats with source, category, value, and activity strength.";
    }

    @Unique
    private String koil$generalCategory(class_2960 id) {
        String value = id.method_12832();

        if (value.contains("time") || value.contains("since")) {
            return "Time";
        }

        if (value.contains("cm") || value.contains("distance") || value.contains("walk") || value.contains("sprint") || value.contains("swim") || value.contains("fly") || value.contains("climb") || value.contains("fall") || value.equals("jump")) {
            return "Movement";
        }

        if (value.contains("kill") || value.contains("damage") || value.contains("death")) {
            return "Combat";
        }

        if (value.contains("craft") || value.contains("mine") || value.contains("use") || value.contains("drop") || value.contains("pickup") || value.contains("open") || value.contains("interact")) {
            return "Interaction";
        }

        if (value.contains("villager") || value.contains("trade") || value.contains("raid")) {
            return "World";
        }

        if (value.contains("fish") || value.contains("breed") || value.contains("sleep") || value.contains("bell") || value.contains("cauldron")) {
            return "Activity";
        }

        return id.method_12836().equals("minecraft") ? "Other" : "Modded";
    }

    @Unique
    private int koil$categoryColor(String category) {
        return switch (category) {
            case "Time" -> 0xFF8FC5FF;
            case "Movement" -> 0xFFA6D989;
            case "Combat" -> 0xFFE06A6A;
            case "Interaction" -> 0xFFE8C86F;
            case "World" -> 0xFF8FD5D0;
            case "Activity" -> 0xFFE6A15C;
            case "Modded" -> 0xFFB7A8FF;
            default -> 0xFFB8C7D6;
        };
    }


    @Unique
    private String koil$marketDisplayName(KoilGlobalActivityRow row) {
        if (row == null) {
            return "Unknown Market";
        }

        String metric = row.metric() == null ? "" : row.metric();
        String label = koil$metricPathLabel(metric);

        if (label.isBlank()) {
            label = koil$metricPathLabel(row.id());
        }

        if (label.isBlank()) {
            label = row.title();
        }

        if (row.market()) {
            if (koil$metricContains(metric, "block_broken/")) {
                return label + " Block Break Market";
            }

            if (koil$metricContains(metric, "block_place_intent/") || koil$metricContains(metric, "block_placed/")) {
                return label + " Block Placement Market";
            }

            if (koil$metricContains(metric, "item_use_intent/") || koil$metricContains(metric, "item_used/")) {
                return label + " Item Use Market";
            }

            if (koil$metricContains(metric, "item_crafted/")) {
                return label + " Crafting Market";
            }

            if (koil$metricContains(metric, "item_traded/")) {
                return label + " Trade Market";
            }

            if (koil$metricContains(metric, "mainhand/") || koil$metricContains(metric, "self_mainhand/")) {
                return label + " Main-Hand Demand Market";
            }

            if (koil$metricContains(metric, "offhand/") || koil$metricContains(metric, "self_offhand/")) {
                return label + " Off-Hand Demand Market";
            }

            return label + " Market";
        }

        if (koil$metricContains(metric, "block_broken/")) {
            return label + " Blocks Broken";
        }

        if (koil$metricContains(metric, "block_place_intent/") || koil$metricContains(metric, "block_placed/")) {
            return label + " Block Placement Demand";
        }

        if (koil$metricContains(metric, "item_use_intent/") || koil$metricContains(metric, "item_used/")) {
            return label + " Item Use Demand";
        }

        if (koil$metricContains(metric, "mainhand/") || koil$metricContains(metric, "self_mainhand/")) {
            return label + " Main-Hand Demand";
        }

        if (koil$metricContains(metric, "offhand/") || koil$metricContains(metric, "self_offhand/")) {
            return label + " Off-Hand Demand";
        }

        return label;
    }


    @Unique
    private boolean koil$metricContains(String metric, String marker) {
        return metric != null && metric.contains(marker);
    }

    @Unique
    private String koil$metricPathLabel(String metric) {
        if (metric == null || metric.isBlank()) {
            return "";
        }

        String[] prefixes = new String[]{"block_broken/", "block_place_intent/", "block_placed/", "block_used/", "block_use/", "item_use_intent/", "item_used/", "item_crafted/", "item_picked_up/", "item_dropped/", "item_traded/", "food_eaten/", "item_eaten/", "mob_killed/", "entity_killed/", "killed_by/", "mainhand/", "offhand/", "self_mainhand/", "self_offhand/"};

        for (String prefix : prefixes) {
            int prefixIndex = metric.indexOf(prefix);

            if (prefixIndex < 0) {
                continue;
            }

            String rest = metric.substring(prefixIndex + prefix.length());
            int separator = rest.indexOf('/');

            if (separator <= 0 || separator >= rest.length() - 1) {
                continue;
            }

            return koil$formatIdentifierName(rest.substring(separator + 1));
        }

        String value = metric;
        int separator = value.lastIndexOf('/');

        if (separator >= 0 && separator < value.length() - 1) {
            value = value.substring(separator + 1);
        }

        return koil$formatIdentifierName(value);
    }

    @Unique
    private int koil$globalMarketDomainColor(KoilGlobalMarketViewRow view) {
        String domain = view == null || view.domain() == null ? "" : view.domain().toLowerCase(Locale.ROOT);
        String metric = view == null || view.chartRow() == null ? "" : view.chartRow().metric().toLowerCase(Locale.ROOT);

        if ("resource".equals(domain) || metric.contains("processing/") || metric.contains("resource/")) {
            return 0xFFE8C86F;
        }

        if ("block".equals(domain)) {
            return 0xFF8FC5FF;
        }

        if ("item".equals(domain)) {
            return 0xFF8FD5D0;
        }

        if ("entity".equals(domain) || "combat".equals(domain)) {
            return 0xFFE06A6A;
        }

        if ("food".equals(domain)) {
            return 0xFFE6A15C;
        }

        if ("trade".equals(domain)) {
            return 0xFFA6D989;
        }

        return 0xFFB7A8FF;
    }

    private int koil$globalMetricColor(String metric, boolean market) {
        String value = metric.toLowerCase(Locale.ROOT);

        if (market) {
            return 0xFFB7A8FF;
        }

        if (value.contains("break") || value.contains("mine")) {
            return 0xFF8FC5FF;
        }

        if (value.contains("place") || value.contains("build")) {
            return 0xFFA6D989;
        }

        if (value.contains("trade") || value.contains("market") || value.contains("sell") || value.contains("buy")) {
            return 0xFFE8C86F;
        }

        if (value.contains("kill") || value.contains("death") || value.contains("damage")) {
            return 0xFFE06A6A;
        }

        if (koil$isFoodMetricText(value)) {
            return 0xFFE6A15C;
        }

        return 0xFF8FD5D0;
    }

    @Unique
    private String koil$itemDominantMetric(int mined, int used, int crafted, int pickedUp, int dropped, int broken) {
        int max = Math.max(mined, Math.max(used, Math.max(crafted, Math.max(pickedUp, Math.max(dropped, broken)))));

        if (max <= 0) {
            return "tracked";
        }

        if (max == mined) {
            return "mostly mined";
        }

        if (max == used) {
            return "mostly used";
        }

        if (max == crafted) {
            return "mostly crafted";
        }

        if (max == pickedUp) {
            return "mostly collected";
        }

        if (max == dropped) {
            return "mostly dropped";
        }

        return "mostly broken";
    }

    @Unique
    private String koil$threatLabel(int killed, int killedBy) {
        if (killedBy <= 0 && killed > 0) {
            return "safe record";
        }

        if (killedBy > killed) {
            return "dangerous";
        }

        if (killedBy > 0) {
            return "some risk";
        }

        return "unknown";
    }

    @Unique
    private int koil$threatColor(int killed, int killedBy) {
        if (killedBy > killed) {
            return 0xFFE06A6A;
        }

        if (killedBy > 0) {
            return 0xFFE6A15C;
        }

        return 0xFFA6D989;
    }

    @Unique
    private String koil$sourceSummary() {
        Set<String> namespaces = new TreeSet<>();

        for (class_3445<class_2960> stat : class_3468.field_15419) {
            class_2960 id = stat.method_14951();

            if (!id.method_12836().equals("minecraft")) {
                namespaces.add(id.method_12836());
            }
        }

        for (class_1792 item : class_7923.field_41178) {
            class_2960 id = class_7923.field_41178.method_10221(item);

            if (!id.method_12836().equals("minecraft")) {
                namespaces.add(id.method_12836());
            }
        }

        for (class_1299<?> entityType : class_7923.field_41177) {
            class_2960 id = class_7923.field_41177.method_10221(entityType);

            if (!id.method_12836().equals("minecraft")) {
                namespaces.add(id.method_12836());
            }
        }

        return namespaces.isEmpty() ? "minecraft" : "minecraft + " + namespaces.size() + " modded";
    }

    @Unique
    private String koil$formatIdentifierName(String value) {
        String[] parts = value.replace('-', '_').split("_");
        StringBuilder builder = new StringBuilder();

        for (String part : parts) {
            if (part.isBlank()) {
                continue;
            }

            if (builder.length() > 0) {
                builder.append(' ');
            }

            builder.append(Character.toUpperCase(part.charAt(0))).append(part.substring(1));
        }

        return builder.length() == 0 ? value : builder.toString();
    }

    @Unique
    private String koil$formatTime(int ticks) {
        long seconds = Math.max(0, ticks) / 20L;
        long hours = seconds / 3600L;
        long minutes = seconds % 3600L / 60L;
        long remainingSeconds = seconds % 60L;

        if (hours > 0) {
            return hours + "h " + minutes + "m";
        }

        if (minutes > 0) {
            return minutes + "m " + remainingSeconds + "s";
        }

        return remainingSeconds + "s";
    }

    @Unique
    private String koil$formatDistance(int centimeters) {
        double meters = Math.max(0, centimeters) / 100.0D;

        if (meters >= 1000.0D) {
            return String.format(Locale.ROOT, "%.2f km", meters / 1000.0D);
        }

        return String.format(Locale.ROOT, "%.1f m", meters);
    }

    @Unique
    private int koil$latest(int[] values) {
        return values == null || values.length == 0 ? 0 : values[values.length - 1];
    }

    @Unique
    private String koil$signed(int value) {
        return value > 0 ? "+" + value : String.valueOf(value);
    }

    @Unique
    private String koil$compact(int value) {
        if (value >= 1000000) {
            return String.format(Locale.ROOT, "%.1fm", value / 1000000.0F);
        }

        if (value >= 1000) {
            return String.format(Locale.ROOT, "%.1fk", value / 1000.0F);
        }

        return String.valueOf(value);
    }

    @Unique
    private String koil$ratio(int killed, int killedBy) {
        if (killedBy <= 0) {
            return killed <= 0 ? "0.0" : killed + ".0";
        }

        return String.format(Locale.ROOT, "%.1f", killed / (float) killedBy);
    }

    @Unique
    private String koil$ellipsize(String value, int maxWidth) {
        if (value == null) {
            return "";
        }

        if (this.field_22793.method_1727(value) <= maxWidth) {
            return value;
        }

        String suffix = "...";
        int suffixWidth = this.field_22793.method_1727(suffix);
        String trimmed = value;

        while (!trimmed.isEmpty() && this.field_22793.method_1727(trimmed) + suffixWidth > maxWidth) {
            trimmed = trimmed.substring(0, trimmed.length() - 1);
        }

        return trimmed.isEmpty() ? suffix : trimmed + suffix;
    }

    @Unique
    private void koil$renderStatsScrollbar(class_332 context) {
        if (this.koil$statsScrollMax <= 0 || this.koil$statsViewportHeight <= 0) {
            return;
        }

        int trackX = koil$statsScrollbarTrackX();
        int thumbHeight = koil$statsScrollbarThumbHeight();
        int thumbY = koil$statsScrollbarThumbY();
        context.method_25294(trackX, this.koil$statsViewportY, trackX + 2, this.koil$statsViewportY + this.koil$statsViewportHeight, 0x44000000);
        context.method_25294(trackX - 1, thumbY, trackX + 3, thumbY + thumbHeight, 0x99B8C7D6);
    }

    @Unique
    private int koil$statsScrollbarTrackX() {
        return this.koil$statsViewportX + this.koil$statsViewportWidth - 4;
    }

    @Unique
    private int koil$statsScrollbarThumbHeight() {
        if (this.koil$statsScrollMax <= 0 || this.koil$statsViewportHeight <= 0) {
            return this.koil$statsViewportHeight;
        }

        return Math.max(18, (int) ((this.koil$statsViewportHeight / (float) (this.koil$statsViewportHeight + this.koil$statsScrollMax)) * this.koil$statsViewportHeight));
    }

    @Unique
    private int koil$statsScrollbarThumbY() {
        if (this.koil$statsScrollMax <= 0 || this.koil$statsViewportHeight <= 0) {
            return this.koil$statsViewportY;
        }

        int thumbHeight = koil$statsScrollbarThumbHeight();
        int thumbTravel = Math.max(1, this.koil$statsViewportHeight - thumbHeight);
        return this.koil$statsViewportY + (int) ((this.koil$statsScrollOffset / (float) this.koil$statsScrollMax) * thumbTravel);
    }

    @Unique
    private boolean koil$isMouseOverStatsScrollbar(double mouseX, double mouseY) {
        if (this.koil$statsScrollMax <= 0 || this.koil$statsViewportHeight <= 0) {
            return false;
        }

        int trackX = koil$statsScrollbarTrackX();
        return mouseX >= trackX - 4 && mouseX <= trackX + 6 && mouseY >= this.koil$statsViewportY && mouseY <= this.koil$statsViewportY + this.koil$statsViewportHeight;
    }

    @Unique
    private boolean koil$isMouseOverStatsScrollbarThumb(double mouseX, double mouseY) {
        if (!koil$isMouseOverStatsScrollbar(mouseX, mouseY)) {
            return false;
        }

        int thumbY = koil$statsScrollbarThumbY();
        int thumbHeight = koil$statsScrollbarThumbHeight();
        return mouseY >= thumbY && mouseY <= thumbY + thumbHeight;
    }

    @Unique
    private void koil$setStatsScrollFromThumbY(double thumbY) {
        if (this.koil$statsScrollMax <= 0 || this.koil$statsViewportHeight <= 0) {
            this.koil$statsScrollOffset = 0;
            return;
        }

        int thumbHeight = koil$statsScrollbarThumbHeight();
        int thumbTravel = Math.max(1, this.koil$statsViewportHeight - thumbHeight);
        int clampedThumbY = Math.max(this.koil$statsViewportY, Math.min(this.koil$statsViewportY + thumbTravel, (int) thumbY));
        float progress = (clampedThumbY - this.koil$statsViewportY) / (float) thumbTravel;
        this.koil$statsScrollOffset = Math.max(0, Math.min(this.koil$statsScrollMax, Math.round(progress * this.koil$statsScrollMax)));
    }

    @Override
    public boolean method_25402(double mouseX, double mouseY, int button) {
        if (!koil$isKoilRedesignEnabled()) {
            return super.method_25402(mouseX, mouseY, button);
        }

        if (button == 0 && KOIL_PAGE_GLOBAL.equals(this.koil$activePage)) {
            boolean insideDropdown = koil$isMouseInsideRawRect(mouseX, mouseY, this.koil$stockDropdownX, this.koil$stockDropdownY, this.koil$stockDropdownWidth, this.koil$stockDropdownHeight);

            if (this.koil$stockDropdownOpen) {
                for (Map.Entry<String, int[]> entry : this.koil$stockDropdownOptionRects.entrySet()) {
                    int[] rect = entry.getValue();

                    if (koil$isMouseInsideRawRect(mouseX, mouseY, rect[0], rect[1], rect[2], rect[3])) {
                        if (koil$applyStockDropdownSelection(entry.getKey())) {
                            koil$playUiClick();
                        }

                        return true;
                    }
                }

                if (!insideDropdown) {
                    this.koil$stockDropdownOpen = false;
                    this.koil$stockDropdownPopupX = -1;
                    this.koil$stockDropdownPopupY = -1;
                    return true;
                }
            }

            if (insideDropdown) {
                this.koil$stockDropdownOpen = true;
                this.koil$stockDropdownPopupX = (int) Math.round(mouseX);
                this.koil$stockDropdownPopupY = (int) Math.round(mouseY);
                koil$playUiClick();
                return true;
            }

            for (Map.Entry<String, int[]> entry : this.koil$globalGroupHeaderRects.entrySet()) {
                int[] rect = entry.getValue();

                if (koil$inside((int) mouseX, (int) mouseY, rect[0], rect[1], rect[2], rect[3])) {
                    String key = entry.getKey();
                    boolean defaultOpen = "head".equals(key);
                    this.koil$expandedGlobalGroups.put(key, !koil$isGlobalGroupOpen(key, defaultOpen));
                    this.koil$statsScrollOffset = Math.max(0, Math.min(this.koil$statsScrollOffset, this.koil$statsScrollMax));
                    koil$playUiClick();
                    return true;
                }
            }

            for (Map.Entry<String, int[]> entry : this.koil$globalRowRects.entrySet()) {
                int[] rect = entry.getValue();

                if (koil$inside((int) mouseX, (int) mouseY, rect[0], rect[1], rect[2], rect[3])) {
                    String key = entry.getKey();
                    boolean open = !this.koil$expandedGlobalRows.getOrDefault(key, false);
                    this.koil$expandedGlobalRows.clear();

                    if (open) {
                        this.koil$expandedGlobalRows.put(key, true);
                    }

                    koil$playUiClick();
                    return true;
                }
            }
        }

        if (button == 0 && koil$isMouseOverStatsScrollbar(mouseX, mouseY)) {
            int thumbY = koil$statsScrollbarThumbY();

            if (koil$isMouseOverStatsScrollbarThumb(mouseX, mouseY)) {
                this.koil$statsScrollbarDragOffset = (int) mouseY - thumbY;
            } else {
                this.koil$statsScrollbarDragOffset = koil$statsScrollbarThumbHeight() / 2;
                koil$setStatsScrollFromThumbY(mouseY - this.koil$statsScrollbarDragOffset);
            }

            this.koil$statsScrollbarDragging = true;
            return true;
        }

        String clickedPage = "";

        if (button == 0) {
            for (class_364 child : this.method_25396()) {
                if (!(child instanceof class_339 widget) || !widget.field_22764 || !widget.field_22763) {
                    continue;
                }

                if (mouseX >= widget.method_46426() && mouseX <= widget.method_46426() + widget.method_25368() && mouseY >= widget.method_46427() && mouseY <= widget.method_46427() + widget.method_25364()) {
                    clickedPage = koil$pageFromButton(widget);
                    break;
                }
            }
        }

        boolean handled = super.method_25402(mouseX, mouseY, button);

        if (!clickedPage.isBlank()) {
            this.koil$activePage = clickedPage;
            this.koil$statsScrollOffset = 0;
            this.koil$statsScrollbarDragging = false;
            koil$invalidateRowCache();
        }

        return handled;
    }

    @Override
    public boolean method_25406(double mouseX, double mouseY, int button) {
        if (!koil$isKoilRedesignEnabled()) {
            this.koil$statsScrollbarDragging = false;
            return super.method_25406(mouseX, mouseY, button);
        }

        if (button == 0 && this.koil$statsScrollbarDragging) {
            this.koil$statsScrollbarDragging = false;
            return true;
        }

        return super.method_25406(mouseX, mouseY, button);
    }

    @Override
    public boolean method_25403(double mouseX, double mouseY, int button, double deltaX, double deltaY) {
        if (!koil$isKoilRedesignEnabled()) {
            this.koil$statsScrollbarDragging = false;
            return super.method_25403(mouseX, mouseY, button, deltaX, deltaY);
        }

        if (button == 0 && this.koil$statsScrollbarDragging) {
            koil$setStatsScrollFromThumbY(mouseY - this.koil$statsScrollbarDragOffset);
            return true;
        }

        return super.method_25403(mouseX, mouseY, button, deltaX, deltaY);
    }

    @Override
    public boolean method_25401(double mouseX, double mouseY, double amount) {
        if (!koil$isKoilRedesignEnabled()) {
            return super.method_25401(mouseX, mouseY, amount);
        }

        if (mouseX >= this.koil$statsViewportX
                && mouseX <= this.koil$statsViewportX + this.koil$statsViewportWidth
                && mouseY >= this.koil$statsViewportY
                && mouseY <= this.koil$statsViewportY + this.koil$statsViewportHeight
                && this.koil$statsScrollMax > 0) {
            this.koil$statsScrollOffset = Math.max(0, Math.min(this.koil$statsScrollMax, this.koil$statsScrollOffset - (int) amount * 18));
            return true;
        }

        return super.method_25401(mouseX, mouseY, amount);
    }


    @Unique
    private boolean koil$isMouseInsideRawRect(double mouseX, double mouseY, int x, int y, int width, int height) {
        return width > 0 && height > 0 && mouseX >= x && mouseX <= x + width && mouseY >= y && mouseY <= y + height;
    }

    @Unique
    private boolean koil$inside(int mouseX, int mouseY, int x, int y, int width, int height) {
        return koil$isMouseInsideStatsViewport(mouseX, mouseY) && mouseX >= x && mouseX <= x + width && mouseY >= y && mouseY <= y + height;
    }

    @Unique
    private boolean koil$isMouseInsideStatsViewport(double mouseX, double mouseY) {
        return this.koil$statsViewportWidth > 0
                && this.koil$statsViewportHeight > 0
                && mouseX >= this.koil$statsViewportX
                && mouseX <= this.koil$statsViewportX + this.koil$statsViewportWidth
                && mouseY >= this.koil$statsViewportY
                && mouseY <= this.koil$statsViewportY + this.koil$statsViewportHeight;
    }

    @Unique
    private boolean koil$isFoodMetricText(String value) {
        String safe = value == null ? "" : value.toLowerCase(Locale.ROOT);
        return safe.contains("food") || safe.contains("eaten") || safe.contains("food_") || safe.contains("/food") || safe.startsWith("food_") || safe.startsWith("food/");
    }

    @Unique
    private void koil$playUiClick() {
        class_310 client = class_310.method_1551();

        if (client != null && client.method_1483() != null) {
            client.method_1483().method_4873(class_1109.method_47978(class_3417.field_15015, 1.0F));
        }
    }

    @Unique
    private void koil$playUiTick() {
        class_310 client = class_310.method_1551();

        if (client != null && client.method_1483() != null) {
            client.method_1483().method_4873(class_1109.method_47978(class_3417.field_15015, 1.35F));
        }
    }

    @Unique
    private int koil$color(int value) {
        return new Color(value, true).getRGB();
    }
}
