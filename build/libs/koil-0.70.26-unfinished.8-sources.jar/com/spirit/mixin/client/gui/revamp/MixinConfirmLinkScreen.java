package com.spirit.mixin.client.gui.revamp;

import com.spirit.koil.api.util.file.json.JSONFileEditor;
import it.unimi.dsi.fastutil.booleans.BooleanConsumer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_407;
import net.minecraft.class_410;
import net.minecraft.class_4185;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Overwrite;
import org.spongepowered.asm.mixin.Shadow;

import java.awt.*;

import static com.spirit.koil.api.design.uiColorVal.*;

@Environment(EnvType.CLIENT)
@Mixin(class_407.class)
public abstract class MixinConfirmLinkScreen extends class_410 {
    @Shadow @Final private static class_2561 COPY;
    @Shadow public abstract void copyToClipboard();
    @Shadow @Final private boolean drawWarning;
    @Shadow @Final private static class_2561 WARNING;
    public MixinConfirmLinkScreen(BooleanConsumer callback, class_2561 title, class_2561 message) {
        super(callback, title, message);
    }

    /**
     * @author SpiritXIV
     * @reason im so tired
     */
    @Overwrite
    protected void method_37051(int y) {
        if (JSONFileEditor.getValueFromJson("./koil/sys/config.json", "uiRedesign").getAsBoolean()) {
            this.method_37063(class_4185.method_46430(this.COPY, (button) -> {
                this.copyToClipboard();
                this.field_2403.accept(false);
            }).method_46434(38, 155, 230, 20).method_46431());
        } else {
            this.method_37063(class_4185.method_46430(this.field_2402, (button) -> {
                this.field_2403.accept(true);
            }).method_46434(this.field_22789 / 2 - 50 - 105, y, 100, 20).method_46431());
            this.method_37063(class_4185.method_46430(COPY, (button) -> {
                this.copyToClipboard();
                this.field_2403.accept(false);
            }).method_46434(this.field_22789 / 2 - 50, y, 100, 20).method_46431());
            this.method_37063(class_4185.method_46430(this.field_2399, (button) -> {
                this.field_2403.accept(false);
            }).method_46434(this.field_22789 / 2 - 50 + 105, y, 100, 20).method_46431());
        }
    }

    /**
     * @author SpiritXIV
     * @reason no dup text
     */
    @Overwrite
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        if (JSONFileEditor.getValueFromJson("./koil/sys/config.json", "uiRedesign").getAsBoolean()) {
            super.method_25394(context, mouseX, mouseY, delta);
            if (this.drawWarning) {
                context.method_51439(this.field_22793, WARNING, 38, 110, new Color(uiColorBasicDescriptionText, true).getRGB(), true);
            }
        } else {
            super.method_25394(context, mouseX, mouseY, delta);
            if (this.drawWarning) {
                context.method_27534(this.field_22793, WARNING, this.field_22789 / 2, 110, 16764108);
            }
        }
    }

}
