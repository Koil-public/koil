package com.spirit.mixin.client.gui.revamp.accessor;

import net.minecraft.class_2561;
import net.minecraft.class_4267;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_4267.class)
public interface MultiplayerServerListWidgetAccessor {
    @Accessor("LAN_SCANNING_TEXT")
    static class_2561 getLanScanningText() {
        throw new AssertionError();
    }
}
