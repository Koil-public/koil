package com.spirit.mixin.client.gui.revamp.world;

import com.spirit.koil.api.design.KoilScreenBackgrounds;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_8134;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin(class_8134.class)
public class MixinExperimentsScreen {
    @Redirect(
            method = "render",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/client/gui/DrawContext;drawTexture(Lnet/minecraft/util/Identifier;IIFFIIII)V"
            )
    )
    private void koil$renderSharedContentBackground(class_332 context, class_2960 texture, int x, int y, float u, float v, int width, int height, int textureWidth, int textureHeight) {
        class_310 client = class_310.method_1551();
        if (KoilScreenBackgrounds.uiRedesignEnabled()) {
            context.method_25294(x, y, x + width, y + height, 0x65000000);
            return;
        }
        context.method_25290(texture, x, y, u, v, width, height, textureWidth, textureHeight);
    }
}
