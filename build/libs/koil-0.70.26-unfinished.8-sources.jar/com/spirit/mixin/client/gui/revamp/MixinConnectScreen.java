package com.spirit.mixin.client.gui.revamp;

import com.google.gson.JsonElement;
import com.spirit.koil.api.design.DesignLoader;
import com.spirit.koil.api.util.file.audio.AudioManager;
import com.spirit.koil.api.util.file.json.JSONFileEditor;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_412;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import static com.spirit.Main.*;

@Mixin(class_412.class)
public class MixinConnectScreen {
    private int dotCount;
    private long lastUpdateTime;

    @Inject(method = "init*", at = @At("RETURN"))
    private void onInit(CallbackInfo ci) {
        class_310 client = class_310.method_1551();
        if (client != null) {
            this.lastUpdateTime = System.currentTimeMillis();
            this.dotCount = 0;
        }
    }

    @Inject(method = "render", at = @At("HEAD"))
    private void onRender(class_332 context, int mouseX, int mouseY, float delta, CallbackInfo info) {
        AudioManager.stopAllAudio();
        class_310 client = class_310.method_1551();
        JsonElement jsonBackgroundElement = JSONFileEditor.getValueFromJson("./koil/sys/config.json", "jsonBackground");
        context.method_25293(DesignLoader.getLoadingTexture(), 0, 0, client.method_22683().method_4486(), client.method_22683().method_4502(), 0.0F, 0.0F, 319, 192, 319, 192);


        client.method_1531().method_22813(LOGO_TEXTURE);
        context.method_25290(LOGO_TEXTURE, client.method_22683().method_4486() - 60, client.method_22683().method_4502() - 60, 0, 0, 45, 45, 45, 45);
        client.method_1531().method_22813(MOJANG_LOGO);
        context.method_25290(MOJANG_LOGO, client.method_22683().method_4486() - 130, client.method_22683().method_4502() - 60, 0, 0, 45, 45, 45, 45);

        // Update dot animation
        long currentTime = System.currentTimeMillis();
        if (currentTime - lastUpdateTime >= 500) {
            lastUpdateTime = currentTime;
            dotCount = (dotCount + 1) % 4;
        }

        int loadingImageWidth = 184 + (dotCount == 0 ? 0 : (dotCount == 1 ? 15 : (dotCount == 2 ? 30 : 44)));
        int loadingImageHeight = 35;

        client.method_1531().method_22813(LOADING_TEXT_TEXTURE);
        context.method_25290(LOADING_TEXT_TEXTURE, 10, client.method_22683().method_4502() - 30, 0, 0, loadingImageWidth / 2, loadingImageHeight / 2, 228 / 2, loadingImageHeight / 2);
    }
}
