package com.spirit.mixin.client.gui.revamp.world;

import com.spirit.koil.api.design.KoilScreenBackgrounds;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_5235;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_5235.class)
public class MixinEditGameRulesScreen {
    @Inject(method = "render", at = @At("HEAD"))
    private void koil$renderSharedBackground(class_332 context, int mouseX, int mouseY, float delta, CallbackInfo info) {
        class_310 client = class_310.method_1551();
        int width = client.method_22683().method_4486();
        int height = client.method_22683().method_4502();
        KoilScreenBackgrounds.render(context, client, width, height);
        context.method_25294(0, 0, width, height, KoilScreenBackgrounds.overlayColor(client));
    }
}
