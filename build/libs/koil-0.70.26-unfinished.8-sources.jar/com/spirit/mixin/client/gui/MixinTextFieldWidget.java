package com.spirit.mixin.client.gui;

import net.minecraft.class_156;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_342;
import net.minecraft.class_3532;
import net.minecraft.class_437;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;

@Mixin(class_342.class)
public abstract class MixinTextFieldWidget {
    private static final long KOIL_MULTI_CLICK_MS = 350L;
    private static final double KOIL_MULTI_CLICK_RANGE = 6.0D;

    @Shadow @Final private class_327 textRenderer;
    @Shadow private boolean drawsBackground;
    @Shadow private int firstCharacterIndex;
    @Shadow private int selectionStart;
    @Shadow private int selectionEnd;

    @Shadow public abstract String getText();
    @Shadow public abstract int getInnerWidth();
    @Shadow public abstract int getCursor();
    @Shadow public abstract void setSelectionStart(int cursor);
    @Shadow public abstract void setSelectionEnd(int index);
    @Shadow public abstract void playDownSound(net.minecraft.class_1144 soundManager);

    private long koil$lastClickTime;
    private double koil$lastClickX;
    private double koil$lastClickY;
    private int koil$clickCount;
    private boolean koil$dragSelecting;
    private int koil$dragAnchor = -1;
    private int koil$selectionAnchor = -1;

    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        class_342 self = (class_342)(Object)this;
        if (!self.field_22763 || !self.method_1885()) {
            koil$dragSelecting = false;
            return false;
        }
        if (button != 0 || !self.method_25405(mouseX, mouseY)) {
            koil$dragSelecting = false;
            return false;
        }

        playDownSound(class_310.method_1551().method_1483());
        self.method_25365(true);

        long now = class_156.method_658();
        boolean repeatedClick = now - koil$lastClickTime <= KOIL_MULTI_CLICK_MS
                && Math.abs(mouseX - koil$lastClickX) <= KOIL_MULTI_CLICK_RANGE
                && Math.abs(mouseY - koil$lastClickY) <= KOIL_MULTI_CLICK_RANGE;

        koil$clickCount = repeatedClick ? Math.min(3, koil$clickCount + 1) : 1;
        koil$lastClickTime = now;
        koil$lastClickX = mouseX;
        koil$lastClickY = mouseY;

        int clickedIndex = koil$getCursorIndex(mouseX);
        if (class_437.method_25442()) {
            int anchor = koil$selectionAnchor >= 0 && koil$selectionAnchor <= getText().length()
                    ? koil$selectionAnchor
                    : (selectionStart != selectionEnd ? selectionEnd : getCursor());
            koil$selectRange(clickedIndex, anchor);
            koil$dragAnchor = anchor;
            koil$selectionAnchor = anchor;
            koil$dragSelecting = false;
            return true;
        }

        if (koil$clickCount == 2) {
            koil$selectWord(clickedIndex);
            koil$selectionAnchor = Math.min(selectionStart, selectionEnd);
            koil$dragSelecting = false;
        } else if (koil$clickCount >= 3) {
            koil$selectAll();
            koil$selectionAnchor = 0;
            koil$dragSelecting = false;
        } else {
            koil$selectionAnchor = clickedIndex;
            koil$dragAnchor = clickedIndex;
            koil$dragSelecting = true;
        }
        return true;
    }

    public boolean mouseDragged(double mouseX, double mouseY, int button, double deltaX, double deltaY) {
        if (button == 0 && koil$dragSelecting) {
            koil$applyDragSelection(mouseX);
            return true;
        }
        return false;
    }

    protected void onDrag(double mouseX, double mouseY, double deltaX, double deltaY) {
        if (koil$dragSelecting) {
            koil$applyDragSelection(mouseX);
        }
    }

    public boolean mouseReleased(double mouseX, double mouseY, int button) {
        if (button == 0 && koil$dragSelecting) {
            koil$dragSelecting = false;
            return true;
        }
        return false;
    }

    private void koil$applyDragSelection(double mouseX) {
        class_342 self = (class_342)(Object)this;
        if (!self.method_1885()) {
            return;
        }

        koil$selectRange(koil$getCursorIndex(mouseX), koil$dragAnchor);
        koil$selectionAnchor = koil$dragAnchor;
    }

    private int koil$getCursorIndex(double mouseX) {
        class_342 self = (class_342)(Object)this;
        String text = getText();
        if (text.isEmpty()) {
            return 0;
        }

        int relativeX = class_3532.method_15357(mouseX) - self.method_46426();
        if (drawsBackground) {
            relativeX -= 4;
        }
        relativeX = class_3532.method_15340(relativeX, 0, getInnerWidth());

        int visibleStart = class_3532.method_15340(firstCharacterIndex, 0, text.length());
        String visibleText = textRenderer.method_27523(text.substring(visibleStart), getInnerWidth());
        int localIndex = textRenderer.method_27523(visibleText, relativeX).length();
        return class_3532.method_15340(visibleStart + localIndex, 0, text.length());
    }

    private void koil$selectWord(int index) {
        String text = getText();
        if (text.isEmpty()) {
            return;
        }

        int probe = class_3532.method_15340(index, 0, text.length() - 1);
        if (index == text.length() && probe > 0) {
            probe--;
        }

        int start = probe;
        int end = probe + 1;
        int mode = koil$charMode(text.charAt(probe));

        while (start > 0 && koil$charMode(text.charAt(start - 1)) == mode) {
            start--;
        }
        while (end < text.length() && koil$charMode(text.charAt(end)) == mode) {
            end++;
        }

        koil$selectRange(end, start);
    }

    private void koil$selectAll() {
        koil$selectRange(getText().length(), 0);
    }

    private void koil$selectRange(int cursor, int anchor) {
        setSelectionStart(cursor);
        setSelectionEnd(anchor);
    }

    private int koil$charMode(char c) {
        if (Character.isWhitespace(c)) {
            return 0;
        }
        if (Character.isLetterOrDigit(c) || c == '_' || c == '-' || c == '.' || c == '/' || c == '\\' || c == ':') {
            return 1;
        }
        return 2;
    }
}
