package com.spirit.mixin.client.gui.revamp.option;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2561;
import net.minecraft.class_315;
import net.minecraft.class_332;
import net.minecraft.class_437;
import net.minecraft.class_443;
import net.minecraft.class_4667;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Environment(EnvType.CLIENT)
@Mixin(class_443.class)
public class MixinSoundOptionsScreen extends class_4667 {
    public MixinSoundOptionsScreen(class_437 parent, class_315 gameOptions, class_2561 title) {
        super(parent, gameOptions, title);
    }

    @Inject(method = "render", at = @At("HEAD"))
    private void onRender(class_332 context, int mouseX, int mouseY, float delta, CallbackInfo info) {
        // SoundOptionsScreen renders through GameOptionsScreen, which owns the shared Koil shell.
    }
}
