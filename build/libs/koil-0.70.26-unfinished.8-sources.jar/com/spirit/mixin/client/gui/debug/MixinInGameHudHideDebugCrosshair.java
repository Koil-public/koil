package com.spirit.mixin.client.gui.debug;

import com.spirit.client.gui.debug.F3OverlayRenderer;
import net.minecraft.class_310;
import net.minecraft.class_329;
import net.minecraft.class_332;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_329.class)
public abstract class MixinInGameHudHideDebugCrosshair {
    @Inject(method = "renderCrosshair", at = @At("HEAD"), cancellable = true)
    private void koil$hideVanillaCrosshairForRedesignedF3(class_332 context, CallbackInfo ci) {
        if (F3OverlayRenderer.shouldHideVanillaCrosshair(class_310.method_1551())) {
            ci.cancel();
        }
    }
}
