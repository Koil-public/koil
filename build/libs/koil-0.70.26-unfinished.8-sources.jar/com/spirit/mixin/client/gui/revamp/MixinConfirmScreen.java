package com.spirit.mixin.client.gui.revamp;

import com.spirit.koil.api.design.DesignLoader;
import com.spirit.koil.api.util.file.json.JSONFileEditor;
import it.unimi.dsi.fastutil.booleans.BooleanConsumer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_410;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_5489;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Overwrite;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.awt.*;
import java.util.List;

import static com.spirit.koil.api.design.uiColorVal.*;

@Environment(EnvType.CLIENT)
@Mixin(class_410.class)
public abstract class MixinConfirmScreen extends class_437 {
    private static final int KOIL_WARNING_LEFT = 38;
    private static final int KOIL_WARNING_TITLE_Y = 70;
    private static final int KOIL_WARNING_BODY_Y = 90;
    private static final int KOIL_WARNING_LINE_HEIGHT = 12;
    private static final int KOIL_WARNING_FOOTER_HEIGHT = 102;
    private static final int KOIL_WARNING_BUTTON_WIDTH = 150;
    private static final int KOIL_WARNING_BUTTON_HEIGHT = 20;
    private static final int KOIL_WARNING_BUTTON_GAP = 10;
    @Shadow private class_5489 messageSplit;
    @Shadow @Final private List<class_4185> buttons;
    @Shadow @Final private class_2561 message;
    @Shadow protected class_2561 yesText;
    @Shadow protected class_2561 noText;
    @Shadow @Final protected BooleanConsumer callback;
    @Shadow protected abstract int getMessageY();
    @Shadow protected abstract void addButton(class_4185 button);
    @Shadow protected abstract int getMessagesHeight();
    @Shadow protected abstract int getTitleY();

    public MixinConfirmScreen(class_2561 title) {
        super(title);
    }

    @Inject(method = "init", at = @At("RETURN"))
    protected void onInit(CallbackInfo ci) {
        if (JSONFileEditor.getValueFromJson("./koil/sys/config.json", "uiRedesign").getAsBoolean()) {
            int wrapWidth = Math.max(120, this.field_22789 - (KOIL_WARNING_LEFT * 2));
            this.messageSplit = class_5489.method_30890(this.field_22793, this.message, wrapWidth);
            int bodyHeight = this.messageSplit.method_30887() * KOIL_WARNING_LINE_HEIGHT;
            int buttonY = Math.min(this.field_22790 - 56, Math.max(KOIL_WARNING_BODY_Y + bodyHeight + 18, this.field_22790 - KOIL_WARNING_FOOTER_HEIGHT + 16));
            boolean stackButtons = this.field_22789 < KOIL_WARNING_LEFT + (KOIL_WARNING_BUTTON_WIDTH * 2) + KOIL_WARNING_BUTTON_GAP + 24;
            int yesX = KOIL_WARNING_LEFT;
            int noX = stackButtons ? KOIL_WARNING_LEFT : KOIL_WARNING_LEFT + KOIL_WARNING_BUTTON_WIDTH + KOIL_WARNING_BUTTON_GAP;
            int noY = stackButtons ? buttonY + KOIL_WARNING_BUTTON_HEIGHT + 4 : buttonY;

            this.addButton(class_4185.method_46430(this.yesText, (button) -> this.callback.accept(true))
                    .method_46434(yesX, buttonY, KOIL_WARNING_BUTTON_WIDTH, KOIL_WARNING_BUTTON_HEIGHT).method_46431());
            this.addButton(class_4185.method_46430(this.noText, (button) -> this.callback.accept(false))
                    .method_46434(noX, noY, KOIL_WARNING_BUTTON_WIDTH, KOIL_WARNING_BUTTON_HEIGHT).method_46431());
        }
    }

    /**
     * @author SpiritXIV
     * @reason no dup text
     */
    @Overwrite
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        if (JSONFileEditor.getValueFromJson("./koil/sys/config.json", "uiRedesign").getAsBoolean()) {
            renderKoilWarningShell(context);
            context.method_51439(this.field_22793, this.field_22785, KOIL_WARNING_LEFT, KOIL_WARNING_TITLE_Y, new Color(uiColorBasicTitleText, true).getRGB(), true);
            this.messageSplit.method_30896(context, KOIL_WARNING_LEFT, KOIL_WARNING_BODY_Y, KOIL_WARNING_LINE_HEIGHT, new Color(uiColorBasicDescriptionText, true).getRGB());
            super.method_25394(context, mouseX, mouseY, delta);
        } else {
            this.method_25420(context);
            context.method_27534(this.field_22793, this.field_22785, this.field_22789 / 2, this.getTitleY(), 16777215);
            this.messageSplit.method_30888(context, this.field_22789 / 2, this.getMessageY());
            super.method_25394(context, mouseX, mouseY, delta);
        }
    }

    @Inject(method = "render", at = @At("HEAD"))
    public void onRender(class_332 context, int mouseX, int mouseY, float delta, CallbackInfo info) {
        // The overwrite above owns the prompt shell. Rendering it here as well doubles the dark background.
    }

    private void renderKoilWarningShell(class_332 context) {
        boolean inWorld = field_22787 != null && field_22787.field_1687 != null;
        if (!inWorld) {
            this.method_25420(context);
            context.method_25293(DesignLoader.getLoadingTexture(), 0, 0, field_22787.method_22683().method_4486(), field_22787.method_22683().method_4502(), 0.0F, 0.0F, 319, 192, 319, 192);
        }

        context.method_51448().method_22903();
        context.method_51448().method_22905(2F, 2F, 1.0F);
        context.method_51439(this.field_22793, class_2561.method_43470("[!] Warning."), 20, 8, new Color(uiColorWarningPromptText, true).getRGB(), true);
        context.method_51448().method_22909();

        context.method_25294(0, 6, this.field_22789, this.field_22790 - KOIL_WARNING_FOOTER_HEIGHT, new Color(uiColorContentBase, true).getRGB());
        context.method_25294(0, 8, this.field_22789, 10, new Color(uiColorContentStripeLeft, true).getRGB());
        context.method_25294(0, this.field_22790 - KOIL_WARNING_FOOTER_HEIGHT - 2, this.field_22789, this.field_22790 - KOIL_WARNING_FOOTER_HEIGHT - 4, new Color(uiColorContentStripeRight, true).getRGB());
    }

    /**
     * @author SpiritXIV
     * @reason no dup buttons
     */
    @Overwrite
    protected void addButtons(int y) {
        if (JSONFileEditor.getValueFromJson("./koil/sys/config.json", "uiRedesign").getAsBoolean()) {

        } else {
            this.addButton(class_4185.method_46430(this.yesText, (button) -> this.callback.accept(true)).method_46434(this.field_22789 / 2 - 155, y, 150, 20).method_46431());
            this.addButton(class_4185.method_46430(this.noText, (button) -> this.callback.accept(false)).method_46434(this.field_22789 / 2 - 155 + 160, y, 150, 20).method_46431());
        }
    }
}
