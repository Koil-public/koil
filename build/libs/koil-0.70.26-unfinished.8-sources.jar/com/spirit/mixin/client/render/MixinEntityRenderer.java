package com.spirit.mixin.client.render;

import com.spirit.koil.api.automation.cli.AutomationPresenceState;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_1921;
import net.minecraft.class_2561;
import net.minecraft.class_327;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_897;
import net.minecraft.class_898;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.joml.Matrix4f;

@Mixin(class_897.class)
public abstract class MixinEntityRenderer<T extends class_1297> {
    @Shadow @Final protected class_898 dispatcher;

    @Shadow public abstract class_327 getTextRenderer();

    @Inject(method = "renderLabelIfPresent", at = @At("TAIL"))
    private void koil$renderAutomationUnderline(T entity, class_2561 text, class_4587 matrices, class_4597 vertexConsumers, int light, CallbackInfo ci) {
        if (!(entity instanceof class_1657 player) || !AutomationPresenceState.automationModeFor(player) || text == null) {
            return;
        }
        double distance = this.dispatcher.method_23168(entity);
        if (distance > 4096.0D) {
            return;
        }

        class_327 textRenderer = getTextRenderer();
        int color = AutomationPresenceState.colorFor(player);
        int textWidth = textRenderer.method_27525(text);
        if (textWidth <= 0) {
            return;
        }
        int x = -textWidth / 2;
        int top = textRenderer.field_2000;
        int bottom = top + 1;

        matrices.method_22903();
        matrices.method_46416(0.0F, entity.method_17682() + 0.5F, 0.0F);
        matrices.method_22907(this.dispatcher.method_24197());
        matrices.method_22905(-0.025F, -0.025F, 0.025F);
        matrices.method_46416(0.0F, 0.0F, 0.01F);
        drawUnderlineQuad(matrices.method_23760().method_23761(), vertexConsumers.getBuffer(class_1921.method_49046()), x - 1, x + textWidth + 1, top, bottom, color, light);
        matrices.method_22909();
    }

    private static void drawUnderlineQuad(Matrix4f matrix, class_4588 consumer, int left, int right, int top, int bottom, int color, int light) {
        int red = color >> 16 & 255;
        int green = color >> 8 & 255;
        int blue = color & 255;
        int alpha = color >> 24 & 255;
        if (alpha == 0) {
            alpha = 255;
        }
        consumer.method_22918(matrix, left, bottom, 0.0F).method_1336(red, green, blue, alpha).method_22916(light).method_1344();
        consumer.method_22918(matrix, right, bottom, 0.0F).method_1336(red, green, blue, alpha).method_22916(light).method_1344();
        consumer.method_22918(matrix, right, top, 0.0F).method_1336(red, green, blue, alpha).method_22916(light).method_1344();
        consumer.method_22918(matrix, left, top, 0.0F).method_1336(red, green, blue, alpha).method_22916(light).method_1344();
    }
}
