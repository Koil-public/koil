package com.spirit.mixin.client;

import com.spirit.client.gui.ide.FileExplorerScreen;
import net.minecraft.class_1041;
import net.minecraft.class_310;
import org.lwjgl.glfw.GLFW;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import static com.spirit.Client.KOIL_UTIL_POPUP_KEY_INT;
@Mixin(class_310.class)
public abstract class MinecraftClientMixin {
    @Shadow @Final private class_1041 window;

    @Shadow
    public static class_310 getInstance() {
        return null;
    }

    @Inject(method = "getFramerateLimit", at = @At(value = "HEAD"), cancellable = true)
    public void titleFramerateLimit(CallbackInfoReturnable<Integer> cir) {
        cir.setReturnValue(this.window.method_16000());
    }

    @Inject(method = "handleInputEvents", at = @At("HEAD"))
    private void toggleKoilPopup(CallbackInfo ci) {
        class_310 client = (class_310) (Object) this;
        if (client.field_1755 == null && GLFW.glfwGetKey(this.window.method_4490(), KOIL_UTIL_POPUP_KEY_INT) == GLFW.GLFW_PRESS) {
            if (client == null) {
                return;
            }


            client.method_1507(FileExplorerScreen.openAtLastVisitedPath());
            //ApplicationBar.togglePopup();
        }
    }
}
