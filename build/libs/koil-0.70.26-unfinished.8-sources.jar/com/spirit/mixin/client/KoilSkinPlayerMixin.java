package com.spirit.mixin.client;

import com.spirit.client.gui.skin.SkinRuntime;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_742;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_742.class)
public abstract class KoilSkinPlayerMixin {
    @Inject(method = "getSkinTexture", at = @At("HEAD"), cancellable = true)
    private void koil$getSkinTexture(CallbackInfoReturnable<class_2960> cir) {
        class_310 client = class_310.method_1551();
        if (client != null && (Object) this == client.field_1724 && SkinRuntime.getActiveSkinTexture() != null) {
            cir.setReturnValue(SkinRuntime.getActiveSkinTexture());
        }
    }

    @Inject(method = "getModel", at = @At("HEAD"), cancellable = true)
    private void koil$getModel(CallbackInfoReturnable<String> cir) {
        class_310 client = class_310.method_1551();
        if (client != null && (Object) this == client.field_1724 && SkinRuntime.getActiveSkinTexture() != null) {
            cir.setReturnValue(SkinRuntime.isActiveSlim() ? "slim" : "default");
        }
    }
}
