package com.spirit.client.gui;

import com.spirit.client.gui.ide.FileExplorerScreen;
import com.spirit.client.gui.ide.FileEditorScreen;
import java.io.File;
import java.nio.file.Path;
import net.minecraft.class_156;
import net.minecraft.class_310;

public final class ScreenActionHelper {
    private ScreenActionHelper() {
    }

    public static void openInKoilExplorer(String path) {
        class_310 client = class_310.method_1551();
        if (client == null) {
            return;
        }
        client.method_1507(FileExplorerScreen.openAtPath(normalizeExplorerPath(path)));
    }

    public static void openInKoilEditor(String path) {
        openInKoilEditor(path, -1);
    }

    public static void openInKoilEditor(String path, int lineNumber) {
        class_310 client = class_310.method_1551();
        if (client == null || path == null || path.isBlank()) {
            return;
        }
        try {
            File file = new File(path);
            if (!file.isAbsolute()) {
                file = Path.of(path).normalize().toFile();
            }
            if (!file.exists() || !file.isFile()) {
                return;
            }
            client.method_1507(new FileEditorScreen(client.field_1755, file, null, lineNumber));
        } catch (Exception ignored) {
        }
    }

    public static void openInSystemExplorer(String path) {
        if (path == null || path.isBlank()) {
            return;
        }
        class_156.method_668().method_673(new File(path).toURI());
    }

    public static String normalizeToInstanceRelativePath(String path) {
        return normalizeExplorerPath(path);
    }

    public static String normalizeExplorerPath(String path) {
        if (path == null || path.isBlank()) {
            return ".";
        }
        try {
            Path rawPath = Path.of(path).normalize();
            Path absolutePath = rawPath.isAbsolute() ? rawPath : Path.of(".").toAbsolutePath().normalize().resolve(rawPath).normalize();
            Path instanceRoot = Path.of(".").toAbsolutePath().normalize();
            if (absolutePath.startsWith(instanceRoot)) {
                Path relative = instanceRoot.relativize(absolutePath);
                String normalized = relative.toString().replace("\\", "/");
                return normalized.isBlank() ? "." : "./" + normalized;
            }
            return absolutePath.toString().replace("\\", "/");
        } catch (Exception ignored) {
            return path;
        }
    }
}
