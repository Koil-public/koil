package com.spirit.client.gui.world;

import com.spirit.client.gui.browser.ContentBrowserListRowRenderer;
import com.spirit.koil.api.world.LocalWorldDiscovery;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Supplier;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_4280;

import static com.spirit.Main.uiImageDirectory;
import static com.spirit.koil.api.util.file.image.ExternalImageLoader.loadExternalPngTextureWithColorVariant;

public class DiscoveredWorldListWidget extends class_4280<DiscoveredWorldListWidget.DiscoveredWorldEntry> {
    private static final class_2960 FALLBACK_WORLD_ICON = loadExternalPngTextureWithColorVariant(uiImageDirectory, "image.png");
    private final Function<LocalWorldDiscovery.DiscoveredWorld, class_2960> iconResolver;
    private final Supplier<LocalWorldDiscovery.DiscoveredWorld> selectionSupplier;
    private final Consumer<LocalWorldDiscovery.DiscoveredWorld> selectionConsumer;

    public DiscoveredWorldListWidget(class_310 client, int width, int height, int top, int bottom, int itemHeight, Function<LocalWorldDiscovery.DiscoveredWorld, class_2960> iconResolver, Supplier<LocalWorldDiscovery.DiscoveredWorld> selectionSupplier, Consumer<LocalWorldDiscovery.DiscoveredWorld> selectionConsumer) {
        super(client, width, height, top, bottom, itemHeight);
        this.iconResolver = iconResolver;
        this.selectionSupplier = selectionSupplier;
        this.selectionConsumer = selectionConsumer;
    }

    public void updateEntries(List<LocalWorldDiscovery.DiscoveredWorld> worlds) {
        LocalWorldDiscovery.DiscoveredWorld previous = this.selectionSupplier.get();
        this.method_25339();
        for (LocalWorldDiscovery.DiscoveredWorld world : worlds) {
            DiscoveredWorldEntry entry = new DiscoveredWorldEntry(world);
            this.method_25321(entry);
            if (previous != null && previous.worldPath().equals(world.worldPath())) {
                this.method_25313(entry);
            }
        }
        if (this.method_25334() == null && this.method_25340() > 0) {
            DiscoveredWorldEntry first = this.method_25326(0);
            this.method_25313(first);
            this.selectionConsumer.accept(first.world);
        }
    }

    @Override
    public int method_25322() {
        return this.field_22742 - 12;
    }

    @Override
    public int method_25342() {
        return this.field_19088 + 2;
    }

    @Override
    protected int method_25329() {
        return this.field_19087 - 6;
    }

    @Override
    protected void method_25325(class_332 context) {
    }

    public final class DiscoveredWorldEntry extends class_4280.class_4281<DiscoveredWorldEntry> {
        private final LocalWorldDiscovery.DiscoveredWorld world;

        private DiscoveredWorldEntry(LocalWorldDiscovery.DiscoveredWorld world) {
            this.world = world;
        }

        @Override
        public void method_25343(class_332 context, int index, int y, int x, int entryWidth, int entryHeight, int mouseX, int mouseY, boolean hovered, float tickDelta) {
            String subLabel = this.world.folderName() + "  |  " + (this.world.versionCompatible() ? "Compatible" : "Version mismatch") + "  |  " + this.world.worldVersion();
            ContentBrowserListRowRenderer.renderModMenuStyleItem(context, DiscoveredWorldListWidget.this.field_22740.field_1772, DiscoveredWorldListWidget.this.iconResolver.apply(this.world), FALLBACK_WORLD_ICON, x, y, entryWidth, this.world.displayName(), subLabel);
        }

        @Override
        public boolean method_25402(double mouseX, double mouseY, int button) {
            if (button != 0) {
                return false;
            }
            DiscoveredWorldListWidget.this.selectionConsumer.accept(this.world);
            DiscoveredWorldListWidget.this.method_25313(this);
            return true;
        }

        @Override
        public class_2561 method_37006() {
            return class_2561.method_43470(this.world.displayName());
        }
    }
}
