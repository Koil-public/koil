package com.spirit.client.gui.update;

import com.spirit.client.gui.update.elements.UpdateScreenData;
import com.spirit.koil.api.design.KoilScreenBackgrounds;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_7919;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;

import static com.spirit.Main.*;
import static com.spirit.koil.api.design.uiColorVal.*;
import static com.spirit.koil.api.util.file.image.ExternalImageLoader.loadExternalPngTexture;

@Environment(EnvType.CLIENT)
public class UpdateScreen extends class_437 {
    private static final class_2960 LOGO_TEXTURE = loadExternalPngTexture(uiImageDirectory, "icon.png");
    private final class_437 parent;
    private UpdateScreenData.UpdateData data;
    private List<UpdateScreenData.Branch> branches = new ArrayList<>();
    private List<UpdateScreenData.Release> releases = new ArrayList<>();
    private UpdateScreenData.Branch selectedBranch;
    private UpdateScreenData.Release selectedRelease;
    private class_4185 branchButton;
    private class_4185 fileButton;
    private class_4185 downloadButton;
    private class_4185 refreshButton;
    private class_4185 doneButton;
    private int selectedBranchIndex;
    private int selectedFileIndex;
    private int scrollPosition;
    private int maxScrollOffset;
    private String status = "Review Koil release notes. Downloading an update will close Minecraft when complete.";
    private boolean betaTester;

    public UpdateScreen(class_437 parent) {
        super(class_2561.method_43470("Koil Update"));
        this.parent = parent;
    }

    @Override
    protected void method_25426() {
        super.method_25426();
        loadData(true);
        int buttonY = this.field_22790 - 28;
        this.branchButton = this.method_37063(class_4185.method_46430(class_2561.method_43470(branchButtonLabel()), button -> cycleBranch())
                .method_46434(140, buttonY, 126, 20)
                .method_46436(class_7919.method_47407(class_2561.method_43470("Select Public, .unfinished, or .frequent when beta access is enabled.")))
                .method_46431());
        this.fileButton = this.method_37063(class_4185.method_46430(class_2561.method_43470(fileButtonLabel()), button -> cycleFile())
                .method_46434(270, buttonY, 128, 20)
                .method_46436(class_7919.method_47407(class_2561.method_43470("Select which jar file this branch should download.")))
                .method_46431());
        this.downloadButton = this.method_37063(class_4185.method_46430(class_2561.method_43470("Download & Quit"), button -> downloadSelected())
                .method_46434(402, buttonY, 118, 20)
                .method_46436(class_7919.method_47407(class_2561.method_43470("Downloads the selected Koil jar, removes old Koil jars, then closes Minecraft so the update can load next launch.")))
                .method_46431());
        this.refreshButton = this.method_37063(class_4185.method_46430(class_2561.method_43470("Refresh"), button -> {
            loadData(true);
            this.status = "Update data refreshed.";
        }).method_46434(this.field_22789 - 178, buttonY, 78, 20).method_46431());
        this.doneButton = this.method_37063(class_4185.method_46430(class_2561.method_43470("Done"), button -> method_25419())
                .method_46434(this.field_22789 - 94, buttonY, 80, 20)
                .method_46431());
        refreshButtonStates();
    }

    private void loadData(boolean refreshOnline) {
        if (refreshOnline) {
            UpdateScreenData.refreshOnlineData();
        }
        this.data = UpdateScreenData.readLocalData();
        this.betaTester = UpdateScreenData.isBetaTester();
        this.branches = UpdateScreenData.visibleBranches(this.data, this.betaTester);
        if (this.branches.isEmpty()) {
            this.branches.add(new UpdateScreenData.Branch("public", "Public", "public", false, "Downloads from Modrinth."));
        }
        String activeBranch = activeKoilBranch();
        this.selectedBranchIndex = 0;
        for (int i = 0; i < this.branches.size(); i++) {
            if (this.branches.get(i).key.equalsIgnoreCase(activeBranch)) {
                this.selectedBranchIndex = i;
                break;
            }
        }
        selectBranch(this.selectedBranchIndex);
    }

    private void selectBranch(int index) {
        this.selectedBranchIndex = Math.max(0, Math.min(index, this.branches.size() - 1));
        this.selectedBranch = this.branches.get(this.selectedBranchIndex);
        this.releases = UpdateScreenData.releasesForBranch(this.data, this.selectedBranch.key, this.betaTester);
        this.selectedRelease = this.releases.isEmpty() ? null : this.releases.get(0);
        this.selectedFileIndex = 0;
        this.scrollPosition = 0;
        refreshButtonStates();
    }

    private void refreshButtonStates() {
        if (this.branchButton == null) {
            return;
        }
        this.branchButton.method_25355(class_2561.method_43470(branchButtonLabel()));
        this.fileButton.method_25355(class_2561.method_43470(fileButtonLabel()));
        this.branchButton.field_22764 = this.betaTester;
        this.fileButton.field_22764 = this.betaTester && this.selectedBranch != null && !"public".equalsIgnoreCase(this.selectedBranch.key) && fileCount() > 1;
        this.downloadButton.field_22763 = this.selectedBranch != null;
    }

    private void cycleBranch() {
        if (this.branches.isEmpty()) {
            return;
        }
        selectBranch((this.selectedBranchIndex + 1) % this.branches.size());
    }

    private void cycleFile() {
        int count = fileCount();
        if (count <= 0) {
            return;
        }
        this.selectedFileIndex = (this.selectedFileIndex + 1) % count;
        refreshButtonStates();
    }

    private int fileCount() {
        return this.selectedRelease == null || this.selectedRelease.files == null ? 0 : this.selectedRelease.files.size();
    }

    private String selectedFileName() {
        if (fileCount() <= 0) {
            return "";
        }
        return this.selectedRelease.files.get(Math.max(0, Math.min(this.selectedFileIndex, fileCount() - 1))).fileName;
    }

    private String branchButtonLabel() {
        return "Branch: " + (this.selectedBranch == null ? "Public" : this.selectedBranch.label);
    }

    private String fileButtonLabel() {
        String fileName = selectedFileName();
        return fileName.isBlank() ? "File: default jar" : "File: " + trim(fileName, 18);
    }

    private void downloadSelected() {
        UpdateScreenData.DownloadResult result = UpdateScreenData.downloadSelected(this.data, this.selectedBranch, this.selectedRelease, selectedFileName());
        this.status = result.message;
        if (result.success) {
            this.status = result.message + " Closing Minecraft...";
            SUBLOGGER.logF("Shut-down thread", "Koil update downloaded. Closing Minecraft so the new jar can load next launch.");
            if (this.field_22787 != null) {
                this.field_22787.method_1592();
            }
        }
    }

    @Override
    public void method_25419() {
        if (this.field_22787 != null) {
            this.field_22787.method_1507(this.parent);
        }
    }

    @Override
    public boolean method_25422() {
        return true;
    }

    @Override
    public boolean method_25404(int keyCode, int scanCode, int modifiers) {
        if (keyCode == 256) {
            method_25419();
            return true;
        }
        return super.method_25404(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean method_25401(double mouseX, double mouseY, double amount) {
        this.scrollPosition = Math.max(0, Math.min(this.scrollPosition - (int) amount * 12, this.maxScrollOffset));
        return true;
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        assert field_22787 != null;
        KoilScreenBackgrounds.render(context, field_22787, this.field_22789, this.field_22790);
        context.method_25294(0, 0, this.field_22789, this.field_22790, KoilScreenBackgrounds.overlayColor(field_22787));
        renderChrome(context);
        renderSidebar(context);
        renderUpdatePanel(context, mouseX, mouseY);
        super.method_25394(context, mouseX, mouseY, delta);
    }

    private void renderChrome(class_332 context) {
        context.method_49601(0, 0, this.field_22789, this.field_22790, new Color(uiColorBackgroundBorder, true).getRGB());
        context.method_25294(0, 0, this.field_22789, 60, new Color(uiColorHeader, true).getRGB());
        context.method_49601(0, 0, this.field_22789, 60, new Color(uiColorBackgroundBorder, true).getRGB());
        context.method_25294(0, 62, 125, this.field_22790, new Color(uiColorContentBase, true).getRGB());
        context.method_49601(0, 62, 125, this.field_22790 - 62, new Color(uiColorBackgroundBorder, true).getRGB());
        context.method_25294(127, 62, this.field_22789, this.field_22790, new Color(uiColorContentBase, true).getRGB());
        context.method_49601(127, 62, this.field_22789 - 127, this.field_22790 - 62, new Color(uiColorBackgroundBorder, true).getRGB());
        context.method_25290(LOGO_TEXTURE, 10, 5, 0, 0, 45, 45, 45, 45);
        context.method_51448().method_22903();
        context.method_51448().method_22905(2, 2, 1.0F);
        context.method_51433(this.field_22793, "Koil", 34, 6, new Color(uiColorHeaderTitleText, true).getRGB(), true);
        context.method_51448().method_22909();
        context.method_51433(this.field_22793, "Update Manager", 68, 35, new Color(uiColorHeaderSubTitleText, true).getRGB(), true);
        context.method_51433(this.field_22793, "Version - " + version(), this.field_22789 - 100, 10, new Color(uiColorHeaderTitleText, true).getRGB(), true);
    }

    private void renderSidebar(class_332 context) {
        int x = 10;
        int y = 76;
        drawSidebarLine(context, x, y, "Current", version());
        y += 32;
        drawSidebarLine(context, x, y, "Branch", this.selectedBranch == null ? "Public" : this.selectedBranch.label);
        y += 32;
        drawSidebarLine(context, x, y, "Update Type", this.selectedRelease == null ? "Unknown" : UpdateScreenData.displayType(this.data, this.selectedRelease));
        y += 32;
        drawSidebarLine(context, x, y, "Download", this.selectedBranch != null && "public".equalsIgnoreCase(this.selectedBranch.key) ? "Modrinth" : "GitHub jar");
        y += 38;
        context.method_51433(this.field_22793, trim(this.status, 18), x, y, new Color(uiColorContentBaseDescriptionText, true).getRGB(), false);
    }

    private void drawSidebarLine(class_332 context, int x, int y, String label, String value) {
        int accent = this.selectedRelease == null ? new Color(uiColorContentStripeLeft, true).getRGB() : UpdateScreenData.colorForType(this.data, UpdateScreenData.dominantTypeKey(this.data, this.selectedRelease));
        context.method_25294(x, y + 1, x + 2, y + 18, accent);
        context.method_51433(this.field_22793, label, x + 8, y, new Color(uiColorHeaderSubTitleText, true).getRGB(), false);
        context.method_51433(this.field_22793, trim(value, 16), x + 8, y + 11, new Color(uiColorContentBaseTitleText, true).getRGB(), false);
    }

    private void renderUpdatePanel(class_332 context, int mouseX, int mouseY) {
        int x = 140;
        int y = 76;
        int right = this.field_22789 - 16;
        int bottom = this.field_22790 - 36;
        context.method_51448().method_22903();
        context.method_51448().method_22905(1.2F, 1.2F, 1.0F);
        context.method_51433(this.field_22793, "Koil Updates", (int) (x / 1.2F), (int) (y / 1.2F), new Color(uiColorContentBaseTitleText, true).getRGB(), true);
        context.method_51448().method_22909();
        context.method_51433(this.field_22793, "Branch-aware changelog timeline and jar download selection.", x, y + 18, new Color(uiColorContentBaseDescriptionText, true).getRGB(), false);

        int timelineTop = y + 38;
        int timelineBottom = bottom - 4;
        context.method_44379(x, timelineTop, right, timelineBottom);
        UpdateScreenData.TimelineRenderResult result = UpdateScreenData.renderReleaseTimelineInteractive(
                context,
                this.field_22793,
                this.data,
                this.releases,
                x,
                timelineTop + 6,
                right - x - 8,
                this.scrollPosition,
                timelineTop,
                timelineBottom,
                this.betaTester,
                mouseX,
                mouseY
        );
        context.method_44380();
        this.maxScrollOffset = Math.max(0, result.contentHeight - (timelineBottom - timelineTop - 8));
        this.scrollPosition = Math.max(0, Math.min(this.scrollPosition, this.maxScrollOffset));
        if (this.releases.isEmpty()) {
            context.method_51433(this.field_22793, "No release entries were found for this branch.", x + 10, timelineTop + 12, new Color(uiColorContentBaseDescriptionText, true).getRGB(), false);
        }
        UpdateScreenData.renderHoverPopup(context, this.field_22793, result, mouseX, mouseY, this.field_22789, this.field_22790);
    }

    private String trim(String value, int maxChars) {
        if (value == null) {
            return "";
        }
        return value.length() <= maxChars ? value : value.substring(0, Math.max(0, maxChars - 3)) + "...";
    }
}
