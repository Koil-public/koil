package com.spirit.client.gui.datapack;

import com.spirit.client.gui.BrowserLayoutHelper;
import com.spirit.client.gui.browser.AbstractModrinthContentScreen;
import com.spirit.mixin.client.gui.revamp.accessor.WorldListWidgetWorldEntryAccessor;
import java.io.File;
import java.nio.file.Path;
import java.util.Optional;
import net.minecraft.class_2960;
import net.minecraft.class_34;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_528;

import static com.spirit.Main.uiImageDirectory;
import static com.spirit.koil.api.util.file.image.ExternalImageLoader.loadExternalPngTextureWithColorVariant;

public class DatapackScreen extends AbstractModrinthContentScreen {
	private static final class_2960 DATAPACK_ICON = loadExternalPngTextureWithColorVariant(uiImageDirectory, "code.png");
	private class_528.class_4272 selectedWorld;
	private final class_528 levelList;
	private final File fixedDatapacksDirectory;
	private class_4185 inDevButton;

	public DatapackScreen(class_437 parent, class_528.class_4272 selectedWorld, class_528 levelList) {
		super(parent);
		this.selectedWorld = selectedWorld;
		this.levelList = levelList;
		this.fixedDatapacksDirectory = null;
	}

	public DatapackScreen(class_437 parent, class_528.class_4272 selectedWorld, class_528 levelList, String initialQuery) {
		super(parent, initialQuery);
		this.selectedWorld = selectedWorld;
		this.levelList = levelList;
		this.fixedDatapacksDirectory = null;
	}

	public DatapackScreen(class_437 parent, File datapacksDirectory) {
		super(parent);
		this.selectedWorld = null;
		this.levelList = null;
		this.fixedDatapacksDirectory = datapacksDirectory;
	}

	public DatapackScreen(class_437 parent, File datapacksDirectory, String initialQuery) {
		super(parent, initialQuery);
		this.selectedWorld = null;
		this.levelList = null;
		this.fixedDatapacksDirectory = datapacksDirectory;
	}

	@Override
	protected String getProjectTypeFacet() {
		return "datapack";
	}

	@Override
	protected String getScreenTitle() {
		return "Download Data Packs";
	}

	@Override
	protected String getSearchPlaceholder() {
		return "Search data packs";
	}

	@Override
	protected class_2960 getFallbackIcon() {
		return DATAPACK_ICON;
	}

	@Override
	protected File getContentDirectory() {
		if (this.field_22787 == null) {
			return null;
		}
		if (this.fixedDatapacksDirectory != null) {
			return this.fixedDatapacksDirectory;
		}
		if (this.levelList == null) {
			return null;
		}
		Optional<class_528.class_4272> selectedWorldOptional = this.levelList.method_20159();
		if (selectedWorldOptional.isPresent()) {
			this.selectedWorld = selectedWorldOptional.get();
		}
		if (this.selectedWorld == null || !this.selectedWorld.method_43465()) {
			return null;
		}
		class_34 level = ((WorldListWidgetWorldEntryAccessor) (Object) this.selectedWorld).koil$getLevel();
		String folderName = level == null ? this.selectedWorld.method_35740() : level.method_248();
		Path path = this.field_22787.method_1586().method_19636().resolve(folderName).resolve("datapacks");
		return path.toFile();
	}

	public File getDatapacksDirectory() {
		return getContentDirectory();
	}

	@Override
	protected String getLocalFileExtension() {
		return ".zip";
	}

	@Override
	protected String getLocalContextLabel() {
		if (this.fixedDatapacksDirectory != null) {
			return "Folder: " + this.fixedDatapacksDirectory.getName();
		}
		return this.selectedWorld == null ? "" : "World: " + this.selectedWorld.method_35740();
	}

	@Override
	protected void method_25426() {
		super.method_25426();
		if (!usesKoilChrome()) {
			return;
		}
		int rightActionX = BrowserLayoutHelper.FOOTER_RIGHT_ACTION_X;
		int rightActionWidth = BrowserLayoutHelper.FOOTER_RIGHT_ACTION_WIDTH;
		if (this.reloadButton != null) {
			this.reloadButton.field_22764 = false;
			this.reloadButton.field_22763 = false;
		}
		if (this.cancelButton != null) {
			this.cancelButton.method_46421(BrowserLayoutHelper.footerSmallButtonX(3));
			this.cancelButton.field_22764 = true;
			this.cancelButton.field_22763 = true;
		}
		if (this.openFolderButton != null) {
			this.openFolderButton.method_25358(rightActionWidth);
			this.openFolderButton.method_46421(rightActionX);
			this.openFolderButton.method_46419(this.field_22790 - 52);
			this.openFolderButton.method_25355(net.minecraft.class_2561.method_30163("Open Folder"));
		}
		if (this.inDevButton != null) {
			this.method_37066(this.inDevButton);
		}
		this.inDevButton = this.method_37063(class_4185.method_46430(net.minecraft.class_2561.method_30163("InDev"), button -> {
		}).method_46434(rightActionX, this.field_22790 - 28, rightActionWidth, 20).method_46431());
		this.inDevButton.field_22763 = false;
	}

	@Override
	protected void updateSelectionButtons() {
		super.updateSelectionButtons();
		if (this.reloadButton != null) {
			this.reloadButton.field_22764 = false;
			this.reloadButton.field_22763 = false;
		}
		if (this.cancelButton != null) {
			this.cancelButton.field_22764 = true;
			this.cancelButton.field_22763 = true;
		}
		if (this.inDevButton != null) {
			this.inDevButton.field_22763 = false;
		}
	}

	@Override
	protected class_437 createReloadScreen() {
		if (this.fixedDatapacksDirectory != null) {
			return new DatapackScreen(this.parent, this.fixedDatapacksDirectory, currentSearchQuery());
		}
		return new DatapackScreen(this.parent, this.selectedWorld, this.levelList, currentSearchQuery());
	}
}
