package com.spirit.client.gui.measure;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_437;
import org.lwjgl.glfw.GLFW;

@Environment(EnvType.CLIENT)
public final class PixelDifferenceOverlay {
    private static boolean armed;
    private static boolean measuring;
    private static boolean pinned;
    private static int startX;
    private static int startY;
    private static int endX;
    private static int endY;

    private PixelDifferenceOverlay() {
    }

    public static void arm() {
        armed = true;
        measuring = false;
    }

    public static boolean active() {
        return armed || measuring || pinned;
    }

    public static boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (!armed || button != 0) {
            return false;
        }
        startX = (int) Math.round(mouseX);
        startY = (int) Math.round(mouseY);
        endX = startX;
        endY = startY;
        measuring = true;
        pinned = false;
        return true;
    }

    public static boolean mouseDragged(double mouseX, double mouseY, int button, double deltaX, double deltaY) {
        if (!measuring || button != 0) {
            return false;
        }
        endX = (int) Math.round(mouseX);
        endY = (int) Math.round(mouseY);
        return true;
    }

    public static boolean mouseReleased(double mouseX, double mouseY, int button) {
        if (!measuring || button != 0) {
            return false;
        }
        endX = (int) Math.round(mouseX);
        endY = (int) Math.round(mouseY);
        measuring = false;
        armed = false;
        pinned = class_437.method_25442();
        if (!pinned) {
            clear();
        }
        return true;
    }

    public static boolean keyPressed(int keyCode) {
        if (!active() || keyCode != GLFW.GLFW_KEY_ESCAPE) {
            return false;
        }
        clear();
        return true;
    }

    public static void clearForRemovedScreen() {
        armed = false;
        measuring = false;
    }

    public static void render(class_332 context, int mouseX, int mouseY) {
        if (armed && !measuring && !pinned) {
            renderArmedHint(context, mouseX, mouseY);
            return;
        }
        if (!measuring && !pinned) {
            return;
        }
        int x2 = measuring ? mouseX : endX;
        int y2 = measuring ? mouseY : endY;
        renderMeasurement(context, startX, startY, x2, y2, measuring);
    }

    private static void renderArmedHint(class_332 context, int mouseX, int mouseY) {
        class_310 client = class_310.method_1551();
        if (client == null || client.field_1772 == null) {
            return;
        }
        String text = "Pixel Difference: drag to measure, hold Shift to pin";
        int width = client.field_1772.method_1727(text) + 10;
        int x = Math.max(6, Math.min(mouseX + 10, client.method_22683().method_4486() - width - 6));
        int y = Math.max(6, Math.min(mouseY + 12, client.method_22683().method_4502() - 20));
        context.method_51448().method_22903();
        context.method_51448().method_46416(0.0F, 0.0F, 5000.0F);
        context.method_25294(x + 1, y + 1, x + width + 1, y + 17, 0x90000000);
        context.method_25294(x, y, x + width, y + 16, 0xEA10151C);
        context.method_49601(x, y, width, 16, 0xFFC7D2E4);
        context.method_51433(client.field_1772, text, x + 5, y + 4, 0xFFE9F1FF, false);
        context.method_51448().method_22909();
    }

    private static void renderMeasurement(class_332 context, int x1, int y1, int x2, int y2, boolean live) {
        class_310 client = class_310.method_1551();
        if (client == null || client.field_1772 == null) {
            return;
        }
        int dx = x2 - x1;
        int dy = y2 - y1;
        int absX = Math.abs(dx);
        int absY = Math.abs(dy);
        int distance = (int) Math.round(Math.sqrt(dx * dx + dy * dy));
        String label = "ΔX " + absX + " px  ΔY " + absY + " px  D " + distance + " px";
        int midX = (x1 + x2) / 2;
        int midY = (y1 + y2) / 2;
        int labelWidth = client.field_1772.method_1727(label) + 10;
        int labelX = Math.max(6, Math.min(midX - labelWidth / 2, client.method_22683().method_4486() - labelWidth - 6));
        int labelY = Math.max(6, Math.min(midY - 20, client.method_22683().method_4502() - 20));
        int lineColor = live ? 0xFFE7F1FF : 0xFF79D0FF;
        context.method_51448().method_22903();
        context.method_51448().method_46416(0.0F, 0.0F, 5000.0F);
        drawLine(context, x1, y1, x2, y2, 0xD0000000, 3);
        drawLine(context, x1, y1, x2, y2, lineColor, 1);
        drawEndpoint(context, x1, y1, 0xFFFFD166);
        drawEndpoint(context, x2, y2, live ? 0xFF8BF779 : 0xFF79D0FF);
        context.method_25294(labelX + 1, labelY + 1, labelX + labelWidth + 1, labelY + 17, 0x95000000);
        context.method_25294(labelX, labelY, labelX + labelWidth, labelY + 16, 0xEE10151C);
        context.method_49601(labelX, labelY, labelWidth, 16, lineColor);
        context.method_51433(client.field_1772, label, labelX + 5, labelY + 4, 0xFFF7FAFF, false);
        context.method_51448().method_22909();
    }

    private static void drawEndpoint(class_332 context, int x, int y, int color) {
        context.method_25294(x - 3, y - 3, x + 4, y + 4, 0xC0000000);
        context.method_25294(x - 2, y - 2, x + 3, y + 3, color);
        context.method_25294(x, y - 5, x + 1, y + 6, color);
        context.method_25294(x - 5, y, x + 6, y + 1, color);
    }

    private static void drawLine(class_332 context, int x1, int y1, int x2, int y2, int color, int thickness) {
        int dx = Math.abs(x2 - x1);
        int dy = Math.abs(y2 - y1);
        int sx = x1 < x2 ? 1 : -1;
        int sy = y1 < y2 ? 1 : -1;
        int error = dx - dy;
        int x = x1;
        int y = y1;
        int radius = Math.max(0, thickness / 2);
        while (true) {
            context.method_25294(x - radius, y - radius, x + radius + 1, y + radius + 1, color);
            if (x == x2 && y == y2) {
                break;
            }
            int doubleError = 2 * error;
            if (doubleError > -dy) {
                error -= dy;
                x += sx;
            }
            if (doubleError < dx) {
                error += dx;
                y += sy;
            }
        }
    }

    private static void clear() {
        armed = false;
        measuring = false;
        pinned = false;
    }
}
