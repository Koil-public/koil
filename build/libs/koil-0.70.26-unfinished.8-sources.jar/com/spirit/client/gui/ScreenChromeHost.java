package com.spirit.client.gui;

import net.minecraft.class_332;

public interface ScreenChromeHost {
    void koil$renderScreenChromeLate(class_332 context, int mouseX, int mouseY, float delta);

    boolean koil$consumeScreenChromeClick(double mouseX, double mouseY, int button);
}
