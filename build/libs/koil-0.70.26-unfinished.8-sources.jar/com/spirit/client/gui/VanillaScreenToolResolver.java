package com.spirit.client.gui;

import com.google.gson.JsonPrimitive;
import com.spirit.client.gui.datapack.DatapackScreen;
import com.spirit.client.gui.ide.FileEditorScreen;
import com.spirit.client.gui.ide.FileExplorerScreen;
import com.spirit.client.gui.mod.ModConfigScreen;
import com.spirit.client.gui.mod.ModScreen;
import com.spirit.client.gui.resourcepack.ResourcePackMenuScreen;
import com.spirit.client.gui.resourcepack.ResourcepackScreen;
import com.spirit.client.gui.main.KoilMenuScreen;
import com.spirit.client.gui.measure.PixelDifferenceOverlay;
import com.spirit.client.gui.mod.ModMenuScreen;
import com.spirit.client.gui.update.UpdateScreen;
import com.spirit.client.gui.video.KoilVideoOptionsScreen;
import com.spirit.koil.api.util.file.json.JSONFileEditor;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_404;
import net.minecraft.class_4189;
import net.minecraft.class_420;
import net.minecraft.class_422;
import net.minecraft.class_426;
import net.minecraft.class_4288;
import net.minecraft.class_429;
import net.minecraft.class_437;
import net.minecraft.class_440;
import net.minecraft.class_442;
import net.minecraft.class_443;
import net.minecraft.class_446;
import net.minecraft.class_458;
import net.minecraft.class_4667;
import net.minecraft.class_500;
import net.minecraft.class_524;
import net.minecraft.class_525;
import net.minecraft.class_526;
import net.minecraft.class_5375;
import net.minecraft.class_5500;
import net.minecraft.class_6599;
import net.minecraft.class_6777;
import net.minecraft.class_7745;
import net.minecraft.class_7944;
import net.minecraft.client.gui.screen.option.*;
import org.jetbrains.annotations.Nullable;

import java.io.File;
import java.io.IOException;
import java.lang.reflect.Field;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.function.Function;

import static com.spirit.Main.SUBLOGGER;

@Environment(EnvType.CLIENT)
public final class VanillaScreenToolResolver {
    private static final List<Provider> EXTRA_PROVIDERS = new ArrayList<>();

    private VanillaScreenToolResolver() {
    }

    public static void registerProvider(Provider provider) {
        if (provider != null) {
            EXTRA_PROVIDERS.add(provider);
        }
    }

    public static <T extends class_437> void registerScreen(Class<T> screenClass, Function<T, ResolvedScreenTools> factory) {
        if (screenClass == null || factory == null) {
            return;
        }
        registerProvider(screen -> {
            if (!screenClass.isInstance(screen)) {
                return null;
            }
            return factory.apply(screenClass.cast(screen));
        });
    }

    public static <T extends class_437> void registerSimpleScreen(Class<T> screenClass, String displayName, Function<T, String> pathResolver) {
        registerScreen(screenClass, screen -> createDefaultTools(screen, displayName, pathResolver == null ? null : pathResolver.apply(screen)));
    }

    public static ResolvedScreenTools resolve(class_437 screen) {
        if (screen == null) {
            return null;
        }

        for (Provider provider : EXTRA_PROVIDERS) {
            ResolvedScreenTools resolved = provider.resolve(screen);
            if (resolved != null) {
                return resolved;
            }
        }

        return resolveBuiltin(screen);
    }

    private static ResolvedScreenTools resolveBuiltin(class_437 screen) {
        String displayName = resolveDisplayName(screen);
        String path = resolvePath(screen);
        return createDefaultTools(screen, displayName, path);
    }

    private static @Nullable ResolvedScreenTools createDefaultTools(class_437 screen, String displayName, @Nullable String path) {
        boolean hasPath = path != null && !path.isBlank();
        List<PopupMenu.MenuEntry> actions = new ArrayList<>();
        actions.add(new PopupMenu.MenuEntry("info", "Screen Info"));
        if (hasPath) {
            actions.add(new PopupMenu.MenuEntry("open_explorer", "Open In Explorer"));
        }
        if (hasPath && supportsEditor(screen, path)) {
            actions.add(new PopupMenu.MenuEntry("open_editor", "Open In Editor"));
        }
        actions.add(new PopupMenu.MenuEntry("pixel_difference", "Pixel Difference"));
        actions.add(new PopupMenu.MenuEntry("ui_music", toggleLabel("Music", "designMusic")));
        actions.add(new PopupMenu.MenuEntry("ui_redesign", toggleLabel("Koil UI Design", "uiRedesign")));
        actions.add(new PopupMenu.MenuEntry("ui_panorama", toggleLabel("Menu Panorama", "menuPanorama")));

        List<String> infoLines = buildInfoLines(screen, displayName, path, actions);
        return new ResolvedScreenTools(displayName, path, actions, infoLines, defaultActionHandler());
    }

    private static ToolActionHandler defaultActionHandler() {
        return (actionId, tools, mouseX, mouseY, screenWidth, screenHeight, infoPopup) -> {
            switch (actionId) {
                case "open_explorer" -> ScreenActionHelper.openInKoilExplorer(tools.path());
                case "open_editor" -> ScreenActionHelper.openInKoilEditor(tools.path());
                case "info" -> infoPopup.openAtPointer(mouseX, mouseY, screenWidth, screenHeight, tools.infoLines());
                case "pixel_difference" -> PixelDifferenceOverlay.arm();
                case "ui_music" -> DesignMusicController.applyDesignMusicState(toggleConfigBoolean("designMusic", "screen tools"), true);
                case "ui_redesign" -> {
                    toggleConfigBoolean("uiRedesign", "screen tools");
                    DesignMusicController.applyConfiguredMusic(true);
                }
                case "ui_panorama" -> toggleConfigBoolean("menuPanorama", "screen tools");
                default -> {
                }
            }
        };
    }

    private static String toggleLabel(String label, String configKey) {
        return label + ": " + (readConfigBoolean(configKey, false) ? "On" : "Off");
    }

    private static boolean readConfigBoolean(String key, boolean fallback) {
        try {
            var element = JSONFileEditor.getValueFromJson("./koil/sys/config.json", key);
            return element != null && element.isJsonPrimitive() ? element.getAsBoolean() : fallback;
        } catch (Exception e) {
            SUBLOGGER.logW("Screen tools", "Failed to read " + key + " config value: " + e.getMessage());
            return fallback;
        }
    }

    private static boolean toggleConfigBoolean(String key, String source) {
        boolean nextValue = !readConfigBoolean(key, false);
        try {
            JSONFileEditor.updateValueInJson("./koil/sys/config.json", key, new JsonPrimitive(nextValue));
            SUBLOGGER.logI("Screen tools", source + " set " + key + "=" + nextValue);
        } catch (IOException e) {
            SUBLOGGER.logE("Screen tools", "Failed to update " + key + " config value: " + e.getMessage());
        }
        return nextValue;
    }

    private static String resolveDisplayName(class_437 screen) {
        if (screen instanceof class_526 || screen instanceof class_525 || screen instanceof class_524) {
            return "Singleplayer";
        }
        if (screen instanceof class_500 || screen instanceof class_422 || screen instanceof class_420) {
            return "Multiplayer";
        }
        if (screen instanceof class_5375 || screen instanceof class_7745) {
            return "Resource Packs";
        }
        if (screen instanceof ResourcepackScreen) {
            return "Resource Packs";
        }
        if (screen instanceof DatapackScreen) {
            return "Datapacks";
        }
        if (screen instanceof ModScreen) {
            return "Mods";
        }
        if (screen instanceof FileExplorerScreen) {
            return "File Explorer";
        }
        if (screen instanceof FileEditorScreen) {
            return "File Editor";
        }
        if (screen instanceof ModConfigScreen) {
            return "Config Editor";
        }
        if (screen instanceof ModMenuScreen) {
            return "Mod Menu";
        }
        if (screen instanceof ResourcePackMenuScreen) {
            return "Resource Pack Manager";
        }
        if (screen instanceof KoilMenuScreen) {
            return "Koil Manager";
        }
        if (screen instanceof UpdateScreen) {
            return "Koil Updater";
        }
        if (screen instanceof class_4667
                || screen instanceof class_429
                || screen instanceof class_404
                || screen instanceof class_458
                || screen instanceof class_6599
                || screen instanceof class_426
                || screen instanceof class_4288
                || screen instanceof class_6777
                || screen instanceof class_5500
                || screen instanceof class_440
                || screen instanceof class_443
                || screen instanceof class_7944
                || screen instanceof class_446
                || screen instanceof KoilVideoOptionsScreen
                || screen instanceof class_4189) {
            return "Options";
        }
        if (screen instanceof class_442) {
            return "Minecraft";
        }
        String title = screen.method_25440() == null ? "" : screen.method_25440().getString().trim();
        if (!title.isBlank()) {
            return title;
        }
        return humanize(screen.getClass().getSimpleName());
    }

    private static @Nullable String resolvePath(class_437 screen) {
        if (screen instanceof class_526 || screen instanceof class_525 || screen instanceof class_524) {
            return "./saves";
        }
        if (screen instanceof class_500 || screen instanceof class_422 || screen instanceof class_420) {
            return "./servers.dat";
        }
        if (screen instanceof class_5375 || screen instanceof class_7745) {
            return "./resourcepacks";
        }
        if (screen instanceof ResourcepackScreen) {
            return "./resourcepacks";
        }
        if (screen instanceof DatapackScreen) {
            return resolveDatapackPath((DatapackScreen) screen);
        }
        if (screen instanceof ModScreen) {
            return "./mods";
        }
        if (screen instanceof FileExplorerScreen) {
            return resolveExplorerPath(screen);
        }
        if (screen instanceof FileEditorScreen) {
            return resolveEditorPath(screen);
        }
        if (screen instanceof ModConfigScreen) {
            return resolveConfigPath(screen);
        }
        if (screen instanceof ModMenuScreen) {
            return "./mods";
        }
        if (screen instanceof ResourcePackMenuScreen) {
            return resolveResourcePackManagerPath(screen);
        }
        if (screen instanceof KoilMenuScreen || screen instanceof UpdateScreen) {
            return "./koil";
        }
        if (screen instanceof class_4667
                || screen instanceof class_429
                || screen instanceof class_404
                || screen instanceof class_458
                || screen instanceof class_6599
                || screen instanceof class_426
                || screen instanceof class_4288
                || screen instanceof class_6777
                || screen instanceof class_5500
                || screen instanceof class_440
                || screen instanceof class_443
                || screen instanceof class_7944
                || screen instanceof class_446
                || screen instanceof KoilVideoOptionsScreen
                || screen instanceof class_4189) {
            return "./options.txt";
        }
        return null;
    }

    private static String resolveDatapackPath(DatapackScreen screen) {
        try {
            java.io.File directory = screen.getDatapacksDirectory();
            if (directory == null) {
                return "./saves";
            }
            return ScreenActionHelper.normalizeToInstanceRelativePath(directory.getPath());
        } catch (Exception ignored) {
            return "./saves";
        }
    }

    private static List<String> buildInfoLines(class_437 screen, String displayName, @Nullable String path, List<PopupMenu.MenuEntry> actions) {
        List<String> lines = new ArrayList<>();
        lines.add(displayName);
        lines.add("Game Name: " + describeScreenTitle(screen));
        lines.add("Class: " + screen.getClass().getName());
        lines.add("Class File: " + toSourceFilePath(screen.getClass()));
        lines.add("Path: " + ((path == null || path.isBlank()) ? "No default file target" : ScreenActionHelper.normalizeToInstanceRelativePath(path)));
        return lines;
    }

    private static String describeScreenTitle(class_437 screen) {
        if (screen.method_25440() == null) {
            return resolveDisplayName(screen);
        }
        String title = screen.method_25440().getString().trim();
        return title.isBlank() ? resolveDisplayName(screen) : title;
    }

    private static boolean supportsEditor(class_437 screen, String path) {
        if (path == null || path.isBlank()) {
            return false;
        }
        if (screen instanceof class_500 || screen instanceof class_422 || screen instanceof class_420) {
            return true;
        }
        if (screen instanceof ModConfigScreen) {
            return true;
        }
        return screen instanceof class_4667
                || screen instanceof class_429
                || screen instanceof class_404
                || screen instanceof class_458
                || screen instanceof class_6599
                || screen instanceof class_426
                || screen instanceof class_4288
                || screen instanceof class_6777
                || screen instanceof class_5500
                || screen instanceof class_440
                || screen instanceof class_443
                || screen instanceof class_7944
                || screen instanceof class_446
                || screen instanceof KoilVideoOptionsScreen
                || screen instanceof class_4189;
    }

    private static String resolveExplorerPath(class_437 screen) {
        File directory = readFieldValue(screen, "currentDirectory", File.class);
        if (directory != null) {
            return ScreenActionHelper.normalizeToInstanceRelativePath(directory.getPath());
        }
        return ".";
    }

    private static String resolveEditorPath(class_437 screen) {
        File file = readFieldValue(screen, "fileItem", File.class);
        if (file != null) {
            return ScreenActionHelper.normalizeToInstanceRelativePath(file.getPath());
        }
        return ".";
    }

    private static String resolveConfigPath(class_437 screen) {
        File file = readFieldValue(screen, "configFile", File.class);
        if (file != null) {
            return ScreenActionHelper.normalizeToInstanceRelativePath(file.getPath());
        }
        return "./koil/sys/config.json";
    }

    private static String resolveResourcePackManagerPath(class_437 screen) {
        Path path = readFieldValue(screen, "packDirectory", Path.class);
        if (path != null) {
            return ScreenActionHelper.normalizeToInstanceRelativePath(path.toString());
        }
        return "./resourcepacks";
    }

    private static String toSourceFilePath(Class<?> screenClass) {
        return "src/main/java/" + screenClass.getName().replace('.', '/') + ".java";
    }

    private static <T> @Nullable T readFieldValue(Object target, String fieldName, Class<T> type) {
        try {
            Field field = target.getClass().getDeclaredField(fieldName);
            field.setAccessible(true);
            Object value = field.get(target);
            if (type.isInstance(value)) {
                return type.cast(value);
            }
        } catch (Exception ignored) {
        }
        return null;
    }

    private static String humanize(String simpleName) {
        String base = simpleName.replace("Screen", "");
        StringBuilder builder = new StringBuilder();
        for (int i = 0; i < base.length(); i++) {
            char c = base.charAt(i);
            if (i > 0 && Character.isUpperCase(c) && Character.isLowerCase(base.charAt(i - 1))) {
                builder.append(' ');
            }
            builder.append(c);
        }
        return builder.toString().trim().toLowerCase(Locale.ROOT);
    }

    public interface Provider {
        ResolvedScreenTools resolve(class_437 screen);
    }

    @FunctionalInterface
    public interface ToolActionHandler {
        void handle(String actionId, ResolvedScreenTools tools, double mouseX, double mouseY, int screenWidth, int screenHeight, InfoPopup infoPopup);
    }

    public record ResolvedScreenTools(
            String displayName,
            String path,
            List<PopupMenu.MenuEntry> actions,
            List<String> infoLines,
            ToolActionHandler actionHandler
    ) {
    }
}
