package com.spirit.client.gui;

import com.spirit.client.gui.ide.FileExplorerScreen;
import java.io.File;
import java.util.List;
import net.minecraft.class_156;
import net.minecraft.class_310;

public final class FolderOpenHelper {
    public static final String ACTION_KOIL_EXPLORER = "folder_open:koil_explorer";
    public static final String ACTION_SYSTEM = "folder_open:system";
    private static final List<PopupMenu.MenuEntry> MENU_ENTRIES = List.of(
            new PopupMenu.MenuEntry(ACTION_KOIL_EXPLORER, "in Explorer"),
            new PopupMenu.MenuEntry(ACTION_SYSTEM, "with Default Application")
    );

    private FolderOpenHelper() {
    }

    public static List<PopupMenu.MenuEntry> menuEntries() {
        return MENU_ENTRIES;
    }

    public static void handleAction(class_310 client, File folder, String actionId) {
        if (client == null || folder == null || actionId == null || actionId.isBlank()) {
            return;
        }
        if (!folder.exists()) {
            folder.mkdirs();
        }
        switch (actionId) {
            case ACTION_KOIL_EXPLORER -> client.method_1507(FileExplorerScreen.openAtPath(ScreenActionHelper.normalizeToInstanceRelativePath(folder.getAbsolutePath())));
            case ACTION_SYSTEM -> class_156.method_668().method_673(folder.toURI());
            default -> {
            }
        }
    }
}
