package com.spirit.client.gui.skin;

import net.minecraft.class_2960;

public final class SkinRuntime {
    private static String activeSkinId;
    private static class_2960 activeSkinTexture;
    private static boolean activeSlim;

    private SkinRuntime() {
    }

    public static void setActiveSkin(String id, class_2960 texture, boolean slim) {
        activeSkinId = id;
        activeSkinTexture = texture;
        activeSlim = slim;
    }

    public static void clearActiveSkin() {
        activeSkinId = null;
        activeSkinTexture = null;
        activeSlim = false;
    }

    public static String getActiveSkinId() {
        return activeSkinId;
    }

    public static class_2960 getActiveSkinTexture() {
        return activeSkinTexture;
    }

    public static boolean isActiveSlim() {
        return activeSlim;
    }
}
