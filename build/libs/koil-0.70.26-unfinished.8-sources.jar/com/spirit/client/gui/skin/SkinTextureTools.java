package com.spirit.client.gui.skin;

import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Locale;
import net.minecraft.class_1011;
import net.minecraft.class_1043;
import net.minecraft.class_2960;
import net.minecraft.class_310;

public final class SkinTextureTools {
    private SkinTextureTools() {
    }

    public static class_1011 readSkin(Path path) throws Exception {
        try (InputStream stream = Files.newInputStream(path)) {
            class_1011 image = class_1011.method_4309(stream);
            return normalize(image);
        }
    }

    public static class_1011 normalize(class_1011 image) {
        if (image.method_4307() == 64 && image.method_4323() == 64) {
            return image;
        }
        if (image.method_4307() == 64 && image.method_4323() == 32) {
            class_1011 converted = new class_1011(64, 64, true);
            for (int y = 0; y < 32; y++) {
                for (int x = 0; x < 64; x++) {
                    converted.method_4305(x, y, image.method_4315(x, y));
                }
            }
            image.close();
            return converted;
        }
        int width = image.method_4307();
        int height = image.method_4323();
        image.close();
        throw new IllegalArgumentException("Minecraft skins must be 64x64 or legacy 64x32, got " + width + "x" + height);
    }

    public static class_1011 copy(class_1011 source) {
        class_1011 copy = new class_1011(source.method_4307(), source.method_4323(), true);
        for (int y = 0; y < source.method_4323(); y++) {
            for (int x = 0; x < source.method_4307(); x++) {
                copy.method_4305(x, y, source.method_4315(x, y));
            }
        }
        return copy;
    }

    public static int[] snapshot(class_1011 source) {
        int[] pixels = new int[source.method_4307() * source.method_4323()];
        int i = 0;
        for (int y = 0; y < source.method_4323(); y++) {
            for (int x = 0; x < source.method_4307(); x++) {
                pixels[i++] = source.method_4315(x, y);
            }
        }
        return pixels;
    }

    public static void restore(class_1011 target, int[] pixels) {
        int i = 0;
        for (int y = 0; y < target.method_4323(); y++) {
            for (int x = 0; x < target.method_4307(); x++) {
                target.method_4305(x, y, pixels[i++]);
            }
        }
    }

    public static void writeSkin(class_1011 image, Path path) throws Exception {
        Files.createDirectories(path.getParent());
        image.method_4314(path);
    }

    public static class_2960 registerTexture(String key, class_1011 image) {
        String safe = key.toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9_./-]", "_");
        class_2960 id = new class_2960("koil", "skin/" + safe);
        class_310.method_1551().method_1531().method_4616(id, new class_1043(image));
        return id;
    }


    public static int nativeToArgb(int color) {
        return (color & 0xFF000000) | ((color & 0x000000FF) << 16) | (color & 0x0000FF00) | ((color & 0x00FF0000) >> 16);
    }

    public static int argbToNative(int color) {
        return nativeToArgb(color);
    }

    public static int withAlpha(int color, int alpha) {
        return (color & 0x00FFFFFF) | ((alpha & 255) << 24);
    }

    public static int lighten(int color, int amount) {
        int a = color & 0xFF000000;
        int r = Math.min(255, ((color >> 16) & 255) + amount);
        int g = Math.min(255, ((color >> 8) & 255) + amount);
        int b = Math.min(255, (color & 255) + amount);
        return a | (r << 16) | (g << 8) | b;
    }

    public static int darken(int color, int amount) {
        int a = color & 0xFF000000;
        int r = Math.max(0, ((color >> 16) & 255) - amount);
        int g = Math.max(0, ((color >> 8) & 255) - amount);
        int b = Math.max(0, (color & 255) - amount);
        return a | (r << 16) | (g << 8) | b;
    }
}
