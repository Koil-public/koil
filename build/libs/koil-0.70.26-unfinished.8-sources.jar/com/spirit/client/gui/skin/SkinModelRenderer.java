package com.spirit.client.gui.skin;

import net.minecraft.class_1657;
import net.minecraft.class_1921;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_4608;
import net.minecraft.class_5602;
import net.minecraft.class_591;
import net.minecraft.class_630;
import net.minecraft.class_7833;

public final class SkinModelRenderer {
    private SkinModelRenderer() {
    }

    public static void render(class_332 context, class_2960 texture, boolean slim, int centerX, int centerY, float scale, float yaw, float pitch, float roll) {
        render(context, texture, slim, centerX, centerY, scale, yaw, pitch, roll, true, true);
    }

    public static void render(class_332 context, class_2960 texture, boolean slim, int centerX, int centerY, float scale, float yaw, float pitch, float roll, boolean showBaseLayer, boolean showOverlayLayer) {
        render(context, texture, slim, centerX, centerY, scale, yaw, pitch, roll, showBaseLayer, showBaseLayer, showBaseLayer, showBaseLayer, showBaseLayer, showBaseLayer, showOverlayLayer, showOverlayLayer, showOverlayLayer, showOverlayLayer, showOverlayLayer, showOverlayLayer);
    }

    public static void render(class_332 context, class_2960 texture, boolean slim, int centerX, int centerY, float scale, float yaw, float pitch, float roll, boolean showBaseHead, boolean showBaseBody, boolean showBaseRightArm, boolean showBaseLeftArm, boolean showBaseRightLeg, boolean showBaseLeftLeg, boolean showOverlayHead, boolean showOverlayBody, boolean showOverlayRightArm, boolean showOverlayLeftArm, boolean showOverlayRightLeg, boolean showOverlayLeftLeg) {
        class_310 client = class_310.method_1551();
        class_4587 matrices = context.method_51448();
        class_630 modelPart = client.method_31974().method_32072(slim ? class_5602.field_27581 : class_5602.field_27577);
        class_591<class_1657> model = new class_591<>(modelPart, slim);
        model.field_3448 = false;
        class_2960 skin = texture == null ? new class_2960("minecraft", slim ? "textures/entity/alex.png" : "textures/entity/steve.png") : texture;
        model.method_2805(true);
        model.field_3398.field_3665 = showBaseHead;
        model.field_3391.field_3665 = showBaseBody;
        model.field_3401.field_3665 = showBaseRightArm;
        model.field_27433.field_3665 = showBaseLeftArm;
        model.field_3392.field_3665 = showBaseRightLeg;
        model.field_3397.field_3665 = showBaseLeftLeg;
        model.field_3394.field_3665 = showOverlayHead;
        model.field_3483.field_3665 = showOverlayBody;
        model.field_3486.field_3665 = showOverlayRightArm;
        model.field_3484.field_3665 = showOverlayLeftArm;
        model.field_3479.field_3665 = showOverlayRightLeg;
        model.field_3482.field_3665 = showOverlayLeftLeg;
        model.field_3398.field_3654 = 0.0F;
        model.field_3398.field_3675 = 0.0F;
        model.field_3398.field_3674 = 0.0F;
        model.field_3394.field_3654 = 0.0F;
        model.field_3394.field_3675 = 0.0F;
        model.field_3394.field_3674 = 0.0F;
        model.field_3391.field_3654 = 0.0F;
        model.field_3391.field_3675 = 0.0F;
        model.field_3391.field_3674 = 0.0F;
        model.field_3483.field_3654 = 0.0F;
        model.field_3483.field_3675 = 0.0F;
        model.field_3483.field_3674 = 0.0F;
        model.field_3401.field_3654 = 0.06F;
        model.field_27433.field_3654 = -0.06F;
        model.field_3392.field_3654 = -0.035F;
        model.field_3397.field_3654 = 0.035F;
        model.field_3394.method_17138(model.field_3398);
        model.field_3483.method_17138(model.field_3391);
        model.field_3486.method_17138(model.field_3401);
        model.field_3484.method_17138(model.field_27433);
        model.field_3479.method_17138(model.field_3392);
        model.field_3482.method_17138(model.field_3397);
        matrices.method_22903();
        matrices.method_46416(centerX, centerY, 360.0F);
        matrices.method_22907(class_7833.field_40718.rotationDegrees(roll));
        matrices.method_22907(class_7833.field_40714.rotationDegrees(pitch));
        matrices.method_22907(class_7833.field_40716.rotationDegrees(180.0F + yaw));
        matrices.method_22905(-scale, scale, scale);
        matrices.method_46416(0.0F, -0.34F, 0.0F);
        class_4597.class_4598 consumers = client.method_22940().method_23000();
        model.method_2828(matrices, consumers.getBuffer(class_1921.method_23578(skin)), 15728880, class_4608.field_21444, 1.0F, 1.0F, 1.0F, 1.0F);
        consumers.method_22993();
        matrices.method_22909();
    }





    public static float wrap(float value) {
        while (value > 360.0F) {
            value -= 360.0F;
        }
        while (value < -360.0F) {
            value += 360.0F;
        }
        return value;
    }

    public static float clampPitch(float value) {
        return Math.max(-89.0F, Math.min(89.0F, value));
    }
}
