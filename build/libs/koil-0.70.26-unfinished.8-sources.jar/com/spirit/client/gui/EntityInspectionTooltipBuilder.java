package com.spirit.client.gui;

import com.spirit.koil.api.automation.cli.AutomationPresenceState;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import net.minecraft.class_1293;
import net.minecraft.class_1297;
import net.minecraft.class_1308;
import net.minecraft.class_1309;
import net.minecraft.class_1321;
import net.minecraft.class_1324;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_2487;
import net.minecraft.class_2561;
import net.minecraft.class_2583;
import net.minecraft.class_270;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_5134;
import net.minecraft.class_7923;

import static com.spirit.koil.api.design.uiColorVal.*;

public final class EntityInspectionTooltipBuilder {
    private EntityInspectionTooltipBuilder() {
    }

    public static List<class_2561> build(class_1297 entity) {
        List<class_2561> lines = new ArrayList<>();
        if (entity == null) {
            return lines;
        }
        int titleColor = uiColorToolTipWarning;
        int labelColor = uiColorToolTipLabel;
        int primaryColor = uiColorToolTipPrimary;
        int secondaryColor = uiColorToolTipSecondary;
        int ideaColor = uiColorToolTipIdea;

        class_2960 entityId = class_7923.field_41177.method_10221(entity.method_5864());
        lines.add(
                class_2561.method_43470("Entity").method_10862(class_2583.field_24360.method_36139(titleColor).method_10982(true))
                        .method_10852(class_2561.method_43470("  ").method_10862(class_2583.field_24360.method_36139(labelColor)))
                        .method_10852(class_2561.method_43470(entity.method_5477().getString()).method_10862(class_2583.field_24360.method_36139(primaryColor)))
        );
        addLine(lines, "Type: ", entityId == null ? "unknown" : entityId.toString(), labelColor, secondaryColor);
        addLine(lines, "UUID: ", entity.method_5845(), labelColor, secondaryColor);
        addLine(lines, "Entity Id: ", String.valueOf(entity.method_5628()), labelColor, secondaryColor);
        addLine(lines, "World: ", worldId(entity.method_37908()), labelColor, secondaryColor);
        addLine(lines, "Automation: ", automationState(entity), ideaColor, automationColor(entity));
        addLine(lines, "Position: ", formatPos(entity), labelColor, primaryColor);
        addLine(lines, "Block: ", blockPos(entity.method_24515()), labelColor, secondaryColor);
        addLine(lines, "Velocity: ", formatVelocity(entity), labelColor, secondaryColor);
        addLine(lines, "Rotation: ", String.format(Locale.ROOT, "yaw %.2f pitch %.2f", entity.method_36454(), entity.method_36455()), labelColor, secondaryColor);
        addLine(lines, "Flags: ", formatFlags(entity), labelColor, secondaryColor);
        addLine(lines, "Bounding Box: ", formatBox(entity.method_5829()), labelColor, secondaryColor);

        if (entity instanceof class_1309 living) {
            addLine(lines, "Vitals: ", String.format(Locale.ROOT, "health %.2f / %.2f, absorption %.2f, armor %d", living.method_6032(), living.method_6063(), living.method_6067(), living.method_6096()), labelColor, primaryColor);
            addAttribute(lines, "Move Speed", living.method_5996(class_5134.field_23719), labelColor, secondaryColor);
            addAttribute(lines, "Attack Damage", living.method_5996(class_5134.field_23721), labelColor, secondaryColor);
            addAttribute(lines, "Attack Speed", living.method_5996(class_5134.field_23723), labelColor, secondaryColor);
            addAttribute(lines, "Follow Range", living.method_5996(class_5134.field_23717), labelColor, secondaryColor);
            addAttribute(lines, "Knockback Resist", living.method_5996(class_5134.field_23718), labelColor, secondaryColor);
            addLine(lines, "Air / Fire: ", living.method_5669() + " / " + living.method_20802(), labelColor, secondaryColor);
            addLine(lines, "Hands: ", stackLabel(living.method_6047()) + " | offhand " + stackLabel(living.method_6079()), labelColor, secondaryColor);
            if (living.method_6065() != null) {
                addLine(lines, "Attacker: ", living.method_6065().method_5477().getString(), labelColor, secondaryColor);
            }
            if (living.method_6052() != null) {
                addLine(lines, "Target: ", living.method_6052().method_5477().getString(), labelColor, secondaryColor);
            }
            if (!living.method_6026().isEmpty()) {
                addLine(lines, "Effects: ", formatEffects(living.method_6026()), labelColor, secondaryColor);
            }
        }

        if (entity instanceof class_1657 player) {
            addLine(lines, "Player: ", player.method_7334().getName(), labelColor, primaryColor);
            addLine(lines, "Food: ", String.format(Locale.ROOT, "%d food, %.2f saturation, %.2f exhaustion", player.method_7344().method_7586(), player.method_7344().method_7589(), player.method_7344().method_35219()), labelColor, secondaryColor);
            class_270 team = player.method_5781();
            if (team != null) {
                addLine(lines, "Team: ", team.method_1197(), labelColor, secondaryColor);
            }
        } else if (entity instanceof class_1308 mob) {
            addLine(lines, "Mob State: ", "ai " + (!mob.method_5987()) + ", left-handed " + mob.method_5961() + ", attacking " + mob.method_6510(), labelColor, secondaryColor);
            if (mob.method_5968() != null) {
                addLine(lines, "Mob Target: ", mob.method_5968().method_5477().getString(), labelColor, secondaryColor);
            }
        }

        if (entity instanceof class_1321 tameable) {
            addLine(lines, "Owner: ", tameable.method_6139() == null ? "none" : tameable.method_6139().toString(), labelColor, secondaryColor);
        }

        if (entity.method_5782()) {
            addLine(lines, "Passengers: ", joinEntityNames(entity.method_5685()), labelColor, secondaryColor);
        }
        if (entity.method_5765()) {
            addLine(lines, "Vehicle: ", entity.method_5854() == null ? "none" : entity.method_5854().method_5477().getString(), labelColor, secondaryColor);
        }

        class_2487 nbt = new class_2487();
        try {
            entity.method_5647(nbt);
            addWrappedLine(lines, "NBT: ", nbt.method_10714(), labelColor, secondaryColor);
        } catch (Exception exception) {
            addLine(lines, "NBT: ", "unavailable: " + exception.getMessage(), labelColor, secondaryColor);
        }

        return lines;
    }

    private static void addAttribute(List<class_2561> lines, String label, class_1324 attribute, int labelColor, int valueColor) {
        if (attribute != null) {
            addLine(lines, label + ": ", String.format(Locale.ROOT, "%.3f", attribute.method_6194()), labelColor, valueColor);
        }
    }

    private static void addLine(List<class_2561> lines, String label, String value, int labelColor, int valueColor) {
        lines.add(class_2561.method_43470(label).method_10862(class_2583.field_24360.method_36139(labelColor))
                .method_10852(class_2561.method_43470(value == null || value.isBlank() ? "none" : value).method_10862(class_2583.field_24360.method_36139(valueColor))));
    }

    private static void addWrappedLine(List<class_2561> lines, String label, String value, int labelColor, int valueColor) {
        class_310 client = class_310.method_1551();
        if (client == null) {
            addLine(lines, label, value, labelColor, valueColor);
            return;
        }
        int wrapWidth = 320 - client.field_1772.method_1727(label);
        List<String> wrapped = wrapPlain(client, value, Math.max(80, wrapWidth));
        if (wrapped.isEmpty()) {
            addLine(lines, label, value, labelColor, valueColor);
            return;
        }
        for (int i = 0; i < wrapped.size(); i++) {
            String row = wrapped.get(i);
            addLine(lines, i == 0 ? label : "  ", row, labelColor, valueColor);
        }
    }

    private static List<String> wrapPlain(class_310 client, String value, int maxWidth) {
        List<String> rows = new ArrayList<>();
        if (client == null || client.field_1772 == null || value == null || value.isBlank()) {
            rows.add(value == null ? "" : value);
            return rows;
        }
        StringBuilder current = new StringBuilder();
        for (String word : value.split(" ")) {
            String candidate = current.isEmpty() ? word : current + " " + word;
            if (!current.isEmpty() && client.field_1772.method_1727(candidate) > maxWidth) {
                rows.add(current.toString());
                current = new StringBuilder(word);
            } else {
                current.setLength(0);
                current.append(candidate);
            }
        }
        if (!current.isEmpty()) {
            rows.add(current.toString());
        }
        if (rows.isEmpty()) {
            rows.add(value);
        }
        return rows;
    }

    private static String worldId(class_1937 world) {
        if (world == null || world.method_27983() == null || world.method_27983().method_29177() == null) {
            return "unknown";
        }
        return world.method_27983().method_29177().toString();
    }

    private static String automationState(class_1297 entity) {
        if (!(entity instanceof class_1657 player)) {
            return "not a player";
        }
        String state = AutomationPresenceState.stateFor(player);
        String detail = AutomationPresenceState.detailFor(player);
        return detail.isBlank() ? state : state + " - " + detail;
    }

    private static int automationColor(class_1297 entity) {
        if (entity instanceof class_1657 player) {
            return AutomationPresenceState.colorFor(player);
        }
        return uiColorToolTipPrimary;
    }

    private static String formatPos(class_1297 entity) {
        return String.format(Locale.ROOT, "x %.3f y %.3f z %.3f", entity.method_23317(), entity.method_23318(), entity.method_23321());
    }

    private static String blockPos(class_2338 pos) {
        return pos == null ? "unknown" : pos.method_10263() + ", " + pos.method_10264() + ", " + pos.method_10260();
    }

    private static String formatVelocity(class_1297 entity) {
        return String.format(Locale.ROOT, "x %.3f y %.3f z %.3f", entity.method_18798().field_1352, entity.method_18798().field_1351, entity.method_18798().field_1350);
    }

    private static String formatFlags(class_1297 entity) {
        return "on_ground " + entity.method_24828()
                + ", sprinting " + entity.method_5624()
                + ", sneaking " + entity.method_5715()
                + ", swimming " + entity.method_5681()
                + ", glowing " + entity.method_5851()
                + ", invisible " + entity.method_5767()
                + ", silent " + entity.method_5701()
                + ", no_gravity " + entity.method_5740();
    }

    private static String formatBox(class_238 box) {
        return String.format(Locale.ROOT, "min %.2f %.2f %.2f | max %.2f %.2f %.2f", box.field_1323, box.field_1322, box.field_1321, box.field_1320, box.field_1325, box.field_1324);
    }

    private static String stackLabel(class_1799 stack) {
        if (stack == null || stack.method_7960()) {
            return "empty";
        }
        class_2960 id = class_7923.field_41178.method_10221(stack.method_7909());
        return stack.method_7947() + "x " + (id == null ? stack.method_7964().getString() : id.toString());
    }

    private static String formatEffects(Iterable<class_1293> effects) {
        List<String> rows = new ArrayList<>();
        for (class_1293 effect : effects) {
            class_2960 id = class_7923.field_41174.method_10221(effect.method_5579());
            rows.add((id == null ? effect.method_5579().method_5560().getString() : id.toString()) + " amp " + effect.method_5578() + " dur " + effect.method_5584());
        }
        return String.join(" | ", rows);
    }

    private static String joinEntityNames(List<class_1297> entities) {
        List<String> names = new ArrayList<>();
        for (class_1297 entity : entities) {
            names.add(entity.method_5477().getString());
        }
        return names.isEmpty() ? "none" : String.join(", ", names);
    }
}
