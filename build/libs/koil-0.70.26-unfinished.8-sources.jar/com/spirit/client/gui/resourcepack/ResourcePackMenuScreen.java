package com.spirit.client.gui.resourcepack;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.spirit.client.gui.*;
import com.spirit.client.gui.datapack.DatapackScreen;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_156;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_350;
import net.minecraft.class_410;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_5244;
import net.minecraft.class_5369;
import net.minecraft.class_5375;
import net.minecraft.class_6382;
import net.minecraft.class_7919;
import org.apache.commons.io.FileUtils;
import org.lwjgl.util.tinyfd.TinyFileDialogs;

import java.awt.*;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Field;
import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

import static com.spirit.koil.api.design.uiColorVal.*;

@Environment(EnvType.CLIENT)
public class ResourcePackMenuScreen extends class_437 {
    private static final int LIST_OUTER_LEFT = 31;
    private static final int LIST_INNER_LEFT = 37;
    private static final int LIST_OUTER_RIGHT = 351;
    private static final int LIST_INNER_RIGHT = 345;
    private static final int INSTALLED_FILTER_Y = 10;
    private static final int INSTALLED_FILTER_HEIGHT = 20;
    private static final int INSTALLED_FILTER_GAP = 6;
    private static final int PREVIEW_INFO_LABEL_WIDTH = 96;
    private static final int PREVIEW_INFO_ROW_PADDING = 4;

    private enum InstalledSortMode {
        NAME("Name"),
        PACK_ID("Pack ID"),
        STATE("Status"),
        SOURCE("Source"),
        PICTURE("Picture");

        private final String label;

        InstalledSortMode(String label) {
            this.label = label;
        }
    }

    private enum InstalledFilterMode {
        ALL("All"),
        ENABLED("Enabled"),
        DISABLED("Disabled"),
        REMOTE("Has Remote");

        private final String label;

        InstalledFilterMode(String label) {
            this.label = label;
        }
    }

    private enum InstalledGroupMode {
        NONE("None"),
        STATUS("Status"),
        SOURCE("Source"),
        FAMILY("Family");

        private final String label;

        InstalledGroupMode(String label) {
            this.label = label;
        }
    }

    private enum PreviewSourceMode {
        AUTO("Auto"),
        MODRINTH("Modrinth"),
        LOCAL("Local");

        private final String label;

        PreviewSourceMode(String label) {
            this.label = label;
        }
    }

    private record LocalPackInsight(
            String fileName,
            String filePath,
            String packFormat,
            String supportedFormats,
            String metadataFile,
            int iconCount,
            boolean zipped,
            boolean found,
            long fileSize
    ) {
    }

    private record LocalPackDescriptor(
            String id,
            String description
    ) {
    }

    private record RemotePackPreviewData(
            String provider,
            String projectTitle,
            String projectSlug,
            String projectDescription,
            String projectType,
            String licenseName,
            String sourceUrl,
            String issuesUrl,
            String wikiUrl,
            String discordUrl,
            String publishedAt,
            String updatedAt,
            String authorName,
            String versionTitle,
            String versionNumber,
            String versionSummary,
            String body,
            String downloads,
            String followers,
            String clientSide,
            String serverSide,
            String loaderRequirement,
            boolean exactGameVersion,
            boolean exactLoaderMatch,
            int versionCount,
            List<String> loaders,
            List<String> gameVersions,
            List<String> categories,
            boolean exactVersion,
            boolean approximateProject,
            boolean updateAvailable,
            boolean found
    ) {
    }

    private record PreviewTooltipRegion(int x, int y, int width, int height, List<class_2561> lines) {
    }

    private record PreviewChip(String label, int background) {
    }

    private final class_5375 bridge;
    private final class_5369 organizer;
    private final Path packDirectory;
    private final boolean datapackMode;
    private PackListWidget packListWidget;
    private class_342 searchField;
    private class_4185 downloadButton;
    private class_4185 enableDisableButton;
    private class_4185 deleteButton;
    private class_4185 websiteButton;
    private class_4185 reloadButton;
    private class_4185 openFolderButton;
    private class_5369.class_5371 selectedPack;
    private final Map<String, RemotePackPreviewData> remotePreviewCache = new ConcurrentHashMap<>();
    private final Set<String> remotePreviewLoading = ConcurrentHashMap.newKeySet();
    private final Set<String> expandedInstalledGroups = new HashSet<>();
    private final PopupMenu installedFilterPopup = new PopupMenu();
    private final PopupMenu previewSourcePopup = new PopupMenu();
    private final PopupMenu packActionPopup = new PopupMenu();
    private final PopupMenu folderOpenPopup = new PopupMenu();
    private InstalledSortMode installedSortMode = InstalledSortMode.NAME;
    private InstalledFilterMode installedFilterMode = InstalledFilterMode.ALL;
    private InstalledGroupMode installedGroupMode = InstalledGroupMode.NONE;
    private PreviewSourceMode previewSourceMode = PreviewSourceMode.AUTO;
    private boolean showIconlessPacks = true;
    private int previewScrollOffset;
    private int previewScrollMax;
    private int previewViewportX;
    private int previewViewportY;
    private int previewViewportWidth;
    private int previewViewportHeight;
    private boolean previewScrollbarDragging;
    private int previewScrollbarDragOffset;
    private int previewSourceChipX;
    private int previewSourceChipY;
    private int previewSourceChipWidth;
    private int previewVersionX;
    private int previewVersionY;
    private int previewVersionWidth;
    private int previewVersionSplitX = -1;
    private int previewUpdateChipX = -1;
    private int previewUpdateChipY = -1;
    private int previewUpdateChipWidth;
    private final List<PreviewTooltipRegion> previewTooltipRegions = new ArrayList<>();
    private File pendingFolderOpenDirectory;
    private int lastMouseX;
    private int lastMouseY;
    private class_5369.class_5371 popupActionPack;
    private boolean organizerCallbackPatched = false;
    private boolean reloadRequired = false;
    private boolean suppressOrganizerReloadCallback = false;
    private Set<String> initialEnabledPackNames = Set.of();
    private String lastClickedPackName = "";
    private long lastPackClickTimeMs;

    public ResourcePackMenuScreen(class_5375 bridge, class_5369 organizer, Path packDirectory, class_2561 title) {
        super(title);
        this.bridge = bridge;
        this.organizer = organizer;
        this.packDirectory = packDirectory;
        this.datapackMode = isDatapackContext(title, packDirectory);
        this.expandedInstalledGroups.add(packPluralSpacedLabel());
    }

    private static boolean isDatapackContext(class_2561 title, Path packDirectory) {
        String titleText = title == null ? "" : title.getString().toLowerCase(Locale.ROOT);
        String directoryText = packDirectory == null ? "" : packDirectory.toString().toLowerCase(Locale.ROOT);
        return titleText.contains("data pack")
                || titleText.contains("datapack")
                || directoryText.contains("datapack")
                || directoryText.contains("data-pack");
    }

    private String packPluralLabel() {
        return this.datapackMode ? "Datapacks" : "Resourcepacks";
    }

    private String packPluralSpacedLabel() {
        return this.datapackMode ? "Data Packs" : "Resource Packs";
    }

    private String packSingularLabel() {
        return this.datapackMode ? "Datapack" : "Resourcepack";
    }

    private String packSingularSpacedLabel() {
        return this.datapackMode ? "Data Pack" : "Resource Pack";
    }

    private String packTypeId() {
        return this.datapackMode ? "datapack" : "resourcepack";
    }

    private String packRemotePath() {
        return this.datapackMode ? "datapack" : "resourcepack";
    }

    private String packRemoteSearchPath() {
        return this.datapackMode ? "datapacks" : "resourcepacks";
    }

    @Override
    protected void method_25426() {
        int x = BrowserLayoutHelper.FOOTER_BUTTON_X;
        int searchWidth = 200;
        int searchX = this.field_22789 - 210;
        int rightActionX = BrowserLayoutHelper.FOOTER_RIGHT_ACTION_X;
        int topButtonWidth = BrowserLayoutHelper.FOOTER_TOP_BUTTON_WIDTH;
        int smallButtonWidth = BrowserLayoutHelper.FOOTER_SMALL_BUTTON_WIDTH;

        this.searchField = new class_342(this.field_22793, searchX, 10, searchWidth, 20, class_2561.method_43470("Search " + packPluralLabel()));
        this.searchField.method_1863(this::onSearchChanged);
        this.searchField.method_47404(class_2561.method_43470("Search installed " + packPluralLabel().toLowerCase(Locale.ROOT)));
        this.method_25429(this.searchField);

        this.downloadButton = this.method_37063(class_4185.method_46430(class_2561.method_30163("Download " + packPluralLabel()), button -> {
            if (this.field_22787 != null) {
                if (this.datapackMode) {
                    this.field_22787.method_1507(new DatapackScreen(this, this.packDirectory.toFile()));
                } else {
                    this.field_22787.method_1507(new ResourcepackScreen(this));
                }
            }
        }).method_46434(BrowserLayoutHelper.footerTopButtonX(0), this.field_22790 - 52, topButtonWidth, 20).method_46431());

        this.method_37063(class_4185.method_46430(class_2561.method_30163("Import " + packSingularLabel()), button -> openImportResourcepackChooser()).method_46434(BrowserLayoutHelper.footerTopButtonX(1), this.field_22790 - 52, topButtonWidth, 20).method_46431());

        this.websiteButton = this.method_37063(class_4185.method_46430(class_2561.method_30163("Website"), button -> openSelectedPackRemotePage()).method_46434(rightActionX, this.field_22790 - 52, topButtonWidth, 20).method_46431());

        this.enableDisableButton = this.method_37063(class_4185.method_46430(class_2561.method_30163("Disable"), button -> {
            if (this.selectedPack != null) {
                toggleSelectedPack();
            }
        }).method_46434(BrowserLayoutHelper.footerSmallButtonX(0), this.field_22790 - 28, smallButtonWidth, 20).method_46431());

        this.deleteButton = this.method_37063(class_4185.method_46430(class_2561.method_30163("Delete"), button -> {
            if (this.selectedPack != null) {
                confirmDeleteSelectedPack();
            }
        }).method_46434(BrowserLayoutHelper.footerSmallButtonX(1), this.field_22790 - 28, smallButtonWidth, 20).method_46431());

        this.openFolderButton = this.method_37063(class_4185.method_46430(class_2561.method_30163("Open Folder"), button -> openFolderPopupAtPointer(this.packDirectory.toFile())).method_46434(rightActionX, this.field_22790 - 28, topButtonWidth, 20).method_46436(class_7919.method_47407(class_2561.method_43471("pack.folderInfo"))).method_46431());

        this.reloadButton = this.method_37063(class_4185.method_46430(class_2561.method_30163("Reload"), button -> reloadScreen()).method_46434(BrowserLayoutHelper.footerSmallButtonX(2), this.field_22790 - 28, smallButtonWidth, 20).method_46431());
        this.method_37063(class_4185.method_46430(class_5244.field_24335, button -> finishAndClose()).method_46434(BrowserLayoutHelper.footerSmallButtonX(3), this.field_22790 - 28, smallButtonWidth, 20).method_46431());

        this.packListWidget = new PackListWidget(this.field_22787, LIST_INNER_RIGHT - LIST_INNER_LEFT, this.field_22790, 39, this.field_22790 - 57, 36);
        this.packListWidget.method_25333(LIST_INNER_LEFT);
        this.method_25429(this.packListWidget);

        ensureOrganizerCallbackPatched();
        refreshOrganizerWithoutReloadMark();
        rebuildInstalledPackList();
        this.initialEnabledPackNames = currentEnabledPackNames();
        packSelected(this.selectedPack != null);
    }

    private void packSelected(boolean buttonsActive) {
        updateReloadRequiredFromOrganizerState();
        boolean hasSelection = buttonsActive && this.selectedPack != null;
        boolean canToggle = hasSelection && (this.selectedPack.method_29662() || this.selectedPack.method_29661());
        boolean canDelete = hasSelection && resolvePackPath(this.selectedPack) != null && !this.selectedPack.method_29655();
        this.enableDisableButton.field_22763 = canToggle;
        this.deleteButton.field_22763 = canDelete;
        this.websiteButton.field_22763 = hasSelection;
        this.reloadButton.field_22763 = this.reloadRequired;
        this.openFolderButton.field_22763 = true;
        if (this.selectedPack != null) {
            this.enableDisableButton.method_25355(class_2561.method_30163(this.selectedPack.method_29660() ? "Disable" : "Enable"));
        } else {
            this.enableDisableButton.method_25355(class_2561.method_30163("Disable"));
        }
    }

    private void onSearchChanged(String query) {
        rebuildInstalledPackList();
    }

    private List<class_5369.class_5371> allPacks() {
        List<class_5369.class_5371> packs = new ArrayList<>();
        packs.addAll(this.organizer.method_29643().toList());
        packs.addAll(this.organizer.method_29639().toList());
        return packs;
    }

    private void rebuildInstalledPackList() {
        this.packListWidget.method_25339();
        List<class_5369.class_5371> filteredPacks = allPacks().stream()
                .filter(this::matchesInstalledSearch)
                .filter(this::matchesInstalledFilter)
                .filter(this::matchesInstalledPicturePreference)
                .sorted(installedPackComparator())
                .toList();

        filteredPacks.forEach(pack -> this.packListWidget.addPackEntry(new PackListWidget.PackEntry(pack, this.field_22787, this)));

        if (this.selectedPack == null || filteredPacks.stream().noneMatch(pack -> pack.method_48276().equals(this.selectedPack.method_48276()))) {
            this.selectedPack = filteredPacks.isEmpty() ? null : filteredPacks.get(0);
            if (this.selectedPack != null) {
                setSelectedPack(this.selectedPack);
            } else {
                this.packSelected(false);
            }
        } else {
            class_5369.class_5371 refreshedSelection = filteredPacks.stream()
                    .filter(pack -> pack.method_48276().equals(this.selectedPack.method_48276()))
                    .findFirst()
                    .orElse(null);
            this.selectedPack = refreshedSelection;
            this.packSelected(this.selectedPack != null);
        }
    }

    private boolean matchesInstalledSearch(class_5369.class_5371 pack) {
        String query = this.searchField == null ? "" : this.searchField.method_1882().trim().toLowerCase(Locale.ROOT);
        if (query.isBlank()) {
            return true;
        }
        String name = pack.method_48276().toLowerCase(Locale.ROOT);
        String displayName = pack.method_29650().getString().toLowerCase(Locale.ROOT);
        String description = pack.method_29651().getString().toLowerCase(Locale.ROOT);
        String source = String.valueOf(pack.method_29652()).toLowerCase(Locale.ROOT);
        return name.contains(query) || displayName.contains(query) || description.contains(query) || source.contains(query);
    }

    private boolean matchesInstalledFilter(class_5369.class_5371 pack) {
        return switch (this.installedFilterMode) {
            case ALL -> true;
            case ENABLED -> pack.method_29660();
            case DISABLED -> !pack.method_29660();
            case REMOTE -> {
                RemotePackPreviewData remote = getCachedRemotePreview(pack);
                if (remote != null && remote.found()) {
                    yield true;
                }
                fetchRemotePreviewIfNeeded(pack);
                yield false;
            }
        };
    }

    private boolean matchesInstalledPicturePreference(class_5369.class_5371 pack) {
        return this.showIconlessPacks || hasPackPicture(pack);
    }

    private Comparator<class_5369.class_5371> installedPackComparator() {
        Comparator<class_5369.class_5371> base = switch (this.installedSortMode) {
            case NAME -> Comparator.comparing(pack -> pack.method_29650().getString().toLowerCase(Locale.ROOT));
            case PACK_ID -> Comparator.comparing(pack -> pack.method_48276().toLowerCase(Locale.ROOT));
            case STATE -> Comparator.comparing((class_5369.class_5371 pack) -> !pack.method_29660()).thenComparing(pack -> pack.method_29650().getString().toLowerCase(Locale.ROOT));
            case SOURCE -> Comparator.comparing((class_5369.class_5371 pack) -> String.valueOf(pack.method_29652()).toLowerCase(Locale.ROOT)).thenComparing(pack -> pack.method_29650().getString().toLowerCase(Locale.ROOT));
            case PICTURE -> Comparator.comparing((class_5369.class_5371 pack) -> !hasPackPicture(pack)).thenComparing(pack -> pack.method_29650().getString().toLowerCase(Locale.ROOT));
        };
        return this.installedSortMode == InstalledSortMode.PICTURE ? base : Comparator.comparing((class_5369.class_5371 pack) -> !hasPackPicture(pack)).thenComparing(base);
    }

    private String groupLabel(class_5369.class_5371 pack) {
        return switch (this.installedGroupMode) {
            case STATUS -> pack.method_29660() ? "Enabled" : "Disabled";
            case SOURCE -> blankFallback(String.valueOf(pack.method_29652()), "Unknown Source");
            case FAMILY -> familyLabel(pack);
            case NONE -> "";
        };
    }

    private String familyLabel(class_5369.class_5371 pack) {
        String name = pack.method_48276().toLowerCase(Locale.ROOT);
        String source = String.valueOf(pack.method_29652()).toLowerCase(Locale.ROOT);
        if (source.contains("default") || name.contains("vanilla")) {
            return "Default Packs";
        }
        if (name.contains("programmer") || name.contains("faithful") || name.contains("bare") || name.contains("visual")) {
            return "Visual Packs";
        }
        return packPluralSpacedLabel();
    }

    private String familyClusterKey(class_5369.class_5371 pack) {
        String label = familyLabel(pack);
        if (packPluralSpacedLabel().equals(label)) {
            return pack.method_48276();
        }
        return label;
    }

    private class_5369.class_5371 chooseRepresentative(List<class_5369.class_5371> packs) {
        return packs.stream()
                .sorted(Comparator.comparing((class_5369.class_5371 pack) -> !hasPackPicture(pack)).thenComparing(pack -> pack.method_29650().getString().length()))
                .findFirst()
                .orElse(packs.get(0));
    }

    private void toggleInstalledGroup(String label) {
        if (this.expandedInstalledGroups.contains(label)) {
            this.expandedInstalledGroups.remove(label);
        } else {
            this.expandedInstalledGroups.add(label);
        }
        rebuildInstalledPackList();
    }

    private boolean hasPackPicture(class_5369.class_5371 pack) {
        return pack != null && pack.method_30286() != null;
    }

    public void setSelectedPack(class_5369.class_5371 pack) {
        this.selectedPack = pack;
        this.previewScrollOffset = 0;
        this.previewScrollMax = 0;
        if (pack != null) {
            fetchRemotePreviewIfNeeded(pack);
        }
        this.packSelected(pack != null);
    }

    private void selectPackFromList(class_5369.class_5371 pack) {
        if (pack == null) {
            return;
        }
        String packName = pack.method_48276();
        long now = class_156.method_658();
        boolean doubleClick = packName.equals(this.lastClickedPackName) && now - this.lastPackClickTimeMs <= 350L;
        setSelectedPack(pack);
        this.lastClickedPackName = doubleClick ? "" : packName;
        this.lastPackClickTimeMs = doubleClick ? 0L : now;
        if (doubleClick) {
            toggleSelectedPack();
        }
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        updateReloadRequiredFromOrganizerState();
        if (this.reloadButton != null) {
            this.reloadButton.field_22763 = this.reloadRequired;
        }
        this.lastMouseX = mouseX;
        this.lastMouseY = mouseY;
        class_310 client = class_310.method_1551();
        BrowserLayoutHelper.renderContentBackground(context, client, this.field_22789, this.field_22790);

        context.method_25294(0, 0, this.field_22789, 43, new Color(uiColorHeader, true).getRGB());
        context.method_25294(0, 39, this.field_22789, 42, new Color(uiColorHeaderStripe, true).getRGB());
        context.method_25294(0, this.field_22790 - 60, this.field_22789, this.field_22790, new Color(uiColorFooter, true).getRGB());
        context.method_25294(0, this.field_22790 - 60, this.field_22789, this.field_22790 - 57, new Color(uiColorFooterStripe, true).getRGB());
        context.method_25294(LIST_OUTER_LEFT, 39, LIST_OUTER_RIGHT, this.field_22790 - 60, new Color(uiColorContentBase, true).getRGB());
        context.method_25294(LIST_INNER_LEFT, 39, LIST_INNER_LEFT + 2, this.field_22790 - 60, new Color(uiColorContentStripeLeft, true).getRGB());
        context.method_25294(LIST_INNER_RIGHT - 2, 39, LIST_INNER_RIGHT, this.field_22790 - 60, new Color(uiColorContentStripeRight, true).getRGB());

        context.method_51448().method_22903();
        context.method_51448().method_22905(1.5F, 1.5F, 1.0F);
        context.method_51433(this.field_22793, packPluralLabel(), 25, 6, new Color(uiColorHeaderTitleText, true).getRGB(), true);
        context.method_51448().method_22909();
        context.method_51433(this.field_22793, "-= -".replace(" ", ""), 37, 23, new Color(uiColorHeaderSubTitleText, true).getRGB(), true);

        int searchX = this.field_22789 - 210;
        int filterX = searchX - INSTALLED_FILTER_GAP - getInstalledFilterWidth(getShowButtonLabel()) - INSTALLED_FILTER_GAP - getInstalledFilterWidth(getSortButtonLabel());
        renderInstalledFilterButton(context, filterX, getSortButtonLabel());
        int showX = filterX + getInstalledFilterWidth(getSortButtonLabel()) + INSTALLED_FILTER_GAP;
        renderInstalledFilterButton(context, showX, getShowButtonLabel());
        this.searchField.method_25394(context, mouseX, mouseY, delta);
        this.installedFilterPopup.render(context, mouseX, mouseY);
        this.previewSourcePopup.render(context, mouseX, mouseY);
        this.packActionPopup.render(context, mouseX, mouseY);
        this.folderOpenPopup.render(context, mouseX, mouseY);

        super.method_25394(context, mouseX, mouseY, delta);
        this.packListWidget.method_25394(context, mouseX, mouseY, delta);

        if (this.selectedPack != null) {
            MarkdownPreviewRenderer.beginInteractiveFrame();
            renderPackDetails(context, this.selectedPack, LIST_OUTER_RIGHT + 7, 43);
            renderPreviewHoverTooltip(context, mouseX, mouseY);
        }
        ((ScreenChromeHost) this).koil$renderScreenChromeLate(context, mouseX, mouseY, delta);
    }

    @Override
    public boolean method_25402(double mouseX, double mouseY, int button) {
        if (((ScreenChromeHost) this).koil$consumeScreenChromeClick(mouseX, mouseY, button)) {
            return true;
        }
        if (button == 0 && this.installedFilterPopup.isOpen()) {
            PopupMenu.MenuEntry selected = this.installedFilterPopup.click(mouseX, mouseY);
            if (selected != null) {
                UiSoundHelper.playButtonClick();
                applyInstalledFilterAction(selected.id());
                return true;
            }
            if (!this.installedFilterPopup.isOpen()) {
                return true;
            }
        }
        if (button == 0 && this.previewSourcePopup.isOpen()) {
            PopupMenu.MenuEntry selected = this.previewSourcePopup.click(mouseX, mouseY);
            if (selected != null) {
                UiSoundHelper.playButtonClick();
                applyPreviewSourceAction(selected.id());
                return true;
            }
            if (!this.previewSourcePopup.isOpen()) {
                return true;
            }
        }
        if (button == 0 && this.packActionPopup.isOpen()) {
            PopupMenu.MenuEntry selected = this.packActionPopup.click(mouseX, mouseY);
            if (selected != null) {
                UiSoundHelper.playButtonClick();
                applyPackAction(selected.id());
                return true;
            }
            if (!this.packActionPopup.isOpen()) {
                return true;
            }
        }
        if (button == 0 && this.folderOpenPopup.isOpen()) {
            PopupMenu.MenuEntry selected = this.folderOpenPopup.click(mouseX, mouseY);
            if (selected != null) {
                FolderOpenHelper.handleAction(this.field_22787, this.pendingFolderOpenDirectory, selected.id());
                UiSoundHelper.playButtonClick();
                return true;
            }
            if (!this.folderOpenPopup.isOpen()) {
                return true;
            }
        }

        if (button == 0) {
            if (MarkdownPreviewRenderer.handleLinkClick(mouseX, mouseY)) {
                UiSoundHelper.playButtonClick();
                return true;
            }
            int searchX = this.field_22789 - 210;
            int sortX = searchX - INSTALLED_FILTER_GAP - getInstalledFilterWidth(getShowButtonLabel()) - INSTALLED_FILTER_GAP - getInstalledFilterWidth(getSortButtonLabel());
            int sortWidth = getInstalledFilterWidth(getSortButtonLabel());
            int showWidth = getInstalledFilterWidth(getShowButtonLabel());

            if (isWithinInstalledFilter(mouseX, mouseY, sortX, INSTALLED_FILTER_Y, sortWidth, INSTALLED_FILTER_HEIGHT)) {
                UiSoundHelper.playButtonClick();
                openInstalledFilterMenu(mouseX, mouseY, buildSortEntries());
                return true;
            }
            int showX = sortX + sortWidth + INSTALLED_FILTER_GAP;
            if (isWithinInstalledFilter(mouseX, mouseY, showX, INSTALLED_FILTER_Y, showWidth, INSTALLED_FILTER_HEIGHT)) {
                UiSoundHelper.playButtonClick();
                openInstalledFilterMenu(mouseX, mouseY, buildShowEntries());
                return true;
            }
            if (isWithinInstalledFilter(mouseX, mouseY, this.previewSourceChipX, this.previewSourceChipY, this.previewSourceChipWidth, 10)) {
                UiSoundHelper.playButtonClick();
                this.previewSourcePopup.openAtPointer(mouseX, mouseY, this.field_22789, this.field_22790, buildPreviewSourceEntries());
                return true;
            }
            if (this.previewScrollMax > 0 && isOverPreviewScrollbar(mouseX, mouseY)) {
                int thumbY = previewScrollbarThumbY();
                int thumbHeight = previewScrollbarThumbHeight();
                this.previewScrollbarDragging = true;
                this.previewScrollbarDragOffset = mouseY >= thumbY && mouseY <= thumbY + thumbHeight ? (int) mouseY - thumbY : thumbHeight / 2;
                setPreviewScrollFromThumbTop((int) mouseY - this.previewScrollbarDragOffset);
                return true;
            }
            if (this.previewUpdateChipWidth > 0 && isWithinInstalledFilter(mouseX, mouseY, this.previewUpdateChipX, this.previewUpdateChipY, this.previewUpdateChipWidth, 11)) {
                openSelectedPackRemotePage();
                return true;
            }
        }

        return super.method_25402(mouseX, mouseY, button);
    }

    @Override
    public boolean method_25403(double mouseX, double mouseY, int button, double deltaX, double deltaY) {
        if (button == 0 && this.previewScrollbarDragging) {
            setPreviewScrollFromThumbTop((int) mouseY - this.previewScrollbarDragOffset);
            return true;
        }
        return super.method_25403(mouseX, mouseY, button, deltaX, deltaY);
    }

    @Override
    public boolean method_25406(double mouseX, double mouseY, int button) {
        if (button == 0 && this.previewScrollbarDragging) {
            this.previewScrollbarDragging = false;
            return true;
        }
        return super.method_25406(mouseX, mouseY, button);
    }

    private void renderPackDetails(class_332 context, class_5369.class_5371 pack, int x, int y) {
        this.previewTooltipRegions.clear();
        String packName = pack.method_29650().getString();
        String packId = pack.method_48276();
        boolean disabled = !pack.method_29660();
        LocalPackInsight localInsight = inspectLocalPack(pack);
        RemotePackPreviewData remoteData = getOrFetchRemotePreview(pack);
        String providerName = remoteData != null && remoteData.found() ? remoteData.provider() : this.previewSourceMode == PreviewSourceMode.LOCAL ? "Local" : "Auto";

        int panelWidth = Math.max(220, this.field_22789 - x - 8);
        int panelHeight = Math.max(120, (this.field_22790 - 60) - y);
        int bannerHeight = 82;
        this.previewSourceChipWidth = Math.max(56, this.field_22793.method_1727("Source " + providerName) + 12);
        this.previewSourceChipX = x + panelWidth - this.previewSourceChipWidth - 10;
        this.previewSourceChipY = y + 5;

        context.method_25294(x, y, x + panelWidth, y + panelHeight, new Color(uiColorContentBase, true).getRGB());
        context.method_49601(x, y, panelWidth, panelHeight, new Color(uiColorBackgroundBorder, true).getRGB());
        context.method_25294(x, y, x + 2, y + panelHeight, new Color(uiColorContentStripeLeft, true).getRGB());
        context.method_25294(x + panelWidth - 2, y, x + panelWidth, y + panelHeight, new Color(uiColorContentStripeRight, true).getRGB());
        renderPreviewSourceChip(context);

        int overlayY = y + 10;
        class_2960 icon = pack.method_30286();
        if (icon != null) {
            context.method_25290(icon, x + 10, overlayY, 0, 0, 64, 64, 64, 64);
        }

        context.method_51448().method_22903();
        context.method_51448().method_22905(1.5F, 1.5F, 1.0F);
        context.method_51433(this.field_22793, packName, (int) (x / 1.5F) + 54, (int) (overlayY / 1.5F), new Color(uiColorContentBaseTitleText, true).getRGB(), true);
        context.method_51448().method_22909();

        int chipX = x + 80;
        this.previewUpdateChipX = -1;
        this.previewUpdateChipY = -1;
        this.previewUpdateChipWidth = 0;
        int detailChipY = overlayY + 15;
        chipX = renderDetailChip(context, chipX, detailChipY, disabled ? "Disabled" : "Enabled", disabled ? 0x8A5A3B3B : 0x8A314E39,
                List.of(
                        class_2561.method_43470("State").method_27694(style -> style.method_36139(0xFF96A9BC)),
                        class_2561.method_43470(disabled ? "Disabled" : "Enabled").method_27694(style -> style.method_36139(disabled ? 0xFFD48E8E : 0xFF8ED4A8)),
                        class_2561.method_43470(disabled ? "This local " + packSingularSpacedLabel().toLowerCase(Locale.ROOT) + " is available but not active." : "This local " + packSingularSpacedLabel().toLowerCase(Locale.ROOT) + " is active in the current order.").method_27694(style -> style.method_36139(0xFFE6EDF5))
                ));
        if (remoteData != null && remoteData.found()) {
            chipX = renderDetailChip(context, chipX + 4, detailChipY, remoteData.exactVersion() ? "Exact Match" : "Closest Match", remoteData.exactVersion() ? 0x8A33465C : 0x8A5A4B33,
                    List.of(
                            class_2561.method_43470(remoteData.exactVersion() ? "Exact Match" : "Closest Match").method_27694(style -> style.method_36139(remoteData.exactVersion() ? 0xFF8ED4A8 : 0xFFD9C48F)),
                            class_2561.method_43470(blankFallback(remoteData.provider(), "Remote")).method_27694(style -> style.method_36139("Modrinth".equalsIgnoreCase(remoteData.provider()) ? 0xFF1BD96A : 0xFF8FC5FF)),
                            class_2561.method_43470(remoteData.exactVersion() ? "Remote version data matches this installed " + packSingularSpacedLabel().toLowerCase(Locale.ROOT) + " directly." : "Found the nearest matching remote version data for this " + packSingularSpacedLabel().toLowerCase(Locale.ROOT) + ".").method_27694(style -> style.method_36139(0xFFE6EDF5))
                    ));
            if (remoteData.approximateProject()) {
                chipX = renderDetailChip(context, chipX + 4, detailChipY, "Closest Project", 0x8A5A4B33,
                        List.of(
                                class_2561.method_43470("Closest Project").method_27694(style -> style.method_36139(0xFFD9C48F)),
                                class_2561.method_43470(blankFallback(remoteData.projectSlug(), "unknown project")).method_27694(style -> style.method_36139(0xFF8FC5FF)),
                                class_2561.method_43470("The remote project title or id was matched as closely as possible instead of exactly.").method_27694(style -> style.method_36139(0xFFE6EDF5))
                        ));
            }
            if (remoteData.updateAvailable()) {
                this.previewUpdateChipX = chipX + 4;
                this.previewUpdateChipY = detailChipY;
                this.previewUpdateChipWidth = this.field_22793.method_1727("Update Available") + 10;
                chipX = renderDetailChip(context, chipX + 4, detailChipY, "Update Available", 0x8A38543F,
                        List.of(
                                class_2561.method_43470("Update Available").method_27694(style -> style.method_36139(0xFF9BDEAE)),
                                class_2561.method_43470("A compatible remote version appears newer than the local pack version.").method_27694(style -> style.method_36139(0xFFE6EDF5)),
                                class_2561.method_43470("Click to open provider page.").method_27694(style -> style.method_36139(0xFF8FC5FF))
                        ));
            }
        }

        context.method_51433(this.field_22793, "Pack ID", x + 80, overlayY + 33, uiColorBasicSubtitleText, false);
        context.method_51433(this.field_22793, fitDetailsText(packId, 188), x + 122, overlayY + 33, 0xFFD8DFE9, false);
        context.method_51433(this.field_22793, "Version", x + 80, overlayY + 44, uiColorBasicSubtitleText, false);
        String localVersion = blankFallback(localInsight.packFormat(), "unknown");
        String remoteVersion = remoteData != null && remoteData.found() ? blankFallback(remoteData.versionNumber(), blankFallback(remoteData.versionTitle(), "unknown")) : "";
        String versionLabel = remoteVersion.isBlank() ? localVersion : localVersion + "  ->  " + remoteVersion;
        this.previewVersionX = x + 122;
        this.previewVersionY = overlayY + 44;
        this.previewVersionWidth = this.field_22793.method_1727(versionLabel);
        this.previewVersionSplitX = remoteVersion.isBlank() ? -1 : this.previewVersionX + this.field_22793.method_1727(localVersion + "  ->");
        context.method_51433(this.field_22793, versionLabel, this.previewVersionX, this.previewVersionY, 0xFFE9DFC9, false);
        context.method_51433(this.field_22793, "Author", x + 80, overlayY + 55, uiColorBasicSubtitleText, false);
        String previewAuthor = remoteData != null && remoteData.found() ? blankFallback(remoteData.authorName(), "Unknown") : "Unknown";
        context.method_51433(this.field_22793, fitDetailsText(previewAuthor, 188), x + 122, overlayY + 55, 0xFFD8DFE9, false);

        int tagsY = overlayY + 66;
        int tagX = x + 80;
        if (remoteData != null && remoteData.found() && remoteData.categories() != null) {
            Set<String> seenTags = new LinkedHashSet<>();
            for (String rawCategory : remoteData.categories()) {
                String category = sanitizePreviewTag(rawCategory);
                if (category.isBlank() || isGenericPackTag(category) || !seenTags.add(category.toLowerCase(Locale.ROOT))) {
                    continue;
                }
                int chipWidth = this.field_22793.method_1727(category) + 10;
                if (tagX + chipWidth > x + panelWidth - 12) {
                    break;
                }
                tagX = renderDetailChip(context, tagX, tagsY, category, getPreviewTagBackground(category), buildPreviewTagTooltip(category)) + 4;
            }
        }

        int detailsViewportY = overlayY + 82;
        int detailsViewportHeight = Math.max(70, panelHeight - (detailsViewportY - y) - 8);
        this.previewViewportX = x + 8;
        this.previewViewportY = detailsViewportY;
        this.previewViewportWidth = panelWidth - 16;
        this.previewViewportHeight = detailsViewportHeight;
        context.method_44379(this.previewViewportX, this.previewViewportY, this.previewViewportX + this.previewViewportWidth, this.previewViewportY + this.previewViewportHeight);

        int contentY = detailsViewportY - this.previewScrollOffset;
        int contentHeight = 0;
        String previewDescription = remoteData != null && remoteData.found() && remoteData.body() != null && !remoteData.body().isBlank()
                ? remoteData.body()
                : remoteData != null && remoteData.found() && remoteData.projectDescription() != null && !remoteData.projectDescription().isBlank()
                ? remoteData.projectDescription()
                : pack.method_29651().getString();

        renderSectionRule(context, x + 8, x + panelWidth - 8, contentY, "Remote Data");
        contentY += 14;
        contentHeight += 14;
        if (remoteData != null && remoteData.found()) {
            int nextY = renderPreviewInfoLine(context, x + 10, contentY, panelWidth, "Provider", blankFallback(remoteData.provider(), "Modrinth"), 0xFF76E6A0);
            contentHeight += nextY - contentY;
            contentY = nextY;
            nextY = renderPreviewInfoLine(context, x + 10, contentY, panelWidth, "Sides", blankFallback(remoteData.clientSide(), "unknown") + " client  |  " + blankFallback(remoteData.serverSide(), "unknown") + " server", 0xFFD7E2EF);
            contentHeight += nextY - contentY;
            contentY = nextY;
            nextY = renderPreviewInfoLine(context, x + 10, contentY, panelWidth, "Targets", formatTargets(remoteData), 0xFFD6E5DA);
            contentHeight += nextY - contentY;
            contentY = nextY;
            nextY = renderPreviewInfoLine(context, x + 10, contentY, panelWidth, "Type", blankFallback(remoteData.projectType(), packTypeId()), 0xFFDCE4EE);
            contentHeight += nextY - contentY;
            contentY = nextY;
            nextY = renderPreviewInfoLine(context, x + 10, contentY, panelWidth, "License", blankFallback(remoteData.licenseName(), "unknown"), 0xFFE4DAC8);
            contentHeight += nextY - contentY;
            contentY = nextY;
            nextY = renderPreviewInfoLine(context, x + 10, contentY, panelWidth, "Loader", blankFallback(remoteData.loaderRequirement(), "not required"), 0xFFD6E5DA);
            contentHeight += nextY - contentY;
            contentY = nextY;
            nextY = renderPreviewInfoLine(context, x + 10, contentY, panelWidth, "Downloads", blankFallback(remoteData.downloads(), "0"), 0xFFDDE5EF);
            contentHeight += nextY - contentY;
            contentY = nextY;
            nextY = renderPreviewInfoLine(context, x + 10, contentY, panelWidth, "Followers", blankFallback(remoteData.followers(), "0"), 0xFFD7DDF0);
            contentHeight += nextY - contentY;
            contentY = nextY;
            nextY = renderPreviewInfoLine(context, x + 10, contentY, panelWidth, "Links", formatLinks(remoteData), 0xFFD3E3DE);
            contentHeight += nextY - contentY;
            contentY = nextY;
            nextY = renderPreviewInfoLine(context, x + 10, contentY, panelWidth, "Dates", formatDates(remoteData), 0xFFD9D5E8);
            contentHeight += nextY - contentY;
            contentY = nextY;
            nextY = renderPreviewInfoLine(context, x + 10, contentY, panelWidth, "Project", blankFallback(remoteData.projectTitle(), packName) + "  |  " + blankFallback(remoteData.projectSlug(), "unknown"), 0xFFF2F4F7);
            contentHeight += nextY - contentY;
            contentY = nextY;
            nextY = renderPreviewInfoLine(context, x + 10, contentY, panelWidth, "Author", blankFallback(remoteData.authorName(), "unknown"), 0xFFD8E7DE);
            contentHeight += nextY - contentY;
            contentY = nextY;
            nextY = renderPreviewInfoLine(context, x + 10, contentY, panelWidth, "Version", blankFallback(remoteData.versionTitle(), blankFallback(remoteData.versionSummary(), remoteData.versionNumber())), 0xFFDCE4EE);
            contentHeight += nextY - contentY;
            contentY = nextY;
            if (!remoteData.exactVersion()) {
                context.method_51433(this.field_22793, "Closest available version info is being shown for this installed " + packSingularSpacedLabel().toLowerCase(Locale.ROOT) + ".", x + 10, contentY, 0xFFD9C48F, false);
                contentY += this.field_22793.field_2000 + 4;
                contentHeight += this.field_22793.field_2000 + 4;
            }
        } else if (this.remotePreviewLoading.contains(pack.method_48276())) {
            context.method_51433(this.field_22793, "Loading Modrinth metadata...", x + 10, contentY, uiColorContentBaseDescriptionText, false);
            contentY += 16;
            contentHeight += 16;
        } else {
            context.method_51433(this.field_22793, "No Modrinth metadata match was found for this " + packSingularSpacedLabel().toLowerCase(Locale.ROOT) + ".", x + 10, contentY, uiColorContentBaseDescriptionText, false);
            contentY += 16;
            contentHeight += 16;
        }

        renderSectionRule(context, x + 8, x + panelWidth - 8, contentY, "Local Metadata");
        contentY += 14;
        contentHeight += 14;
        int nextY = renderPreviewInfoLine(context, x + 10, contentY, panelWidth, "Type", packTypeId(), 0xFFD5DDE7);
        contentHeight += nextY - contentY;
        contentY = nextY;
        nextY = renderPreviewInfoLine(context, x + 10, contentY, panelWidth, "Environment", "client", 0xFFCCD7E6);
        contentHeight += nextY - contentY;
        contentY = nextY;
        nextY = renderPreviewInfoLine(context, x + 10, contentY, panelWidth, "Metadata File", blankFallback(localInsight.metadataFile(), "unknown"), 0xFFD8DFE9);
        contentHeight += nextY - contentY;
        contentY = nextY;
        nextY = renderPreviewInfoLine(context, x + 10, contentY, panelWidth, "Pack Format", blankFallback(localInsight.packFormat(), "unknown"), 0xFFE5D9C2);
        contentHeight += nextY - contentY;
        contentY = nextY;
        nextY = renderPreviewInfoLine(context, x + 10, contentY, panelWidth, "Supported", blankFallback(localInsight.supportedFormats(), "unknown"), 0xFFD2E0CF);
        contentHeight += nextY - contentY;
        contentY = nextY;
        nextY = renderPreviewInfoLine(context, x + 10, contentY, panelWidth, "Icon Files", String.valueOf(localInsight.iconCount()), 0xFFD8DFE9);
        contentHeight += nextY - contentY;
        contentY = nextY;
        nextY = renderPreviewInfoLine(context, x + 10, contentY, panelWidth, "Package", localInsight.zipped() ? "zip" : "folder", 0xFFD9D4E5);
        contentHeight += nextY - contentY;
        contentY = nextY;
        nextY = renderPreviewInfoLine(context, x + 10, contentY, panelWidth, "Source", blankFallback(String.valueOf(pack.method_29652()), "unknown"), 0xFFC9DDD9);
        contentHeight += nextY - contentY;
        contentY = nextY;
        nextY = renderPreviewInfoLine(context, x + 10, contentY, panelWidth, "State", pack.method_29660() ? "Enabled" : "Disabled", pack.method_29660() ? 0xFF9BDEAE : 0xFFD48E8E);
        contentHeight += nextY - contentY;
        contentY = nextY;

        contentY += 6;
        contentHeight += 6;
        renderSectionRule(context, x + 8, x + panelWidth - 8, contentY, remoteData != null && remoteData.found() ? "Body" : "Local Description");
        contentY += 14;
        contentHeight += 14;
        int descriptionWidth = Math.max(180, panelWidth - 20);
        for (MarkdownPreviewRenderer.Line line : MarkdownPreviewRenderer.wrap(blankFallback(previewDescription, "none"), this.field_22793, descriptionWidth)) {
            int lineHeight = MarkdownPreviewRenderer.renderLine(context, this.field_22793, line, x + 10, contentY);
            contentY += lineHeight;
            contentHeight += lineHeight;
        }

        contentY += 6;
        contentHeight += 6;
        renderSectionRule(context, x + 8, x + panelWidth - 8, contentY, "Local File");
        contentY += 14;
        contentHeight += 14;
        nextY = renderPreviewInfoLine(context, x + 10, contentY, panelWidth, "File", blankFallback(localInsight.fileName(), "unknown"), uiColorContentBaseTitleText);
        contentHeight += nextY - contentY;
        contentY = nextY;
        nextY = renderPreviewInfoLine(context, x + 10, contentY, panelWidth, "Size", localInsight.fileSize() <= 0 ? "unknown" : localInsight.fileSize() + " bytes", 0xFFD8DFE9);
        contentHeight += nextY - contentY;
        contentY = nextY;
        for (MarkdownPreviewRenderer.Line line : MarkdownPreviewRenderer.wrap(blankFallback(localInsight.filePath(), this.packDirectory.toString().replace("\\", "/")), this.field_22793, panelWidth - 20)) {
            int lineHeight = MarkdownPreviewRenderer.renderLine(context, this.field_22793, line, x + 10, contentY);
            contentY += lineHeight;
            contentHeight += lineHeight;
        }

        this.previewScrollMax = Math.max(0, contentHeight - detailsViewportHeight + 4);
        if (this.previewScrollOffset > this.previewScrollMax) {
            this.previewScrollOffset = this.previewScrollMax;
        }
        context.method_44380();
        renderPreviewScrollbar(context);
    }

    private void renderSectionRule(class_332 context, int left, int right, int y, String title) {
        context.method_25294(left, y, right, y + 1, 0x50798596);
        context.method_51433(this.field_22793, title, left + 2, y + 3, 0xFFBFCAD8, false);
    }

    private int renderPreviewInfoLine(class_332 context, int x, int y, int panelWidth, String label, String value, int valueColor) {
        int labelWidth = PREVIEW_INFO_LABEL_WIDTH;
        int valueX = x + labelWidth;
        int valueWidth = Math.max(40, panelWidth - (valueX - x) - 18);
        int lineLeft = x - 2;
        int lineRight = x + panelWidth - 12;

        context.method_25294(lineLeft, y - 2, lineRight, y - 1, 0x20374455);
        context.method_51433(this.field_22793, label, x, y, 0xFF9FB1C4, false);
        context.method_25294(valueX - 7, y - 1, valueX - 6, y + this.field_22793.field_2000 + 1, 0x38465567);

        List<MarkdownPreviewRenderer.Line> lines = MarkdownPreviewRenderer.wrap(blankFallback(value, "none"), this.field_22793, valueWidth);
        int currentY = y;
        for (MarkdownPreviewRenderer.Line line : lines) {
            int lineHeight = MarkdownPreviewRenderer.renderLine(context, this.field_22793, new MarkdownPreviewRenderer.Line(line.rawText(), 0, valueColor, 0, MarkdownPreviewRenderer.Accent.NONE), valueX, currentY);
            currentY += lineHeight;
        }
        int rowBottom = Math.max(y + this.field_22793.field_2000 + PREVIEW_INFO_ROW_PADDING, currentY + 1);
        context.method_25294(lineLeft, rowBottom, lineRight, rowBottom + 1, 0x142C3643);
        return rowBottom + PREVIEW_INFO_ROW_PADDING;
    }


    private String sanitizePreviewTag(String rawTag) {
        if (rawTag == null) {
            return "";
        }
        String tag = rawTag.trim();
        if (tag.isEmpty()) {
            return "";
        }
        if (tag.length() > 48) {
            return "";
        }
        String lower = tag.toLowerCase(Locale.ROOT);
        if (lower.equals("unknown") || lower.equals("none") || lower.equals("null") || lower.equals("n/a")) {
            return "";
        }
        if (lower.contains(".class") || lower.contains(".java") || lower.contains(".jar") || lower.contains(".zip")) {
            return "";
        }
        if (lower.matches(".*\\.(class|java|jar|zip|png|jpg|jpeg|gif|webp|json|json5|toml|yml|yaml|txt|md|properties|cfg|conf)$")) {
            return "";
        }
        if (tag.contains("/") || tag.contains("\\") || tag.contains(":") || tag.contains("{") || tag.contains("}") || tag.contains("[") || tag.contains("]")) {
            return "";
        }
        if (tag.matches(".*\\s{2,}.*")) {
            return "";
        }
        if (tag.matches("(?:[A-Za-z_$][\\\\w$]*\\\\.){2,}[A-Za-z_$][\\\\w$]*")) {
            return "";
        }
        if (tag.matches("^[A-Za-z_$][\\w$]*\\.[A-Za-z_$][\\w$]*$") && lower.contains("class")) {
            return "";
        }
        return tag;
    }

    private boolean isGenericPackTag(String tag) {
        String normalized = tag == null ? "" : tag.toLowerCase(Locale.ROOT).replace('-', ' ').replace('_', ' ').replaceAll("\\s+", " ").trim();
        if (normalized.equals("pack")) {
            return true;
        }
        if (this.datapackMode) {
            return normalized.equals("data pack") || normalized.equals("datapack");
        }
        return normalized.equals("resource pack") || normalized.equals("resourcepack");
    }

    private int getPreviewTagBackground(String tag) {
        String lower = tag.toLowerCase(Locale.ROOT);
        if (lower.contains("vanilla") || lower.contains("default")) {
            return 0x8A41513A;
        }
        if (lower.contains("faithful") || lower.contains("classic")) {
            return 0x8A33465C;
        }
        if (lower.contains("dark") || lower.contains("night")) {
            return 0x8A4A3B55;
        }
        if (lower.contains("medieval") || lower.contains("fantasy") || lower.contains("rpg")) {
            return 0x8A5A4B33;
        }
        if (lower.contains("pvp") || lower.contains("utility") || lower.contains("ui")) {
            return 0x8A38543F;
        }
        return 0x8A33465C;
    }

    private int getPreviewTagAccentColor(String tag) {
        String lower = tag.toLowerCase(Locale.ROOT);
        if (lower.contains("vanilla") || lower.contains("default")) {
            return 0xFFB9D49A;
        }
        if (lower.contains("faithful") || lower.contains("classic")) {
            return 0xFF8FC5FF;
        }
        if (lower.contains("dark") || lower.contains("night")) {
            return 0xFFD5B6FF;
        }
        if (lower.contains("medieval") || lower.contains("fantasy") || lower.contains("rpg")) {
            return 0xFFD9C48F;
        }
        if (lower.contains("pvp") || lower.contains("utility") || lower.contains("ui")) {
            return 0xFF9BDEAE;
        }
        return 0xFF8FC5FF;
    }

    private List<class_2561> buildPreviewTagTooltip(String tag) {
        int accent = getPreviewTagAccentColor(tag);
        return List.of(
                class_2561.method_43470("Category").method_27694(style -> style.method_36139(0xFF96A9BC)),
                class_2561.method_43470(tag).method_27694(style -> style.method_36139(accent)),
                class_2561.method_43470("Remote provider category tag used to describe this resource pack's purpose or style.").method_27694(style -> style.method_36139(0xFFE6EDF5))
        );
    }

    private int renderDetailChip(class_332 context, int x, int y, String label, int background, List<class_2561> tooltipLines) {
        int width = this.field_22793.method_1727(label) + 10;
        context.method_25294(x, y, x + width, y + 11, background);
        context.method_49601(x, y, width, 11, 0xB06B7485);
        context.method_51433(this.field_22793, label, x + 5, y + 2, 0xFFE8EDF5, false);
        if (tooltipLines != null && !tooltipLines.isEmpty()) {
            this.previewTooltipRegions.add(new PreviewTooltipRegion(x, y, width, 11, tooltipLines));
        }
        return x + width;
    }

    private void renderPreviewSourceChip(class_332 context) {
        String chipLabel = this.selectedPack != null && this.previewSourceMode != PreviewSourceMode.LOCAL ? blankFallback(getOrFetchRemotePreview(this.selectedPack) != null ? getOrFetchRemotePreview(this.selectedPack).provider() : this.previewSourceMode.label, this.previewSourceMode.label) : this.previewSourceMode.label;
        context.method_25294(this.previewSourceChipX - 4, this.previewSourceChipY - 3, this.previewSourceChipX + this.previewSourceChipWidth, this.previewSourceChipY + 10, 0x27333D49);
        context.method_49601(this.previewSourceChipX - 4, this.previewSourceChipY - 3, this.previewSourceChipWidth + 4, 13, 0x8E6A7684);
        context.method_51433(this.field_22793, "Source " + chipLabel, this.previewSourceChipX, this.previewSourceChipY, 0xFFD5DEE8, false);
    }

    private void renderPreviewScrollbar(class_332 context) {
        if (this.previewScrollMax <= 0 || this.previewViewportHeight <= 0) {
            return;
        }
        int trackX = this.previewViewportX + this.previewViewportWidth - 4;
        context.method_25294(trackX, this.previewViewportY, trackX + 2, this.previewViewportY + this.previewViewportHeight, 0x2E67727F);
        int thumbHeight = Math.max(18, (int) ((this.previewViewportHeight / (float) (this.previewViewportHeight + this.previewScrollMax)) * this.previewViewportHeight));
        int thumbTravel = Math.max(1, this.previewViewportHeight - thumbHeight);
        int thumbY = this.previewViewportY + (int) ((this.previewScrollOffset / (float) this.previewScrollMax) * thumbTravel);
        context.method_25294(trackX - 1, thumbY, trackX + 3, thumbY + thumbHeight, 0x9AA9B9CA);
    }

    private boolean isOverPreviewScrollbar(double mouseX, double mouseY) {
        int trackX = this.previewViewportX + this.previewViewportWidth - 4;
        return mouseX >= trackX - 4
                && mouseX <= trackX + 8
                && mouseY >= this.previewViewportY
                && mouseY <= this.previewViewportY + this.previewViewportHeight;
    }

    private int previewScrollbarThumbHeight() {
        return Math.max(18, (int) ((this.previewViewportHeight / (float) (this.previewViewportHeight + this.previewScrollMax)) * this.previewViewportHeight));
    }

    private int previewScrollbarThumbY() {
        int thumbTravel = Math.max(1, this.previewViewportHeight - previewScrollbarThumbHeight());
        return this.previewViewportY + (int) ((this.previewScrollOffset / (float) this.previewScrollMax) * thumbTravel);
    }

    private void setPreviewScrollFromThumbTop(int thumbTop) {
        int thumbHeight = previewScrollbarThumbHeight();
        int minTop = this.previewViewportY;
        int maxTop = this.previewViewportY + this.previewViewportHeight - thumbHeight;
        int clampedTop = Math.max(minTop, Math.min(maxTop, thumbTop));
        int travel = Math.max(1, maxTop - minTop);
        float ratio = (clampedTop - minTop) / (float) travel;
        this.previewScrollOffset = Math.max(0, Math.min(this.previewScrollMax, Math.round(ratio * this.previewScrollMax)));
    }

    private void renderPreviewHoverTooltip(class_332 context, int mouseX, int mouseY) {
        if (MarkdownPreviewRenderer.renderLinkTooltip(context, this.field_22793, mouseX, mouseY)) {
            return;
        }
        for (PreviewTooltipRegion region : this.previewTooltipRegions) {
            if (mouseX >= region.x() && mouseX <= region.x() + region.width() && mouseY >= region.y() && mouseY <= region.y() + region.height()) {
                context.method_51434(this.field_22793, region.lines(), mouseX, mouseY);
                return;
            }
        }
        if (isWithinInstalledFilter(mouseX, mouseY, this.previewSourceChipX, this.previewSourceChipY, this.previewSourceChipWidth, 10)) {
            context.method_51434(this.field_22793, List.of(
                    class_2561.method_43470("Source").method_27694(style -> style.method_36139(0xFF96A9BC)),
                    class_2561.method_43470(switch (this.previewSourceMode) {
                        case AUTO -> "Best available match";
                        case MODRINTH -> "Remote provider data";
                        case LOCAL -> "Local pack metadata only";
                    }).method_27694(style -> style.method_36139(0xFFE6EDF5))
            ), mouseX, mouseY);
            return;
        }
        if (mouseX >= this.previewVersionX && mouseX <= this.previewVersionX + this.previewVersionWidth && mouseY >= this.previewVersionY && mouseY <= this.previewVersionY + this.field_22793.field_2000) {
            List<class_2561> lines = new ArrayList<>();
            if (this.previewVersionSplitX > 0 && mouseX >= this.previewVersionSplitX) {
                lines.add(class_2561.method_43470("Source").method_27694(style -> style.method_36139(0xFF96A9BC)));
                String provider = this.selectedPack != null && getOrFetchRemotePreview(this.selectedPack) != null ? getOrFetchRemotePreview(this.selectedPack).provider() : this.previewSourceMode.label;
                lines.add(class_2561.method_43470(provider).method_27694(style -> style.method_36139(0xFFE6EDF5)));
            } else {
                lines.add(class_2561.method_43470("Source").method_27694(style -> style.method_36139(0xFF96A9BC)));
                lines.add(class_2561.method_43470("Local").method_27694(style -> style.method_36139(0xFFE6EDF5)));
            }
            context.method_51434(this.field_22793, lines, mouseX, mouseY);
            return;
        }
        if (this.previewUpdateChipWidth > 0 && mouseX >= this.previewUpdateChipX && mouseX <= this.previewUpdateChipX + this.previewUpdateChipWidth && mouseY >= this.previewUpdateChipY && mouseY <= this.previewUpdateChipY + 11) {
            context.method_51434(this.field_22793, List.of(
                    class_2561.method_43470("Open Project Page").method_27694(style -> style.method_36139(0xFF96A9BC)),
                    class_2561.method_43470("Jump to the remote project for this resource pack").method_27694(style -> style.method_36139(0xFF76E6A0))
            ), mouseX, mouseY);
        }
    }

    private String formatTargets(RemotePackPreviewData data) {
        String versionPart = data.gameVersions() == null || data.gameVersions().isEmpty() ? "versions unknown" : String.join(", ", data.gameVersions().subList(0, Math.min(3, data.gameVersions().size())));
        return packTypeId() + "  |  " + versionPart + "  |  " + data.versionCount() + " version" + (data.versionCount() == 1 ? "" : "s");
    }

    private String formatLinks(RemotePackPreviewData data) {
        List<String> links = new ArrayList<>();
        if (data.sourceUrl() != null && !data.sourceUrl().isBlank()) {
            links.add("source");
        }
        if (data.issuesUrl() != null && !data.issuesUrl().isBlank()) {
            links.add("issues");
        }
        if (data.wikiUrl() != null && !data.wikiUrl().isBlank()) {
            links.add("wiki");
        }
        if (data.discordUrl() != null && !data.discordUrl().isBlank()) {
            links.add("discord");
        }
        return links.isEmpty() ? "no public links" : String.join("  |  ", links);
    }

    private String formatDates(RemotePackPreviewData data) {
        String published = blankFallback(shortIsoDate(data.publishedAt()), "unknown");
        String updated = blankFallback(shortIsoDate(data.updatedAt()), "unknown");
        return "Published " + published + "  |  Updated " + updated;
    }

    private String shortIsoDate(String raw) {
        if (raw == null || raw.isBlank()) {
            return "";
        }
        return raw.length() >= 10 ? raw.substring(0, 10) : raw;
    }

    private void openSelectedPackRemotePage() {
        if (this.selectedPack == null) {
            return;
        }
        RemotePackPreviewData data = getOrFetchRemotePreview(this.selectedPack);
        if (data != null && data.found() && data.projectSlug() != null && !data.projectSlug().isBlank()) {
            UiSoundHelper.playButtonClick();
            class_156.method_668().method_670("https://modrinth.com/" + packRemotePath() + "/" + data.projectSlug());
            return;
        }
        String query = this.selectedPack.method_29650().getString();
        if (query.isBlank()) {
            query = this.selectedPack.method_48276();
        }
        UiSoundHelper.playButtonClick();
        class_156.method_668().method_670("https://modrinth.com/" + packRemoteSearchPath() + "?q=" + URLEncoder.encode(query, StandardCharsets.UTF_8));
    }

    private void openImportResourcepackChooser() {
        String chosenPath = TinyFileDialogs.tinyfd_openFileDialog("Import " + packSingularLabel(), this.packDirectory.toAbsolutePath().toString(), null, null, false);
        if (chosenPath == null || chosenPath.isBlank()) {
            return;
        }
        Path source = Path.of(chosenPath);
        try {
            Files.createDirectories(this.packDirectory);
            Path target = this.packDirectory.resolve(source.getFileName());
            Files.copy(source, target, StandardCopyOption.REPLACE_EXISTING);
            refreshOrganizerWithoutReloadMark();
            rebuildInstalledPackList();
            markReloadRequired();
        } catch (IOException ignored) {
        }
    }

    private void deleteSelectedPack() {
        if (this.selectedPack == null) {
            return;
        }
        if (this.selectedPack.method_29655()) {
            return;
        }
        String deletedPackName = this.selectedPack.method_48276();
        Path selectedPath = resolvePackPath(this.selectedPack);
        boolean deleted = false;
        if (selectedPath != null) {
            if (this.selectedPack.method_29660() && this.selectedPack.method_29662()) {
                ensureOrganizerCallbackPatched();
                this.selectedPack.method_29657();
                this.organizer.method_29642();
            }
            FileUtils.deleteQuietly(selectedPath.toFile());
            deleted = !Files.exists(selectedPath);
        }
        refreshOrganizerWithoutReloadMark();
        if (deleted && this.selectedPack != null && deletedPackName.equals(this.selectedPack.method_48276())) {
            this.selectedPack = null;
        }
        rebuildInstalledPackList();
        if (deleted) {
            markReloadRequired();
        } else {
            packSelected(this.selectedPack != null);
        }
    }

    private void confirmDeleteSelectedPack() {
        if (this.selectedPack == null || this.selectedPack.method_29655()) {
            return;
        }
        Path selectedPath = resolvePackPath(this.selectedPack);
        if (selectedPath == null) {
            packSelected(this.selectedPack != null);
            return;
        }
        String packName = this.selectedPack.method_48276();
        if (this.field_22787 == null) {
            deleteSelectedPack();
            return;
        }
        this.field_22787.method_1507(new class_410(confirmed -> {
            if (confirmed) {
                deleteSelectedPack();
            }
            if (this.field_22787 != null) {
                this.field_22787.method_1507(this);
            }
        }, class_2561.method_43470("Delete " + packSingularSpacedLabel()), class_2561.method_43470("Are you sure you want to delete " + packName + "?"), class_2561.method_43470("Delete"), class_2561.method_43470("Cancel")));
    }

    private void toggleSelectedPack() {
        if (this.selectedPack == null) {
            return;
        }
        String selectedName = this.selectedPack.method_48276();
        ensureOrganizerCallbackPatched();
        boolean toggled = false;
        try {
            if (this.selectedPack.method_29660()) {
                if (!this.selectedPack.method_29662()) {
                    return;
                }
                this.selectedPack.method_29657();
            } else {
                if (!this.selectedPack.method_29661()) {
                    return;
                }
                this.selectedPack.method_29656();
            }
            toggled = true;
        } catch (NullPointerException ignored) {
            toggled = forceToggleSelectedPack(this.selectedPack);
        } catch (RuntimeException ignored) {
            toggled = forceToggleSelectedPack(this.selectedPack);
        }
        if (!toggled) {
            refreshOrganizerWithoutReloadMark();
            rebuildInstalledPackList();
            this.packSelected(this.selectedPack != null);
            return;
        }
        this.organizer.method_29642();
        refreshOrganizerWithoutReloadMark();
        rebuildInstalledPackList();
        markReloadRequired();
        class_5369.class_5371 refreshedSelection = allPacks().stream()
                .filter(pack -> pack.method_48276().equals(selectedName))
                .findFirst()
                .orElse(null);
        this.selectedPack = refreshedSelection;
        this.packSelected(this.selectedPack != null);
        if (this.selectedPack != null) {
            setSelectedPack(this.selectedPack);
        }
    }

    private boolean forceToggleSelectedPack(class_5369.class_5371 pack) {
        if (pack == null) {
            return false;
        }
        try {
            Object profile = getPackProfile(pack);
            if (profile == null) {
                return false;
            }
            List<?> current = getPackProfileList(pack, "getCurrentList");
            List<?> opposite = getPackProfileList(pack, "getOppositeList");
            if (current == null || opposite == null) {
                return false;
            }
            if (!current.contains(profile)) {
                return false;
            }
            ((List<Object>) current).remove(profile);
            int insertIndex = pack.method_29660() ? opposite.size() : getManualEnableInsertIndex(opposite);
            ((List<Object>) opposite).add(insertIndex, profile);
            return true;
        } catch (Exception ignored) {
            return false;
        }
    }

    private Object getPackProfile(class_5369.class_5371 pack) throws ReflectiveOperationException {
        Class<?> type = pack.getClass();
        while (type != null) {
            try {
                Field field = type.getDeclaredField("profile");
                field.setAccessible(true);
                return field.get(pack);
            } catch (NoSuchFieldException ignored) {
                type = type.getSuperclass();
            }
        }
        return null;
    }

    @SuppressWarnings("unchecked")
    private List<?> getPackProfileList(class_5369.class_5371 pack, String methodName) throws ReflectiveOperationException {
        Class<?> type = pack.getClass();
        while (type != null) {
            try {
                java.lang.reflect.Method method = type.getDeclaredMethod(methodName);
                method.setAccessible(true);
                Object value = method.invoke(pack);
                return value instanceof List<?> list ? list : null;
            } catch (NoSuchMethodException ignored) {
                type = type.getSuperclass();
            }
        }
        return null;
    }

    private int getManualEnableInsertIndex(List<?> enabledProfiles) {
        int index = 0;
        for (Object profile : enabledProfiles) {
            if (!isPinnedProfile(profile)) {
                break;
            }
            index++;
        }
        return index;
    }

    private boolean isPinnedProfile(Object profile) {
        if (profile == null) {
            return false;
        }
        try {
            java.lang.reflect.Method method = profile.getClass().getMethod("isPinned");
            Object value = method.invoke(profile);
            return value instanceof Boolean bool && bool;
        } catch (Exception ignored) {
            return false;
        }
    }

    private void ensureOrganizerCallbackPatched() {
        if (this.organizerCallbackPatched) {
            return;
        }
        try {
            Field field = class_5369.class.getDeclaredField("updateCallback");
            field.setAccessible(true);
            field.set(this.organizer, (Runnable) () -> {
                if (!this.suppressOrganizerReloadCallback) {
                    markReloadRequired();
                }
            });
            this.organizerCallbackPatched = true;
        } catch (Exception ignored) {
        }
    }

    private void refreshOrganizerWithoutReloadMark() {
        this.suppressOrganizerReloadCallback = true;
        try {
            this.organizer.method_29981();
        } finally {
            this.suppressOrganizerReloadCallback = false;
        }
    }

    @Override
    public void method_25419() {
        finishAndClose();
    }

    private void reloadScreen() {
        if (!this.reloadRequired || this.field_22787 == null) {
            return;
        }
        this.organizer.method_29642();
        refreshOrganizerWithoutReloadMark();
        this.remotePreviewCache.clear();
        this.remotePreviewLoading.clear();
        this.previewScrollOffset = 0;
        this.previewScrollMax = 0;
        this.reloadRequired = false;
        this.initialEnabledPackNames = currentEnabledPackNames();
        rebuildInstalledPackList();
        packSelected(this.selectedPack != null);
    }

    private void markReloadRequired() {
        this.reloadRequired = true;
        packSelected(this.selectedPack != null);
    }

    private void updateReloadRequiredFromOrganizerState() {
        if (!this.reloadRequired && !this.initialEnabledPackNames.isEmpty() && !this.initialEnabledPackNames.equals(currentEnabledPackNames())) {
            this.reloadRequired = true;
        }
    }

    private Set<String> currentEnabledPackNames() {
        try {
            return this.organizer.method_29643()
                    .map(class_5369.class_5371::method_48276)
                    .collect(java.util.stream.Collectors.toCollection(LinkedHashSet::new));
        } catch (Exception ignored) {
            return Set.of();
        }
    }

    private void finishAndClose() {
        if (this.bridge != null) {
            this.bridge.method_25419();
        }
    }

    private String getSortButtonLabel() {
        return "Sort: " + this.installedSortMode.label;
    }

    private String getShowButtonLabel() {
        return "Show: " + this.installedFilterMode.label;
    }

    private String getGroupButtonLabel() {
        return "Group: " + this.installedGroupMode.label;
    }

    private int getInstalledFilterWidth(String label) {
        return Math.max(72, this.field_22793.method_1727(label) + 18);
    }

    private void renderInstalledFilterButton(class_332 context, int x, String label) {
        int width = getInstalledFilterWidth(label);
        context.method_25294(x, INSTALLED_FILTER_Y, x + width, INSTALLED_FILTER_Y + INSTALLED_FILTER_HEIGHT, new Color(uiColorContentBase, true).getRGB());
        context.method_49601(x, INSTALLED_FILTER_Y, width, INSTALLED_FILTER_HEIGHT, new Color(uiColorBackgroundBorder, true).getRGB());
        context.method_51433(this.field_22793, label, x + 7, INSTALLED_FILTER_Y + 6, new Color(uiColorContentBaseTitleText, true).getRGB(), false);
    }

    private boolean isWithinInstalledFilter(double mouseX, double mouseY, int x, int y, int width, int height) {
        return mouseX >= x && mouseX <= x + width && mouseY >= y && mouseY <= y + height;
    }

    private void openInstalledFilterMenu(double mouseX, double mouseY, List<PopupMenu.MenuEntry> entries) {
        this.installedFilterPopup.openAtPointer(mouseX, mouseY, this.field_22789, this.field_22790, entries);
    }

    private List<PopupMenu.MenuEntry> buildPreviewSourceEntries() {
        return List.of(
                new PopupMenu.MenuEntry("source:AUTO", "Auto"),
                new PopupMenu.MenuEntry("source:MODRINTH", "Modrinth"),
                new PopupMenu.MenuEntry("source:LOCAL", "Local")
        );
    }

    private List<PopupMenu.MenuEntry> buildSortEntries() {
        List<PopupMenu.MenuEntry> entries = new ArrayList<>();
        for (InstalledSortMode mode : InstalledSortMode.values()) {
            if (mode == InstalledSortMode.PICTURE) {
                continue;
            }
            entries.add(new PopupMenu.MenuEntry("sort:" + mode.name(), mode.label));
        }
        return entries;
    }

    private List<PopupMenu.MenuEntry> buildShowEntries() {
        List<PopupMenu.MenuEntry> entries = new ArrayList<>();
        for (InstalledFilterMode mode : InstalledFilterMode.values()) {
            entries.add(new PopupMenu.MenuEntry("show:" + mode.name(), mode.label));
        }
        entries.add(new PopupMenu.MenuEntry("show_iconless:" + (this.showIconlessPacks ? "hide" : "show"), this.showIconlessPacks ? "Hide No Image Packs" : "Show No Image Packs"));
        return entries;
    }

    private List<PopupMenu.MenuEntry> buildGroupEntries() {
        List<PopupMenu.MenuEntry> entries = new ArrayList<>();
        for (InstalledGroupMode mode : InstalledGroupMode.values()) {
            entries.add(new PopupMenu.MenuEntry("group:" + mode.name(), mode.label));
        }
        return entries;
    }

    private void applyInstalledFilterAction(String actionId) {
        if (actionId == null || actionId.isBlank()) {
            return;
        }
        if (actionId.startsWith("sort:")) {
            this.installedSortMode = InstalledSortMode.valueOf(actionId.substring("sort:".length()));
        } else if (actionId.startsWith("group:")) {
            this.installedGroupMode = InstalledGroupMode.valueOf(actionId.substring("group:".length()));
        } else if (actionId.startsWith("show:")) {
            this.installedFilterMode = InstalledFilterMode.valueOf(actionId.substring("show:".length()));
        } else if (actionId.startsWith("show_iconless:")) {
            this.showIconlessPacks = actionId.endsWith("show");
        }
        rebuildInstalledPackList();
    }

    private void applyPreviewSourceAction(String actionId) {
        if (actionId == null || !actionId.startsWith("source:")) {
            return;
        }
        this.previewSourceMode = PreviewSourceMode.valueOf(actionId.substring("source:".length()));
        if (this.selectedPack != null) {
            this.remotePreviewCache.remove(this.selectedPack.method_48276());
            fetchRemotePreviewIfNeeded(this.selectedPack);
        }
    }

    private List<PopupMenu.MenuEntry> buildPackActionEntries(class_5369.class_5371 pack) {
        return List.of(
                new PopupMenu.MenuEntry("pack_action:folder", "Open " + packPluralLabel() + " Folder"),
                new PopupMenu.MenuEntry("pack_action:copy_id", "Copy Pack ID"),
                new PopupMenu.MenuEntry("pack_action:remote", "Open Provider Page"),
                new PopupMenu.MenuEntry("pack_action:toggle", pack != null && pack.method_29660() ? "Disable Pack" : "Enable Pack")
        );
    }

    private void openPackActionMenu(class_5369.class_5371 pack, double mouseX, double mouseY) {
        this.popupActionPack = pack;
        this.packActionPopup.openAtPointer(mouseX, mouseY, this.field_22789, this.field_22790, buildPackActionEntries(pack));
    }

    private void applyPackAction(String actionId) {
        if (this.field_22787 == null || this.popupActionPack == null || actionId == null) {
            return;
        }
        switch (actionId) {
            case "pack_action:folder" -> openFolderPopupAtPointer(this.packDirectory.toFile());
            case "pack_action:copy_id" -> this.field_22787.field_1774.method_1455(this.popupActionPack.method_48276());
            case "pack_action:remote" -> {
                this.selectedPack = this.popupActionPack;
                openSelectedPackRemotePage();
            }
            case "pack_action:toggle" -> {
                this.selectedPack = this.popupActionPack;
                toggleSelectedPack();
            }
            default -> {
                return;
            }
        }
    }

    private void openFolderPopupAtPointer(File folder) {
        if (folder == null) {
            return;
        }
        this.pendingFolderOpenDirectory = folder;
        this.folderOpenPopup.toggleAtPointer(this.lastMouseX, this.lastMouseY, this.field_22789, this.field_22790, FolderOpenHelper.menuEntries());
    }

    private RemotePackPreviewData getCachedRemotePreview(class_5369.class_5371 pack) {
        if (pack == null) {
            return null;
        }
        return this.remotePreviewCache.get(pack.method_48276());
    }

    private RemotePackPreviewData getOrFetchRemotePreview(class_5369.class_5371 pack) {
        if (pack == null || this.previewSourceMode == PreviewSourceMode.LOCAL) {
            return null;
        }
        RemotePackPreviewData cached = this.remotePreviewCache.get(pack.method_48276());
        if (cached != null) {
            return cached;
        }
        fetchRemotePreviewIfNeeded(pack);
        return null;
    }

    private void fetchRemotePreviewIfNeeded(class_5369.class_5371 pack) {
        if (pack == null || this.previewSourceMode == PreviewSourceMode.LOCAL) {
            return;
        }
        String key = pack.method_48276();
        if (this.remotePreviewCache.containsKey(key) || !this.remotePreviewLoading.add(key)) {
            return;
        }
        Thread thread = new Thread(() -> {
            try {
                this.remotePreviewCache.put(key, fetchRemotePreview(pack));
            } catch (Exception ignored) {
                this.remotePreviewCache.put(key, new RemotePackPreviewData("", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", false, false, 0, List.of(), List.of(), List.of(), false, false, false, false));
            } finally {
                this.remotePreviewLoading.remove(key);
            }
        }, "koil-resourcepack-preview-" + key.replaceAll("[^a-zA-Z0-9._-]", "_"));
        thread.setDaemon(true);
        thread.start();
    }

    private RemotePackPreviewData fetchRemotePreview(class_5369.class_5371 pack) throws Exception {
        return fetchModrinthPreview(pack);
    }

    private RemotePackPreviewData fetchModrinthPreview(class_5369.class_5371 pack) throws Exception {
        List<JsonObject> hits = new ArrayList<>();
        hits.addAll(fetchModrinthHits(pack.method_48276()));
        if (!pack.method_29650().getString().equalsIgnoreCase(pack.method_48276())) {
            hits.addAll(fetchModrinthHits(pack.method_29650().getString()));
        }
        if (hits.isEmpty()) {
            return new RemotePackPreviewData("", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", false, false, 0, List.of(), List.of(), List.of(), false, false, false, false);
        }

        JsonObject chosen = null;
        int bestScore = Integer.MIN_VALUE;
        String packId = pack.method_48276();
        String packName = pack.method_29650().getString();
        for (JsonObject object : hits) {
            int score = scoreSearchHit(object, packId, packName);
            if (score > bestScore) {
                bestScore = score;
                chosen = object;
            }
        }
        boolean approximateProject = bestScore < 100;

        String slug = getString(chosen, "slug");
        URI projectUri = new URI("https://api.modrinth.com/v2/project/" + slug);
        HttpResponse<String> projectResponse = HttpClient.newHttpClient().send(HttpRequest.newBuilder().uri(projectUri).GET().build(), HttpResponse.BodyHandlers.ofString());
        JsonObject project = new Gson().fromJson(projectResponse.body(), JsonObject.class);

        URI versionUri = new URI("https://api.modrinth.com/v2/project/" + slug + "/version");
        HttpResponse<String> versionResponse = HttpClient.newHttpClient().send(HttpRequest.newBuilder().uri(versionUri).GET().build(), HttpResponse.BodyHandlers.ofString());
        JsonArray versions = new Gson().fromJson(versionResponse.body(), JsonArray.class);

        LocalPackInsight localInsight = inspectLocalPack(pack);
        String installedVersion = blankFallback(localInsight.packFormat(), "");
        JsonObject chosenVersion = null;
        boolean exactVersion = false;
        boolean exactGameVersion = false;
        if (versions != null) {
            for (JsonElement element : versions) {
                JsonObject object = element.getAsJsonObject();
                String versionNumber = getString(object, "version_number");
                if (!installedVersion.isBlank() && installedVersion.equalsIgnoreCase(versionNumber)) {
                    chosenVersion = object;
                    exactVersion = true;
                    break;
                }
            }
            if (chosenVersion == null && !versions.isEmpty()) {
                chosenVersion = versions.get(0).getAsJsonObject();
            }
        }

        List<String> categories = new ArrayList<>();
        JsonArray categoryArray = project == null ? null : project.getAsJsonArray("categories");
        if (categoryArray != null) {
            for (JsonElement element : categoryArray) {
                categories.add(element.getAsString());
                if (categories.size() >= 6) {
                    break;
                }
            }
        }

        JsonObject license = project == null || !project.has("license") || !project.get("license").isJsonObject() ? null : project.getAsJsonObject("license");
        List<String> loaders = new ArrayList<>();
        List<String> gameVersions = new ArrayList<>();
        if (chosenVersion != null) {
            JsonArray loaderArray = chosenVersion.getAsJsonArray("loaders");
            if (loaderArray != null) {
                for (JsonElement element : loaderArray) {
                    loaders.add(element.getAsString());
                }
            }
            JsonArray gameVersionArray = chosenVersion.getAsJsonArray("game_versions");
            if (gameVersionArray != null) {
                for (JsonElement element : gameVersionArray) {
                    String gameVersion = element.getAsString();
                    gameVersions.add(gameVersion);
                    if (localInsight.supportedFormats() != null && localInsight.supportedFormats().contains(gameVersion)) {
                        exactGameVersion = true;
                    }
                }
            }
        }

        boolean updateAvailable = chosenVersion != null && !installedVersion.isBlank() && isVersionLower(installedVersion, getString(chosenVersion, "version_number"));
        return new RemotePackPreviewData(
                "Modrinth",
                getString(project == null ? chosen : project, "title"),
                slug,
                getString(project == null ? chosen : project, "description"),
                getString(project, "project_type"),
                getString(license, "name"),
                getString(project, "source_url"),
                getString(project, "issues_url"),
                getString(project, "wiki_url"),
                getString(project, "discord_url"),
                getString(project, "published"),
                getString(project, "updated"),
                getString(project, "team"),
                chosenVersion == null ? "" : getString(chosenVersion, "name"),
                chosenVersion == null ? "" : getString(chosenVersion, "version_number"),
                chosenVersion == null ? "" : getString(chosenVersion, "version_type"),
                getString(project, "body"),
                getString(project == null ? chosen : project, "downloads"),
                getString(project == null ? chosen : project, "followers"),
                getString(project, "client_side"),
                getString(project, "server_side"),
                "not required",
                exactGameVersion,
                true,
                versions == null ? 0 : versions.size(),
                loaders,
                gameVersions,
                categories,
                exactVersion,
                approximateProject,
                updateAvailable,
                true
        );
    }

    private List<JsonObject> fetchModrinthHits(String queryText) throws Exception {
        if (queryText == null || queryText.isBlank()) {
            return List.of();
        }
        String query = URLEncoder.encode(queryText, StandardCharsets.UTF_8);
        URI searchUri = new URI("https://api.modrinth.com/v2/search?query=" + query + "&limit=12&facets=%5B%5B%22project_type%3A" + packTypeId() + "%22%5D%5D");
        HttpResponse<String> searchResponse = HttpClient.newHttpClient().send(HttpRequest.newBuilder().uri(searchUri).GET().build(), HttpResponse.BodyHandlers.ofString());
        JsonObject searchRoot = new Gson().fromJson(searchResponse.body(), JsonObject.class);
        JsonArray hits = searchRoot == null ? null : searchRoot.getAsJsonArray("hits");
        if (hits == null || hits.isEmpty()) {
            return List.of();
        }
        List<JsonObject> results = new ArrayList<>();
        Set<String> seenProjects = new HashSet<>();
        for (JsonElement hit : hits) {
            JsonObject object = hit.getAsJsonObject();
            String projectId = getString(object, "project_id");
            if (seenProjects.add(projectId)) {
                results.add(object);
            }
        }
        return results;
    }

    private int scoreSearchHit(JsonObject object, String packId, String packName) {
        String slug = getString(object, "slug");
        String projectId = getString(object, "project_id");
        String title = getString(object, "title");
        int score = 0;
        if (packId.equalsIgnoreCase(slug)) score += 120;
        if (packId.equalsIgnoreCase(projectId)) score += 110;
        if (packName.equalsIgnoreCase(title)) score += 100;
        if (title.equalsIgnoreCase(packId)) score += 95;
        if (slug.equalsIgnoreCase(packName.replace(" ", "-"))) score += 85;
        if (title.toLowerCase(Locale.ROOT).contains(packName.toLowerCase(Locale.ROOT))) score += 25;
        if (slug.toLowerCase(Locale.ROOT).contains(packId.toLowerCase(Locale.ROOT))) score += 20;
        return score;
    }

    private boolean isVersionLower(String installedVersion, String remoteVersion) {
        if (installedVersion == null || installedVersion.isBlank() || remoteVersion == null || remoteVersion.isBlank()) {
            return false;
        }
        int[] installed = parseVersionSegments(installedVersion);
        int[] remote = parseVersionSegments(remoteVersion);
        int length = Math.max(installed.length, remote.length);
        for (int i = 0; i < length; i++) {
            int left = i < installed.length ? installed[i] : 0;
            int right = i < remote.length ? remote[i] : 0;
            if (left != right) {
                return left < right;
            }
        }
        return false;
    }

    private int[] parseVersionSegments(String version) {
        String[] rawParts = version.replaceAll("[^0-9.]", "").split("\\.");
        return Arrays.stream(rawParts).filter(part -> !part.isBlank()).mapToInt(part -> {
            try {
                return Integer.parseInt(part);
            } catch (NumberFormatException ignored) {
                return 0;
            }
        }).toArray();
    }

    private String getString(JsonObject object, String key) {
        if (object == null || !object.has(key) || object.get(key).isJsonNull()) {
            return "";
        }
        return object.get(key).getAsString();
    }

    private String blankFallback(String value, String fallback) {
        return value == null || value.isBlank() ? fallback : value;
    }

    private String fitDetailsText(String text, int maxWidth) {
        if (text == null) {
            return "";
        }
        String trimmed = this.field_22793.method_27523(text, maxWidth);
        if (trimmed.length() == text.length()) {
            return trimmed;
        }
        return this.field_22793.method_27523(text, Math.max(8, maxWidth - this.field_22793.method_1727("..."))) + "...";
    }

    private Path resolvePackPath(class_5369.class_5371 pack) {
        if (pack == null) {
            return null;
        }
        Set<String> candidates = packPathCandidates(pack);
        for (String candidate : candidates) {
            Path direct = this.packDirectory.resolve(candidate);
            if (Files.exists(direct)) {
                return direct;
            }
            Path zip = this.packDirectory.resolve(candidate + ".zip");
            if (Files.exists(zip)) {
                return zip;
            }
        }
        try {
            if (Files.exists(this.packDirectory)) {
                try (var stream = Files.list(this.packDirectory)) {
                    Optional<Path> match = stream.filter(path -> pathMatchesPack(path, pack, candidates)).findFirst();
                    if (match.isPresent()) {
                        return match.get();
                    }
                }
            }
        } catch (IOException ignored) {
        }
        return null;
    }

    private Set<String> packPathCandidates(class_5369.class_5371 pack) {
        Set<String> candidates = new LinkedHashSet<>();
        addPackPathCandidate(candidates, pack.method_48276());
        addPackPathCandidate(candidates, pack.method_29650().getString());
        addPackPathCandidate(candidates, pack.method_29651().getString());
        String source = String.valueOf(pack.method_29652());
        int slash = Math.max(source.lastIndexOf('/'), source.lastIndexOf('\\'));
        if (slash >= 0 && slash + 1 < source.length()) {
            addPackPathCandidate(candidates, source.substring(slash + 1));
        }
        return candidates;
    }

    private void addPackPathCandidate(Set<String> candidates, String value) {
        if (value == null || value.isBlank()) {
            return;
        }
        String trimmed = value.trim();
        candidates.add(trimmed);
        if (trimmed.endsWith(".zip")) {
            candidates.add(trimmed.substring(0, trimmed.length() - 4));
        }
        String normalized = normalizePackLookup(trimmed);
        if (!normalized.isBlank()) {
            candidates.add(normalized);
        }
    }

    private boolean pathMatchesPack(Path path, class_5369.class_5371 pack, Set<String> candidates) {
        String fileName = path.getFileName().toString();
        String baseName = fileName.endsWith(".zip") ? fileName.substring(0, fileName.length() - 4) : fileName;
        String normalizedFile = normalizePackLookup(baseName);
        for (String candidate : candidates) {
            if (fileName.equalsIgnoreCase(candidate) || baseName.equalsIgnoreCase(candidate) || normalizedFile.equals(normalizePackLookup(candidate))) {
                return true;
            }
        }
        LocalPackDescriptor descriptor = readLocalPackDescriptor(path);
        if (descriptor == null) {
            return false;
        }
        String packName = normalizePackLookup(pack.method_48276());
        String displayName = normalizePackLookup(pack.method_29650().getString());
        String description = normalizePackLookup(pack.method_29651().getString());
        return descriptor.description().equals(packName)
                || descriptor.description().equals(displayName)
                || descriptor.description().equals(description)
                || descriptor.id().equals(packName)
                || descriptor.id().equals(displayName);
    }

    private LocalPackDescriptor readLocalPackDescriptor(Path path) {
        try {
            JsonObject root = null;
            if (Files.isDirectory(path)) {
                Path mcmeta = path.resolve("pack.mcmeta");
                if (Files.exists(mcmeta)) {
                    root = new Gson().fromJson(Files.readString(mcmeta), JsonObject.class);
                }
            } else if (path.getFileName().toString().endsWith(".zip")) {
                try (ZipFile zipFile = new ZipFile(path.toFile())) {
                    ZipEntry mcmeta = zipFile.getEntry("pack.mcmeta");
                    if (mcmeta != null) {
                        try (InputStream input = zipFile.getInputStream(mcmeta)) {
                            root = new Gson().fromJson(new String(input.readAllBytes(), StandardCharsets.UTF_8), JsonObject.class);
                        }
                    }
                }
            }
            JsonObject packObject = root != null && root.has("pack") && root.get("pack").isJsonObject() ? root.getAsJsonObject("pack") : null;
            String description = packObject != null && packObject.has("description") ? normalizePackLookup(packObject.get("description").getAsString()) : "";
            return new LocalPackDescriptor(normalizePackLookup(path.getFileName().toString()), description);
        } catch (Exception ignored) {
            return null;
        }
    }

    private String normalizePackLookup(String value) {
        if (value == null) {
            return "";
        }
        String cleaned = value.replaceAll("(?i)\\.zip$", "").replaceAll("§.", "").toLowerCase(Locale.ROOT);
        return cleaned.replaceAll("[^a-z0-9]+", "");
    }

    private LocalPackInsight inspectLocalPack(class_5369.class_5371 pack) {
        Path path = resolvePackPath(pack);
        String fileName = path == null ? "" : path.getFileName().toString();
        String filePath = path == null ? "" : path.toAbsolutePath().toString().replace("\\", "/");
        long fileSize = 0L;
        boolean zipped = false;
        String metadataFile = "";
        String packFormat = "";
        String supportedFormats = "";
        int iconCount = 0;
        boolean found = false;
        try {
            if (path != null && Files.exists(path)) {
                found = true;
                fileSize = Files.isDirectory(path) ? 0L : Files.size(path);
                zipped = !Files.isDirectory(path);
                if (Files.isDirectory(path)) {
                    Path mcmeta = path.resolve("pack.mcmeta");
                    if (Files.exists(mcmeta)) {
                        metadataFile = "pack.mcmeta";
                        JsonObject root = new Gson().fromJson(Files.readString(mcmeta), JsonObject.class);
                        JsonObject packObject = root != null && root.has("pack") && root.get("pack").isJsonObject() ? root.getAsJsonObject("pack") : null;
                        if (packObject != null) {
                            packFormat = getPackFormatLabel(packObject);
                            supportedFormats = getSupportedFormatsLabel(packObject);
                        }
                    }
                    iconCount = Files.exists(path.resolve("pack.png")) ? 1 : 0;
                } else if (fileName.toLowerCase(Locale.ROOT).endsWith(".zip")) {
                    try (ZipFile zipFile = new ZipFile(path.toFile())) {
                        ZipEntry mcmeta = zipFile.getEntry("pack.mcmeta");
                        if (mcmeta != null) {
                            metadataFile = "pack.mcmeta";
                            try (InputStream inputStream = zipFile.getInputStream(mcmeta)) {
                                JsonObject root = new Gson().fromJson(new String(inputStream.readAllBytes(), StandardCharsets.UTF_8), JsonObject.class);
                                JsonObject packObject = root != null && root.has("pack") && root.get("pack").isJsonObject() ? root.getAsJsonObject("pack") : null;
                                if (packObject != null) {
                                    packFormat = getPackFormatLabel(packObject);
                                    supportedFormats = getSupportedFormatsLabel(packObject);
                                }
                            }
                        }
                        iconCount = zipFile.getEntry("pack.png") != null ? 1 : 0;
                    }
                }
            }
        } catch (Exception ignored) {
        }
        return new LocalPackInsight(fileName, filePath, packFormat, supportedFormats, metadataFile, iconCount, zipped, found, fileSize);
    }

    private String getPackFormatLabel(JsonObject packObject) {
        if (packObject == null || !packObject.has("pack_format")) {
            return "";
        }
        try {
            return String.valueOf(packObject.get("pack_format").getAsInt());
        } catch (Exception ignored) {
            return getString(packObject, "pack_format");
        }
    }

    private String getSupportedFormatsLabel(JsonObject packObject) {
        if (packObject == null || !packObject.has("supported_formats")) {
            return "";
        }
        JsonElement element = packObject.get("supported_formats");
        if (element.isJsonPrimitive()) {
            return element.getAsString();
        }
        if (element.isJsonArray()) {
            List<String> values = new ArrayList<>();
            for (JsonElement entry : element.getAsJsonArray()) {
                values.add(entry.getAsString());
            }
            return String.join(", ", values);
        }
        if (element.isJsonObject()) {
            JsonObject obj = element.getAsJsonObject();
            String min = obj.has("min_inclusive") ? obj.get("min_inclusive").getAsString() : "";
            String max = obj.has("max_inclusive") ? obj.get("max_inclusive").getAsString() : "";
            return min.isBlank() && max.isBlank() ? obj.toString() : min + (max.isBlank() ? "" : " - " + max);
        }
        return element.toString();
    }

    private static class PackListWidget extends class_350<PackListWidget.PackEntry> {
        public PackListWidget(class_310 client, int width, int height, int top, int bottom, int entryHeight) {
            super(client, width, height, top, bottom, entryHeight);
        }

        @Override
        public int method_25322() {
            return this.field_22742 - 4;
        }

        @Override
        public int method_25342() {
            return this.field_19088 + 2;
        }

        @Override
        protected int method_25329() {
            return this.field_19087 - 6;
        }

        @Override
        protected void method_25325(class_332 context) {
        }

        public void addGroupHeader(String label, int count, boolean expanded, ResourcePackMenuScreen parentScreen) {
            this.method_25321(new GroupHeaderEntry(label, count, expanded, parentScreen));
        }

        public void addPackEntry(PackEntry entry) {
            this.method_25321(entry);
        }

        public void addParentPackEntry(ParentPackEntry entry) {
            this.method_25321(entry);
        }

        public void method_25339() {
            super.method_25339();
        }

        @Override
        public void method_37020(class_6382 builder) {
        }

        private static class GroupHeaderEntry extends PackEntry {
            private final String label;
            private final int count;
            private final boolean expanded;
            private final ResourcePackMenuScreen parentScreen;

            public GroupHeaderEntry(String label, int count, boolean expanded, ResourcePackMenuScreen parentScreen) {
                super(null, class_310.method_1551(), parentScreen);
                this.label = label;
                this.count = count;
                this.expanded = expanded;
                this.parentScreen = parentScreen;
            }

            @Override
            public void method_25343(class_332 context, int index, int y, int x, int entryWidth, int entryHeight, int mouseX, int mouseY, boolean hovered, float delta) {
                if (hovered) {
                    context.method_25294(x + 2, y + 2, x + entryWidth - 10, y + 34, 0x2F5D6674);
                }
                context.method_25294(x + 9, y + 8, x + 10, y + 27, 0x5A728294);
                context.method_25294(x + 10, y + 17, x + 18, y + 18, 0x7A8FA2B6);
                context.method_51433(class_310.method_1551().field_1772, this.expanded ? "-" : "+", x + 3, y + 11, new Color(uiColorContentBaseTitleText, true).getRGB(), false);
                context.method_51433(class_310.method_1551().field_1772, this.label, x + 22, y + 6, new Color(uiColorContentBaseTitleText, true).getRGB(), true);
                context.method_51433(class_310.method_1551().field_1772, "Group", x + 22, y + 19, new Color(uiColorHeaderSubTitleText, true).getRGB(), false);
                String countLabel = this.count + (this.count == 1 ? " pack" : " packs");
                context.method_51433(class_310.method_1551().field_1772, countLabel, x + entryWidth - 24 - class_310.method_1551().field_1772.method_1727(countLabel), y + 12, new Color(uiColorHeaderSubTitleText, true).getRGB(), false);
            }

            @Override
            public boolean method_25402(double mouseX, double mouseY, int button) {
                if (button == 0 && this.parentScreen != null) {
                    UiSoundHelper.playButtonClick();
                    this.parentScreen.toggleInstalledGroup(this.label);
                    return true;
                }
                return false;
            }
        }

        private static class ParentPackEntry extends PackEntry {
            private final List<PackEntry> childPacks = new ArrayList<>();
            private final String groupKey;
            private final int groupCount;

            public ParentPackEntry(class_5369.class_5371 pack, class_310 client, ResourcePackMenuScreen parentScreen, String groupKey, int groupCount, boolean expanded) {
                super(pack, client, parentScreen);
                this.groupKey = groupKey;
                this.groupCount = groupCount;
            }

            public void addChildPack(class_5369.class_5371 childPack) {
                this.childPacks.add(new PackEntry(childPack, this.client, this.parentScreen, true, this.childPacks.size(), this.groupCount));
            }

            public List<PackEntry> getChildPacks() {
                return this.childPacks;
            }

            @Override
            public void method_25343(class_332 context, int index, int y, int x, int entryWidth, int entryHeight, int mouseX, int mouseY, boolean hovered, float delta) {
                super.method_25343(context, index, y, x, entryWidth, entryHeight, mouseX, mouseY, hovered, delta);
                String countLabel = this.groupCount + " packs";
                context.method_51433(this.client.field_1772, countLabel, x + entryWidth - 18 - this.client.field_1772.method_1727(countLabel), y + 18, 0xB9C7D8, false);
            }

            @Override
            public boolean method_25402(double mouseX, double mouseY, int button) {
                if (button == 0 && this.parentScreen != null) {
                    UiSoundHelper.playButtonClick();
                    this.parentScreen.setSelectedPack(this.pack);
                    this.parentScreen.toggleInstalledGroup(this.groupKey);
                    return true;
                }
                return super.method_25402(mouseX, mouseY, button);
            }
        }

        private static class PackEntry extends class_350.class_351<PackEntry> {
            protected final class_5369.class_5371 pack;
            protected final class_310 client;
            protected final ResourcePackMenuScreen parentScreen;
            protected final boolean childRow;
            protected final int childIndex;
            protected final int childCount;

            public PackEntry(class_5369.class_5371 pack, class_310 client, ResourcePackMenuScreen parentScreen) {
                this(pack, client, parentScreen, false, -1, 0);
            }

            public PackEntry(class_5369.class_5371 pack, class_310 client, ResourcePackMenuScreen parentScreen, boolean childRow, int childIndex, int childCount) {
                this.pack = pack;
                this.client = client;
                this.parentScreen = parentScreen;
                this.childRow = childRow;
                this.childIndex = childIndex;
                this.childCount = childCount;
            }

            @Override
            public void method_25343(class_332 context, int index, int y, int x, int entryWidth, int entryHeight, int mouseX, int mouseY, boolean hovered, float delta) {
                if (this.pack == null || this.client == null || this.parentScreen == null) {
                    return;
                }
                int guideX = x + 11;
                int branchEndX = x + 25;
                int iconX = this.childRow ? x + 31 : x + BrowserLayoutHelper.LIST_ROW_ICON_OFFSET_X;
                int textX = this.childRow ? x + 68 : x + BrowserLayoutHelper.LIST_ROW_TEXT_OFFSET_X;
                if (this.childRow) {
                    boolean lastChild = this.childIndex >= this.childCount - 1;
                    int connectorY = y + 18;
                    int verticalTop = y - 2;
                    int verticalBottom = lastChild ? y + 18 : y + 33;
                    if (verticalBottom > verticalTop) {
                        context.method_25294(guideX, verticalTop, guideX + 1, verticalBottom, 0x4D748291);
                    }
                    if (lastChild) {
                        context.method_25294(guideX, y + 8, guideX + 1, connectorY, 0x4D748291);
                    }
                    context.method_25294(guideX, y + 18, branchEndX, y + 19, 0x66748291);
                }
                class_2960 icon = this.pack.method_30286();
                if (icon != null) {
                    context.method_25290(icon, iconX, y + BrowserLayoutHelper.LIST_ROW_ICON_OFFSET_Y, 0, 0, BrowserLayoutHelper.LIST_ROW_ICON_SIZE, BrowserLayoutHelper.LIST_ROW_ICON_SIZE, BrowserLayoutHelper.LIST_ROW_ICON_SIZE, BrowserLayoutHelper.LIST_ROW_ICON_SIZE);
                }
                String titleLabel = this.client.field_1772.method_27523(this.pack.method_29650().getString(), Math.max(72, entryWidth - (textX - x) - BrowserLayoutHelper.LIST_ROW_RIGHT_PADDING));
                String subLabel = this.client.field_1772.method_27523((this.pack.method_29660() ? "Enabled" : "Disabled") + "  |  " + this.pack.method_48276(), Math.max(72, entryWidth - (textX - x) - BrowserLayoutHelper.LIST_ROW_RIGHT_PADDING));
                context.method_51433(this.client.field_1772, titleLabel, textX, y + BrowserLayoutHelper.LIST_ROW_TITLE_OFFSET_Y, 0xFFFFFF, true);
                context.method_51433(this.client.field_1772, subLabel, textX, y + BrowserLayoutHelper.LIST_ROW_META_OFFSET_Y, this.childRow ? 0xAEBCCB : 0xAAAAAA, false);
            }

            @Override
            public boolean method_25402(double mouseX, double mouseY, int button) {
                if (this.pack == null || this.parentScreen == null) {
                    return false;
                }
                if (button == 0) {
                    UiSoundHelper.playButtonClick();
                    this.parentScreen.selectPackFromList(this.pack);
                    return true;
                }
                if (button == 1) {
                    UiSoundHelper.playButtonClick();
                    this.parentScreen.openPackActionMenu(this.pack, mouseX, mouseY);
                    return true;
                }
                return false;
            }
        }
    }

    @Override
    public boolean method_25422() {
        return true;
    }

    @Override
    public boolean method_25401(double mouseX, double mouseY, double amount) {
        if (mouseX >= this.previewViewportX && mouseX <= this.previewViewportX + this.previewViewportWidth && mouseY >= this.previewViewportY && mouseY <= this.previewViewportY + this.previewViewportHeight && this.previewScrollMax > 0) {
            this.previewScrollOffset = Math.max(0, Math.min(this.previewScrollMax, this.previewScrollOffset - (int) amount * 12));
            return true;
        }
        if (this.packListWidget != null && this.packListWidget.method_25405(mouseX, mouseY)) {
            this.packListWidget.method_25307(Math.max(0.0D, this.packListWidget.method_25341() - (int) amount * 20.0D));
            return true;
        }
        return super.method_25401(mouseX, mouseY, amount);
    }
}
