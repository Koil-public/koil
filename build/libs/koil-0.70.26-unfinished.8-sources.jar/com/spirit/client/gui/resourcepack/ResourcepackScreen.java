package com.spirit.client.gui.resourcepack;

import com.spirit.client.gui.BrowserLayoutHelper;
import com.spirit.client.gui.browser.AbstractModrinthContentScreen;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import java.io.File;
import java.nio.file.Path;

import static com.spirit.Main.uiImageDirectory;
import static com.spirit.koil.api.util.file.image.ExternalImageLoader.loadExternalPngTextureWithColorVariant;

public class ResourcepackScreen extends AbstractModrinthContentScreen {
	private static final class_2960 RESOURCEPACK_ICON = loadExternalPngTextureWithColorVariant(uiImageDirectory, "image.png");
	private class_4185 inDevButton;

	public ResourcepackScreen(class_437 parent) {
		super(parent);
	}

	public ResourcepackScreen(class_437 parent, String initialQuery) {
		super(parent, initialQuery);
	}

	@Override
	protected String getProjectTypeFacet() {
		return "resourcepack";
	}

	@Override
	protected String getScreenTitle() {
		return "Download Resource Packs";
	}

	@Override
	protected String getSearchPlaceholder() {
		return "Search resource packs";
	}

	@Override
	protected class_2960 getFallbackIcon() {
		return RESOURCEPACK_ICON;
	}

	@Override
	protected File getContentDirectory() {
		Path path = FabricLoader.getInstance().getGameDir().resolve("resourcepacks");
		return path.toFile();
	}

	public File getResourcepacksDirectory() {
		return getContentDirectory();
	}

	@Override
	protected String getLocalFileExtension() {
		return ".zip";
	}

	@Override
	protected void method_25426() {
		super.method_25426();
		if (!usesKoilChrome()) {
			return;
		}
		int rightActionX = BrowserLayoutHelper.FOOTER_RIGHT_ACTION_X;
		int rightActionWidth = BrowserLayoutHelper.FOOTER_RIGHT_ACTION_WIDTH;
		if (this.reloadButton != null) {
			this.reloadButton.field_22764 = false;
			this.reloadButton.field_22763 = false;
		}
		if (this.cancelButton != null) {
			this.cancelButton.method_46421(BrowserLayoutHelper.footerSmallButtonX(3));
			this.cancelButton.field_22764 = true;
			this.cancelButton.field_22763 = true;
		}
		if (this.openFolderButton != null) {
			this.openFolderButton.method_25358(rightActionWidth);
			this.openFolderButton.method_46421(rightActionX);
			this.openFolderButton.method_46419(this.field_22790 - 52);
			this.openFolderButton.method_25355(class_2561.method_30163("Open Folder"));
		}
		if (this.inDevButton != null) {
			this.method_37066(this.inDevButton);
		}
		this.inDevButton = this.method_37063(class_4185.method_46430(class_2561.method_30163("InDev"), button -> {
		}).method_46434(rightActionX, this.field_22790 - 28, rightActionWidth, 20).method_46431());
		this.inDevButton.field_22763 = false;
	}

	@Override
	protected void updateSelectionButtons() {
		super.updateSelectionButtons();
		if (this.reloadButton != null) {
			this.reloadButton.field_22764 = false;
			this.reloadButton.field_22763 = false;
		}
		if (this.cancelButton != null) {
			this.cancelButton.field_22764 = true;
			this.cancelButton.field_22763 = true;
		}
		if (this.inDevButton != null) {
			this.inDevButton.field_22763 = false;
		}
	}

	@Override
	protected class_437 createReloadScreen() {
		return new ResourcepackScreen(this.parent, currentSearchQuery());
	}
}
