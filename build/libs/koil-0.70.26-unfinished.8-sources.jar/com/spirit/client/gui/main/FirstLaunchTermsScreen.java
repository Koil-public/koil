package com.spirit.client.gui.main;

import com.spirit.Main;
import com.spirit.koil.api.design.DesignLoader;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_5481;
import java.awt.*;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

import static com.spirit.koil.api.design.uiColorVal.*;

@Environment(EnvType.CLIENT)
public class FirstLaunchTermsScreen extends class_437 {
    private static final int WARNING_LEFT = 38;
    private static final int WARNING_TITLE_Y = 70;
    private static final int WARNING_BODY_Y = 90;
    private static final int WARNING_LINE_HEIGHT = 12;
    private static final int WARNING_FOOTER_HEIGHT = 102;
    private static final int WARNING_BUTTON_HEIGHT = 20;
    private static final List<String> DOWNLOAD_URLS = List.of(
            "https://raw.githubusercontent.com/Koil-public/koil-online-data/main/config.json",
            "https://raw.githubusercontent.com/Koil-public/koil-online-data/main/sys.json",
            "https://raw.githubusercontent.com/Koil-public/koil-online-data/main/koil.json",
            "https://raw.githubusercontent.com/Koil-public/koil-online-data/main/key.json",
            "https://raw.githubusercontent.com/Koil-public/koil-online-data/main/catcher.json",
            "https://raw.githubusercontent.com/Koil-public/koil-online-data/main/design.json",
            "https://raw.githubusercontent.com/Koil-public/koil-online-data/main/data.json",
            "https://raw.githubusercontent.com/Koil-public/koil-online-data/main/content/sys/design/files/music.json",
            "https://raw.githubusercontent.com/Koil-public/koil-online-data/main/content/sys/design/files/background.json",
            "https://raw.githubusercontent.com/Koil-public/koil-online-data/main/wiki/help_book.json",
            "https://raw.githubusercontent.com/Koil-public/koil-online-data/main/store/membership.json",
            "https://raw.githubusercontent.com/Koil-public/koil-online-data/main/auth/validDigits.json",
            "https://raw.githubusercontent.com/Koil-public/koil-online-data/main/auth/validSerial.json",
            "https://raw.githubusercontent.com/Koil-public/koil-online-data/main/auth/verifiedAuthors.json"
    );

    private Step step = Step.TERMS;
    private boolean downloadsExpanded;
    private int scrollOffset;
    private boolean draggingBodyScrollbar;
    private int bodyScrollbarDragOffset;

    public FirstLaunchTermsScreen() {
        super(class_2561.method_43470("Koil First Launch Terms"));
    }

    @Override
    protected void method_25426() {
        rebuildButtons();
    }

    private void rebuildButtons() {
        method_37067();
        int x = WARNING_LEFT;
        int buttonY = Math.max(this.field_22790 - 86, WARNING_BODY_Y + Math.min(bodyContentHeight(), bodyViewportHeight()) + 18);
        buttonY = Math.min(buttonY, this.field_22790 - 30);
        int rightButtonWidth = 80;
        int rightButtonGap = 8;
        int acceptX = Math.max(x, this.field_22789 - x - rightButtonWidth);
        int denyX = Math.max(x, acceptX - 78 - rightButtonGap);
        if (step == Step.TERMS) {
            method_37063(class_4185.method_46430(class_2561.method_43470(downloadsExpanded ? "Hide Downloads" : "Show Downloads"), button -> downloadsExpanded = !downloadsExpanded)
                    .method_46434(x, buttonY, Math.min(124, Math.max(84, this.field_22789 - 76)), WARNING_BUTTON_HEIGHT).method_46431());
            method_37063(class_4185.method_46430(class_2561.method_43470("Deny"), button -> denyTerms())
                    .method_46434(denyX, buttonY, 78, WARNING_BUTTON_HEIGHT).method_46431());
            method_37063(class_4185.method_46430(class_2561.method_43470("Accept"), button -> {
                step = Step.DEFAULT_UI;
                scrollOffset = 0;
                rebuildButtons();
            }).method_46434(acceptX, buttonY, rightButtonWidth, WARNING_BUTTON_HEIGHT).method_46431());
        } else if (step == Step.DEFAULT_UI) {
            method_37063(class_4185.method_46430(class_2561.method_43470("Yes"), button -> {
                step = Step.CHANGE_UI;
                rebuildButtons();
            }).method_46434(denyX, buttonY, 78, WARNING_BUTTON_HEIGHT).method_46431());
            method_37063(class_4185.method_46430(class_2561.method_43470("No"), button -> acceptAndExit(true))
                    .method_46434(acceptX, buttonY, rightButtonWidth, WARNING_BUTTON_HEIGHT).method_46431());
        } else {
            method_37063(class_4185.method_46430(class_2561.method_43470("Yes"), button -> acceptAndExit(true))
                    .method_46434(denyX, buttonY, 78, WARNING_BUTTON_HEIGHT).method_46431());
            method_37063(class_4185.method_46430(class_2561.method_43470("No"), button -> acceptAndExit(false))
                    .method_46434(acceptX, buttonY, rightButtonWidth, WARNING_BUTTON_HEIGHT).method_46431());
        }
    }

    private void acceptAndExit(boolean uiRedesign) {
        Main.SUBLOGGER.logI("First-Launch thread", "First launch terms accepted. uiRedesign=" + uiRedesign);
        Main.completeFirstLaunch(uiRedesign);
        class_310 client = class_310.method_1551();
        client.method_1507(new FirstLaunchDownloadScreen());
    }

    private void denyTerms() {
        Main.SUBLOGGER.logW("First-Launch thread", "First launch terms denied. Attempting Koil jar removal before crash.");
        try {
            FabricLoader.getInstance().getModContainer("koil")
                    .ifPresent(container -> container.getRootPaths().forEach(this::deleteModPath));
        } catch (Exception exception) {
            Main.SUBLOGGER.logE("First-Launch thread", "Failed while attempting Koil jar removal: " + exception.getMessage());
        }
        throw new RuntimeException("Koil first launch terms were denied. Koil attempted to remove its mod file as requested.");
    }

    private void deleteModPath(Path path) {
        try {
            if (Files.isRegularFile(path) && path.toString().endsWith(".jar")) {
                if (Files.deleteIfExists(path)) {
                    Main.SUBLOGGER.logI("First-Launch thread", "Deleted Koil jar after terms denial: " + path);
                }
            }
        } catch (IOException exception) {
            Main.SUBLOGGER.logE("First-Launch thread", "Failed to delete Koil jar after terms denial: " + path + " - " + exception.getMessage());
        }
    }

    @Override
    public boolean method_25422() {
        return false;
    }

    @Override
    public boolean method_25401(double mouseX, double mouseY, double amount) {
        int maxScroll = Math.max(0, bodyContentHeight() - bodyViewportHeight());
        scrollOffset = Math.max(0, Math.min(maxScroll, scrollOffset - (int) (amount * 18)));
        return true;
    }

    @Override
    public boolean method_25402(double mouseX, double mouseY, int button) {
        if (button == 0 && isOverBodyScrollbar(mouseX, mouseY)) {
            this.draggingBodyScrollbar = true;
            this.bodyScrollbarDragOffset = scrollbarGrabOffset(mouseY);
            this.scrollOffset = scrollOffsetFromMouse(mouseY, this.bodyScrollbarDragOffset);
            return true;
        }
        return super.method_25402(mouseX, mouseY, button);
    }

    @Override
    public boolean method_25403(double mouseX, double mouseY, int button, double deltaX, double deltaY) {
        if (button == 0 && this.draggingBodyScrollbar) {
            this.scrollOffset = scrollOffsetFromMouse(mouseY, this.bodyScrollbarDragOffset);
            return true;
        }
        return super.method_25403(mouseX, mouseY, button, deltaX, deltaY);
    }

    @Override
    public boolean method_25406(double mouseX, double mouseY, int button) {
        if (button == 0 && this.draggingBodyScrollbar) {
            this.draggingBodyScrollbar = false;
            return true;
        }
        return super.method_25406(mouseX, mouseY, button);
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        class_310 client = class_310.method_1551();
        context.method_25293(DesignLoader.getLoadingTexture(), 0, 0, client.method_22683().method_4486(), client.method_22683().method_4502(), 0.0F, 0.0F, 319, 192, 319, 192);
        renderBackupPromptShell(context);

        List<BodyRow> rows = wrappedBodyRows(bodyWidth());
        int contentTop = WARNING_BODY_Y;
        int contentBottom = Math.max(contentTop + 20, this.field_22790 - WARNING_FOOTER_HEIGHT - 10);
        context.method_44379(WARNING_LEFT, contentTop, this.field_22789 - WARNING_LEFT, contentBottom);
        int y = contentTop - scrollOffset;
        for (BodyRow row : rows) {
            if (y > contentTop - WARNING_LINE_HEIGHT && y < contentBottom) {
                context.method_51430(this.field_22793, row.text(), WARNING_LEFT, y, row.color(), false);
            }
            y += row.height();
        }
        context.method_44380();

        renderScrollIndicator(context, rows);
        super.method_25394(context, mouseX, mouseY, delta);
    }

    private List<RawLine> termsLines() {
        if (step == Step.DEFAULT_UI) {
            return List.of(
                    RawLine.title("Do you like Minecraft's default UI?"),
                    RawLine.blank(),
                    RawLine.body("Choose Yes if you prefer the normal Minecraft screen layout."),
                    RawLine.body("Choose No if you want Koil's redesigned Minecraft UI enabled.")
            );
        }
        if (step == Step.CHANGE_UI) {
            return List.of(
                    RawLine.title("Do you still want to see a change?"),
                    RawLine.blank(),
                    RawLine.body("Choosing Yes enables Koil's redesigned Minecraft UI screens."),
                    RawLine.body("Choosing No keeps the default Minecraft UI style where Koil supports that fallback.")
            );
        }
        ArrayList<RawLine> lines = new ArrayList<>();
        lines.add(RawLine.title("External Files"));
        lines.add(RawLine.body("Koil downloads runtime configuration, design files, wiki data, Koro state files, and store/funding metadata from the SpiritXIV koil-online-data GitHub repository."));
        lines.add(RawLine.body("Koil writes those files under this Minecraft instance, mainly in ./koil, ./config, and design subfolders."));
        lines.add(RawLine.blank());
        lines.add(RawLine.title("Generated Formatting"));
        lines.add(RawLine.body("Some Koil screens inspect your local files and generate formatting, previews, warnings, icons, grouped controls, and metadata panels from file contents."));
        lines.add(RawLine.body("This is deterministic program logic running locally in the mod. It is not a ChatGPT-style model and it does not send your file contents to ChatGPT for those screen layouts."));
        lines.add(RawLine.blank());
        lines.add(RawLine.title("Koil Packages"));
        lines.add(RawLine.body("A valid koil-package is allowed to copy package contents into the instance root and can overwrite or reformat files in the instance folder."));
        lines.add(RawLine.body("Only install a koil-package from a source you trust, because accepted packages can change your local Minecraft instance files."));
        lines.add(RawLine.blank());
        if (downloadsExpanded) {
            lines.add(RawLine.title("Download URLs"));
            for (String url : DOWNLOAD_URLS) {
                lines.add(RawLine.body(url));
            }
            lines.add(RawLine.body("The asset updater may also download files listed by the downloaded catcher/key metadata."));
        }
        return lines;
    }

    private void renderBackupPromptShell(class_332 context) {
        context.method_51448().method_22903();
        context.method_51448().method_22905(2F, 2F, 1.0F);
        context.method_51439(this.field_22793, class_2561.method_43470("[!] Warning."), 20, 8, new Color(uiColorWarningPromptText, true).getRGB(), true);
        context.method_51448().method_22909();

        context.method_25294(0, 6, this.field_22789, this.field_22790 - WARNING_FOOTER_HEIGHT, new Color(uiColorContentBase, true).getRGB());
        context.method_25294(0, 8, this.field_22789, 10, new Color(uiColorContentStripeLeft, true).getRGB());
        context.method_25294(0, this.field_22790 - WARNING_FOOTER_HEIGHT - 2, this.field_22789, this.field_22790 - WARNING_FOOTER_HEIGHT - 4, new Color(uiColorContentStripeRight, true).getRGB());

        String title = step == Step.TERMS ? "Koil First Launch Terms" : "Koil UI Preference";
        context.method_51433(this.field_22793, title, WARNING_LEFT, WARNING_TITLE_Y, new Color(uiColorBasicTitleText, true).getRGB(), true);
    }

    private void renderScrollIndicator(class_332 context, List<BodyRow> rows) {
        int contentHeight = rows.stream().mapToInt(BodyRow::height).sum();
        int viewportHeight = bodyViewportHeight();
        if (contentHeight <= viewportHeight) {
            return;
        }
        int trackX = this.field_22789 - 16;
        int trackTop = WARNING_BODY_Y;
        int trackHeight = viewportHeight;
        context.method_25294(trackX, trackTop, trackX + 2, trackTop + trackHeight, withAlpha(uiColorBackgroundBorder, 90));
        int thumbHeight = Math.max(18, trackHeight * viewportHeight / contentHeight);
        int thumbY = trackTop + (trackHeight - thumbHeight) * scrollOffset / Math.max(1, contentHeight - viewportHeight);
        context.method_25294(trackX - 1, thumbY, trackX + 3, thumbY + thumbHeight, uiColorIDEFileNameText);
    }

    private boolean isOverBodyScrollbar(double mouseX, double mouseY) {
        return bodyContentHeight() > bodyViewportHeight()
                && mouseX >= this.field_22789 - 28
                && mouseX <= this.field_22789 - 6
                && mouseY >= WARNING_BODY_Y
                && mouseY <= WARNING_BODY_Y + bodyViewportHeight();
    }

    private int scrollbarGrabOffset(double mouseY) {
        int thumbHeight = bodyScrollbarThumbHeight();
        int thumbY = bodyScrollbarThumbY(thumbHeight);
        if (mouseY >= thumbY && mouseY <= thumbY + thumbHeight) {
            return (int) mouseY - thumbY;
        }
        return thumbHeight / 2;
    }

    private int scrollOffsetFromMouse(double mouseY, int dragOffset) {
        int contentHeight = bodyContentHeight();
        int viewportHeight = bodyViewportHeight();
        if (contentHeight <= viewportHeight) {
            return 0;
        }
        int thumbHeight = bodyScrollbarThumbHeight();
        int thumbTravel = Math.max(1, viewportHeight - thumbHeight);
        int maxScroll = Math.max(1, contentHeight - viewportHeight);
        int relativeY = Math.max(0, Math.min(thumbTravel, (int) mouseY - WARNING_BODY_Y - dragOffset));
        return Math.max(0, Math.min(maxScroll, Math.round(relativeY * maxScroll / (float) thumbTravel)));
    }

    private int bodyScrollbarThumbHeight() {
        int contentHeight = bodyContentHeight();
        int viewportHeight = bodyViewportHeight();
        return Math.max(18, viewportHeight * viewportHeight / Math.max(1, contentHeight));
    }

    private int bodyScrollbarThumbY(int thumbHeight) {
        int contentHeight = bodyContentHeight();
        int viewportHeight = bodyViewportHeight();
        return WARNING_BODY_Y + (viewportHeight - thumbHeight) * scrollOffset / Math.max(1, contentHeight - viewportHeight);
    }

    private List<BodyRow> wrappedBodyRows(int wrapWidth) {
        ArrayList<BodyRow> rows = new ArrayList<>();
        for (RawLine line : termsLines()) {
            if (line.text().isBlank()) {
                rows.add(new BodyRow(class_5481.field_26385, 6, new Color(uiColorHeaderSubTitleText, true).getRGB()));
                continue;
            }
            int color = line.title()
                    ? new Color(uiColorContentBaseTitleText, true).getRGB()
                    : new Color(uiColorHeaderSubTitleText, true).getRGB();
            List<class_5481> wrapped = this.field_22793.method_1728(class_2561.method_43470(line.text()), wrapWidth);
            for (class_5481 text : wrapped) {
                rows.add(new BodyRow(text, WARNING_LINE_HEIGHT, color));
            }
            if (line.title()) {
                rows.add(new BodyRow(class_5481.field_26385, 3, color));
            }
        }
        return rows;
    }

    private int bodyWidth() {
        return Math.max(100, this.field_22789 - (WARNING_LEFT * 2) - 16);
    }

    private int bodyViewportHeight() {
        return Math.max(24, this.field_22790 - WARNING_FOOTER_HEIGHT - WARNING_BODY_Y - 10);
    }

    private int bodyContentHeight() {
        return wrappedBodyRows(bodyWidth()).stream().mapToInt(BodyRow::height).sum();
    }

    private static int withAlpha(int argbColor, int alpha) {
        Color color = new Color(argbColor, true);
        return new Color(color.getRed(), color.getGreen(), color.getBlue(), Math.max(0, Math.min(255, alpha))).getRGB();
    }

    private enum Step {
        TERMS,
        DEFAULT_UI,
        CHANGE_UI
    }

    private record RawLine(String text, boolean title) {
        private static RawLine title(String text) {
            return new RawLine(text, true);
        }

        private static RawLine body(String text) {
            return new RawLine(text, false);
        }

        private static RawLine blank() {
            return new RawLine("", false);
        }
    }

    private record BodyRow(class_5481 text, int height, int color) {
    }
}
