package com.spirit.client.gui.main.elements;

import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;

public class ClickableImage {
    private final class_2960 texture;
    private final int x, y, width, height;
    private final Runnable onClick;

    public ClickableImage(class_2960 texture, int x, int y, int width, int height, Runnable onClick) {
        this.texture = texture;
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
        this.onClick = onClick;
    }

    public void render(class_332 context, int mouseX, int mouseY) {
        class_310 client = class_310.method_1551();
        context.method_25290(texture, x, y, 0, 0, width, height, width, height);
    }

    public boolean isMouseOver(int mouseX, int mouseY) {
        return mouseX >= x && mouseX <= x + width && mouseY >= y && mouseY <= y + height;
    }

    public void onClick() {
        onClick.run();
    }
}
