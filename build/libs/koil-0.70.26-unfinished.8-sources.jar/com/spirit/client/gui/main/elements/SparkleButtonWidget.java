package com.spirit.client.gui.main.elements;

import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_344;
import net.minecraft.class_3532;
import net.minecraft.class_5819;

public class SparkleButtonWidget extends class_344 {
    private final class_5819 sparkleRandom = class_5819.method_43053();
    private static final int[] GLITTER_COLORS = {
            0xFFE8A3,
            0xFFD86B,
            0xFFF3C7,
            0xFFC94D
    };

    public SparkleButtonWidget(int x, int y, int width, int height, int u, int v, int hoveredV,
                               class_2960 texture, int textureWidth, int textureHeight,
                               class_4241 onPress) {
        super(x, y, width, height, u, v, hoveredV, texture, textureWidth, textureHeight, onPress);
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        super.method_25394(context, mouseX, mouseY, delta);

        if (this.method_49606()) {
            long now = System.currentTimeMillis();
            int sparkleCount = 10;
            int effectLeft = this.method_46426() - 6;
            int effectWidth = this.method_25368() + 12;
            int effectTop = this.method_46427() - 12;
            int fallDistance = this.method_25364() + 24;
            for (int i = 0; i < sparkleCount; i++) {
                double phase = (now / (360.0 + (i * 35.0))) + (i * 0.67);
                int laneX = effectLeft + ((i * 7) % Math.max(8, effectWidth));
                int sparkleX = laneX + (int) Math.round(Math.sin(phase * 1.1) * 2.0);
                int fall = (int) ((((now / (26.0 + i * 2.0)) + (i * 9.0))) % Math.max(1, fallDistance));
                int sparkleY = effectTop + fall;
                float fade = 1.0f - Math.min(1.0f, fall / (float) Math.max(1, fallDistance - 1));
                int alpha = Math.max(36, Math.round((120 + 80 * (float) Math.abs(Math.sin(phase * 1.35))) * fade));
                int color = withAlpha(GLITTER_COLORS[i % GLITTER_COLORS.length], alpha);
                drawSparkle(context, sparkleX, sparkleY, color, alpha);
            }

            int glowAlpha = 38 + class_3532.method_15395(sparkleRandom, 0, 22);
            context.method_25294(this.method_46426() - 2, this.method_46427() - 2, this.method_46426() + this.method_25368() + 2, this.method_46427() + this.method_25364() + 2, withAlpha(0xF7D27A, glowAlpha));
            context.method_49601(this.method_46426() - 1, this.method_46427() - 1, this.method_25368() + 2, this.method_25364() + 2, withAlpha(0xFFF1B8, 150));
        }
    }

    private void drawSparkle(class_332 context, int x, int y, int color, int alpha) {
        context.method_25294(x, y, x + 2, y + 2, color);
        context.method_25294(x - 1, y + 1, x + 3, y + 2, withAlpha(0xFFFFFF, alpha / 4));
        context.method_25294(x + 1, y - 1, x + 2, y + 3, withAlpha(0xFFFFFF, alpha / 4));
    }

    private static int withAlpha(int rgb, int alpha) {
        return (Math.max(0, Math.min(255, alpha)) << 24) | (rgb & 0x00FFFFFF);
    }
}
