package com.spirit.client.gui.main;

import com.google.common.collect.ImmutableList;
import com.spirit.client.gui.update.UpdateScreen;
import com.spirit.client.gui.update.elements.UpdateState;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_368;
import net.minecraft.class_374;
import net.minecraft.class_5481;
import org.jetbrains.annotations.Nullable;

import java.awt.*;
import java.util.List;
import java.util.stream.Stream;

import static com.spirit.Main.uiImageDirectory;
import static com.spirit.koil.api.util.file.image.ExternalImageLoader.loadExternalPngTexture;

@Environment(EnvType.CLIENT)
public class KoilUpdateToast implements class_368 {
    private final Type type;
    private class_2561 title;
    private List<class_5481> lines;
    private long startTime;
    private boolean justUpdated;
    private final int width;
    private static long lastShownAt;
    private static int lastShownWidth = 200;
    private static int lastShownHeight = 44;

    class_2960 field_2207 = loadExternalPngTexture(uiImageDirectory, "koil_update_toasts.png");

    public KoilUpdateToast(Type type, class_2561 title, @Nullable class_2561 description) {
        this(type, title, getTextAsList(description), Math.max(160, 30 + Math.max(class_310.method_1551().field_1772.method_27525(title), description == null ? 0 : class_310.method_1551().field_1772.method_27525(description))));
    }

    public static KoilUpdateToast create(class_310 client, Type type, class_2561 title, class_2561 description) {
        class_327 textRenderer = client.field_1772;
        List<class_5481> list = textRenderer.method_1728(description, 200);
        Stream<class_5481> stream = list.stream();
        int i = Math.max(200, stream.mapToInt(textRenderer::method_30880).max().orElse(200));
        return new KoilUpdateToast(type, title, list, i + 30);
    }

    private KoilUpdateToast(Type type, class_2561 title, List<class_5481> lines, int width) {
        this.type = type;
        this.title = title;
        this.lines = lines;
        this.width = width;
    }

    private static ImmutableList<class_5481> getTextAsList(@Nullable class_2561 text) {
        return text == null ? ImmutableList.of() : ImmutableList.of(text.method_30937());
    }

    @Override
    public int method_29049() {
        return this.width;
    }

    @Override
    public int method_29050() {
        return 20 + Math.max(this.lines.size(), 1) * 12;
    }

    @Override
    public class_369 method_1986(class_332 context, class_374 manager, long startTime) {
        if (this.justUpdated) {
            this.startTime = startTime;
            this.justUpdated = false;
        }

        int i = this.method_29049();
        int j = this.method_29050();
        lastShownAt = System.currentTimeMillis();
        lastShownWidth = i;
        lastShownHeight = j;
        int l = Math.min(8, j - 28);

        int textureY = getTextureOffsetY(this.type);

        this.drawPart(context, manager, i, textureY, 0, 28);

        for (int m = 28; m < j - l; m += 10) {
            this.drawPart(context, manager, i, textureY + 16, m, Math.min(16, j - m - l));
        }

        this.drawPart(context, manager, i, textureY + 32 - l, j - l, l);

        int titleColor = getTitleColor(this.type);
        int descriptionColor = getDescriptionColor(this.type);

        context.method_51439(manager.method_1995().field_1772, this.title, 18, 7, titleColor, false);
        for (int lineIndex = 0; lineIndex < this.lines.size(); ++lineIndex) {
            context.method_51430(manager.method_1995().field_1772, this.lines.get(lineIndex), 18, 18 + lineIndex * 12, descriptionColor, false);
        }

        return (double) (startTime - this.startTime) < (double) this.type.displayDuration * manager.method_48221() ? class_369.field_2210 : class_369.field_2209;
    }

    private int getTextureOffsetY(Type type) {
        return switch (type) {
            case UPDATE_UI -> 0;
            case UPDATE_DEBUG -> 32;
            case UPDATE_API -> 64;
            case UPDATE_CONSOLE -> 96;
            case UPDATE_OTHER -> 128;
        };
    }

    private void drawPart(class_332 context, class_374 manager, int width, int textureV, int y, int height) {
        if (field_2207 == null) {
            int background = new Color(12, 14, 18, 232).getRGB();
            int border = getTitleColor(this.type);
            context.method_25294(0, y, width, y + height, background);
            if (y == 0) {
                context.method_25294(0, 0, 3, Math.max(height, method_29050()), border);
                context.method_49601(0, 0, width, method_29050(), new Color(42, 46, 56, 255).getRGB());
            }
            return;
        }
        int partWidth = width / 8;
        int j = Math.min(60, width - partWidth);

        context.method_25302(field_2207, 0, y, 0, 64 + textureV, partWidth, height);

        for (int k = partWidth; k < width - j; k += partWidth) {
            context.method_25302(field_2207, k, y, 32, 64 + textureV, Math.min(partWidth, width - k - j), height);
        }

        context.method_25302(field_2207, width - j, y, 160 - j, 64 + textureV, j, height);
    }

    private int getTitleColor(Type type) {
        return switch (type) {
            case UPDATE_UI -> new Color(0xA7, 0x00, 0x3A, 255).getRGB();
            case UPDATE_DEBUG -> new Color(0x2D, 0xA7, 0x00, 255).getRGB();
            case UPDATE_API -> new Color(0x00, 0x85, 0xA4, 255).getRGB();
            case UPDATE_CONSOLE -> new Color(0x74, 0x00, 0xA4, 255).getRGB();
            case UPDATE_OTHER -> new Color(0x8C, 0x88, 0xB5, 255).getRGB();
        };
    }

    private int getDescriptionColor(Type type) {
        return switch (type) {
            case UPDATE_UI -> new Color(0xD5, 0x5D, 0x87, 255).getRGB();
            case UPDATE_DEBUG -> new Color(0x78, 0xD4, 0x5A, 255).getRGB();
            case UPDATE_API -> new Color(0x5E, 0xC7, 0xDB, 255).getRGB();
            case UPDATE_CONSOLE -> new Color(0xAE, 0x66, 0xD3, 255).getRGB();
            case UPDATE_OTHER -> new Color(0xC2, 0xBE, 0xE8, 255).getRGB();
        };
    }

    public Type method_1987() {
        return this.type;
    }

    public static void add(class_374 manager, Type type, class_2561 title, @Nullable class_2561 description) {
        manager.method_1999(new KoilUpdateToast(type, title, description));
    }

    public static boolean handleClick(class_310 client, double mouseX, double mouseY) {
        if (client == null || client.method_22683() == null) {
            return false;
        }
        UpdateState.Status status = UpdateState.resolve();
        if (!status.updateAvailable()) {
            return false;
        }
        long visibleWindow = Type.UPDATE_OTHER.displayDuration + 1500L;
        if (System.currentTimeMillis() - lastShownAt > visibleWindow) {
            return false;
        }
        int screenWidth = client.method_22683().method_4486();
        int toastX = Math.max(0, screenWidth - lastShownWidth - 4);
        int toastY = 4;
        int toastH = Math.max(32, lastShownHeight + 4);
        if (mouseX >= toastX && mouseX <= screenWidth && mouseY >= toastY && mouseY <= toastY + toastH) {
            client.method_1507(new UpdateScreen(client.field_1755));
            return true;
        }
        return false;
    }

    @Environment(EnvType.CLIENT)
    public enum Type {
        UPDATE_UI,
        UPDATE_DEBUG,
        UPDATE_API,
        UPDATE_CONSOLE,
        UPDATE_OTHER;

        final long displayDuration;

        Type(long displayDuration) {
            this.displayDuration = displayDuration;
        }

        Type() {
            this(5000L);
        }
    }
}
