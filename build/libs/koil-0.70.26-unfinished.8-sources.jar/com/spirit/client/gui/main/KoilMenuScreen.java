package com.spirit.client.gui.main;

import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;
import com.spirit.Main;
import com.spirit.client.gui.UiSoundHelper;
import com.spirit.client.gui.console.ConsoleScreen;
import com.spirit.client.gui.ide.FileExplorerScreen;
import com.spirit.client.gui.main.elements.MenuBookEntry;
import com.spirit.client.gui.main.elements.SparkleButtonWidget;
import com.spirit.client.gui.update.elements.UpdateScreenData;
import com.spirit.koil.api.console.ConsoleChannel;
import com.spirit.koil.api.design.KoilScreenBackgrounds;
import com.spirit.koil.api.util.application.WindowManager;
import com.spirit.koil.api.util.file.json.JSONFileEditor;
import com.spirit.koil.api.util.file.media.image.ImageTextureService;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_339;
import net.minecraft.class_410;
import net.minecraft.class_4185;
import net.minecraft.class_4286;
import net.minecraft.class_437;
import net.minecraft.class_5348;
import net.minecraft.class_5481;
import net.minecraft.class_7919;
import java.awt.*;
import java.io.File;
import java.io.IOException;
import java.lang.reflect.Constructor;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.security.CodeSource;
import java.util.*;
import java.util.jar.JarEntry;
import java.util.jar.JarFile;

import static com.spirit.Main.*;
import static com.spirit.koil.api.design.uiColorVal.*;
import static com.spirit.koil.api.util.file.image.ExternalImageLoader.loadExternalPngTexture;

@Environment(EnvType.CLIENT)
public class KoilMenuScreen extends class_437 {
    private static final class_2960 LOGO_TEXTURE = loadExternalPngTexture(uiImageDirectory, "icon.png");
    private static final class_2960 FUNDING_TEXTURE = loadExternalPngTexture(uiImageDirectory, "koil_funding.png");
    private static final int PANEL_HOME = 1;
    private static final int PANEL_WIKI = 5;
    private static final int PANEL_CHANGELOG = 7;
    private static final int PANEL_TOOLS = 8;
    private static final int PANEL_BOOK = 9;
    private static final int PANEL_SETTINGS = 10;
    private static final int PANEL_DEBUG = 11;
    private static final int PANEL_DEBUG_VISUALS = 12;
    private static final int PANEL_DEBUG_CONSOLE = 13;
    private final List<class_339> globalButtons;
    private final List<class_339> sidebarButtons;
    private final List<class_339> debugButtons;
    private final List<class_339> toolButtons;
    private final List<MenuBookEntry> books = new ArrayList<>();
    private final List<ToolEntry> detectedTools = new ArrayList<>();
    private int currentPanel;
    private int scrollOffset;
    private int maxScrollOffset;
    private MenuBookEntry selectedBooks;
    private final String configFilePath = "./koil/sys/config.json";
    private class_4286 debugCheckbox;
    private class_4286 designMusicCheckbox;
    private class_4185 uninstallKoilButton;
    private class_4185 downloadDummyFilesButton;
    private class_4185 deleteBootstrapFilesButton;

    public KoilMenuScreen() {
        super(class_2561.method_43470("Title"));
        this.globalButtons = new ArrayList<>();
        this.sidebarButtons = new ArrayList<>();
        this.debugButtons = new ArrayList<>();
        this.toolButtons = new ArrayList<>();
        this.currentPanel = PANEL_HOME;
        this.scrollOffset = 0;

        books.add(new MenuBookEntry(loadExternalPngTexture(uiImageDirectory, "start_book.png"), "Manager Guide", "SpiritXIV", "Overview of the manager menu, navigation, and core Koil tools.", "SpiritXIV", "./koil/wiki/help_book.json"));
        books.add(new MenuBookEntry(loadExternalPngTexture(uiImageDirectory, "code_book.png"), "J-API Quickstart", "SpiritXIV", "Starting guide for working with Koil's Java-facing systems.", "SpiritXIV", "./koil/wiki/japi_begin.json"));
        books.add(new MenuBookEntry(loadExternalPngTexture(uiImageDirectory, "code_book.png"), "Blocks and Items Guide", "SpiritXIV", "Guide for custom block and item workflows in the J-API.", "SpiritXIV", "./koil/wiki/japi_blocksitems.json"));
        books.add(new MenuBookEntry(loadExternalPngTexture(uiImageDirectory, "code_book.png"), "Entities Guide", "SpiritXIV", "Guide for custom entity workflows in the J-API.", "SpiritXIV", "./koil/wiki/japi_entities.json"));
        books.add(new MenuBookEntry(loadExternalPngTexture(uiImageDirectory, "code_book.png"), "Effects Guide", "SpiritXIV", "Guide for custom effect workflows in the J-API.", "SpiritXIV", "./koil/wiki/japi_effects.json"));
        books.add(new MenuBookEntry(loadExternalPngTexture(uiImageDirectory, "code_book.png"), "Enchantments Guide", "SpiritXIV", "Guide for custom enchantment workflows in the J-API.", "SpiritXIV", "./koil/wiki/japi_enchantments.json"));
        books.add(new MenuBookEntry(loadExternalPngTexture(uiImageDirectory, "code_book.png"), "Commands Guide", "SpiritXIV", "Guide for command creation through the J-API.", "SpiritXIV", "./koil/wiki/japi_commands.json"));
        books.add(new MenuBookEntry(loadExternalPngTexture(uiImageDirectory, "code_book.png"), "Particles Guide", "SpiritXIV", "Guide for particle workflows in the J-API.", "SpiritXIV", "./koil/wiki/japi_particles.json"));
    }

    @Override
    protected void method_25426() {
        super.method_25426();
        clearWidgetList(globalButtons);
        clearWidgetList(sidebarButtons);
        clearWidgetList(debugButtons);
        clearWidgetList(toolButtons);
        removeSettingsWidgets();

        initGlobalButtons();
        initSidebarButtons();
        refreshDetectedTools();
        if (currentPanel == PANEL_TOOLS) {
            initToolButtons();
        }
    }

    private void initGlobalButtons() {
        class_4185 homeButton = this.method_37063(class_4185.method_46430(class_2561.method_43470("Home"), button -> switchPanel(PANEL_HOME))
                .method_46434(this.field_22789 - 126, 36, 54, 20)
                .method_46431());
        globalButtons.add(homeButton);

        JsonElement debugElement = JSONFileEditor.getValueFromJson(configFilePath, "debug");
        if (debugElement != null && debugElement.isJsonPrimitive() && debugElement.getAsBoolean()) {
            class_4185 debugButton = this.method_37063(class_4185.method_46430(class_2561.method_43470("Debug"), button -> switchPanel(PANEL_DEBUG))
                    .method_46434(this.field_22789 - 68, 36, 54, 20)
                    .method_46431());
            globalButtons.add(debugButton);
        }
    }

    private void initSidebarButtons() {
        int buttonX = 10;
        int buttonWidth = 100;
        int buttonHeight = 20;
        int buttonY = 70;
        int buttonSpacing = 30;

        File fundingTextureFile = new File(uiImageDirectory, "koil_funding.png");
        ImageTextureService.markFilePersistent(fundingTextureFile);

        SparkleButtonWidget fundingButton = this.method_37063(new SparkleButtonWidget(
                buttonX, buttonY,
                20, 20, 0, 0, 20,
                FUNDING_TEXTURE, 32, 64,
                button -> {
                    assert this.field_22787 != null;
                    this.field_22787.method_1507(new FundingScreen(this));
                }
        ));
        fundingButton.method_47400(class_7919.method_47407(class_2561.method_43470("Donate to the project's Development!")));
        sidebarButtons.add(fundingButton);

        boolean debugSidebarMode = currentPanel == PANEL_DEBUG || currentPanel == PANEL_DEBUG_VISUALS || currentPanel == PANEL_DEBUG_CONSOLE;

        if (debugSidebarMode) {
            class_4185 debugHomeButton = this.method_37063(class_4185.method_46430(class_2561.method_43470("Debug Home"), button -> switchPanel(PANEL_DEBUG))
                    .method_46434(buttonX + 26, buttonY, 74, buttonHeight)
                    .method_46431());
            class_4185 debugVisualsButton = this.method_37063(class_4185.method_46430(class_2561.method_43470("Visuals"), button -> switchPanel(PANEL_DEBUG_VISUALS))
                    .method_46434(buttonX, buttonY + buttonSpacing, buttonWidth, buttonHeight)
                    .method_46431());
            class_4185 debugConsoleButton = this.method_37063(class_4185.method_46430(class_2561.method_43470("Console"), button -> switchPanel(PANEL_DEBUG_CONSOLE))
                    .method_46434(buttonX, buttonY + (buttonSpacing * 2), buttonWidth, buttonHeight)
                    .method_46431());

            sidebarButtons.add(debugHomeButton);
            sidebarButtons.add(debugVisualsButton);
            sidebarButtons.add(debugConsoleButton);
            return;
        }

        class_4185 welcomeButton = this.method_37063(class_4185.method_46430(class_2561.method_43470("Welcome"), button -> switchPanel(PANEL_HOME))
                .method_46434(buttonX + 26, buttonY, 74, buttonHeight)
                .method_46431());
        class_4185 panelChangeLog = this.method_37063(class_4185.method_46430(class_2561.method_43470("Change Log"), button -> switchPanel(PANEL_CHANGELOG))
                .method_46434(buttonX, buttonY + buttonSpacing, buttonWidth, buttonHeight)
                .method_46431());
        class_4185 panelTools = this.method_37063(class_4185.method_46430(class_2561.method_43470("Tools"), button -> switchPanel(PANEL_TOOLS))
                .method_46434(buttonX, buttonY + (buttonSpacing * 2), buttonWidth, buttonHeight)
                .method_46431());
        class_4185 panelSettings = this.method_37063(class_4185.method_46430(class_2561.method_43470("Settings"), button -> switchPanel(PANEL_SETTINGS))
                .method_46434(buttonX, buttonY + (buttonSpacing * 3), buttonWidth, buttonHeight)
                .method_46431());

        sidebarButtons.add(welcomeButton);
        sidebarButtons.add(panelChangeLog);
        sidebarButtons.add(panelTools);
        sidebarButtons.add(panelSettings);
    }

    private void switchPanel(int panelId) {
        removeSettingsWidgets();
        clearWidgetList(debugButtons);
        clearWidgetList(toolButtons);
        this.currentPanel = panelId;
        this.scrollOffset = 0;
        this.maxScrollOffset = 0;
        this.method_25426();
    }

    private void clearWidgetList(List<? extends class_339> widgets) {
        for (class_339 widget : widgets) {
            this.method_37066(widget);
        }
        widgets.clear();
    }

    private void removeSettingsWidgets() {
        if (debugCheckbox != null && this.method_25396().contains(debugCheckbox)) {
            this.method_37066(debugCheckbox);
        }
        if (designMusicCheckbox != null && this.method_25396().contains(designMusicCheckbox)) {
            this.method_37066(designMusicCheckbox);
        }
        if (uninstallKoilButton != null && this.method_25396().contains(uninstallKoilButton)) {
            this.method_37066(uninstallKoilButton);
        }
        if (downloadDummyFilesButton != null && this.method_25396().contains(downloadDummyFilesButton)) {
            this.method_37066(downloadDummyFilesButton);
        }
        if (deleteBootstrapFilesButton != null && this.method_25396().contains(deleteBootstrapFilesButton)) {
            this.method_37066(deleteBootstrapFilesButton);
        }
        debugCheckbox = null;
        designMusicCheckbox = null;
        uninstallKoilButton = null;
        downloadDummyFilesButton = null;
        deleteBootstrapFilesButton = null;
    }

    private void refreshDetectedTools() {
        detectedTools.clear();
        Set<String> classNames = new LinkedHashSet<>();
        classNames.add("com.spirit.client.gui.ide.FileExplorerScreen");
        classNames.add("com.spirit.client.gui.ide.FileEditorScreen");
        classNames.add("com.spirit.client.gui.ModConfigScreen");
        classNames.add("com.spirit.client.gui.ide.KoilImageEditorScreen");
        classNames.add("com.spirit.client.gui.ide.KoilVideoEditorScreen");
        classNames.add("com.spirit.client.gui.ide.KoilAudioEditorScreen");
        classNames.add("com.spirit.client.gui.tool.KoilToolScreen");
        classNames.add("com.spirit.client.gui.tool.PackageBuilderScreen");
        classNames.add("com.spirit.client.gui.tool.PerformanceOptimizerScreen");

        classNames.addAll(scanToolScreenClassNames());

        for (String className : classNames) {
            ToolEntry entry = buildToolEntry(className);
            if (entry != null && !containsTool(entry.className)) {
                detectedTools.add(entry);
            }
        }
        detectedTools.sort(Comparator.comparing(entry -> entry.title.toLowerCase()));
    }

    private boolean containsTool(String className) {
        for (ToolEntry entry : detectedTools) {
            if (entry.className.equals(className)) {
                return true;
            }
        }
        return false;
    }

    private Set<String> scanToolScreenClassNames() {
        Set<String> classNames = new LinkedHashSet<>();
        try {
            CodeSource codeSource = Main.class.getProtectionDomain().getCodeSource();
            if (codeSource == null || codeSource.getLocation() == null) {
                return classNames;
            }
            Path sourcePath = Paths.get(codeSource.getLocation().toURI());
            if (!Files.exists(sourcePath) || !sourcePath.toString().endsWith(".jar")) {
                return classNames;
            }

            try (JarFile jarFile = new JarFile(sourcePath.toFile())) {
                var entries = jarFile.entries();
                while (entries.hasMoreElements()) {
                    JarEntry entry = entries.nextElement();
                    String name = entry.getName();
                    if (!name.endsWith(".class")) {
                        continue;
                    }
                    if (!name.startsWith("com/spirit/client/gui/")) {
                        continue;
                    }
                    String className = name.substring(0, name.length() - 6).replace('/', '.');
                    if (isToolScreenClassName(className)) {
                        classNames.add(className);
                    }
                }
            }
        } catch (Exception ignored) {
        }
        return classNames;
    }

    private boolean isToolScreenClassName(String className) {
        String simpleName = className.substring(className.lastIndexOf('.') + 1);
        if (!simpleName.endsWith("Screen")) {
            return false;
        }
        if (simpleName.equals("KoilMenuScreen") || simpleName.equals("FundingScreen")) {
            return false;
        }
        String lower = className.toLowerCase();
        return lower.contains("tool") || lower.contains("editor") || lower.contains("explorer") || lower.contains("config");
    }

    private ToolEntry buildToolEntry(String className) {
        try {
            Class<?> rawClass = Class.forName(className);
            if (!class_437.class.isAssignableFrom(rawClass)) {
                return null;
            }
            @SuppressWarnings("unchecked")
            Class<? extends class_437> screenClass = (Class<? extends class_437>) rawClass;
            screenClass.getDeclaredConstructor();
            String simpleName = screenClass.getSimpleName();
            return new ToolEntry(className, prettifyToolName(simpleName), buildToolDescription(simpleName));
        } catch (Exception ignored) {
            return null;
        }
    }

    private String prettifyToolName(String simpleName) {
        String base = simpleName.replace("Koil", "").replace("Screen", "");
        base = base.replaceAll("([a-z])([A-Z])", "$1 $2").trim();
        if (base.isEmpty()) {
            return "Tool";
        }
        return base;
    }

    private String buildToolDescription(String simpleName) {
        String lower = simpleName.toLowerCase();
        if (lower.contains("explorer")) {
            return "Browse Koil files and folders.";
        }
        if (lower.contains("config")) {
            return "Open Koil configuration editing tools.";
        }
        if (lower.contains("editor")) {
            return "Open a Koil editor tool.";
        }
        return "Open this Koil tool screen.";
    }

    private void initToolButtons() {
        clearWidgetList(toolButtons);
        int startY = 118;
        int buttonWidth = Math.min(220, Math.max(140, this.field_22789 - 180));
        for (int i = 0; i < detectedTools.size(); i++) {
            ToolEntry entry = detectedTools.get(i);
            int buttonY = startY + (i * 24);
            class_4185 toolButton = this.method_37063(class_4185.method_46430(class_2561.method_43470(entry.title), button -> openToolScreen(entry.className))
                    .method_46434(140, buttonY, buttonWidth, 20)
                    .method_46431());
            toolButton.method_47400(class_7919.method_47407(class_2561.method_43470(entry.description)));
            toolButtons.add(toolButton);
        }
    }

    private void updateToolButtonPositions() {
        for (int i = 0; i < toolButtons.size(); i++) {
            class_339 widget = toolButtons.get(i);
            int buttonY = 118 + (i * 24) - scrollOffset;
            widget.method_46421(140);
            widget.method_46419(buttonY);
            widget.field_22764 = buttonY + widget.method_25364() > 108 && buttonY < this.field_22790 - 24;
            widget.field_22763 = widget.field_22764;
        }
        int contentHeight = detectedTools.size() * 24;
        updateMaxScrollOffset(contentHeight, this.field_22790 - 150);
    }

    private void openToolScreen(String className) {
        try {
            if ("com.spirit.client.gui.ide.FileExplorerScreen".equals(className)) {
                assert this.field_22787 != null;
                this.field_22787.method_1507(FileExplorerScreen.openAtPath("/"));
                UiSoundHelper.playButtonClick();
                return;
            }
            Class<?> rawClass = Class.forName(className);
            if (!class_437.class.isAssignableFrom(rawClass)) {
                return;
            }
            Constructor<?> constructor = rawClass.getDeclaredConstructor();
            constructor.setAccessible(true);
            class_437 screen = (class_437) constructor.newInstance();
            assert this.field_22787 != null;
            this.field_22787.method_1507(screen);
            UiSoundHelper.playButtonClick();
        } catch (Exception ignored) {
        }
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        assert field_22787 != null;
        KoilScreenBackgrounds.render(context, field_22787, this.field_22789, this.field_22790);

        context.method_51433(this.field_22793, "Version - " + version(), this.field_22789 - 100, 10, new Color(uiColorHeaderTitleText, true).getRGB(), true);
        context.method_51448().method_22903();
        context.method_51448().method_22905(0.5f, 0.5f, 1.0F);
        context.method_51433(this.field_22793, "By: SpiritXIV", (int) ((this.field_22789 - 100) / 0.5f), (int) (20 / 0.5f), new Color(uiColorHeaderSubTitleText, true).getRGB(), true);
        context.method_51448().method_22909();
        context.method_25294(0, 0, this.field_22789, this.field_22790, KoilScreenBackgrounds.overlayColor(field_22787));
        context.method_49601(0, 0, this.field_22789, this.field_22790, new Color(uiColorBackgroundBorder, true).getRGB());
        context.method_25294(0, 0, this.field_22789, 60, new Color(uiColorHeader, true).getRGB());
        context.method_49601(0, 0, this.field_22789, 60, new Color(uiColorBackgroundBorder, true).getRGB());
        context.method_25294(127, 62, this.field_22789, this.field_22790, new Color(uiColorContentBase, true).getRGB());
        context.method_49601(127, 62, this.field_22789, this.field_22790, new Color(uiColorBackgroundBorder, true).getRGB());
        context.method_25294(0, 62, 125, this.field_22790, new Color(uiColorContentBase, true).getRGB());
        context.method_49601(0, 62, 125, this.field_22790, new Color(uiColorBackgroundBorder, true).getRGB());
        context.method_25290(LOGO_TEXTURE, 10, 5, 0, 0, 45, 45, 45, 45);
        File logoTexture = new File(uiImageDirectory, "icon.png");
        ImageTextureService.markFilePersistent(logoTexture);
        context.method_51448().method_22903();
        context.method_51448().method_22905(2, 2, 1.0F);
        context.method_51433(this.field_22793, "Koil", 34, 6, new Color(uiColorHeaderTitleText, true).getRGB(), true);
        context.method_51448().method_22909();
        context.method_51433(this.field_22793, "Manager Menu - InDEV", 68, 35, new Color(uiColorHeaderSubTitleText, true).getRGB(), true);

        switch (currentPanel) {
            case PANEL_HOME:
                renderHome(context, mouseX, mouseY, delta);
                break;
            case PANEL_WIKI:
                renderHomeWiki(context, mouseX, mouseY, delta);
                break;
            case PANEL_CHANGELOG:
                renderMenuChangeLog(context, mouseX, mouseY, delta);
                break;
            case PANEL_TOOLS:
                renderToolsPanel(context, mouseX, mouseY, delta);
                break;
            case PANEL_BOOK:
                renderBookDetailPanel(context, mouseX, mouseY, delta);
                break;
            case PANEL_SETTINGS:
                renderSettingsPanel(context, mouseX, mouseY, delta);
                break;
            case PANEL_DEBUG:
                renderDebugPanel(context, mouseX, mouseY, delta);
                break;
            case PANEL_DEBUG_VISUALS:
                renderDebugVisualsPanel(context, mouseX, mouseY, delta);
                break;
            case PANEL_DEBUG_CONSOLE:
                renderDebugConsolePanel(context, mouseX, mouseY, delta);
                break;
            default:
                renderHome(context, mouseX, mouseY, delta);
                switchPanel(PANEL_HOME);
        }

        super.method_25394(context, mouseX, mouseY, delta);
    }

    private void renderHome(class_332 context, int mouseX, int mouseY, float delta) {
        context.method_51448().method_22903();
        context.method_51448().method_22905(1.2F, 1.2F, 1.0F);
        context.method_51433(this.field_22793, "Welcome", (int) (140 / 1.2F), (int) (75 / 1.2F), new Color(uiColorContentBaseTitleText, true).getRGB(), true);
        context.method_51448().method_22909();
        context.method_51433(this.field_22793, "A project-sized manager layer for Koil's runtime tools, guides, and in-game utilities.", 140, 92, new Color(uiColorContentBaseDescriptionText, true).getRGB(), false);
        context.method_51433(this.field_22793, "Use the left rail for the change log, tools, settings, and the funding shortcut.", 140, 104, new Color(uiColorContentBaseDescriptionText, true).getRGB(), false);

        String longText = "Koil is built as a long-term platform project rather than a single feature mod. The manager menu is the operating surface for that platform: it should explain what Koil is, expose the most useful tools quickly, and keep the runtime UI readable.\n\nThe left rail now uses a dedicated fundraising button beside Welcome, then keeps the main navigation focused on Change Log, Tools, and Settings.\n\nUse Tools to launch Koil screens like the file explorer, file editor, config editor, and any other Koil tool screen that can be discovered at runtime.";
        renderScrollableText(context, longText, 140, 128, this.field_22789 - 220, this.field_22790 - 150);
    }

    private void renderToolsPanel(class_332 context, int mouseX, int mouseY, float delta) {
        context.method_51448().method_22903();
        context.method_51448().method_22905(1.2F, 1.2F, 1.0F);
        context.method_51433(this.field_22793, "Tools", (int) (140 / 1.2F), (int) (75 / 1.2F), new Color(uiColorContentBaseTitleText, true).getRGB(), true);
        context.method_51448().method_22909();

        int toolCount = detectedTools.size();
        context.method_51433(this.field_22793, "Koil tools detected: " + toolCount, 140, 92, new Color(uiColorContentBaseDescriptionText, true).getRGB(), false);
        context.method_51433(this.field_22793, "Hover a tool to see what it does, then click it to open that screen.", 140, 104, new Color(uiColorContentBaseDescriptionText, true).getRGB(), false);

        updateToolButtonPositions();

        if (toolCount == 0) {
            context.method_51433(this.field_22793, "No tool screens were detected.", 140, 132, new Color(uiColorContentBaseDescriptionText, true).getRGB(), false);
            maxScrollOffset = 0;
            return;
        }

        int infoY = 118 + (toolCount * 24) - scrollOffset;
        if (infoY + 24 > 108 && infoY < this.field_22790 - 24) {
            context.method_51433(this.field_22793, "New Koil editor, explorer, tool, and config screens can show up here automatically.", 140, infoY + 12, new Color(uiColorHeaderSubTitleText, true).getRGB(), false);
        }
    }

    private void renderHomeWiki(class_332 context, int mouseX, int mouseY, float delta) {
        context.method_51448().method_22903();
        context.method_51448().method_22905(1.2F, 1.2F, 1.0F);
        context.method_51433(this.field_22793, "Wiki", (int) (140 / 1.2F), (int) (75 / 1.2F), new Color(uiColorContentBaseTitleText, true).getRGB(), true);
        context.method_51448().method_22909();
        context.method_51433(this.field_22793, "Browse Koil guides and references.", 140, 92, new Color(uiColorContentBaseDescriptionText, true).getRGB(), false);

        int yOffset = 118;
        int itemHeight = 54;
        int viewportHeight = this.field_22790 - 140;

        updateMaxScrollOffset(books.size(), itemHeight, viewportHeight);

        for (int i = 0; i < books.size(); i++) {
            MenuBookEntry book = books.get(i);
            int iconX = 140;
            int iconY = yOffset + (i * itemHeight) - scrollOffset;

            if (iconY + itemHeight > 108 && iconY < this.field_22790 - 24) {
                context.method_25290(book.iconTexture(), iconX, iconY, 0, 0, 32, 32, 32, 32);
                context.method_51433(this.field_22793, book.name(), iconX + 42, iconY, new Color(uiColorContentBaseTitleText, true).getRGB(), false);
                context.method_51433(this.field_22793, "Author: " + book.miniCredits(), iconX + 42, iconY + 12, new Color(uiColorContentBaseDescriptionText, true).getRGB(), false);
                context.method_51433(this.field_22793, "Pages: " + book.pageCount(), iconX + 42, iconY + 24, new Color(uiColorHeaderSubTitleText, true).getRGB(), false);
            }
        }
    }

    private void renderMenuChangeLog(class_332 context, int mouseX, int mouseY, float delta) {
        UpdateScreenData.UpdateData updateData = UpdateScreenData.readLocalData();
        boolean betaTester = UpdateScreenData.isBetaTester();
        List<UpdateScreenData.Release> releases = UpdateScreenData.releasesForBranch(updateData, null, betaTester);

        context.method_51448().method_22903();
        context.method_51448().method_22905(1.2F, 1.2F, 1.0F);
        context.method_51433(this.field_22793, "Change Log", (int) (140 / 1.2F), (int) (75 / 1.2F), new Color(uiColorContentBaseTitleText, true).getRGB(), true);
        context.method_51448().method_22909();
        context.method_51433(this.field_22793, "Release timeline for visible branches.", 140, 92, new Color(uiColorContentBaseDescriptionText, true).getRGB(), false);

        int top = 118;
        int bottom = this.field_22790 - 24;
        context.method_44379(140, top, this.field_22789 - 18, bottom);
        UpdateScreenData.TimelineRenderResult result = UpdateScreenData.renderReleaseTimelineInteractive(
                context,
                this.field_22793,
                updateData,
                releases,
                140,
                top + 6,
                this.field_22789 - 168,
                this.scrollOffset,
                top,
                bottom,
                betaTester,
                mouseX,
                mouseY
        );
        context.method_44380();
        this.maxScrollOffset = Math.max(0, result.contentHeight - (bottom - top - 8));
        this.scrollOffset = Math.max(0, Math.min(this.scrollOffset, this.maxScrollOffset));
        if (releases.isEmpty()) {
            context.method_51433(this.field_22793, "No release entries were found for this branch.", 150, top + 12, new Color(uiColorContentBaseDescriptionText, true).getRGB(), false);
        }
        UpdateScreenData.renderHoverPopup(context, this.field_22793, result, mouseX, mouseY, this.field_22789, this.field_22790);
    }

    private void renderBookDetailPanel(class_332 context, int mouseX, int mouseY, float delta) {
        if (selectedBooks != null) {
            int iconX = 140;
            int iconY = 88;
            String bookText = selectedBooks.description();

            context.method_51448().method_22903();
            context.method_51448().method_22905(1.2F, 1.2F, 1.0F);
            context.method_51433(this.field_22793, selectedBooks.name(), (int) ((iconX + 40) / 1.2F), (int) (75 / 1.2F), new Color(uiColorContentBaseTitleText, true).getRGB(), true);
            context.method_51448().method_22909();
            context.method_51433(this.field_22793, "Author: " + selectedBooks.miniCredits(), iconX + 40, 92, new Color(uiColorContentBaseDescriptionText, true).getRGB(), false);
            context.method_51433(this.field_22793, "Page " + selectedBooks.currentPage() + " / " + selectedBooks.pageCount(), iconX + 40, 104, new Color(uiColorHeaderSubTitleText, true).getRGB(), false);
            context.method_25290(selectedBooks.iconTexture(), iconX, iconY, 0, 0, 32, 32, 32, 32);
            renderScrollableOrderedText(context, this.field_22793.method_1728(class_5348.method_29430(bookText), this.field_22789 - 190), 140, 128, this.field_22789 - 190, this.field_22790 - 150, new Color(uiColorContentBaseDescriptionText, true).getRGB());
        }
    }

    private void renderSettingsPanel(class_332 context, int mouseX, int mouseY, float delta) {
        context.method_51448().method_22903();
        context.method_51448().method_22905(1.2F, 1.2F, 1.0F);
        context.method_51433(this.field_22793, "Settings", (int) (140 / 1.2F), (int) (75 / 1.2F), new Color(uiColorContentBaseTitleText, true).getRGB(), true);
        context.method_51448().method_22909();
        context.method_51433(this.field_22793, "Manager-level toggles and system actions live here now that the old config pane is gone.", 140, 92, new Color(uiColorContentBaseDescriptionText, true).getRGB(), false);

        if (debugCheckbox == null) {
            boolean isDebugModeEnabled = JSONFileEditor.getValueFromJson(configFilePath, "debug").getAsBoolean();
            boolean designMusicisDebugModeEnabled = JSONFileEditor.getValueFromJson(configFilePath, "designMusic").getAsBoolean();

            debugCheckbox = this.method_37063(new class_4286(140, 118, 170, 20, class_2561.method_43470("Toggle Debug"), isDebugModeEnabled) {
                @Override
                public void method_25306() {
                    boolean newDebugValue = !debugCheckbox.method_20372();
                    try {
                        JSONFileEditor.updateValueInJson(configFilePath, "debug", new JsonPrimitive(newDebugValue));
                    } catch (IOException e) {
                        SUBLOGGER.logE("File-Management thread", "Failed to update debug config value: " + e.getMessage());
                    }
                }
            });

            designMusicCheckbox = this.method_37063(new class_4286(140, 146, 170, 20, class_2561.method_43470("Toggle Design Music"), designMusicisDebugModeEnabled) {
                @Override
                public void method_25306() {
                    boolean newDesignMusicValue = !designMusicCheckbox.method_20372();
                    try {
                        JSONFileEditor.updateValueInJson(configFilePath, "designMusic", new JsonPrimitive(newDesignMusicValue));
                    } catch (IOException e) {
                        SUBLOGGER.logE("File-Management thread", "Failed to update designMusic config value: " + e.getMessage());
                    }
                }
            });
        }

        if (uninstallKoilButton == null) {
            uninstallKoilButton = this.method_37063(class_4185.method_46430(class_2561.method_43470("Uninstall Koil"), button -> confirmUninstallKoil()).method_46434(140, 212, 150, 20).method_46431());
        }
    }

    private void renderDebugPanel(class_332 context, int mouseX, int mouseY, float delta) {
        context.method_51448().method_22903();
        context.method_51448().method_22905(1.2F, 1.2F, 1.0F);
        context.method_51433(this.field_22793, "Debug/Dev", (int) (140 / 1.2F), (int) (75 / 1.2F), new Color(uiColorContentBaseTitleText, true).getRGB(), true);
        context.method_51448().method_22909();
        context.method_51433(this.field_22793, "This is the debug menu for testing many things, mostly visual though.", 140, 92, new Color(uiColorContentBaseDescriptionText, true).getRGB(), false);

        String longText = "This is the debug menu for testing many things, mostly visual though.\nYou can find everything here that is in dev and made for testing.\n\nDownload Core Files reruns Koil's bootstrap file flow and refreshes the runtime files it depends on.\nDelete Key/Catcher removes ./koil/sys/key.json and ./koil/sys/catcher.json so they can be downloaded again on demand.";
        int maxWidth = this.field_22789 / 2 + 50;
        List<String> wrappedText = wrapText(longText, maxWidth);

        int y = 118 - scrollOffset;
        for (String line : wrappedText) {
            if (y >= 118 && y <= this.field_22790 - 24) {
                context.method_51433(this.field_22793, line, 140, y, new Color(uiColorContentBaseDescriptionText, true).getRGB(), true);
            }
            y += this.field_22793.field_2000;
        }

        int buttonsY = y + 10;
        if (downloadDummyFilesButton == null) {
            downloadDummyFilesButton = this.method_37063(class_4185.method_46430(class_2561.method_43470("Download Core Files"), button -> refreshBootstrapFiles())
                    .method_46434(140, buttonsY, 170, 20)
                    .method_46431());
            debugButtons.add(downloadDummyFilesButton);
        }
        if (deleteBootstrapFilesButton == null) {
            deleteBootstrapFilesButton = this.method_37063(class_4185.method_46430(class_2561.method_43470("Delete Key/Catcher"), button -> confirmDeleteBootstrapFiles())
                    .method_46434(140, buttonsY + 28, 170, 20)
                    .method_46431());
            debugButtons.add(deleteBootstrapFilesButton);
        }

        downloadDummyFilesButton.method_46421(140);
        downloadDummyFilesButton.method_46419(buttonsY);
        deleteBootstrapFilesButton.method_46421(140);
        deleteBootstrapFilesButton.method_46419(buttonsY + 28);

        int contentHeight = wrappedText.size() * this.field_22793.field_2000 + 66;
        maxScrollOffset = Math.max(0, contentHeight - (this.field_22790 - 118));
    }

    private void refreshBootstrapFiles() {
        Main.refreshBootstrapFiles();
        UiSoundHelper.playButtonClick();
    }

    private void deleteBootstrapFiles() {
        Main.deleteCoreBootstrapFiles();
        UiSoundHelper.playButtonClick();
    }

    private void confirmDeleteBootstrapFiles() {
        class_310 client = class_310.method_1551();
        if (client == null) {
            deleteBootstrapFiles();
            return;
        }
        client.method_1507(new class_410(confirmed -> {
            if (confirmed) {
                deleteBootstrapFiles();
            }
            client.method_1507(this);
        }, class_2561.method_43470("Delete Core Files"), class_2561.method_43470("Are you sure you want to delete key.json and catcher.json?"), class_2561.method_43470("Delete"), class_2561.method_43470("Cancel")));
    }

    private void confirmUninstallKoil() {
        class_310 client = class_310.method_1551();
        if (client == null) {
            uninstallKoil();
            return;
        }
        client.method_1507(new class_410(confirmed -> {
            if (confirmed) {
                uninstallKoil();
            } else {
                client.method_1507(this);
            }
        }, class_2561.method_43470("Uninstall Koil"), class_2561.method_43470("Are you sure you want to delete Koil files and close the game?"), class_2561.method_43470("Uninstall"), class_2561.method_43470("Cancel")));
    }

    private void uninstallKoil() {
        Path koilDir = Paths.get("./koil");
        Path specificFile = Paths.get("./mods", "koil-" + version() + ".jar");
        Path koilConfigFile = Paths.get("./config/koil.json");

        try {
            if (Files.exists(koilDir)) {
                Files.walk(koilDir).sorted(Comparator.reverseOrder()).forEach(path -> {
                    try {
                        Files.delete(path);
                    } catch (IOException e) {
                        SUBLOGGER.logE("File-Management thread", "Failed to delete during Koil uninstall: " + path + " - " + e.getMessage());
                    }
                });
            }

            if (Files.exists(specificFile)) {
                Files.delete(specificFile);
            }

            if (Files.exists(koilConfigFile)) {
                Files.delete(koilConfigFile);
            }

            class_310 client = class_310.method_1551();
            if (client != null) {
                client.method_1490();
            }
        } catch (IOException e) {
            SUBLOGGER.logE("File-Management thread", "Error occurred during Koil uninstallation: " + e.getMessage());
        }
    }

    private void renderDebugVisualsPanel(class_332 context, int mouseX, int mouseY, float delta) {
        context.method_51448().method_22903();
        context.method_51448().method_22905(1.2F, 1.2F, 1.0F);
        context.method_51433(this.field_22793, "Debug Visuals", (int) (140 / 1.2F), (int) (75 / 1.2F), new Color(uiColorContentBaseTitleText, true).getRGB(), true);
        context.method_51448().method_22909();
        context.method_51433(this.field_22793, "Visual toast and display tests for Koil's in-game UI.", 140, 92, new Color(uiColorContentBaseDescriptionText, true).getRGB(), false);

        if (debugButtons.isEmpty()) {
            class_4185 debugVisButton1 = this.method_37063(class_4185.method_46430(class_2561.method_43470("Test Console Toasts"), button -> {
                ConsoleToast.add(field_22787.method_1566(), ConsoleToast.Type.CONSOLE, class_2561.method_30163("CONSOLE"), class_2561.method_30163("toast"));
                ConsoleToast.add(field_22787.method_1566(), ConsoleToast.Type.CONSOLE_INFO, class_2561.method_30163("CONSOLE_INFO"), class_2561.method_30163("toast"));
                ConsoleToast.add(field_22787.method_1566(), ConsoleToast.Type.CONSOLE_WARNING, class_2561.method_30163("CONSOLE_WARNING"), class_2561.method_30163("toast"));
                ConsoleToast.add(field_22787.method_1566(), ConsoleToast.Type.CONSOLE_ERROR, class_2561.method_30163("CONSOLE_ERROR"), class_2561.method_30163("toast"));
                ConsoleToast.add(field_22787.method_1566(), ConsoleToast.Type.CONSOLE_FATAL, class_2561.method_30163("CONSOLE_FATAL"), class_2561.method_30163("toast"));
                ConsoleToast.add(field_22787.method_1566(), ConsoleToast.Type.CONSOLE_DEBUG, class_2561.method_30163("CONSOLE_DEBUG"), class_2561.method_30163("toast"));
                ConsoleToast.add(field_22787.method_1566(), ConsoleToast.Type.CONSOLE_UPDATE, class_2561.method_30163("CONSOLE_UPDATE"), class_2561.method_30163("toast"));
                ConsoleToast.add(field_22787.method_1566(), ConsoleToast.Type.CONSOLE_OTHER, class_2561.method_30163("CONSOLE_OTHER"), class_2561.method_30163("toast"));
            }).method_46434(140, 118, 150, 20).method_46431());

            class_4185 debugVisButton2 = this.method_37063(class_4185.method_46430(class_2561.method_43470("Test Message Toasts"), button -> {
                KoilMessageToast.add(field_22787.method_1566(), KoilMessageToast.Type.MUSIC, class_2561.method_30163("MUSIC"), class_2561.method_30163("toast"));
                KoilMessageToast.add(field_22787.method_1566(), KoilMessageToast.Type.ANNOUNCEMENT, class_2561.method_30163("ANNOUNCEMENT"), class_2561.method_30163("toast"));
                KoilMessageToast.add(field_22787.method_1566(), KoilMessageToast.Type.KORO_MESSAGE, class_2561.method_30163("KORO_MESSAGE"), class_2561.method_30163("toast"));
            }).method_46434(140, 142, 150, 20).method_46431());

            class_4185 debugVisButton3 = this.method_37063(class_4185.method_46430(class_2561.method_43470("Test Update Toasts"), button -> {
                KoilUpdateToast.add(field_22787.method_1566(), KoilUpdateToast.Type.UPDATE_UI, class_2561.method_30163("UPDATE_UI"), class_2561.method_30163("toast"));
                KoilUpdateToast.add(field_22787.method_1566(), KoilUpdateToast.Type.UPDATE_DEBUG, class_2561.method_30163("UPDATE_DEBUG"), class_2561.method_30163("toast"));
                KoilUpdateToast.add(field_22787.method_1566(), KoilUpdateToast.Type.UPDATE_API, class_2561.method_30163("UPDATE_JAPI"), class_2561.method_30163("toast"));
                KoilUpdateToast.add(field_22787.method_1566(), KoilUpdateToast.Type.UPDATE_CONSOLE, class_2561.method_30163("UPDATE_CONSOLE"), class_2561.method_30163("toast"));
                KoilUpdateToast.add(field_22787.method_1566(), KoilUpdateToast.Type.UPDATE_OTHER, class_2561.method_30163("UPDATE_ALL"), class_2561.method_30163("toast"));
            }).method_46434(140, 166, 150, 20).method_46431());

            debugButtons.add(debugVisButton1);
            debugButtons.add(debugVisButton2);
            debugButtons.add(debugVisButton3);
        }
    }

    private void renderDebugConsolePanel(class_332 context, int mouseX, int mouseY, float delta) {
        context.method_51448().method_22903();
        context.method_51448().method_22905(1.2F, 1.2F, 1.0F);
        context.method_51433(this.field_22793, "Debug Console", (int) (140 / 1.2F), (int) (75 / 1.2F), new Color(uiColorContentBaseTitleText, true).getRGB(), true);
        context.method_51448().method_22909();
        context.method_51433(this.field_22793, "Open external debugging surfaces and Koil log utilities.", 140, 92, new Color(uiColorContentBaseDescriptionText, true).getRGB(), false);

        if (debugButtons.isEmpty()) {
            class_4185 consoleButton1 = this.method_37063(class_4185.method_46430(class_2561.method_43470("Open Koil Log"), button -> {
                assert this.field_22787 != null;
                this.field_22787.method_1507(new ConsoleScreen(this));
            }).method_46434(140, 118, 150, 20).method_46431());
            class_4185 consoleButton2 = this.method_37063(class_4185.method_46430(class_2561.method_43470("Pop Out Koil Log"), button -> WindowManager.openConsoleWindow(ConsoleChannel.KOIL))
                    .method_46434(296, 118, 150, 20)
                    .method_46431());
            debugButtons.add(consoleButton1);
            debugButtons.add(consoleButton2);
        }
    }

    private void switchPanelToBook(MenuBookEntry book) {
        this.selectedBooks = book;
        switchPanel(PANEL_BOOK);

        class_4185 prevButton = this.method_37063(class_4185.method_46430(class_2561.method_43470("<"), button -> selectedBooks.prevPage()).method_46434(154, 118, 16, 16).method_46431());
        class_4185 nextButton = this.method_37063(class_4185.method_46430(class_2561.method_43470(">"), button -> selectedBooks.nextPage()).method_46434(174, 118, 16, 16).method_46431());
        debugButtons.add(prevButton);
        debugButtons.add(nextButton);
    }

    @Override
    public boolean method_25402(double mouseX, double mouseY, int button) {
        if (button == 0 && currentPanel == PANEL_WIKI) {
            int yOffset = 146;
            int itemHeight = 54;
            for (int i = 0; i < books.size(); i++) {
                MenuBookEntry book = books.get(i);
                int iconY = yOffset + (i * itemHeight) - scrollOffset;
                if (mouseX >= 140 && mouseX <= this.field_22789 - 24 && mouseY >= iconY - 2 && mouseY <= iconY + 34) {
                    UiSoundHelper.playButtonClick();
                    switchPanelToBook(book);
                    return true;
                }
            }
        }
        return super.method_25402(mouseX, mouseY, button);
    }

    @Override
    public boolean method_25401(double mouseX, double mouseY, double amount) {
        scrollOffset = Math.max(0, Math.min(scrollOffset - (int) amount, maxScrollOffset));
        return true;
    }

    private void updateMaxScrollOffset(int totalItems, int itemHeight, int viewportHeight) {
        int totalContentHeight = totalItems * itemHeight;
        maxScrollOffset = Math.max(0, totalContentHeight - viewportHeight);
    }

    private void updateMaxScrollOffset(int contentHeight, int viewportHeight) {
        maxScrollOffset = Math.max(0, contentHeight - viewportHeight);
    }

    private void renderScrollableText(class_332 context, String text, int x, int y, int width, int height) {
        List<String> wrappedText = wrapText(text, width);
        int contentHeight = wrappedText.size() * (field_22793.field_2000 + 2);
        updateMaxScrollOffset(contentHeight, height);

        int textY = y - scrollOffset;
        for (String line : wrappedText) {
            if (textY + field_22793.field_2000 > y && textY < y + height) {
                context.method_51433(this.field_22793, line, x, textY, Color.WHITE.getRGB(), false);
            }
            textY += field_22793.field_2000 + 2;
        }
    }

    private void renderScrollableOrderedText(class_332 context, List<class_5481> wrappedLines, int x, int y, int width, int height, int color) {
        int contentHeight = wrappedLines.size() * (field_22793.field_2000 + 2);
        updateMaxScrollOffset(contentHeight, height);

        int textY = y - scrollOffset;
        for (class_5481 line : wrappedLines) {
            if (textY + field_22793.field_2000 > y && textY < y + height) {
                context.method_51430(this.field_22793, line, x, textY, color, false);
            }
            textY += field_22793.field_2000 + 2;
        }
    }

    private List<String> wrapText(String text, int maxWidth) {
        List<String> lines = new ArrayList<>();
        if (text == null || maxWidth <= 0) {
            return lines;
        }

        String[] paragraphs = text.split("\n");
        for (String paragraph : paragraphs) {
            String[] words = paragraph.split(" ");
            StringBuilder line = new StringBuilder();
            for (String word : words) {
                String testLine = (!line.isEmpty() ? line + " " : "") + word;
                if (field_22793.method_1727(testLine) > maxWidth) {
                    if (!line.isEmpty()) {
                        lines.add(line.toString());
                        line = new StringBuilder();
                    }
                }
                line.append((!line.isEmpty() ? " " : "")).append(word);
            }
            if (!line.isEmpty()) {
                lines.add(line.toString());
            }
        }
        return lines;
    }

    private void renderChangelog(class_332 context, String changeLog, int x, int y) {
        int finalY = y - scrollOffset;
        for (class_5481 line : this.field_22793.method_1728(class_2561.method_43470(changeLog), this.field_22789 - 160)) {
            if (finalY >= 80 && finalY <= this.field_22790 - 20) {
                context.method_51430(this.field_22793, line, x, finalY, new Color(uiColorContentBaseDescriptionText, true).getRGB(), false);
            }
            finalY += this.field_22793.field_2000 + 2;
        }
        int maxScroll = Math.max(0, finalY - this.field_22790 + 20);
        scrollOffset = Math.max(0, Math.min(scrollOffset, maxScroll));
    }

    private static class ToolEntry {
        private final String className;
        private final String title;
        private final String description;

        private ToolEntry(String className, String title, String description) {
            this.className = className;
            this.title = title;
            this.description = description;
        }
    }
}
