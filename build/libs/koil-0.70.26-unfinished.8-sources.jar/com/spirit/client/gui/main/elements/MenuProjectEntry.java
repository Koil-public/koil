package com.spirit.client.gui.main.elements;

import net.minecraft.class_2960;

public record MenuProjectEntry(class_2960 iconTexture, String name, String description, String credits, String miniDescription, String miniCredits) { }
