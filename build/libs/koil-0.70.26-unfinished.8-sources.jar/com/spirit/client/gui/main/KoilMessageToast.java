package com.spirit.client.gui.main;

import com.google.common.collect.ImmutableList;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_368;
import net.minecraft.class_374;
import net.minecraft.class_5481;
import org.jetbrains.annotations.Nullable;

import java.awt.*;
import java.util.List;
import java.util.stream.Stream;

import static com.spirit.Main.uiImageDirectory;
import static com.spirit.koil.api.util.file.image.ExternalImageLoader.loadExternalPngTexture;

@Environment(EnvType.CLIENT)
public class KoilMessageToast implements class_368 {
    private final Type type;
    private class_2561 title;
    private List<class_5481> lines;
    private long startTime;
    private boolean justUpdated;
    private final int width;

    class_2960 field_2207 = loadExternalPngTexture(uiImageDirectory, "koil_message_toasts.png");

    public KoilMessageToast(Type type, class_2561 title, @Nullable class_2561 description) {
        this(type, title, getTextAsList(description), Math.max(160, 30 + Math.max(class_310.method_1551().field_1772.method_27525(title), description == null ? 0 : class_310.method_1551().field_1772.method_27525(description))));
    }

    public static KoilMessageToast create(class_310 client, Type type, class_2561 title, class_2561 description) {
        class_327 textRenderer = client.field_1772;
        List<class_5481> list = textRenderer.method_1728(description, 200);
        Stream<class_5481> stream = list.stream();
        int i = Math.max(200, stream.mapToInt(textRenderer::method_30880).max().orElse(200));
        return new KoilMessageToast(type, title, list, i + 30);
    }

    private KoilMessageToast(Type type, class_2561 title, List<class_5481> lines, int width) {
        this.type = type;
        this.title = title;
        this.lines = lines;
        this.width = width;
    }

    private static ImmutableList<class_5481> getTextAsList(@Nullable class_2561 text) {
        return text == null ? ImmutableList.of() : ImmutableList.of(text.method_30937());
    }

    @Override
    public int method_29049() {
        return this.width;
    }

    @Override
    public int method_29050() {
        return 20 + Math.max(this.lines.size(), 1) * 12;
    }

    @Override
    public class_369 method_1986(class_332 context, class_374 manager, long startTime) {
        if (this.justUpdated) {
            this.startTime = startTime;
            this.justUpdated = false;
        }

        int i = this.method_29049();
        int j = this.method_29050();
        int l = Math.min(8, j - 28);

        int textureY = getTextureOffsetY(this.type);

        // Drawing the background
        this.drawPart(context, manager, i, textureY, 0, 28);

        for (int m = 28; m < j - l; m += 10) {
            this.drawPart(context, manager, i, textureY + 16, m, Math.min(16, j - m - l));
        }

        this.drawPart(context, manager, i, textureY + 32 - l, j - l, l);

        // Getting text colors
        int titleColor = getTitleColor(this.type);
        int descriptionColor = getDescriptionColor(this.type);

        // Drawing title and description with custom colors
        context.method_51439(manager.method_1995().field_1772, this.title, 18, 7, titleColor, false);
        for (int lineIndex = 0; lineIndex < this.lines.size(); ++lineIndex) {
            context.method_51430(manager.method_1995().field_1772, this.lines.get(lineIndex), 18, 18 + lineIndex * 12, descriptionColor, false);
        }

        return (double) (startTime - this.startTime) < (double) this.type.displayDuration * manager.method_48221() ? class_369.field_2210 : class_369.field_2209;
    }

    private int getTextureOffsetY(Type type) {
        return switch (type) {
            case MUSIC -> 0;
            case CONSOLE_INFO -> 32;
            case CONSOLE_WARNING -> 64;
            case CONSOLE_ERROR -> 96;
            case CONSOLE_FATAL -> 128;
            case CONSOLE_DEBUG -> 160;
            case ANNOUNCEMENT -> 192;
            case KORO_MESSAGE -> 224;
        };
    }

    private void drawPart(class_332 context, class_374 manager, int width, int textureV, int y, int height) {
        if (field_2207 == null) {
            int background = new Color(12, 14, 18, 232).getRGB();
            int border = getTitleColor(this.type);
            context.method_25294(0, y, width, y + height, background);
            if (y == 0) {
                context.method_25294(0, 0, 3, Math.max(height, method_29050()), border);
                context.method_49601(0, 0, width, method_29050(), new Color(42, 46, 56, 255).getRGB());
            }
            return;
        }
        int partWidth = width / 8;
        int j = Math.min(60, width - partWidth);

        context.method_25302(field_2207, 0, y, 0, 64 + textureV, partWidth, height);

        for (int k = partWidth; k < width - j; k += partWidth) {
            context.method_25302(field_2207, k, y, 32, 64 + textureV, Math.min(partWidth, width - k - j), height);
        }

        context.method_25302(field_2207, width - j, y, 160 - j, 64 + textureV, j, height);
    }

    private int getTitleColor(KoilMessageToast.Type type) {
        return switch (type) {
            case MUSIC -> new Color(127, 127, 127, 255).getRGB();
            case CONSOLE_INFO -> new Color(196, 176, 17, 255).getRGB();
            case CONSOLE_WARNING -> new Color(196, 96, 17, 255).getRGB();
            case CONSOLE_ERROR -> new Color(196, 17, 30, 255).getRGB();
            case CONSOLE_FATAL -> new Color(196, 17, 30, 255).getRGB();
            case CONSOLE_DEBUG -> new Color(45, 196, 17, 255).getRGB();
            case ANNOUNCEMENT -> new Color(104, 36, 36, 255).getRGB();
            case KORO_MESSAGE -> new Color(153, 153, 153, 255).getRGB();
        };
    }

    private int getDescriptionColor(KoilMessageToast.Type type) {
        return switch (type) {
            case MUSIC -> new Color(110, 110, 110, 255).getRGB();
            case CONSOLE_INFO -> new Color(156, 139, 14, 255).getRGB();
            case CONSOLE_WARNING -> new Color(158, 77, 14, 255).getRGB();
            case CONSOLE_ERROR -> new Color(142, 12, 21, 255).getRGB();
            case CONSOLE_FATAL -> new Color(143, 14, 24, 255).getRGB();
            case CONSOLE_DEBUG -> new Color(32, 136, 12, 255).getRGB();
            case ANNOUNCEMENT -> new Color(208, 115, 115, 255).getRGB();
            case KORO_MESSAGE -> new Color(131, 131, 131, 255).getRGB();
        };
    }

    public Type method_1987() {
        return this.type;
    }

    public static void add(class_374 manager, Type type, class_2561 title, @Nullable class_2561 description) {
        manager.method_1999(new KoilMessageToast(type, title, description));
    }

    @Environment(EnvType.CLIENT)
    public enum Type {
        MUSIC, // 3
        CONSOLE_INFO, // 4
        CONSOLE_WARNING, // 5
        CONSOLE_ERROR, // 6
        CONSOLE_FATAL, // 7
        CONSOLE_DEBUG,  // 8
        ANNOUNCEMENT, // 1
        KORO_MESSAGE; // 2

        final long displayDuration;

        Type(long displayDuration) {
            this.displayDuration = displayDuration;
        }

        Type() {
            this(12000L);
        }
    }
}
