package com.spirit.client.gui.browser;

import java.util.List;
import net.minecraft.class_2561;

public record ContentPreviewTooltipRegion(int x, int y, int width, int height, List<class_2561> lines) {
}
