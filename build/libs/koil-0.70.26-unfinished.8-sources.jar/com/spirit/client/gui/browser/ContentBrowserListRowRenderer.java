package com.spirit.client.gui.browser;

import com.spirit.client.gui.BrowserLayoutHelper;
import java.awt.Color;
import net.minecraft.class_2960;
import net.minecraft.class_327;
import net.minecraft.class_332;

import static com.spirit.koil.api.design.uiColorVal.uiColorNonSelectionHighlight;
import static com.spirit.koil.api.design.uiColorVal.uiColorSelectionHighlight;

public final class ContentBrowserListRowRenderer {
    private ContentBrowserListRowRenderer() {
    }

    public static void renderItem(class_332 context, class_327 textRenderer, class_2960 icon, class_2960 fallbackIcon, int x, int y, int entryWidth, int entryHeight, boolean selected, String title, String metadata) {
        renderItem(context, textRenderer, icon, fallbackIcon, x, y, entryWidth, entryHeight, selected, true, title, metadata);
    }

    public static void renderItem(class_332 context, class_327 textRenderer, class_2960 icon, class_2960 fallbackIcon, int x, int y, int entryWidth, int entryHeight, boolean selected, boolean drawBackground, String title, String metadata) {
        if (drawBackground) {
            int rowColor = new Color(selected ? uiColorSelectionHighlight : uiColorNonSelectionHighlight, true).getRGB();
            context.method_25294(x - 2, y - 2, x + entryWidth - 10, y + Math.min(entryHeight - 2, 38), rowColor);
        }

        class_2960 texture = icon != null ? icon : fallbackIcon;
        if (texture != null) {
            context.method_25290(texture,
                    x + BrowserLayoutHelper.LIST_ROW_ICON_OFFSET_X,
                    y + BrowserLayoutHelper.LIST_ROW_ICON_OFFSET_Y,
                    0,
                    0,
                    BrowserLayoutHelper.LIST_ROW_ICON_SIZE,
                    BrowserLayoutHelper.LIST_ROW_ICON_SIZE,
                    BrowserLayoutHelper.LIST_ROW_ICON_SIZE,
                    BrowserLayoutHelper.LIST_ROW_ICON_SIZE);
        }

        int textX = x + BrowserLayoutHelper.LIST_ROW_TEXT_OFFSET_X;
        int rightEdge = x + entryWidth - BrowserLayoutHelper.LIST_ROW_RIGHT_PADDING;
        int textWidth = Math.max(72, rightEdge - textX);
        String titleLabel = trim(textRenderer, title, textWidth);
        String metadataLabel = trim(textRenderer, metadata, textWidth);
        context.method_51433(textRenderer, titleLabel, textX, y + BrowserLayoutHelper.LIST_ROW_TITLE_OFFSET_Y, selected ? 0xFFFFFFFF : 0xFFF2F4F7, true);
        context.method_51433(textRenderer, metadataLabel, textX, y + BrowserLayoutHelper.LIST_ROW_META_OFFSET_Y, selected ? 0xFFD2DAE5 : 0xFFAAAAAA, false);
    }

    public static void renderModMenuStyleItem(class_332 context, class_327 textRenderer, class_2960 icon, class_2960 fallbackIcon, int x, int y, int entryWidth, String title, String metadata) {
        class_2960 texture = icon != null ? icon : fallbackIcon;
        if (texture != null) {
            context.method_25290(texture,
                    x + BrowserLayoutHelper.LIST_ROW_ICON_OFFSET_X,
                    y + BrowserLayoutHelper.LIST_ROW_ICON_OFFSET_Y,
                    0,
                    0,
                    BrowserLayoutHelper.LIST_ROW_ICON_SIZE,
                    BrowserLayoutHelper.LIST_ROW_ICON_SIZE,
                    BrowserLayoutHelper.LIST_ROW_ICON_SIZE,
                    BrowserLayoutHelper.LIST_ROW_ICON_SIZE);
        }

        int textX = x + BrowserLayoutHelper.LIST_ROW_TEXT_OFFSET_X;
        int textWidth = Math.max(72, entryWidth - (textX - x) - BrowserLayoutHelper.LIST_ROW_RIGHT_PADDING);
        context.method_51433(textRenderer, trim(textRenderer, title, textWidth), textX, y + BrowserLayoutHelper.LIST_ROW_TITLE_OFFSET_Y, 0xFFFFFF, true);
        context.method_51433(textRenderer, trim(textRenderer, metadata, textWidth), textX, y + BrowserLayoutHelper.LIST_ROW_META_OFFSET_Y, 0xAAAAAA, false);
    }

    private static String trim(class_327 textRenderer, String text, int maxWidth) {
        return textRenderer.method_27523(text == null ? "" : text, Math.max(24, maxWidth));
    }
}
