package com.spirit.client.gui.browser;

import com.spirit.client.gui.UiSoundHelper;
import java.awt.*;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_4280;

import static com.spirit.koil.api.design.uiColorVal.uiColorBackgroundBorder;
import static com.spirit.koil.api.design.uiColorVal.uiColorContentBaseTitleText;
import static com.spirit.koil.api.design.uiColorVal.uiColorHeader;
import static com.spirit.koil.api.design.uiColorVal.uiColorHeaderSubTitleText;

public class ContentBrowserListWidget<T> extends class_4280<ContentBrowserListWidget<T>.BrowserEntry> {
	private final BrowserEntryPresenter<T> presenter;
	private final class_2960 fallbackIcon;

	public ContentBrowserListWidget(
			class_310 client,
			int width,
			int top,
			int bottom,
			int itemHeight,
			class_2960 fallbackIcon,
			BrowserEntryPresenter<T> presenter
	) {
		super(client, width, 150, top, bottom, itemHeight);
		this.fallbackIcon = fallbackIcon;
		this.presenter = presenter;
	}

	@Override
	public int method_25322() {
		return this.field_22742 - 4;
	}

	@Override
	public int method_25342() {
		return this.field_19088 + 2;
	}

	@Override
	protected int method_25329() {
		return this.field_19087 - 6;
	}

	@Override
	protected void method_25325(class_332 context) {
	}

	public void updateEntries(List<T> entries) {
		this.method_25339();
		if (entries == null || entries.isEmpty()) {
			return;
		}
		if (this.presenter.isGroupingEnabled()) {
			Map<String, List<T>> grouped = new LinkedHashMap<>();
			for (T info : entries) {
				grouped.computeIfAbsent(this.presenter.getGroupLabel(info), ignored -> new ArrayList<>()).add(info);
			}
			for (Map.Entry<String, List<T>> group : grouped.entrySet()) {
				this.method_25321(new GroupHeaderEntry(group.getKey(), group.getValue().size()));
				for (T info : group.getValue()) {
					this.method_25321(new ItemEntry(info));
				}
			}
			return;
		}
		for (T info : entries) {
			this.method_25321(new ItemEntry(info));
		}
	}

	public void syncSelection() {
		for (int i = 0; i < this.method_25340(); i++) {
			BrowserEntry entry = this.method_25326(i);
			if (entry instanceof ItemEntry itemEntry && this.presenter.isSelected(itemEntry.info)) {
				this.method_25313(itemEntry);
				return;
			}
		}
		this.method_25313(null);
	}

	public interface BrowserEntryPresenter<T> {
		boolean isGroupingEnabled();

		String getGroupLabel(T info);

		boolean isSelected(T info);

		void onSelected(T info);

		class_2960 resolveIcon(T info);

		String title(T info);

		String metadata(T info);

		class_2561 narration(T info);
	}

	public abstract class BrowserEntry extends Entry<BrowserEntry> {
	}

	public class GroupHeaderEntry extends BrowserEntry {
		private final String label;
		private final int count;

		public GroupHeaderEntry(String label, int count) {
			this.label = label;
			this.count = count;
		}

		@Override
		public void render(class_332 context, int index, int y, int x, int entryWidth, int entryHeight, int mouseX, int mouseY, boolean hovered, float tickDelta) {
			int background = new Color(uiColorHeader, true).getRGB();
			int border = new Color(uiColorBackgroundBorder, true).getRGB();
			int title = new Color(uiColorContentBaseTitleText, true).getRGB();
			int detail = new Color(uiColorHeaderSubTitleText, true).getRGB();
			context.method_25294(x + 2, y + 2, x + entryWidth - 10, y + 20, background);
			context.method_49601(x + 2, y + 2, entryWidth - 12, 18, border);
			context.method_51433(ContentBrowserListWidget.this.field_22740.field_1772, this.label, x + 10, y + 8, title, false);
			String countLabel = this.count + (this.count == 1 ? " item" : " items");
			context.method_51433(ContentBrowserListWidget.this.field_22740.field_1772, countLabel, x + entryWidth - 24 - ContentBrowserListWidget.this.field_22740.field_1772.method_1727(countLabel), y + 8, detail, false);
		}

		@Override
		public boolean mouseClicked(double mouseX, double mouseY, int button) {
			if (button == 0) {
				UiSoundHelper.playButtonClick();
			}
			return false;
		}

		@Override
		public class_2561 getNarration() {
			return class_2561.method_30163(this.label);
		}
	}

	public class ItemEntry extends BrowserEntry {
		private final T info;

		public ItemEntry(T info) {
			this.info = info;
		}

		@Override
		public void render(class_332 context, int index, int y, int x, int entryWidth, int entryHeight, int mouseX, int mouseY, boolean hovered, float tickDelta) {
			class_2960 iconTexture = ContentBrowserListWidget.this.presenter.resolveIcon(this.info);
			boolean selected = ContentBrowserListWidget.this.method_25334() == this || ContentBrowserListWidget.this.presenter.isSelected(this.info);
			ContentBrowserListRowRenderer.renderItem(
					context,
					ContentBrowserListWidget.this.field_22740.field_1772,
					iconTexture,
					ContentBrowserListWidget.this.fallbackIcon,
					x,
					y,
					entryWidth,
					entryHeight,
					selected,
					ContentBrowserListWidget.this.presenter.title(this.info),
					ContentBrowserListWidget.this.presenter.metadata(this.info));
		}

		@Override
		public boolean mouseClicked(double mouseX, double mouseY, int button) {
			if (button != 0) {
				return false;
			}
			UiSoundHelper.playButtonClick();
			ContentBrowserListWidget.this.presenter.onSelected(this.info);
			ContentBrowserListWidget.this.method_25313(this);
			return true;
		}

		@Override
		public class_2561 getNarration() {
			return ContentBrowserListWidget.this.presenter.narration(this.info);
		}
	}
}
