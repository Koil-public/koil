package com.spirit.client.gui.browser;

import java.util.List;
import net.minecraft.class_2561;

public record ContentPreviewSourceOption(String id, String label, List<class_2561> tooltipLines) {
}
