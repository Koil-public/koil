package com.spirit.client.gui.browser;

import java.util.List;
import net.minecraft.class_2561;
import net.minecraft.class_2960;

public record ContentPreviewModel(
	class_2960 icon,
	String title,
	String idLabel,
	String idValue,
	String versionLabel,
	String authors,
	String sourceChipLabel,
	List<class_2561> sourceTooltipLines,
	List<ContentPreviewChip> headerChips,
	List<ContentPreviewChip> categoryChips,
	List<ContentPreviewSection> sections
) {
}
