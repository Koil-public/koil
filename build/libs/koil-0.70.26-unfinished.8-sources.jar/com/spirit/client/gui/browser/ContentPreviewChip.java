package com.spirit.client.gui.browser;

import java.util.List;
import net.minecraft.class_2561;

public record ContentPreviewChip(String label, int background, List<class_2561> tooltipLines, String actionId) {
	public ContentPreviewChip(String label, int background, List<class_2561> tooltipLines) {
		this(label, background, tooltipLines, "");
	}
}
