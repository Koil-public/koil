package com.spirit.client.gui;

import net.minecraft.class_1109;
import net.minecraft.class_310;
import net.minecraft.class_3417;

public final class UiSoundHelper {
    private UiSoundHelper() {
    }

    public static void playButtonClick() {
        class_310 client = class_310.method_1551();
        if (client == null) {
            return;
        }
        client.method_1483().method_4873(class_1109.method_47978(class_3417.field_15015, 1.0F));
    }

    public static void playDialClick() {
        class_310 client = class_310.method_1551();
        if (client == null) {
            return;
        }
        client.method_1483().method_4873(class_1109.method_47978(class_3417.field_15015, 2.0F));
    }

    public static void playQuickFixConfirm() {
        class_310 client = class_310.method_1551();
        if (client == null) {
            return;
        }
        client.method_1483().method_4873(class_1109.method_47978(class_3417.field_15015, 2.0F));
        client.method_1483().method_4873(class_1109.method_47978(class_3417.field_14725, 2));
    }
}
