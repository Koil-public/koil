package com.spirit.client.gui.options;

import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_3283;
import net.minecraft.class_3286;
import net.minecraft.class_437;
import net.minecraft.class_5218;
import net.minecraft.class_5219;
import net.minecraft.class_5375;
import net.minecraft.class_7712;
import net.minecraft.server.MinecraftServer;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

public final class WorldDatapackScreenHelper {
    private WorldDatapackScreenHelper() {
    }

    public static void open(class_437 returnScreen) {
        class_310 minecraft = class_310.method_1551();
        if (minecraft == null) {
            return;
        }
        if (isRemoteServer(minecraft)) {
            if (minecraft.field_1724 != null && minecraft.field_1724.method_5687(2)) {
                minecraft.field_1724.field_3944.method_45730("datapack list");
                minecraft.field_1724.method_7353(class_2561.method_43470("Requested server datapack list. Remote server datapacks cannot be managed from a local pack file screen unless the server exposes those files."), false);
            }
            return;
        }
        Path datapacksFolder = getDatapacksFolder(minecraft);
        try {
            Files.createDirectories(datapacksFolder);
        } catch (IOException ignored) {
            return;
        }
        class_3283 manager = class_3286.method_45286(datapacksFolder);
        manager.method_14445();
        class_7712 dataConfiguration = getDataConfiguration(minecraft);
        if (dataConfiguration != null && dataConfiguration.comp_1010() != null) {
            manager.method_14447(dataConfiguration.comp_1010().method_29547());
        }
        minecraft.method_1507(new class_5375(manager, ignored -> minecraft.method_1507(returnScreen), datapacksFolder, class_2561.method_43470("Data Packs")));
    }

    public static boolean canOpenDatapackManager() {
        class_310 minecraft = class_310.method_1551();
        if (minecraft == null || minecraft.field_1687 == null) {
            return false;
        }
        if (!isRemoteServer(minecraft)) {
            return true;
        }
        return minecraft.field_1724 != null && minecraft.field_1724.method_5687(2);
    }

    private static boolean isRemoteServer(class_310 minecraft) {
        return minecraft.field_1687 != null && minecraft.method_1576() == null;
    }

    private static Path getDatapacksFolder(class_310 minecraft) {
        MinecraftServer server = minecraft.method_1576();
        if (server != null) {
            return server.method_27050(class_5218.field_24186);
        }
        return FabricLoader.getInstance().getGameDir().resolve("datapacks");
    }

    private static class_7712 getDataConfiguration(class_310 minecraft) {
        MinecraftServer server = minecraft.method_1576();
        if (server == null) {
            return class_7712.field_40260;
        }
        class_5219 saveProperties = server.method_27728();
        if (saveProperties == null) {
            return class_7712.field_40260;
        }
        return saveProperties.method_29589();
    }
}
