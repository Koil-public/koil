package com.spirit.client.gui.options;

import com.spirit.client.gui.mod.ModMenuScreen;
import com.spirit.client.gui.shader.ShaderPackMenuScreen;
import com.spirit.koil.api.design.KoilVanillaScreenChrome;
import java.awt.*;
import java.nio.file.Path;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_5244;
import net.minecraft.class_5375;

import static com.spirit.koil.api.design.uiColorVal.uiColorHeaderSubTitleText;
import static com.spirit.koil.api.design.uiColorVal.uiColorHeaderTitleText;

public class ContentOptionsScreen extends class_437 {
    private final class_437 parent;

    public ContentOptionsScreen(class_437 parent) {
        super(class_2561.method_43470("Content"));
        this.parent = parent;
    }

    @Override
    protected void method_25426() {
        int leftX = this.field_22789 / 2 - 155;
        int rightX = this.field_22789 / 2 + 5;
        int y = this.field_22790 / 6 + 24;
        this.method_37063(class_4185.method_46430(class_2561.method_43470("Resource Packs"), button -> openResourcePackManager()).method_46434(leftX, y, 150, 20).method_46431());
        this.method_37063(class_4185.method_46430(class_2561.method_43470("Mods"), button -> this.field_22787.method_1507(new ModMenuScreen(this))).method_46434(rightX, y, 150, 20).method_46431());
        y += 24;
        if (WorldDatapackScreenHelper.canOpenDatapackManager()) {
            this.method_37063(class_4185.method_46430(class_2561.method_43470("Data Packs"), button -> WorldDatapackScreenHelper.open(this)).method_46434(leftX, y, 150, 20).method_46431());
            this.method_37063(class_4185.method_46430(class_2561.method_43470("Shaders"), button -> this.field_22787.method_1507(new ShaderPackMenuScreen(this))).method_46434(rightX, y, 150, 20).method_46431());
        } else {
            this.method_37063(class_4185.method_46430(class_2561.method_43470("Shaders"), button -> this.field_22787.method_1507(new ShaderPackMenuScreen(this))).method_46434(leftX, y, 150, 20).method_46431());
        }
        this.method_37063(class_4185.method_46430(class_5244.field_24334, button -> this.field_22787.method_1507(this.parent)).method_46434(this.field_22789 / 2 - 100, this.field_22790 / 6 + 120, 200, 20).method_46431());
    }

    @Override
    public void method_25419() {
        if (this.field_22787 != null) {
            this.field_22787.method_1507(this.parent);
        }
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        class_310 client = class_310.method_1551();
        KoilVanillaScreenChrome.renderOptionsShell(context, client, this.field_22789, this.field_22790);
        context.method_51448().method_22903();
        context.method_51448().method_22905(1.5F, 1.5F, 1.0F);
        context.method_51439(this.field_22793, class_2561.method_43470("Options"), 25, 3, new Color(uiColorHeaderTitleText, true).getRGB(), true);
        context.method_51448().method_22909();
        context.method_51439(this.field_22793, class_2561.method_43470("Content"), 37, 18, new Color(uiColorHeaderSubTitleText, true).getRGB(), true);
        super.method_25394(context, mouseX, mouseY, delta);
    }

    private void openResourcePackManager() {
        if (this.field_22787 == null) {
            return;
        }
        class_310 minecraft = this.field_22787;
        Path packDir = minecraft.method_1479();
        minecraft.method_1507(new class_5375(minecraft.method_1520(), manager -> {
            minecraft.field_1690.method_49598(manager);
            minecraft.method_1507(this);
        }, packDir, class_2561.method_43471("resourcePack.title")));
    }
}
