package com.spirit.client.gui.shader;

import com.spirit.client.gui.browser.AbstractModrinthContentScreen;
import com.spirit.client.gui.BrowserLayoutHelper;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_5244;
import java.io.File;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import static com.spirit.Main.uiImageDirectory;
import static com.spirit.koil.api.util.file.image.ExternalImageLoader.loadExternalPngTextureWithColorVariant;

public class ShaderpackScreen extends AbstractModrinthContentScreen {
    private static final class_2960 SHADERPACK_ICON = loadExternalPngTextureWithColorVariant(uiImageDirectory, "shader.png");
    private static final class_2960 FALLBACK_ICON = loadExternalPngTextureWithColorVariant(uiImageDirectory, "image.png");

    public ShaderpackScreen(class_437 parent) {
        super(parent);
    }

    public ShaderpackScreen(class_437 parent, String initialQuery) {
        super(parent, initialQuery);
    }

    @Override
    protected void method_25426() {
        super.method_25426();
        if (this.cancelButton != null) {
            this.method_37066(this.cancelButton);
            this.cancelButton = null;
        }
        if (this.reloadButton != null) {
            this.method_37066(this.reloadButton);
            this.reloadButton = null;
        }
        int topButtonWidth = usesKoilChrome() ? BrowserLayoutHelper.FOOTER_TOP_BUTTON_WIDTH : 112;
        int rightActionX = usesKoilChrome() ? BrowserLayoutHelper.FOOTER_RIGHT_ACTION_X : this.field_22789 / 2 + 80;
        int cancelWidth = usesKoilChrome() ? BrowserLayoutHelper.FOOTER_SMALL_BUTTON_WIDTH : 74;
        if (this.openFolderButton != null && usesKoilChrome()) {
            this.openFolderButton.method_46421(rightActionX);
            this.openFolderButton.method_46419(this.field_22790 - 52);
            this.openFolderButton.method_25358(topButtonWidth);
        }
        this.method_37063(class_4185.method_46430(class_2561.method_43470("InDev"), button -> {
        }).method_46434(rightActionX, this.field_22790 - 28, topButtonWidth, 20).method_46431()).field_22763 = false;
        this.cancelButton = this.method_37063(class_4185.method_46430(class_5244.field_24335, button -> {
            if (this.field_22787 != null) {
                this.field_22787.method_1507(this.parent);
            }
        }).method_46434(usesKoilChrome() ? BrowserLayoutHelper.footerSmallButtonX(3) : this.field_22789 / 2 + 80, this.field_22790 - 28, cancelWidth, 20).method_46431());
    }

    @Override
    protected String getProjectTypeFacet() {
        return "shader";
    }

    @Override
    protected String getScreenTitle() {
        return "Download Shaders";
    }

    @Override
    protected String getSearchPlaceholder() {
        return "Search shaders";
    }

    @Override
    protected class_2960 getFallbackIcon() {
        return SHADERPACK_ICON == null ? FALLBACK_ICON : SHADERPACK_ICON;
    }

    @Override
    protected File getContentDirectory() {
        Path path = FabricLoader.getInstance().getGameDir().resolve("shaderpacks");
        return path.toFile();
    }

    @Override
    protected String getLocalFileExtension() {
        return ".zip";
    }

    @Override
    protected String getLocalContextLabel() {
        return "";
    }

    @Override
    protected File findInstalledFile(String slug, String title) {
        File direct = super.findInstalledFile(slug, title);
        if (direct != null) {
            return direct;
        }
        File directory = getContentDirectory();
        File[] files = directory == null ? null : directory.listFiles();
        if (files == null) {
            return null;
        }
        List<String> queryTokens = shaderTokens(slug + " " + title);
        if (queryTokens.isEmpty()) {
            return null;
        }
        File bestFile = null;
        int bestScore = 0;
        for (File file : files) {
            if (!file.isFile() || !file.getName().toLowerCase(Locale.ROOT).endsWith(".zip")) {
                continue;
            }
            List<String> fileTokens = shaderTokens(file.getName());
            int score = 0;
            for (String token : queryTokens) {
                if (fileTokens.contains(token)) {
                    score += token.length() >= 5 ? 3 : 1;
                }
            }
            if (score > bestScore) {
                bestScore = score;
                bestFile = file;
            }
        }
        return bestScore >= 3 ? bestFile : null;
    }

    private List<String> shaderTokens(String text) {
        String normalized = text == null ? "" : text.toLowerCase(Locale.ROOT)
                .replace(".zip", " ")
                .replaceAll("[^a-z0-9]+", " ");
        List<String> tokens = new ArrayList<>();
        for (String token : normalized.split("\\s+")) {
            if (token.isBlank()
                    || token.equals("shader")
                    || token.equals("shaders")
                    || token.equals("shaderpack")
                    || token.equals("pack")
                    || token.equals("fabric")
                    || token.equals("iris")
                    || token.matches("v?\\d+(?:\\.\\d+)*")) {
                continue;
            }
            tokens.add(token);
        }
        return tokens;
    }

    @Override
    protected class_437 createReloadScreen() {
        return new ShaderpackScreen(this.parent, currentSearchQuery());
    }
}
