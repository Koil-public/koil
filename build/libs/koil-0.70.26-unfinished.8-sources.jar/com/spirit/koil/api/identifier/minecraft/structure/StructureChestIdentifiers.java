package com.spirit.koil.api.identifier.minecraft.structure;

import static com.spirit.koil.api.util.file.jar.strings.ModIds.MINECRAFT_ID;

import net.minecraft.class_2960;

public class StructureChestIdentifiers {
    public static final class_2960 DUNGEON_ID = new class_2960(MINECRAFT_ID, "chests/simple_dungeon");
    public static final class_2960 STRONGHOLD_CORRIDOR_ID = new class_2960(MINECRAFT_ID, "chests/stronghold_corridor");
    public static final class_2960 MINESHAFT_ID = new class_2960(MINECRAFT_ID, "chests/abandoned_mineshaft");
    public static final class_2960 ANCIENT_CITY_ID = new class_2960(MINECRAFT_ID, "chests/ancient_city");
}
