package com.spirit.koil.api.f3;

import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import org.lwjgl.glfw.GLFW;

public final class F3Controller {
    private static boolean vanillaFallback;

    private F3Controller() {
    }

    public static boolean vanillaFallback() {
        return vanillaFallback;
    }

    public static void toggleVanillaFallback() {
        vanillaFallback = !vanillaFallback;
        send("Vanilla F3 fallback " + (vanillaFallback ? "enabled" : "disabled"));
    }

    public static void toggleOverlay() {
        F3LayoutState.toggleOverlayVisible();
    }

    public static void setOverlayMode(F3Mode mode) {
        if (mode != null) {
            F3LayoutState.mode(mode);
        }
        F3LayoutState.compactOverlay(false);
        F3LayoutState.resetOverlayScroll();
        F3LayoutState.overlayVisible(true);
    }

    public static void cycleMode() {
        F3Mode[] cycle = {
                F3Mode.SIMPLE,
                F3Mode.NORMAL,
                F3Mode.PLAYER,
                F3Mode.WORLD,
                F3Mode.TARGET,
                F3Mode.PERFORMANCE,
                F3Mode.CREATOR,
                F3Mode.GRAPHS,
                F3Mode.INSPECTOR,
                F3Mode.FULL,
                F3Mode.COMPACT
        };
        F3Mode current = F3LayoutState.mode();
        int next = 0;
        for (int i = 0; i < cycle.length; i++) {
            if (cycle[i] == current) {
                next = (i + 1) % cycle.length;
                break;
            }
        }
        F3LayoutState.mode(cycle[next]);
        F3LayoutState.resetOverlayScroll();
        F3LayoutState.overlayVisible(true);
        send("Overlay mode: " + cycle[next].label());
    }

    public static boolean handleOverlayMouseScroll(double verticalAmount) {
        class_310 client = class_310.method_1551();
        if (client == null || client.field_1755 != null || !F3LayoutState.overlayVisible() || F3LayoutState.mode() == F3Mode.COMPACT) {
            return false;
        }
        int amount = scrollAmount(verticalAmount);
        if (amount == 0) {
            return true;
        }
        scrollOverlay(amount);
        return true;
    }

    public static void scrollOverlay(int amount) {
        if (amount == 0) {
            return;
        }
        class_310 client = class_310.method_1551();
        if (client != null && client.method_22683() != null) {
            long handle = client.method_22683().method_4490();
            boolean leftArrow = GLFW.glfwGetKey(handle, GLFW.GLFW_KEY_LEFT) == GLFW.GLFW_PRESS || GLFW.glfwGetKey(handle, GLFW.GLFW_KEY_LEFT) == GLFW.GLFW_REPEAT;
            boolean rightArrow = GLFW.glfwGetKey(handle, GLFW.GLFW_KEY_RIGHT) == GLFW.GLFW_PRESS || GLFW.glfwGetKey(handle, GLFW.GLFW_KEY_RIGHT) == GLFW.GLFW_REPEAT;
            boolean leftMouse = GLFW.glfwGetMouseButton(handle, GLFW.GLFW_MOUSE_BUTTON_LEFT) == GLFW.GLFW_PRESS;
            boolean rightMouse = GLFW.glfwGetMouseButton(handle, GLFW.GLFW_MOUSE_BUTTON_RIGHT) == GLFW.GLFW_PRESS;
            if (leftArrow && !rightArrow) {
                F3LayoutState.scrollLeftSidePanels(amount);
                return;
            }
            if (rightArrow && !leftArrow) {
                F3LayoutState.scrollRightSidePanels(amount);
                return;
            }
            if (leftMouse && !rightMouse) {
                F3LayoutState.scrollLeftSidePanels(amount);
                return;
            }
            if (rightMouse && !leftMouse) {
                F3LayoutState.scrollRightSidePanels(amount);
                return;
            }
        }
        F3LayoutState.scrollOverlayLines(amount);
    }

    private static F3LayoutState.ScrollPanel hoveredPanel(class_310 client) {
        if (client == null || client.field_1729 == null || client.method_22683() == null || client.method_22683().method_4480() <= 0 || client.method_22683().method_4507() <= 0) {
            return F3LayoutState.ScrollPanel.NONE;
        }
        double scaledX = client.field_1729.method_1603() * client.method_22683().method_4486() / (double) client.method_22683().method_4480();
        double scaledY = client.field_1729.method_1604() * client.method_22683().method_4502() / (double) client.method_22683().method_4507();
        return F3LayoutState.panelAt(scaledX, scaledY);
    }

    private static int scrollAmount(double verticalAmount) {
        if (verticalAmount == 0.0D) {
            return 0;
        }
        int amount = Math.max(1, Math.min(12, (int) Math.ceil(Math.abs(verticalAmount))));
        return verticalAmount < 0.0D ? amount : -amount;
    }

    public static void toggleDashboardFromF3() {
        toggleOverlay();
    }

    public static void copyTarget() {
        class_310 client = class_310.method_1551();
        if (client == null || client.field_1774 == null) {
            return;
        }
        F3Snapshot snapshot = F3SnapshotService.latest(client);
        client.field_1774.method_1455(F3ReportService.shortTargetReport(snapshot));
        send("Copied target debug info.");
    }

    public static void writeReport() {
        class_310 client = class_310.method_1551();
        F3ReportService.writeSnapshotReport(client);
        send("F3 report written to " + F3Paths.SNAPSHOTS);
    }

    public static void send(String message) {
        class_310 client = class_310.method_1551();
        if (client != null && client.field_1724 != null) {
            client.field_1724.method_7353(class_2561.method_43470("[Debug]: ").method_27695(class_124.field_1054, class_124.field_1067).method_10852(class_2561.method_43470(message).method_27694(style -> style.method_10977(class_124.field_1068).method_10982(false).method_10978(false).method_30938(false).method_36140(false).method_36141(false))), false);
        }
    }
}
