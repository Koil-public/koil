package com.spirit.koil.api.f3;

import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_1297;
import net.minecraft.class_1308;
import net.minecraft.class_1309;
import net.minecraft.class_1324;
import net.minecraft.class_1542;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1890;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_239;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_2769;
import net.minecraft.class_310;
import net.minecraft.class_3610;
import net.minecraft.class_3965;
import net.minecraft.class_3966;
import net.minecraft.class_5134;
import net.minecraft.class_6862;
import net.minecraft.class_7923;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Optional;

public final class F3TargetInspector {
    private F3TargetInspector() {
    }

    public static F3TargetSnapshot inspect(class_310 client, F3Mode mode) {
        if (client == null || client.field_1687 == null || client.field_1724 == null || client.field_1765 == null) {
            return F3TargetSnapshot.none();
        }
        class_239 hit = client.field_1765;
        if (hit instanceof class_3966 entityHit) {
            return inspectEntity(client, entityHit.method_17782(), mode);
        }
        if (hit instanceof class_3965 blockHit && hit.method_17783() == class_239.class_240.field_1332) {
            return inspectBlock(client, blockHit.method_17777(), mode);
        }
        return inspectHeldItem(client, mode);
    }

    public static F3TargetSnapshot inspectHeldItem(class_310 client, F3Mode mode) {
        if (client == null || client.field_1724 == null) {
            return F3TargetSnapshot.none();
        }
        class_1799 stack = client.field_1724.method_6047();
        if (stack.method_7960()) {
            return F3TargetSnapshot.none();
        }
        String id = class_7923.field_41178.method_10221(stack.method_7909()).toString();
        List<F3DataLine> lines = new ArrayList<>();
        lines.add(F3DataLine.state("Count", String.valueOf(stack.method_7947()), "item", 0xFF8FC5FF, "Stack count currently held."));
        lines.add(F3DataLine.of("Durability", durabilityText(stack)));
        lines.add(F3DataLine.of("Rarity", stack.method_7932().toString()));
        lines.add(F3DataLine.of("Enchantments", String.valueOf(class_1890.method_8222(stack).size())));
        if (stack.method_19267()) {
            lines.add(F3DataLine.of("Food", stack.method_7909().method_19264().method_19230() + " hunger"));
        }
        if (mode.developerDataEnabled()) {
            lines.add(F3DataLine.of("Class", stack.method_7909().getClass().getName()));
            lines.add(F3DataLine.of("Damage", stack.method_7963() ? stack.method_7919() + "/" + stack.method_7936() : "none"));
            lines.add(F3DataLine.of("Max Count", String.valueOf(stack.method_7914())));
            lines.add(F3DataLine.of("Translation Key", stack.method_7922()));
            lines.add(F3DataLine.of("NBT Present", String.valueOf(stack.method_7985())));
            lines.add(F3DataLine.of("NBT", stack.method_7985() ? stack.method_7969().toString() : "none"));
        }
        return new F3TargetSnapshot(
                F3TargetType.ITEM,
                stack.method_7964().getString(),
                "Held item",
                id,
                modOwner(id),
                "player main hand",
                "Low",
                F3TargetType.ITEM.color(),
                lines,
                itemTags(stack),
                List.of("copy_item_id", "copy_item_report", "where_from")
        );
    }

    private static F3TargetSnapshot inspectBlock(class_310 client, class_2338 pos, F3Mode mode) {
        class_2680 state = client.field_1687.method_8320(pos);
        class_3610 fluid = client.field_1687.method_8316(pos);
        if (!fluid.method_15769() && state.method_26215()) {
            return inspectFluid(client, pos, fluid, mode);
        }
        String id = class_7923.field_41175.method_10221(state.method_26204()).toString();
        List<F3DataLine> lines = new ArrayList<>();
        lines.add(F3DataLine.state("Position", pos.method_23854(), "world", 0xFFE3B735, "Block position in the current dimension."));
        lines.add(F3DataLine.of("State Block", id));
        lines.add(F3DataLine.of("State Values", state.method_28501().isEmpty() ? "none" : state.method_28501().size() + " values"));
        lines.add(F3DataLine.of("Biome", client.field_1687.method_23753(pos).method_40230().map(key -> key.method_29177().toString()).orElse("unknown")));
        lines.add(F3DataLine.of("Chunk Section", (pos.method_10263() >> 4) + ", " + (pos.method_10264() >> 4) + ", " + (pos.method_10260() >> 4)));
        lines.add(F3DataLine.of("Hardness", formatNumber(state.method_26214(client.field_1687, pos))));
        lines.add(F3DataLine.of("Blast Resistance", formatNumber(state.method_26204().method_9520())));
        lines.add(F3DataLine.of("Break Pressure Est", blockBreakScore(state, client.field_1687, pos)));
        lines.add(F3DataLine.of("Properties", String.valueOf(state.method_28501().size())));
        lines.add(F3DataLine.of("Luminance", String.valueOf(state.method_26213())));
        lines.add(F3DataLine.of("Client Light", String.valueOf(client.field_1687.method_22339(pos))));
        lines.add(F3DataLine.of("Redstone Power", String.valueOf(client.field_1687.method_49804(pos))));
        lines.add(F3DataLine.of("Comparator Output", state.method_26221() ? String.valueOf(state.method_26176(client.field_1687, pos)) : "none"));
        lines.add(F3DataLine.of("Emits Redstone", String.valueOf(state.method_26219())));
        lines.add(F3DataLine.of("Opaque", String.valueOf(state.method_26225())));
        lines.add(F3DataLine.of("Solid Block", String.valueOf(state.method_26212(client.field_1687, pos))));
        lines.add(F3DataLine.of("Air", String.valueOf(state.method_26215())));
        lines.add(F3DataLine.of("Replaceable", String.valueOf(state.method_45474())));
        lines.add(F3DataLine.of("Tool Required", String.valueOf(state.method_29291())));
        lines.add(F3DataLine.of("Burnable", String.valueOf(state.method_50011())));
        lines.add(F3DataLine.of("Random Ticks", String.valueOf(state.method_26229())));
        lines.add(F3DataLine.of("Side Solid Up", String.valueOf(state.method_26206(client.field_1687, pos, class_2350.field_11036))));
        lines.add(F3DataLine.of("Side Solid North", String.valueOf(state.method_26206(client.field_1687, pos, class_2350.field_11043))));
        lines.add(F3DataLine.of("Waterlogged/Fluid", fluid.method_15769() ? "none" : class_7923.field_41173.method_10221(fluid.method_15772()).toString()));
        lines.add(F3DataLine.of("Fluid Level", fluid.method_15769() ? "none" : String.valueOf(fluid.method_15761())));
        lines.add(F3DataLine.of("Fluid Still", fluid.method_15769() ? "none" : String.valueOf(fluid.method_15771())));
        lines.add(F3DataLine.of("Fluid Height", fluid.method_15769() ? "none" : formatNumber(fluid.method_20785())));
        lines.add(F3DataLine.of("Collision Empty", String.valueOf(state.method_26220(client.field_1687, pos).method_1110())));
        lines.add(F3DataLine.of("Collision Boxes", String.valueOf(state.method_26220(client.field_1687, pos).method_1090().size())));
        lines.add(F3DataLine.of("Collision Height", formatNumber(state.method_26220(client.field_1687, pos).method_1105(class_2350.class_2351.field_11052))));
        lines.add(F3DataLine.of("Outline Empty", String.valueOf(state.method_26218(client.field_1687, pos).method_1110())));
        lines.add(F3DataLine.of("Outline Boxes", String.valueOf(state.method_26218(client.field_1687, pos).method_1090().size())));
        lines.add(F3DataLine.of("Outline Height", formatNumber(state.method_26218(client.field_1687, pos).method_1105(class_2350.class_2351.field_11052))));
        lines.add(F3DataLine.of("Slipperiness", formatNumber(state.method_26204().method_9499())));
        lines.add(F3DataLine.of("Velocity Mult", formatNumber(state.method_26204().method_23349())));
        lines.add(F3DataLine.of("Jump Mult", formatNumber(state.method_26204().method_23350())));
        class_1799 tool = client.field_1724.method_6047();
        lines.add(F3DataLine.state("Current Tool", tool.method_7960() ? "empty hand" : tool.method_7964().getString(), tool.method_7951(state) ? "good" : "review", tool.method_7951(state) ? 0xFF2DA700 : 0xFFE3B735, "Shows whether Minecraft says the current tool is suitable for this block."));
        lines.add(F3DataLine.of("Tool Suitable", String.valueOf(tool.method_7951(state))));
        lines.add(F3DataLine.of("Mining Speed", tool.method_7960() ? "1.00" : formatNumber(tool.method_7924(state))));
        lines.add(F3DataLine.of("Mining Rate Est", miningScore(state, tool, client.field_1687, pos)));
        class_2586 blockEntity = client.field_1687.method_8321(pos);
        lines.add(F3DataLine.of("Block Entity", blockEntity == null ? "none" : class_7923.field_41181.method_10221(blockEntity.method_11017()).toString()));
        lines.add(F3DataLine.of("Has Block Entity", String.valueOf(blockEntity != null)));
        if (blockEntity != null) {
            lines.add(F3DataLine.of("Block Entity Class", blockEntity.getClass().getName()));
        }
        addBlockStateSummary(lines, state);
        if (!state.method_28501().isEmpty()) {
            lines.add(new F3DataLine("", "", "divider", 0xFFE3B735, ""));
            lines.add(F3DataLine.state("State Properties", state.method_28501().size() + " values", "header", 0xFFE3B735, "All block state properties with no cap."));
        }
        for (class_2769<?> property : state.method_28501()) {
            lines.add(F3DataLine.state("State Value", property.method_11899() + " = " + String.valueOf(state.method_11654(property)), "state", 0xFFB8C4D2, "Single block state value rendered as one vertical row."));
        }
        if (mode.developerDataEnabled()) {
            lines.add(new F3DataLine("", "", "divider", 0xFFE6EDF5, ""));
            lines.add(F3DataLine.state("Block Developer", "complete", "header", 0xFFE6EDF5, "Developer block class and translation data."));
            lines.add(F3DataLine.of("Class", state.method_26204().getClass().getName()));
            lines.add(F3DataLine.of("Translation Key", state.method_26204().method_9539()));
        }
        F3TargetType type = blockEntity == null ? F3TargetType.BLOCK : F3TargetType.CONTAINER;
        return new F3TargetSnapshot(
                type,
                state.method_26204().method_9518().getString(),
                blockEntity == null ? "Target block" : "Target block entity",
                id,
                modOwner(id),
                pos.method_23854(),
                blockDanger(state, fluid),
                type.color(),
                lines,
                blockTags(state),
                List.of("copy_block_id", "copy_block_state", "copy_position", "where_from", "what_can_i_do")
        );
    }

    private static F3TargetSnapshot inspectFluid(class_310 client, class_2338 pos, class_3610 fluid, F3Mode mode) {
        String id = class_7923.field_41173.method_10221(fluid.method_15772()).toString();
        List<F3DataLine> lines = new ArrayList<>();
        lines.add(F3DataLine.state("Position", pos.method_23854(), "world", 0xFFE3B735, "Fluid block position."));
        lines.add(F3DataLine.of("Biome", client.field_1687.method_23753(pos).method_40230().map(key -> key.method_29177().toString()).orElse("unknown")));
        lines.add(F3DataLine.of("Level", String.valueOf(fluid.method_15761())));
        lines.add(F3DataLine.of("Still", String.valueOf(fluid.method_15771())));
        lines.add(F3DataLine.of("Empty", String.valueOf(fluid.method_15769())));
        lines.add(F3DataLine.of("Height", formatNumber(fluid.method_20785())));
        lines.add(F3DataLine.of("Velocity", formatNumber(fluid.method_15758(client.field_1687, pos).field_1352) + ", " + formatNumber(fluid.method_15758(client.field_1687, pos).field_1351) + ", " + formatNumber(fluid.method_15758(client.field_1687, pos).field_1350)));
        lines.add(F3DataLine.of("Flow Speed", formatNumber(Math.sqrt(fluid.method_15758(client.field_1687, pos).field_1352 * fluid.method_15758(client.field_1687, pos).field_1352 + fluid.method_15758(client.field_1687, pos).field_1350 * fluid.method_15758(client.field_1687, pos).field_1350))));
        lines.add(F3DataLine.of("Block State", fluid.method_15759().toString()));
        if (mode.developerDataEnabled()) {
            lines.add(F3DataLine.of("Class", fluid.method_15772().getClass().getName()));
        }
        return new F3TargetSnapshot(
                F3TargetType.FLUID,
                id,
                fluid.method_15771() ? "Still fluid" : "Flowing fluid",
                id,
                modOwner(id),
                pos.method_23854(),
                id.contains("lava") ? "High" : "Low",
                F3TargetType.FLUID.color(),
                lines,
                List.of(),
                List.of("copy_fluid_id", "copy_position", "where_from")
        );
    }

    private static F3TargetSnapshot inspectEntity(class_310 client, class_1297 entity, F3Mode mode) {
        if (entity instanceof class_1542 itemEntity) {
            return inspectItemEntity(itemEntity, mode);
        }
        String id = class_7923.field_41177.method_10221(entity.method_5864()).toString();
        boolean player = entity instanceof class_1657;
        List<F3DataLine> lines = new ArrayList<>();
        lines.add(F3DataLine.state("Distance", formatNumber(client.field_1724.method_5739(entity)) + " blocks", "live", 0xFF7FC8C2, "Distance from your player to this entity."));
        lines.add(F3DataLine.of("Type", id));
        lines.add(F3DataLine.of("Spawn Group", entity.method_5864().method_5891().method_6133()));
        lines.add(F3DataLine.of("Position", formatNumber(entity.method_23317()) + ", " + formatNumber(entity.method_23318()) + ", " + formatNumber(entity.method_23321())));
        lines.add(F3DataLine.of("Block Pos", entity.method_24515().method_23854()));
        lines.add(F3DataLine.of("Chunk Pos", entity.method_31476().field_9181 + ", " + entity.method_31476().field_9180));
        lines.add(F3DataLine.of("Velocity", formatNumber(entity.method_18798().field_1352) + ", " + formatNumber(entity.method_18798().field_1351) + ", " + formatNumber(entity.method_18798().field_1350)));
        lines.add(F3DataLine.of("Horizontal Speed", formatNumber(Math.sqrt(entity.method_18798().field_1352 * entity.method_18798().field_1352 + entity.method_18798().field_1350 * entity.method_18798().field_1350))));
        lines.add(F3DataLine.of("Vertical Speed", formatNumber(entity.method_18798().field_1351)));
        lines.add(F3DataLine.of("Speed Magnitude", formatNumber(Math.sqrt(entity.method_18798().field_1352 * entity.method_18798().field_1352 + entity.method_18798().field_1351 * entity.method_18798().field_1351 + entity.method_18798().field_1350 * entity.method_18798().field_1350))));
        lines.add(F3DataLine.of("Hitbox", formatNumber(entity.method_17681()) + " x " + formatNumber(entity.method_17682())));
        lines.add(F3DataLine.of("Eye Height", formatNumber(entity.method_5751())));
        lines.add(F3DataLine.of("Yaw/Pitch", formatNumber(entity.method_36454()) + " / " + formatNumber(entity.method_36455())));
        lines.add(F3DataLine.of("Age", entity.field_6012 + " ticks"));
        lines.add(F3DataLine.of("On Ground", String.valueOf(entity.method_24828())));
        lines.add(F3DataLine.of("Touching Water", String.valueOf(entity.method_5799())));
        lines.add(F3DataLine.of("In Lava", String.valueOf(entity.method_5771())));
        lines.add(F3DataLine.of("Submerged", String.valueOf(entity.method_5869())));
        lines.add(F3DataLine.of("Sneaking", String.valueOf(entity.method_5715())));
        lines.add(F3DataLine.of("Sprinting", String.valueOf(entity.method_5624())));
        lines.add(F3DataLine.of("Swimming", String.valueOf(entity.method_5681())));
        lines.add(F3DataLine.of("Glowing", String.valueOf(entity.method_5851())));
        lines.add(F3DataLine.of("Invisible", String.valueOf(entity.method_5767())));
        lines.add(F3DataLine.of("Invulnerable", String.valueOf(entity.method_5655())));
        lines.add(F3DataLine.of("Silent", String.valueOf(entity.method_5701())));
        lines.add(F3DataLine.of("Pose", entity.method_18376().toString()));
        lines.add(F3DataLine.of("Fire", entity.method_20802() + " ticks"));
        lines.add(F3DataLine.of("Frozen", entity.method_32312() + " ticks"));
        lines.add(F3DataLine.of("Air", entity.method_5669() + "/" + entity.method_5748()));
        lines.add(F3DataLine.of("Fall Distance", formatNumber(entity.field_6017)));
        lines.add(F3DataLine.of("No Gravity", String.valueOf(entity.method_5740())));
            lines.add(F3DataLine.of("Vehicle", entity.method_5765() ? class_7923.field_41177.method_10221(entity.method_5854().method_5864()).toString() : "none"));
        lines.add(F3DataLine.of("Passengers", String.valueOf(entity.method_5685().size())));
        lines.add(F3DataLine.of("Custom Name", entity.method_16914() ? entity.method_5797().getString() : "none"));
        if (entity instanceof class_1309 living) {
            lines.add(new F3DataLine("", "", "divider", 0xFF2DA700, ""));
            lines.add(F3DataLine.state("Living Vitals", "client-visible", "header", healthColor(living), "Health, armor, attributes, effects, and combat data."));
            lines.add(F3DataLine.state("Health", formatNumber(living.method_6032()) + "/" + formatNumber(living.method_6063()), "health", healthColor(living), "Entity health visible to the client."));
            lines.add(F3DataLine.of("Health Ratio", formatNumber(living.method_6063() <= 0.0F ? 0.0D : living.method_6032() / living.method_6063())));
            lines.add(F3DataLine.of("Absorption", formatNumber(living.method_6067())));
            lines.add(F3DataLine.of("Armor", String.valueOf(living.method_6096())));
            addAttribute(lines, living, class_5134.field_23716, "Max Health Attr");
            addAttribute(lines, living, class_5134.field_23724, "Armor Attr");
            addAttribute(lines, living, class_5134.field_23725, "Armor Toughness");
            addAttribute(lines, living, class_5134.field_23721, "Attack Damage");
            addAttribute(lines, living, class_5134.field_23722, "Attack Knockback");
            addAttribute(lines, living, class_5134.field_23719, "Movement Speed");
            addAttribute(lines, living, class_5134.field_23717, "Follow Range");
            addAttribute(lines, living, class_5134.field_23718, "Knockback Resist");
            lines.add(F3DataLine.of("Effects", String.valueOf(living.method_6026().size())));
            living.method_6026().forEach(effect -> lines.add(F3DataLine.of("Effect", effect.method_5579().method_5560().getString() + " amp " + effect.method_5578() + " | " + effect.method_5584() + "t")));
        }
        if (entity instanceof class_1308 mob) {
            lines.add(new F3DataLine("", "", "divider", 0xFFE06A21, ""));
            lines.add(F3DataLine.state("Mob Brain", "client-visible", "header", 0xFFE06A21, "AI and target state visible to the client."));
            lines.add(F3DataLine.of("AI Disabled", String.valueOf(mob.method_5987())));
            lines.add(F3DataLine.of("Can Pick Up Loot", String.valueOf(mob.method_5936())));
            lines.add(F3DataLine.of("Persistent", String.valueOf(mob.method_5947())));
            lines.add(F3DataLine.of("Target", mob.method_5968() == null ? "none" : mob.method_5968().method_5477().getString()));
            lines.add(F3DataLine.of("Navigation Idle", String.valueOf(mob.method_5942().method_6357())));
            var path = mob.method_5942().method_6345();
            lines.add(F3DataLine.of("Path Active", String.valueOf(path != null && !mob.method_5942().method_6357())));
            lines.add(F3DataLine.of("Path Length", path == null ? "none" : String.valueOf(path.method_38())));
            lines.add(F3DataLine.of("Path Node", path == null ? "none" : path.method_39() + "/" + path.method_38()));
            lines.add(F3DataLine.of("Navigation Type", mob.method_5942().getClass().getSimpleName()));
            lines.add(F3DataLine.of("Move Control", mob.method_5962().getClass().getSimpleName()));
            lines.add(F3DataLine.of("Look Control", mob.method_5988().getClass().getSimpleName()));
            lines.add(F3DataLine.of("Brain", mob.method_18868().getClass().getSimpleName()));
            lines.add(F3DataLine.of("Goal Visibility", "server-side hidden"));
            lines.add(F3DataLine.of("Intent", mobIntent(client, mob)));
            double threatScore = mobThreatScore(client, mob);
            lines.add(F3DataLine.of("Threat Score", formatNumber(threatScore)));
            lines.add(F3DataLine.of("Threat Level", threatLabel(threatScore)));
        }
        if (mode.developerDataEnabled()) {
            lines.add(new F3DataLine("", "", "divider", 0xFFE6EDF5, ""));
            lines.add(F3DataLine.state("Entity Developer", "complete", "header", 0xFFE6EDF5, "Developer entity identifiers and bounds."));
            lines.add(F3DataLine.of("UUID", entity.method_5845()));
            lines.add(F3DataLine.of("Class", entity.getClass().getName()));
            lines.add(F3DataLine.of("Id", String.valueOf(entity.method_5628())));
            lines.add(F3DataLine.of("Bounding Min", formatNumber(entity.method_5829().field_1323) + ", " + formatNumber(entity.method_5829().field_1322) + ", " + formatNumber(entity.method_5829().field_1321)));
            lines.add(F3DataLine.of("Bounding Max", formatNumber(entity.method_5829().field_1320) + ", " + formatNumber(entity.method_5829().field_1325) + ", " + formatNumber(entity.method_5829().field_1324)));
        }
        return new F3TargetSnapshot(
                player ? F3TargetType.PLAYER : F3TargetType.ENTITY,
                entity.method_5477().getString(),
                player ? "Target player" : "Target entity",
                id,
                modOwner(id),
                entity.method_24515().method_23854(),
                entityDanger(client, entity),
                player ? F3TargetType.PLAYER.color() : F3TargetType.ENTITY.color(),
                lines,
                List.of(),
                List.of("copy_entity_id", "copy_entity_report", "where_from", "copy_ktl_target")
        );
    }

    private static F3TargetSnapshot inspectItemEntity(class_1542 itemEntity, F3Mode mode) {
        class_1799 stack = itemEntity.method_6983();
        String id = class_7923.field_41178.method_10221(stack.method_7909()).toString();
        List<F3DataLine> lines = new ArrayList<>();
        lines.add(F3DataLine.of("Count", String.valueOf(stack.method_7947())));
        lines.add(F3DataLine.of("Age", String.valueOf(itemEntity.method_6985())));
        lines.add(F3DataLine.of("Position", itemEntity.method_24515().method_23854()));
        lines.add(F3DataLine.of("Velocity", formatNumber(itemEntity.method_18798().field_1352) + ", " + formatNumber(itemEntity.method_18798().field_1351) + ", " + formatNumber(itemEntity.method_18798().field_1350)));
        lines.add(F3DataLine.of("Speed Magnitude", formatNumber(Math.sqrt(itemEntity.method_18798().field_1352 * itemEntity.method_18798().field_1352 + itemEntity.method_18798().field_1351 * itemEntity.method_18798().field_1351 + itemEntity.method_18798().field_1350 * itemEntity.method_18798().field_1350))));
        lines.add(F3DataLine.of("On Ground", String.valueOf(itemEntity.method_24828())));
        lines.add(F3DataLine.of("Durability", durabilityText(stack)));
        lines.add(F3DataLine.of("Rarity", stack.method_7932().toString()));
        lines.add(F3DataLine.of("Enchantments", String.valueOf(class_1890.method_8222(stack).size())));
        lines.add(F3DataLine.of("NBT Present", String.valueOf(stack.method_7985())));
        if (mode.developerDataEnabled()) {
            lines.add(F3DataLine.of("Class", itemEntity.getClass().getName()));
            lines.add(F3DataLine.of("Stack NBT", stack.method_7985() ? stack.method_7969().toString() : "none"));
            lines.add(F3DataLine.of("Owner", itemEntity.method_24921() == null ? "unknown" : itemEntity.method_24921().toString()));
        }
        return new F3TargetSnapshot(
                F3TargetType.ITEM,
                stack.method_7964().getString(),
                "Dropped item",
                id,
                modOwner(id),
                itemEntity.method_24515().method_23854(),
                "Low",
                F3TargetType.ITEM.color(),
                lines,
                itemTags(stack),
                List.of("copy_item_id", "copy_position", "where_from")
        );
    }

    private static void addBlockStateSummary(List<F3DataLine> lines, class_2680 state) {
        addStateSummary(lines, state, "facing", "Facing Dir");
        addStateSummary(lines, state, "axis", "Axis");
        addStateSummary(lines, state, "half", "Half");
        addStateSummary(lines, state, "shape", "Shape Detail");
        addStateSummary(lines, state, "type", "Type Detail");
        addStateSummary(lines, state, "powered", "Powered State");
        addStateSummary(lines, state, "power", "Power Level");
        addStateSummary(lines, state, "open", "Open State");
        addStateSummary(lines, state, "waterlogged", "Waterlogged State");
        addStateSummary(lines, state, "extended", "Extended State");
        addStateSummary(lines, state, "enabled", "Enabled State");
        addStateSummary(lines, state, "locked", "Locked State");
        addStateSummary(lines, state, "triggered", "Triggered State");
        addStateSummary(lines, state, "mode", "Mode State");
    }

    private static void addStateSummary(List<F3DataLine> lines, class_2680 state, String propertyName, String label) {
        String value = propertyValue(state, propertyName);
        if (!value.equals("unknown")) {
            lines.add(F3DataLine.of(label, value));
        }
    }

    private static String propertyValue(class_2680 state, String propertyName) {
        for (class_2769<?> property : state.method_28501()) {
            if (property.method_11899().equals(propertyName)) {
                return String.valueOf(state.method_11654(property));
            }
        }
        return "unknown";
    }

    private static String mobIntent(class_310 client, class_1308 mob) {
        if (mob.method_5968() != null) {
            if (client != null && client.field_1724 != null && mob.method_5968() == client.field_1724) {
                return "Aggro Player";
            }
            return "Aggro Target";
        }
        var path = mob.method_5942().method_6345();
        if (path != null && !mob.method_5942().method_6357()) {
            return "Pathing";
        }
        if (!mob.method_5942().method_6357()) {
            return "Navigating";
        }
        if (mob.method_18798().method_37267() > 0.03D) {
            return "Roaming";
        }
        if (mob.method_5799()) {
            return "Swimming";
        }
        return "Idle";
    }

    private static double mobThreatScore(class_310 client, class_1308 mob) {
        double distance = client == null || client.field_1724 == null ? 32.0D : client.field_1724.method_5739(mob);
        double distanceScore = clampNumber(1.0D - distance / 20.0D, 0.0D, 1.0D);
        double attackScore = 0.0D;
        class_1324 attack = mob.method_5996(class_5134.field_23721);
        if (attack != null) {
            attackScore = clampNumber(attack.method_6194() / 20.0D, 0.0D, 1.0D);
        }
        double speedScore = clampNumber(mob.method_18798().method_37267() / 0.35D, 0.0D, 1.0D);
        double targetScore = mob.method_5968() == null ? 0.0D : mob.method_5968() == (client == null ? null : client.field_1724) ? 1.0D : 0.65D;
        double pathScore = mob.method_5942().method_6357() ? 0.0D : 0.45D;
        return clampNumber(distanceScore * 0.35D + attackScore * 0.25D + speedScore * 0.10D + targetScore * 0.20D + pathScore * 0.10D, 0.0D, 1.0D);
    }

    private static String threatLabel(double threatScore) {
        if (threatScore >= 0.78D) {
            return "Immediate";
        }
        if (threatScore >= 0.52D) {
            return "Threat";
        }
        if (threatScore >= 0.25D) {
            return "Watching";
        }
        return "Safe";
    }

    private static void addAttribute(List<F3DataLine> lines, class_1309 entity, net.minecraft.class_1320 attribute, String label) {
        class_1324 instance = entity.method_5996(attribute);
        if (instance != null) {
            lines.add(F3DataLine.of(label, formatNumber(instance.method_6194())));
        }
    }

    private static List<String> blockTags(class_2680 state) {
        return state.method_40144()
                .map(class_6862::comp_327)
                .map(Object::toString)
                .sorted()
                .toList();
    }

    private static List<String> itemTags(class_1799 stack) {
        return stack.method_40133()
                .map(class_6862::comp_327)
                .map(Object::toString)
                .sorted()
                .toList();
    }

    private static String blockBreakScore(class_2680 state, class_1937 world, class_2338 pos) {
        double hardness = state.method_26214(world, pos);
        double resistance = state.method_26204().method_9520();
        if (hardness < 0.0D) {
            return "unbreakable";
        }
        double score = clampNumber((hardness / 50.0D) + (resistance / 1200.0D), 0.0D, 1.0D);
        return formatNumber(score);
    }

    private static String miningScore(class_2680 state, class_1799 tool, class_1937 world, class_2338 pos) {
        double hardness = state.method_26214(world, pos);
        if (hardness < 0.0D) {
            return "unbreakable";
        }
        double speed = tool.method_7960() ? 1.0D : tool.method_7924(state);
        double score = hardness <= 0.0D ? speed : speed / Math.max(1.0D, hardness);
        return formatNumber(score);
    }

    private static double clampNumber(double value, double min, double max) {
        return Math.max(min, Math.min(max, value));
    }

    private static String modOwner(String registryId) {
        if (registryId == null || !registryId.contains(":")) {
            return "Unknown";
        }
        String namespace = registryId.substring(0, registryId.indexOf(':'));
        if ("minecraft".equals(namespace)) {
            return "Minecraft";
        }
        Optional<String> name = FabricLoader.getInstance().getModContainer(namespace)
                .map(container -> container.getMetadata().getName());
        return name.orElse(namespace);
    }

    private static String durabilityText(class_1799 stack) {
        if (!stack.method_7963()) {
            return "not damageable";
        }
        return (stack.method_7936() - stack.method_7919()) + "/" + stack.method_7936();
    }

    private static String blockDanger(class_2680 state, class_3610 fluid) {
        String stateText = state.toString().toLowerCase(Locale.ROOT);
        String fluidText = fluid.method_15769() ? "" : class_7923.field_41173.method_10221(fluid.method_15772()).toString();
        if (stateText.contains("fire") || stateText.contains("lava") || fluidText.contains("lava")) {
            return "High";
        }
        if (state.method_26213() <= 0 && !state.method_26215()) {
            return "Normal";
        }
        return "Low";
    }

    private static int healthColor(class_1309 entity) {
        double ratio = entity.method_6063() <= 0 ? 0.0D : entity.method_6032() / entity.method_6063();
        if (ratio > 0.65D) return 0xFF2DA700;
        if (ratio > 0.35D) return 0xFFE3B735;
        return 0xFFA7003A;
    }

    private static String entityDanger(class_310 client, class_1297 entity) {
        double distance = client.field_1724 == null ? 999.0D : client.field_1724.method_5739(entity);
        if (!(entity instanceof class_1309 living)) {
            return "Low";
        }
        double damage = 0.0D;
        class_1324 damageAttribute = living.method_5996(class_5134.field_23721);
        if (damageAttribute != null) {
            damage = damageAttribute.method_6194();
        }
        if (damage >= 8.0D && distance < 8.0D) {
            return "High";
        }
        if (damage > 0.0D && distance < 16.0D) {
            return "Medium";
        }
        return "Low";
    }

    private static String formatNumber(double value) {
        return String.format(Locale.ROOT, "%.2f", value);
    }
}
