package com.spirit.koil.api.stats.global;

import java.util.*;
import net.minecraft.class_124;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_7923;

public final class KoilPhysicalMomensCurrency {
    private static final int[] DENOMINATIONS = new int[]{500, 100, 50, 20, 10, 5, 1};
    private static final String ROOT = "koil_momens";
    private static final String SOURCES = "sources";

    private KoilPhysicalMomensCurrency() {
    }

    public static boolean available() {
        return !detectedNotes().isEmpty();
    }

    public static List<String> detectedNotes() {
        List<String> values = new ArrayList<>();

        for (int denomination : DENOMINATIONS) {
            class_2960 note = new class_2960("shit", denomination + "_momen");
            class_2960 stack = new class_2960("shit", denomination + "_momen_stack");

            if (contains(note)) {
                values.add(note + " = ƒ" + denomination);
            }

            if (contains(stack)) {
                values.add(stack + " = ƒ" + (denomination * 9));
            }
        }

        Collections.reverse(values);
        return values;
    }

    public static int giveMomens(class_3222 player, int amount) {
        SourceInfo source = new SourceInfo("admin", "Admin Issued Momens", Math.max(0, amount), 1.0D, 0, player == null ? "server" : player.method_7334().getName(), false, "admin_issued");
        return giveMomens(player, amount, source);
    }

    public static int giveMomens(class_3222 player, int amount, SourceInfo source) {
        if (player == null || amount <= 0) {
            return 0;
        }

        int remaining = amount;
        int given = 0;

        for (ItemValue itemValue : availableValues()) {
            int itemMomens = itemValue.value();
            int count = remaining / itemMomens;

            while (count > 0) {
                int stackCount = Math.min(count, Math.max(1, new class_1799(itemValue.item()).method_7914()));
                class_1799 stack = new class_1799(itemValue.item(), stackCount);
                int stackValue = stackCount * itemMomens;
                SourceInfo noteSource = source == null ? SourceInfo.admin(amount) : source;
                writeSource(stack, noteSource, itemMomens);
                insertOrDrop(player, stack);
                remaining -= stackValue;
                given += stackValue;
                count -= stackCount;
            }
        }

        return given;
    }


    public static int giveExactMomens(class_3222 player, class_1792 item, int count, int denominationValue, SourceInfo source) {
        if (player == null || item == null || count <= 0 || denominationValue <= 0) {
            return 0;
        }

        int maxCount = Math.max(1, new class_1799(item).method_7914());
        int remaining = count;
        int given = 0;

        while (remaining > 0) {
            int stackCount = Math.min(maxCount, remaining);
            class_1799 stack = new class_1799(item, stackCount);
            writeSource(stack, source == null ? SourceInfo.admin(denominationValue * stackCount) : source, denominationValue);
            insertOrDrop(player, stack);
            remaining -= stackCount;
            given += stackCount * denominationValue;
        }

        return given;
    }

    public static int compactInventory(class_3222 player) {
        if (player == null) {
            return 0;
        }

        Map<String, CompactBucket> buckets = new LinkedHashMap<>();

        for (int i = 0; i < player.method_31548().method_5439(); i++) {
            class_1799 stack = player.method_31548().method_5438(i);

            if (!isMomens(stack)) {
                continue;
            }

            class_2960 id = class_7923.field_41178.method_10221(stack.method_7909());
            int value = momensValue(id);

            if (value <= 0) {
                continue;
            }

            CompactBucket bucket = buckets.computeIfAbsent(id + "|" + sourceMode(sources(stack)), key -> new CompactBucket(stack.method_7909(), value));
            bucket.count += stack.method_7947();
            bucket.momens += value * stack.method_7947();
            bucket.sources.addAll(sources(stack));
            player.method_31548().method_5447(i, class_1799.field_8037);
        }

        int compacted = 0;

        for (CompactBucket bucket : buckets.values()) {
            int maxCount = Math.max(1, new class_1799(bucket.item).method_7914());
            int remaining = bucket.count;

            while (remaining > 0) {
                int count = Math.min(maxCount, remaining);
                class_1799 stack = new class_1799(bucket.item, count);
                writeMixedSources(stack, bucket.sources, bucket.momens, bucket.value);
                insertOrDrop(player, stack);
                remaining -= count;
                compacted += count;
            }
        }

        return compacted;
    }

    public static boolean mergeStacks(class_1799 target, class_1799 incoming) {
        if (!canMergeStacks(target, incoming)) {
            return false;
        }

        int max = target.method_7914();
        int move = Math.min(incoming.method_7947(), max - target.method_7947());

        if (move <= 0) {
            return false;
        }

        List<SourceEntry> mergedSources = new ArrayList<>();
        mergedSources.addAll(sources(target));

        class_1799 movedCopy = incoming.method_7972();
        movedCopy.method_7939(move);
        mergedSources.addAll(sources(movedCopy));

        int targetValue = momensValue(class_7923.field_41178.method_10221(target.method_7909()));
        int mergedCount = target.method_7947() + move;
        int mergedMomens = targetValue * mergedCount;

        target.method_7939(mergedCount);
        incoming.method_7934(move);
        writeMixedSources(target, mergedSources, Math.max(1, totalMomens(mergedSources)), targetValue);
        return true;
    }

    public static boolean canMergeStacks(class_1799 target, class_1799 incoming) {
        if (!isMomens(target) || !isMomens(incoming) || target.method_7960() || incoming.method_7960()) {
            return false;
        }

        if (!target.method_31574(incoming.method_7909())) {
            return false;
        }

        return target.method_7947() < target.method_7914();
    }

    public static boolean isMomens(class_1799 stack) {
        if (stack == null || stack.method_7960()) {
            return false;
        }

        return momensValue(class_7923.field_41178.method_10221(stack.method_7909())) > 0;
    }

    public static int stackMomensValue(class_1799 stack) {
        if (stack == null || stack.method_7960()) {
            return 0;
        }

        return momensValue(class_7923.field_41178.method_10221(stack.method_7909())) * stack.method_7947();
    }

    public static int redeemableMomensValue(class_1799 stack) {
        int value = 0;

        for (SourceEntry entry : sources(stack)) {
            if (entry.redeemable()) {
                value += Math.max(0, entry.momens());
            }
        }

        return Math.min(stackMomensValue(stack), value);
    }

    public static List<SourceEntry> sources(class_1799 stack) {
        List<SourceEntry> entries = new ArrayList<>();

        if (stack == null || stack.method_7960() || stack.method_7969() == null || !stack.method_7969().method_10573(ROOT, 10)) {
            return entries;
        }

        class_2487 root = stack.method_7969().method_10562(ROOT);
        class_2499 list = root.method_10554(SOURCES, 10);
        int count = Math.max(1, stack.method_7947());

        for (int i = 0; i < list.size(); i++) {
            class_2487 entry = list.method_10602(i);
            entries.add(new SourceEntry(
                    entry.method_10558("id"),
                    entry.method_10558("title"),
                    Math.max(0, entry.method_10550("momens")) * count,
                    entry.method_10574("unit_momens"),
                    Math.max(0, entry.method_10550("units")) * count,
                    entry.method_10558("issuer"),
                    entry.method_10577("redeemable"),
                    entry.method_10558("reason")
            ));
        }

        return mergeEntries(entries);
    }

    public static List<class_2561> sourceTooltip(class_1799 stack) {
        List<class_2561> lines = new ArrayList<>();
        List<SourceEntry> entries = sources(stack);
        int stackValue = stackMomensValue(stack);

        if (entries.isEmpty()) {
            if (isMomens(stack)) {
                lines.add(class_2561.method_43470("Momens Portfolio").method_27695(class_124.field_1065, class_124.field_1067));
                lines.add(class_2561.method_43470("┌──────────┬──────────────────────┐").method_27692(class_124.field_1063));
                lines.add(portfolioTooltipRow("Value", "ƒ" + stackValue, class_124.field_1065));
                lines.add(portfolioTooltipRow("Backed", "none", class_124.field_1061));
                lines.add(portfolioTooltipRow("Rate", "unknown", class_124.field_1063));
                lines.add(portfolioTooltipRow("Status", "legacy note", class_124.field_1061));
                lines.add(class_2561.method_43470("└──────────┴──────────────────────┘").method_27692(class_124.field_1063));
                lines.add(tooltipLine("Market link", "none", class_124.field_1063, class_124.field_1063));
                lines.add(tooltipLine("Redeemable", "no source backing", class_124.field_1080, class_124.field_1061));
            }

            return lines;
        }

        int total = 0;
        int redeemable = 0;

        for (SourceEntry entry : entries) {
            total += Math.max(0, entry.momens());

            if (entry.redeemable()) {
                redeemable += Math.max(0, entry.momens());
            }
        }

        int safeRedeemable = Math.min(stackValue, redeemable);
        class_124 coverageColor = coverageColor(safeRedeemable, stackValue);
        String state = entries.size() > 1 ? "mixed-source portfolio" : entries.get(0).redeemable() ? "source-backed note" : "tracked / locked note";
        class_124 stateColor = safeRedeemable > 0 ? entries.size() > 1 ? class_124.field_1075 : class_124.field_1060 : class_124.field_1061;
        lines.add(class_2561.method_43470("Momens Portfolio").method_27695(class_124.field_1065, class_124.field_1067));
        lines.add(class_2561.method_43470("┌──────────┬──────────────────────┐").method_27692(class_124.field_1063));
        lines.add(portfolioTooltipRow("Value", "ƒ" + stackValue, class_124.field_1065));
        lines.add(portfolioTooltipRow("Backed", "ƒ" + safeRedeemable + " " + coveragePercent(safeRedeemable, stackValue), coverageColor));
        lines.add(portfolioTooltipRow("Rate", averageRateText(entries), class_124.field_1076));
        lines.add(portfolioTooltipRow("Status", state, stateColor));
        lines.add(class_2561.method_43470("└──────────┴──────────────────────┘").method_27692(class_124.field_1063));

        if (entries.size() == 1) {
            SourceEntry entry = entries.get(0);
            String sourceId = parseSourceId(entry.id());
            lines.add(tooltipLine("Market", shortTitle(entry.title()), class_124.field_1080, entry.redeemable() ? class_124.field_1075 : class_124.field_1054));
            lines.add(tooltipLine("Backing", "ƒ" + entry.momens() + " / " + entry.units() + " unit(s)", class_124.field_1080, entry.redeemable() ? class_124.field_1060 : class_124.field_1061));
            lines.add(tooltipLine("Stored rate", sourceRateText(entry), class_124.field_1080, class_124.field_1076));
            lines.add(tooltipLine("Position", allocationBar(entry.momens(), total) + " " + coveragePercent(entry.momens(), Math.max(1, total)), class_124.field_1080, entry.redeemable() ? class_124.field_1060 : class_124.field_1061));
            lines.add(tooltipLine("Issuer", shortTitle(entry.issuer()), class_124.field_1063, class_124.field_1080));

            if (entry.redeemable() && sourceId != null) {
                lines.add(tooltipLine("Cash out", "/market to " + sourceId, class_124.field_1080, class_124.field_1060));
            }
        } else {
            lines.add(tooltipLine("Sources", entries.size() + " market positions", class_124.field_1080, class_124.field_1075));
            int limit = Math.min(4, entries.size());

            for (int i = 0; i < limit; i++) {
                SourceEntry entry = entries.get(i);
                class_124 color = entry.redeemable() ? class_124.field_1080 : class_124.field_1063;
                lines.add(class_2561.method_43470("  " + (i + 1) + ". ").method_27692(class_124.field_1063)
                        .method_10852(class_2561.method_43470("ƒ" + entry.momens()).method_27692(entry.redeemable() ? class_124.field_1060 : class_124.field_1061))
                        .method_10852(class_2561.method_43470(" | ").method_27692(class_124.field_1063))
                        .method_10852(class_2561.method_43470(allocationBar(entry.momens(), total)).method_27692(entry.redeemable() ? class_124.field_1060 : class_124.field_1061))
                        .method_10852(class_2561.method_43470(" | ").method_27692(class_124.field_1063))
                        .method_10852(class_2561.method_43470(entry.units() + "u").method_27692(class_124.field_1075))
                        .method_10852(class_2561.method_43470(" | ").method_27692(class_124.field_1063))
                        .method_10852(class_2561.method_43470(sourceRateText(entry)).method_27692(class_124.field_1076))
                        .method_10852(class_2561.method_43470(" | ").method_27692(class_124.field_1063))
                        .method_10852(class_2561.method_43470(shortTitle(entry.title())).method_27692(color)));
            }

            if (entries.size() > limit) {
                lines.add(class_2561.method_43470("  +" + (entries.size() - limit) + " more market source(s)").method_27692(class_124.field_1063));
            }
        }

        if (safeRedeemable > 0) {
            lines.add(tooltipLine("Redeemable", "yes, source-backed cash out", class_124.field_1080, class_124.field_1060));
        } else {
            lines.add(tooltipLine("Redeemable", "no market backing", class_124.field_1080, class_124.field_1061));
        }

        return lines;
    }

    private static class_2561 tooltipLine(String label, String value, class_124 labelColor, class_124 valueColor) {
        return class_2561.method_43470(label + ": ").method_27692(labelColor).method_10852(class_2561.method_43470(value).method_27692(valueColor));
    }

    private static class_2561 portfolioTooltipRow(String label, String value, class_124 valueColor) {
        return class_2561.method_43470("| ").method_27692(class_124.field_1063)
                .method_10852(class_2561.method_43470(padTooltip(label, 8)).method_27692(class_124.field_1080))
                .method_10852(class_2561.method_43470(" | ").method_27692(class_124.field_1063))
                .method_10852(class_2561.method_43470(padTooltip(clipTooltip(value, 20), 20)).method_27692(valueColor))
                .method_10852(class_2561.method_43470(" |").method_27692(class_124.field_1063));
    }

    private static String padTooltip(String value, int width) {
        String safe = value == null ? "" : value;

        if (safe.length() >= width) {
            return safe;
        }

        return safe + " ".repeat(width - safe.length());
    }

    private static String clipTooltip(String value, int width) {
        String safe = value == null ? "" : value;

        if (safe.length() <= width) {
            return safe;
        }

        return safe.substring(0, Math.max(0, width - 1)) + "~";
    }

    private static String allocationBar(int value, int total) {
        int slots = 8;
        int filled = total <= 0 ? 0 : Math.max(0, Math.min(slots, Math.round(value * slots / (float) total)));
        return "[" + "#".repeat(filled) + ".".repeat(slots - filled) + "]";
    }

    private static String averageRateText(List<SourceEntry> entries) {
        if (entries == null || entries.isEmpty()) {
            return "unknown";
        }

        double weighted = 0.0D;
        int units = 0;

        for (SourceEntry entry : entries) {
            if (entry.units() <= 0) {
                continue;
            }

            double rate = entry.unitMomens() > 0.0D ? entry.unitMomens() : entry.momens() / (double) Math.max(1, entry.units());
            weighted += rate * entry.units();
            units += entry.units();
        }

        if (units <= 0) {
            return "unknown";
        }

        return "ƒ" + KoilMarketValueQuote.compactDecimal(weighted / units) + " / unit";
    }

    private static class_124 coverageColor(int redeemable, int value) {
        if (value <= 0 || redeemable <= 0) {
            return class_124.field_1061;
        }

        double ratio = redeemable / (double) value;

        if (ratio >= 0.95D) {
            return class_124.field_1060;
        }

        if (ratio >= 0.5D) {
            return class_124.field_1054;
        }

        return class_124.field_1061;
    }

    private static String coveragePercent(int redeemable, int value) {
        if (value <= 0) {
            return "0%";
        }

        double percent = Math.max(0.0D, Math.min(100.0D, redeemable * 100.0D / value));
        return KoilMarketValueQuote.compactDecimal(percent) + "%";
    }

    private static String sourceRateText(SourceEntry entry) {
        double rate = entry.unitMomens() > 0.0D ? entry.unitMomens() : entry.units() > 0 ? entry.momens() / (double) entry.units() : 0.0D;

        if (rate <= 0.0D) {
            return "unknown";
        }

        return "ƒ" + KoilMarketValueQuote.compactDecimal(rate) + " / unit";
    }

    private static String parseSourceId(String value) {
        if (value == null || value.isBlank()) {
            return null;
        }

        try {
            class_2960 id = new class_2960(value.trim().toLowerCase(Locale.ROOT));
            return class_7923.field_41178.method_10250(id) ? id.toString() : null;
        } catch (Exception ignored) {
            return null;
        }
    }


    public static int denominationValue(String denomination) {
        if (denomination == null || denomination.isBlank()) {
            return 0;
        }

        String clean = denomination.trim().toLowerCase(Locale.ROOT).replace("_momen", "");
        boolean stack = clean.endsWith("_stack") || clean.endsWith("stack");
        clean = clean.replace("_stack", "").replace("stack", "");

        try {
            int value = Integer.parseInt(clean);

            for (int denominationValue : DENOMINATIONS) {
                if (denominationValue == value) {
                    return stack ? value * 9 : value;
                }
            }
        } catch (Exception ignored) {
        }

        return 0;
    }

    public static class_1792 itemForDenomination(String denomination) {
        if (denomination == null || denomination.isBlank()) {
            return null;
        }

        String clean = denomination.trim().toLowerCase(Locale.ROOT).replace("_momen", "");
        boolean stack = clean.endsWith("_stack") || clean.endsWith("stack");
        clean = clean.replace("_stack", "").replace("stack", "");

        try {
            int value = Integer.parseInt(clean);

            for (int denominationValue : DENOMINATIONS) {
                if (denominationValue == value) {
                    return item(new class_2960("shit", value + (stack ? "_momen_stack" : "_momen")));
                }
            }
        } catch (Exception ignored) {
        }

        return null;
    }

    public static int momensValue(class_2960 id) {
        if (id == null || !"shit".equals(id.method_12836())) {
            return 0;
        }

        String path = id.method_12832();

        for (int denomination : DENOMINATIONS) {
            if (path.equals(denomination + "_momen")) {
                return denomination;
            }

            if (path.equals(denomination + "_momen_stack")) {
                return denomination * 9;
            }
        }

        return 0;
    }

    public static String summary() {
        List<String> notes = detectedNotes();

        if (notes.isEmpty()) {
            return "Physical Momens: not detected";
        }

        return "Physical Momens: " + notes.size() + " denominations detected";
    }

    public static String detailedSummary() {
        List<String> notes = detectedNotes();

        if (notes.isEmpty()) {
            return "Physical Momens: not detected";
        }

        return String.join(", ", notes);
    }

    private static void writeSource(class_1799 stack, SourceInfo source, int denominationValue) {
        class_2487 root = new class_2487();
        root.method_10569("value", denominationValue);
        root.method_10569("denomination", denominationValue);
        class_2499 list = new class_2499();
        list.add(sourceEntry(normalizeSourceForUnit(source, denominationValue)));
        root.method_10566(SOURCES, list);
        stack.method_7948().method_10566(ROOT, root);
    }

    private static void writeMixedSources(class_1799 stack, List<SourceEntry> sources, int sourceTotalMomens, int denominationValue) {
        class_2487 root = new class_2487();
        root.method_10569("value", denominationValue);
        root.method_10569("denomination", denominationValue);
        class_2499 list = new class_2499();
        Map<String, SourceInfo> merged = new LinkedHashMap<>();
        int perItemMomens = Math.max(1, denominationValue);

        for (SourceEntry entry : sources) {
            if (entry.momens() <= 0) {
                continue;
            }

            int scaledMomens = Math.max(0, (int) Math.floor(perItemMomens * (entry.momens() / (double) Math.max(1, sourceTotalMomens))));

            if (scaledMomens <= 0) {
                continue;
            }

            int scaledUnits = entry.units() <= 0 ? 0 : Math.max(1, (int) Math.round(entry.units() * (scaledMomens / (double) Math.max(1, entry.momens()))));
            SourceInfo next = new SourceInfo(entry.id(), entry.title(), scaledMomens, entry.unitMomens(), scaledUnits, entry.issuer(), entry.redeemable(), entry.reason());
            SourceInfo previous = merged.get(entry.key());

            if (previous == null) {
                merged.put(entry.key(), next);
            } else {
                merged.put(entry.key(), previous.merge(next));
            }
        }

        int written = 0;

        for (SourceInfo entry : merged.values()) {
            written += Math.max(0, entry.momens());
        }

        if (written < perItemMomens && !merged.isEmpty()) {
            String firstKey = merged.keySet().iterator().next();
            SourceInfo first = merged.get(firstKey);
            SourceInfo adjusted = first.withMomens(first.momens() + (perItemMomens - written));
            merged.put(firstKey, adjusted);
        }

        if (merged.isEmpty()) {
            merged.put("admin|false|admin_issued", SourceInfo.admin(perItemMomens));
        }

        for (SourceInfo entry : merged.values()) {
            list.add(sourceEntry(entry));
        }

        root.method_10566(SOURCES, list);
        stack.method_7948().method_10566(ROOT, root);
    }

    private static SourceInfo normalizeSourceForUnit(SourceInfo source, int denominationValue) {
        SourceInfo safe = source == null ? SourceInfo.admin(denominationValue) : source;
        int originalMomens = Math.max(1, safe.momens());
        int units = safe.units() <= 0 ? 0 : Math.max(1, (int) Math.round(safe.units() * (denominationValue / (double) originalMomens)));
        return new SourceInfo(safe.id(), safe.title(), Math.max(1, denominationValue), safe.unitMomens(), units, safe.issuer(), safe.redeemable(), safe.reason());
    }

    private static class_2487 sourceEntry(SourceInfo source) {
        class_2487 entry = new class_2487();
        entry.method_10582("id", safe(source.id(), "admin"));
        entry.method_10582("title", safe(source.title(), "Admin Issued Momens"));
        entry.method_10569("momens", Math.max(0, source.momens()));
        entry.method_10549("unit_momens", Math.max(0.0D, source.unitMomens()));
        entry.method_10569("units", Math.max(0, source.units()));
        entry.method_10582("issuer", safe(source.issuer(), "server"));
        entry.method_10556("redeemable", source.redeemable());
        entry.method_10582("reason", safe(source.reason(), source.redeemable() ? "resource_exchange" : "admin_issued"));
        return entry;
    }

    private static List<ItemValue> availableValues() {
        List<ItemValue> values = new ArrayList<>();

        for (int denomination : DENOMINATIONS) {
            class_2960 stackId = new class_2960("shit", denomination + "_momen_stack");
            class_1792 stackItem = item(stackId);

            if (stackItem != null) {
                values.add(new ItemValue(stackId, stackItem, denomination * 9));
            }

            class_2960 noteId = new class_2960("shit", denomination + "_momen");
            class_1792 noteItem = item(noteId);

            if (noteItem != null) {
                values.add(new ItemValue(noteId, noteItem, denomination));
            }
        }

        values.sort((a, b) -> Integer.compare(b.value(), a.value()));
        return values;
    }

    private static void insertOrDrop(class_3222 player, class_1799 stack) {
        if (!player.method_31548().method_7394(stack)) {
            player.method_7328(stack, false);
        }
    }

    private static class_1792 item(class_2960 id) {
        try {
            return class_7923.field_41178.method_10250(id) ? class_7923.field_41178.method_10223(id) : null;
        } catch (Exception ignored) {
            return null;
        }
    }

    private static boolean contains(class_2960 id) {
        return item(id) != null;
    }

    private static String shortTitle(String value) {
        String safe = safe(value, "unknown");
        return safe.length() > 36 ? safe.substring(0, 33) + "..." : safe;
    }

    private static String safe(String value, String fallback) {
        return value == null || value.isBlank() ? fallback : value;
    }

    private static int totalMomens(List<SourceEntry> entries) {
        int total = 0;

        for (SourceEntry entry : entries) {
            total += Math.max(0, entry.momens());
        }

        return total;
    }

    private static List<SourceEntry> mergeEntries(List<SourceEntry> entries) {
        Map<String, SourceInfo> merged = new LinkedHashMap<>();

        for (SourceEntry entry : entries) {
            if (entry.momens() <= 0) {
                continue;
            }

            SourceInfo next = new SourceInfo(entry.id(), entry.title(), entry.momens(), entry.unitMomens(), entry.units(), entry.issuer(), entry.redeemable(), entry.reason());
            SourceInfo previous = merged.get(entry.key());

            if (previous == null) {
                merged.put(entry.key(), next);
            } else {
                merged.put(entry.key(), previous.merge(next));
            }
        }

        List<SourceEntry> result = new ArrayList<>();

        for (SourceInfo info : merged.values()) {
            result.add(new SourceEntry(info.id(), info.title(), info.momens(), info.unitMomens(), info.units(), info.issuer(), info.redeemable(), info.reason()));
        }

        result.sort((a, b) -> Integer.compare(b.momens(), a.momens()));
        return result;
    }


    private static String sourceMode(List<SourceEntry> entries) {
        boolean redeemable = false;
        boolean nonRedeemable = false;

        for (SourceEntry entry : entries) {
            if (entry.redeemable()) {
                redeemable = true;
            } else {
                nonRedeemable = true;
            }
        }

        if (redeemable && nonRedeemable) {
            return "mixed";
        }

        if (redeemable) {
            return "redeemable";
        }

        return "nonredeemable";
    }

    private static final class CompactBucket {
        private final class_1792 item;
        private final int value;
        private int count;
        private int momens;
        private final List<SourceEntry> sources = new ArrayList<>();

        private CompactBucket(class_1792 item, int value) {
            this.item = item;
            this.value = value;
        }
    }

    private record ItemValue(class_2960 id, class_1792 item, int value) {
    }

    public record SourceInfo(String id, String title, int momens, double unitMomens, int units, String issuer, boolean redeemable, String reason) {
        public static SourceInfo admin(int momens) {
            return new SourceInfo("admin", "Admin Issued Momens", momens, 1.0D, 0, "server", false, "admin_issued");
        }

        public SourceInfo withMomens(int value) {
            return new SourceInfo(id, title, value, unitMomens, units, issuer, redeemable, reason);
        }

        public SourceInfo merge(SourceInfo other) {
            if (other == null) {
                return this;
            }

            int nextUnits = units + other.units();
            double nextUnitMomens = unitMomens > 0.0D ? unitMomens : other.unitMomens();
            return new SourceInfo(id, title, momens + other.momens(), nextUnitMomens, nextUnits, issuer, redeemable && other.redeemable(), reason);
        }
    }

    public record SourceEntry(String id, String title, int momens, double unitMomens, int units, String issuer, boolean redeemable, String reason) {
        public String key() {
            return id + "|" + redeemable + "|" + reason + "|" + title + "|" + issuer;
        }
    }
}
