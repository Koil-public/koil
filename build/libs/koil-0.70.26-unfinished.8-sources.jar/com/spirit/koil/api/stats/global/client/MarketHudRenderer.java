package com.spirit.koil.api.stats.global.client;

import com.spirit.client.gui.console.ConsoleScreen;
import com.spirit.koil.api.automation.cli.AutomationChatHudRenderer;
import com.spirit.koil.api.stats.global.KoilMarketHudSnapshot;
import com.spirit.koil.api.stats.global.KoilMarketSeriesWindow;
import com.spirit.koil.api.stats.global.KoilMarketValueQuote;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_408;
import net.minecraft.class_5481;

public final class MarketHudRenderer {
    private static final int VANILLA_CHAT_OFFSET_FROM_BOTTOM = 40;
    private static MarketHudBlock cachedBlock;
    private static String cachedBlockKey = "";

    private MarketHudRenderer() {
    }

    public static int reservedHeight(class_310 client) {
        int height = panelHeight(client);

        if (height <= 0) {
            return 0;
        }

        if (AutomationChatHudRenderer.reservedHeight(client) > 0) {
            return height;
        }

        return Math.max(0, height - VANILLA_CHAT_OFFSET_FROM_BOTTOM);
    }

    public static void render(class_332 context, class_310 client) {
        MarketHudBlock block = buildBlock(client);

        if (block == null || client == null) {
            return;
        }

        int automationOffset = AutomationChatHudRenderer.occupiedHeight(client);
        int x = 0;
        int y = client.method_22683().method_4502() - bottomOffset(client) - automationOffset - block.height;
        int background = panelBackgroundColor(client);
        context.method_25294(x, y, x + block.width, y + block.height, background);
        context.method_25294(x, y, x + 2, y + block.height, block.accentColor);

        int textY = y + block.paddingY;

        for (class_5481 line : block.lines) {
            context.method_35720(client.field_1772, line, x + block.paddingX, textY, 0xFFFFFF);
            textY += block.lineHeight;
        }

        if (!block.entries.isEmpty()) {
            int chartY = textY + 3;
            int chartHeight = block.chartHeight;
            int chartX = x + block.paddingX;
            int chartWidth = block.width - block.paddingX * 2;

            if (block.entries.size() >= 2) {
                int gap = 6;
                int cellWidth = Math.max(38, (chartWidth - gap) / 2);
                drawChartCell(context, client, chartX, chartY, cellWidth, chartHeight, block.entries.get(0), 0xFF8EE8FF, block.showDeltas);
                drawChartCell(context, client, chartX + cellWidth + gap, chartY, chartWidth - cellWidth - gap, chartHeight, block.entries.get(1), 0xFFE9B85B, block.showDeltas);
            } else {
                drawChartCell(context, client, chartX, chartY, chartWidth, chartHeight, block.entries.get(0), primaryChartColor(block.entries.get(0)), block.showDeltas);
            }
        }
    }

    private static int panelHeight(class_310 client) {
        MarketHudBlock block = buildBlock(client);
        return block == null ? 0 : block.height + bottomOffset(client);
    }

    private static MarketHudBlock buildBlock(class_310 client) {
        if (client == null || client.field_1724 == null || client.field_1772 == null || client.field_1755 instanceof ConsoleScreen) {
            return null;
        }

        if (!(client.field_1755 == null || client.field_1755 instanceof class_408)) {
            return null;
        }

        KoilMarketHudSnapshot snapshot = MarketHudState.snapshot();

        if (snapshot == null || snapshot.entries().isEmpty() && snapshot.notes().isEmpty()) {
            cachedBlock = null;
            cachedBlockKey = "";
            return null;
        }

        int chatWidth = client.field_1705 == null ? 0 : client.field_1705.method_1743().method_1811();
        String key = blockCacheKey(client, snapshot, chatWidth);

        if (cachedBlock != null && key.equals(cachedBlockKey)) {
            return cachedBlock;
        }
        int width = Math.min(client.method_22683().method_4486(), Math.max(snapshot.entries().size() >= 2 ? 330 : 246, chatWidth + 12));
        int innerWidth = width - 14;
        int lineHeight = client.field_1772.field_2000 + 1;
        List<class_5481> lines = new ArrayList<>();
        lines.addAll(wrappedLines(client, header(snapshot), innerWidth, 1));
        lines.addAll(wrappedLines(client, prompt(snapshot), innerWidth, 1));

        boolean showDeltas = showDeltaText(snapshot);

        if (snapshot.entries().size() >= 2) {
            lines.addAll(wrappedLines(client, compareReceipt(snapshot, showDeltas), innerWidth, 8));
        } else if (snapshot.entries().size() == 1) {
            lines.addAll(wrappedLines(client, singleReceipt(snapshot, showDeltas), innerWidth, 7));
        }

        for (String note : snapshot.notes()) {
            lines.addAll(wrappedLines(client, class_2561.method_43470(note == null ? "" : note).method_27694(style -> style.method_36139(0xD6D6D6)), innerWidth, 1));
        }

        lines.addAll(wrappedLines(client, footer(snapshot), innerWidth, 1));
        int chartHeight = snapshot.entries().size() >= 2 ? 38 : 34;
        boolean hasChart = false;

        for (KoilMarketHudSnapshot.Entry entry : snapshot.entries()) {
            if (displaySeries(client, entry).length > 1) {
                hasChart = true;
                break;
            }
        }

        int height = Math.max(lineHeight, lines.size() * lineHeight) + 7 + (hasChart ? chartHeight + 12 : 0);
        cachedBlock = new MarketHudBlock(lines, snapshot.entries(), width, height, 7, 4, lineHeight, chartHeight, accentColor(snapshot), snapshot.watch(), showDeltas);
        cachedBlockKey = key;
        return cachedBlock;
    }

    private static String blockCacheKey(class_310 client, KoilMarketHudSnapshot snapshot, int chatWidth) {
        StringBuilder builder = new StringBuilder();
        builder.append(client.method_22683().method_4486()).append('|');
        builder.append(chatWidth).append('|');
        builder.append(KoilMarketSeriesWindow.activeKey()).append('|');
        builder.append(snapshot.createdAt()).append('|');
        builder.append(snapshot.mode()).append('|').append(snapshot.title()).append('|').append(snapshot.subtitle()).append('|').append(snapshot.reserveLine()).append('|').append(snapshot.sourceLine()).append('|');

        for (String note : snapshot.notes()) {
            builder.append(note).append('|');
        }

        for (KoilMarketHudSnapshot.Entry entry : snapshot.entries()) {
            builder.append(entry.id()).append('|').append(entry.value()).append('|').append(entry.exchange()).append('|').append(entry.confidence()).append('|').append(entry.demand()).append('|').append(entry.supply()).append('|').append(entry.scarcity()).append('|').append(entry.trend()).append('|');
            int[] series = entry.series();
            builder.append(series.length).append(':');

            if (series.length > 0) {
                builder.append(series[0]).append(',').append(series[series.length - 1]);
            }
        }

        return builder.toString();
    }

    private static class_2561 header(KoilMarketHudSnapshot snapshot) {
        int accent = accentColor(snapshot);
        String mode = snapshot.mode();
        String entryCount = snapshot.entries().size() >= 2 ? "2 charts" : snapshot.entries().size() == 1 ? "1 chart" : "receipt";
        return class_2561.method_43470("Market").method_27694(style -> style.method_36139(0xA7A7A7))
                .method_10852(class_2561.method_43470(" | ").method_27694(style -> style.method_36139(0x444444)))
                .method_10852(class_2561.method_43470(mode).method_27694(style -> style.method_36139(accent)))
                .method_10852(class_2561.method_43470(" | ").method_27694(style -> style.method_36139(0x444444)))
                .method_10852(class_2561.method_43470(entryCount).method_27694(style -> style.method_36139(0xFFFFFF)))
                .method_10852(class_2561.method_43470(" | ").method_27694(style -> style.method_36139(0x444444)))
                .method_10852(class_2561.method_43470(KoilMarketSeriesWindow.label(KoilMarketSeriesWindow.activeKey())).method_27694(style -> style.method_36139(0x55DDE8)));
    }

    private static class_2561 prompt(KoilMarketHudSnapshot snapshot) {
        String title = snapshot.subtitle().isBlank() ? snapshot.title() : snapshot.subtitle();
        return class_2561.method_43470("ƒ_ ").method_27694(style -> style.method_36139(0xE9B85B))
                .method_10852(class_2561.method_43470(clip(title, 60)).method_27694(style -> style.method_36139(0xFFFFFF)));
    }

    private static boolean showDeltaText(KoilMarketHudSnapshot snapshot) {
        String mode = snapshot == null || snapshot.mode() == null ? "" : snapshot.mode().toLowerCase();
        return mode.equals("catch update") || mode.contains("catch update");
    }

    private static class_2561 singleReceipt(KoilMarketHudSnapshot snapshot, boolean showDeltas) {
        KoilMarketHudSnapshot.Entry entry = snapshot.entries().get(0);
        return class_2561.method_43470("Price ").method_27694(style -> style.method_36139(0x777777))
                .method_10852(valueText(entry.value(), entry.valueDelta(), 0x76E28E, showDeltas))
                .method_10852(class_2561.method_43470("   Demand ").method_27694(style -> style.method_36139(0x777777)))
                .method_10852(valueText(compact(entry.demand()), entry.demandDelta(), scoreColor(entry.demand(), entry.supply(), true), showDeltas))
                .method_10852(class_2561.method_43470("\nSupply ").method_27694(style -> style.method_36139(0x777777)))
                .method_10852(valueText(compact(entry.supply()), entry.supplyDelta(), scoreColor(entry.supply(), entry.demand(), false), showDeltas))
                .method_10852(class_2561.method_43470("   Scarcity ").method_27694(style -> style.method_36139(0x777777)))
                .method_10852(valueText(compact(entry.scarcity()), entry.scarcityDelta(), scoreColor(entry.scarcity(), entry.supply(), true), showDeltas))
                .method_10852(class_2561.method_43470("\nTrend ").method_27694(style -> style.method_36139(0x777777)))
                .method_10852(valueText(compact(entry.trend()), entry.trendDelta(), trendColor(entry.trend()), showDeltas))
                .method_10852(class_2561.method_43470("   Confidence ").method_27694(style -> style.method_36139(0x777777)))
                .method_10852(class_2561.method_43470(entry.confidence() + "%").method_27694(style -> style.method_36139(confidenceColor(entry.confidence()))))
                .method_10852(class_2561.method_43470("\nExchange ").method_27694(style -> style.method_36139(0x777777)))
                .method_10852(class_2561.method_43470(clip(entry.exchange(), 48)).method_27694(style -> style.method_36139(0xE0D172)));
    }

    private static class_2561 compareReceipt(KoilMarketHudSnapshot snapshot, boolean showDeltas) {
        KoilMarketHudSnapshot.Entry first = snapshot.entries().get(0);
        KoilMarketHudSnapshot.Entry second = snapshot.entries().get(1);
        return class_2561.method_43470("Asset ").method_27694(style -> style.method_36139(0x777777))
                .method_10852(class_2561.method_43470(clip(first.title(), 20)).method_27694(style -> style.method_36139(0x8EE8FF)))
                .method_10852(class_2561.method_43470(" / ").method_27694(style -> style.method_36139(0x444444)))
                .method_10852(class_2561.method_43470(clip(second.title(), 20)).method_27694(style -> style.method_36139(0xE9B85B)))
                .method_10852(class_2561.method_43470("\nPrice ").method_27694(style -> style.method_36139(0x777777)))
                .method_10852(valueText(first.value(), first.valueDelta(), strongerColor(first, second), showDeltas))
                .method_10852(class_2561.method_43470(" / ").method_27694(style -> style.method_36139(0x444444)))
                .method_10852(valueText(second.value(), second.valueDelta(), strongerColor(second, first), showDeltas))
                .method_10852(class_2561.method_43470("\nDemand ").method_27694(style -> style.method_36139(0x777777)))
                .method_10852(valueText(compact(first.demand()), first.demandDelta(), scoreColor(first.demand(), second.demand(), true), showDeltas))
                .method_10852(class_2561.method_43470(" / ").method_27694(style -> style.method_36139(0x444444)))
                .method_10852(valueText(compact(second.demand()), second.demandDelta(), scoreColor(second.demand(), first.demand(), true), showDeltas))
                .method_10852(class_2561.method_43470("   Supply ").method_27694(style -> style.method_36139(0x777777)))
                .method_10852(valueText(compact(first.supply()), first.supplyDelta(), scoreColor(first.supply(), second.supply(), false), showDeltas))
                .method_10852(class_2561.method_43470(" / ").method_27694(style -> style.method_36139(0x444444)))
                .method_10852(valueText(compact(second.supply()), second.supplyDelta(), scoreColor(second.supply(), first.supply(), false), showDeltas))
                .method_10852(class_2561.method_43470("\nScarcity ").method_27694(style -> style.method_36139(0x777777)))
                .method_10852(valueText(compact(first.scarcity()), first.scarcityDelta(), scoreColor(first.scarcity(), second.scarcity(), true), showDeltas))
                .method_10852(class_2561.method_43470(" / ").method_27694(style -> style.method_36139(0x444444)))
                .method_10852(valueText(compact(second.scarcity()), second.scarcityDelta(), scoreColor(second.scarcity(), first.scarcity(), true), showDeltas))
                .method_10852(class_2561.method_43470("   Confidence ").method_27694(style -> style.method_36139(0x777777)))
                .method_10852(class_2561.method_43470(Math.min(first.confidence(), second.confidence()) + "%").method_27694(style -> style.method_36139(confidenceColor(Math.min(first.confidence(), second.confidence())))));
    }

    private static class_2561 valueText(String value, String delta, int valueColor, boolean showDeltas) {
        return class_2561.method_43470(value == null ? "" : value).method_27694(style -> style.method_36139(valueColor))
                .method_10852(showDeltas ? deltaText(delta) : class_2561.method_43473());
    }

    private static class_2561 deltaText(String delta) {
        if (delta == null || delta.isBlank()) {
            return class_2561.method_43473();
        }

        return class_2561.method_43470(" " + delta).method_27694(style -> style.method_36139(deltaColor(delta)));
    }

    private static int deltaColor(String delta) {
        String safe = delta == null ? "" : delta;

        if (safe.contains("↑") || safe.contains("+")) {
            return 0x76E28E;
        }

        if (safe.contains("↓") || safe.contains("-")) {
            return 0xE06666;
        }

        return 0xE0D172;
    }

    private static class_2561 footer(KoilMarketHudSnapshot snapshot) {
        return class_2561.method_43470(clip(snapshot.reserveLine(), 58)).method_27694(style -> style.method_36139(0xE0D172))
                .method_10852(class_2561.method_43470("  ").method_27694(style -> style.method_36139(0x444444)))
                .method_10852(class_2561.method_43470(clip(snapshot.sourceLine(), 34)).method_27694(style -> style.method_36139(sourceColor(snapshot.sourceLine()))))
                .method_10852(class_2561.method_43470("  ").method_27694(style -> style.method_36139(0x444444)))
                .method_10852(class_2561.method_43470("baseline: previous close").method_27694(style -> style.method_36139(0x718091)));
    }

    private static List<class_5481> wrappedLines(class_310 client, class_2561 text, int width, int maxLines) {
        if (text == null || text.getString().isBlank()) {
            return List.of();
        }

        List<class_5481> result = new ArrayList<>();
        List<class_5481> lines = client.field_1772.method_1728(text, width);

        for (int i = 0; i < lines.size() && i < maxLines; i++) {
            result.add(lines.get(i));
        }

        return result;
    }

    private static int bottomOffset(class_310 client) {
        if (client.field_1755 instanceof class_408) {
            return 22;
        }

        return 8;
    }

    private static int panelBackgroundColor(class_310 client) {
        double opacity = Math.max(client.field_1690.method_42550().method_41753(), 0.48D);
        int value = Math.max(0, Math.min(210, (int) (255.0D * opacity)));
        return (value << 24) | 0x050607;
    }

    private static void drawChartCell(class_332 context, class_310 client, int x, int y, int width, int height, KoilMarketHudSnapshot.Entry entry, int fallbackColor, boolean showDeltas) {
        context.method_25294(x, y, x + width, y + height, 0x2A000000);
        context.method_49601(x, y, width, height, 0x55333333);
        String title = clip(entry.subject(), Math.max(5, width / Math.max(1, client.field_1772.method_1727("W")) - 8));
        context.method_25303(client.field_1772, title, x + 3, y + 3, 0xCFCFCF);
        if (showDeltas && !entry.chartDelta().isBlank()) {
            int deltaX = x + 5 + client.field_1772.method_1727(title);
            context.method_25303(client.field_1772, entry.chartDelta(), deltaX, y + 3, deltaColor(entry.chartDelta()));
        }
        int[] display = displaySeries(client, entry);
        drawMiniChart(context, x + 3, y + 12, width - 6, height - 15, display, display.length > 1 ? primaryChartColor(display) : fallbackColor);
    }

    private static void drawMiniChart(class_332 context, int x, int y, int width, int height, int[] points, int color) {
        if (points == null || points.length < 2 || width <= 2 || height <= 2) {
            return;
        }

        int[] display = renderSeriesForWidth(points, width);
        int min = Integer.MAX_VALUE;
        int max = Integer.MIN_VALUE;

        for (int point : display) {
            min = Math.min(min, point);
            max = Math.max(max, point);
        }

        if (min > 0) {
            min = 0;
        }

        if (max < 0) {
            max = 0;
        }

        int range = Math.max(1, max - min);
        int baselineY = chartY(y, height, 0, min, range);

        if (baselineY > y && baselineY < y + height) {
            drawDashedHorizontal(context, x, x + width, baselineY, 0x44909090);
        }

        drawMiniCandles(context, x, y, width, height, display, min, range);
        int lastX = x;
        int lastY = chartY(y, height, display[0], min, range);

        for (int i = 1; i < display.length; i++) {
            int nextX = x + Math.round(i * (width - 1) / (float) (display.length - 1));
            int nextY = chartY(y, height, display[i], min, range);
            drawLine(context, lastX, lastY, nextX, nextY, color);
            lastX = nextX;
            lastY = nextY;
        }
    }

    private static int[] renderSeriesForWidth(int[] source, int width) {
        if (source == null || source.length == 0) {
            return new int[0];
        }

        int samples = Math.max(2, Math.min(source.length, Math.max(2, width / 2)));

        if (source.length <= samples) {
            int[] copy = new int[source.length];
            System.arraycopy(source, 0, copy, 0, source.length);
            return copy;
        }

        int[] out = new int[samples];

        for (int i = 0; i < samples; i++) {
            int index = Math.round(i * (source.length - 1) / (float) (samples - 1));
            out[i] = source[Math.max(0, Math.min(source.length - 1, index))];
        }

        return out;
    }

    private static void drawMiniCandles(class_332 context, int x, int y, int width, int height, int[] points, int min, int range) {
        if (points == null || points.length < 4 || width < 24) {
            return;
        }

        int candleCount = Math.max(2, Math.min(12, width / 12));
        int bucket = Math.max(1, (int) Math.ceil(points.length / (float) candleCount));

        for (int i = 0; i < candleCount; i++) {
            int start = i * bucket;
            int end = Math.min(points.length, start + bucket);

            if (start >= end) {
                break;
            }

            int open = points[start];
            int close = points[end - 1];
            int high = open;
            int low = open;

            for (int valueIndex = start; valueIndex < end; valueIndex++) {
                high = Math.max(high, points[valueIndex]);
                low = Math.min(low, points[valueIndex]);
            }

            int centerX = x + Math.round((i + 0.5F) * width / candleCount);
            int highY = chartY(y, height, high, min, range);
            int lowY = chartY(y, height, low, min, range);
            int openY = chartY(y, height, open, min, range);
            int closeY = chartY(y, height, close, min, range);
            int candleColor = close >= open ? 0x6676E28E : 0x66E06666;
            context.method_25294(centerX, Math.min(highY, lowY), centerX + 1, Math.max(highY, lowY) + 1, candleColor);
            context.method_25294(centerX - 1, Math.min(openY, closeY), centerX + 2, Math.max(openY, closeY) + 1, candleColor);
        }
    }

    private static int chartY(int y, int height, int value, int min, int range) {
        return y + height - 2 - Math.round((value - min) * (height - 4) / (float) Math.max(1, range));
    }

    private static void drawDashedHorizontal(class_332 context, int x1, int x2, int y, int color) {
        for (int x = x1; x < x2; x += 6) {
            context.method_25294(x, y, Math.min(x + 3, x2), y + 1, color);
        }
    }

    private static void drawLine(class_332 context, int x1, int y1, int x2, int y2, int color) {
        int dx = Math.abs(x2 - x1);
        int dy = Math.abs(y2 - y1);
        int sx = x1 < x2 ? 1 : -1;
        int sy = y1 < y2 ? 1 : -1;
        int err = dx - dy;
        int x = x1;
        int y = y1;

        while (true) {
            context.method_25294(x, y, x + 1, y + 1, color);

            if (x == x2 && y == y2) {
                break;
            }

            int e2 = err * 2;

            if (e2 > -dy) {
                err -= dy;
                x += sx;
            }

            if (e2 < dx) {
                err += dx;
                y += sy;
            }
        }
    }

    private static int primaryChartColor(KoilMarketHudSnapshot.Entry entry) {
        return primaryChartColor(entry.series());
    }

    private static int primaryChartColor(int[] series) {
        if (series == null || series.length < 2) {
            return 0xFFE0D172;
        }

        return series[series.length - 1] >= series[0] ? 0xFF76E28E : 0xFFE06666;
    }

    private static int[] displaySeries(class_310 client, KoilMarketHudSnapshot.Entry entry) {
        long worldTime = client == null || client.field_1687 == null ? 0L : client.field_1687.method_8532();
        return KoilMarketSeriesWindow.points(entry == null ? null : entry.series(), KoilMarketSeriesWindow.activeKey(), worldTime);
    }

    private static int strongerColor(KoilMarketHudSnapshot.Entry value, KoilMarketHudSnapshot.Entry compare) {
        double first = parseMomens(value.value());
        double second = parseMomens(compare.value());
        return first >= second ? 0x76E28E : 0xE06666;
    }

    private static int scoreColor(double value, double compare, boolean higherGood) {
        if (higherGood) {
            return value > compare * 1.08D ? 0x76E28E : value < compare * 0.92D ? 0xE06666 : 0xE0D172;
        }

        return value < compare * 0.92D ? 0x76E28E : value > compare * 1.08D ? 0xE06666 : 0xE0D172;
    }

    private static int trendColor(double trend) {
        return trend > 1.05D ? 0x76E28E : trend < 0.95D ? 0xE06666 : 0xE0D172;
    }

    private static int confidenceColor(int confidence) {
        return confidence >= 70 ? 0x76E28E : confidence >= 40 ? 0xE0D172 : 0xE06666;
    }

    private static int sourceColor(String value) {
        String lower = value == null ? "" : value.toLowerCase();
        return lower.contains("estimated") ? 0xE0D172 : 0x76E28E;
    }

    private static int accentColor(KoilMarketHudSnapshot snapshot) {
        if (snapshot.entries().size() >= 2) {
            return 0xFFE9B85B;
        }

        String mode = snapshot.mode() == null ? "" : snapshot.mode().toLowerCase();
        if (mode.contains("catch")) {
            return 0xFF55DDE8;
        }

        if (mode.contains("error")) {
            return 0xFFE06666;
        }

        if (mode.contains("base") || mode.contains("currency")) {
            return 0xFFE0D172;
        }

        return 0xFF76E28E;
    }

    private static String compact(double value) {
        return KoilMarketValueQuote.compactDecimal(value);
    }

    private static double parseMomens(String value) {
        if (value == null) {
            return 0.0D;
        }

        try {
            return Double.parseDouble(value.replace("ƒ", "").replace("k", "000").replaceAll("[^0-9.]", ""));
        } catch (Exception ignored) {
            return 0.0D;
        }
    }

    private static String clip(String value, int max) {
        String safe = value == null ? "" : value;

        if (safe.length() <= max) {
            return safe;
        }

        return safe.substring(0, Math.max(0, max - 1)) + "~";
    }

    private record MarketHudBlock(List<class_5481> lines, List<KoilMarketHudSnapshot.Entry> entries, int width, int height, int paddingX, int paddingY, int lineHeight, int chartHeight, int accentColor, boolean watch, boolean showDeltas) {
    }
}
