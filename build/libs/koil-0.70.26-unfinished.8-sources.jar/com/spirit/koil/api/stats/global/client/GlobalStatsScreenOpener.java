package com.spirit.koil.api.stats.global.client;

import com.spirit.koil.api.stats.global.KoilStatsScreenOpenRequests;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_310;
import net.minecraft.class_447;

@Environment(EnvType.CLIENT)
public final class GlobalStatsScreenOpener {
    private GlobalStatsScreenOpener() {
    }

    public static void openGlobalStatsScreen() {
        class_310 client = class_310.method_1551();
        if (client == null || client.field_1724 == null) {
            return;
        }
        KoilStatsScreenOpenRequests.requestGlobalPage();
        client.execute(() -> client.method_1507(new class_447(client.field_1755, client.field_1724.method_3143())));
    }
}
