package com.spirit.koil.api.stats.global;

import net.minecraft.class_1799;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.server.MinecraftServer;
import java.util.*;

public final class GlobalActivityApi {
    public static final class_2960 CHANNEL = new class_2960("koil", "global_activity_snapshot");
    public static final class_2960 MARKET_HUD_CHANNEL = new class_2960("koil", "market_hud_snapshot");
    public static final class_2960 REQUEST_CHANNEL = new class_2960("koil", "global_activity_request");

    private GlobalActivityApi() {
    }

    public static void registerServer() {
        KoilGlobalActivityServer.register();
    }

    public static void registerClient() {
        GlobalActivityClient.registerClient();
    }

    public static void recordActivity(MinecraftServer server, UUID uuid, String playerName, String metric, int amount) {
        if (server == null || uuid == null || metric == null || metric.isBlank() || amount == 0) {
            return;
        }

        KoilGlobalActivityServer.recordExternalActivity(server, uuid, playerName, metric, amount);
    }


    public static void recordLedgerActivity(MinecraftServer server, UUID uuid, String playerName, String category, String metric, int amount) {
        if (server == null || uuid == null || metric == null || metric.isBlank() || amount == 0) {
            return;
        }

        KoilGlobalActivityServer.recordLedgerActivity(server, uuid, playerName, category, metric, amount);
    }

    public static void recordLedgerActivity(class_3222 player, String category, String metric, int amount) {
        if (player == null || player.method_5682() == null) {
            return;
        }

        recordLedgerActivity(player.method_5682(), player.method_5667(), player.method_7334().getName(), category, metric, amount);
    }



    public static void recordTransferActivity(MinecraftServer server, UUID uuid, String playerName, String metric, int amount) {
        if (server == null || uuid == null || metric == null || metric.isBlank() || amount == 0) {
            return;
        }

        KoilGlobalActivityServer.recordTransferActivity(server, uuid, playerName, metric, amount);
    }

    public static void recordTransferActivity(class_3222 player, String metric, int amount) {
        if (player == null || player.method_5682() == null) {
            return;
        }

        recordTransferActivity(player.method_5682(), player.method_5667(), player.method_7334().getName(), metric, amount);
    }

    public static void recordPacketActivity(MinecraftServer server, UUID uuid, String playerName, String metric, int amount) {
        if (server == null || uuid == null || metric == null || metric.isBlank() || amount == 0) {
            return;
        }

        KoilGlobalActivityServer.recordPacketActivity(server, uuid, playerName, metric, amount);
    }

    public static void recordPacketActivity(class_3222 player, String metric, int amount) {
        if (player == null || player.method_5682() == null) {
            return;
        }

        recordPacketActivity(player.method_5682(), player.method_5667(), player.method_7334().getName(), metric, amount);
    }

    public static void recordProcessingActivity(MinecraftServer server, String processorName, String metric, int amount) {
        if (server == null || metric == null || metric.isBlank() || amount == 0) {
            return;
        }

        KoilGlobalActivityServer.recordProcessingActivity(server, processorName, metric, amount);
    }

    public static void recordProcessingItem(MinecraftServer server, String processorName, String action, class_1799 stack, int amount) {
        if (server == null || stack == null || stack.method_7960() || action == null || action.isBlank() || amount <= 0) {
            return;
        }

        KoilGlobalActivityServer.recordProcessingItem(server, processorName, action, stack, amount);
    }

    public static void recordProcessingPair(MinecraftServer server, String processorName, String action, class_1799 first, class_1799 second, int amount) {
        if (server == null || first == null || first.method_7960() || second == null || second.method_7960() || action == null || action.isBlank() || amount <= 0) {
            return;
        }

        KoilGlobalActivityServer.recordProcessingPair(server, processorName, action, first, second, amount);
    }

    public static void recordStationActivity(MinecraftServer server, UUID uuid, String playerName, String stationName, String action, class_1799 stack, int amount) {
        if (server == null || uuid == null || stack == null || stack.method_7960() || action == null || action.isBlank() || amount <= 0) {
            return;
        }

        KoilGlobalActivityServer.recordStationItem(server, uuid, playerName, stationName, action, stack, amount);
    }

    public static void recordStationActivity(class_3222 player, String stationName, String action, class_1799 stack, int amount) {
        if (player == null || player.method_5682() == null) {
            return;
        }

        recordStationActivity(player.method_5682(), player.method_5667(), player.method_7334().getName(), stationName, action, stack, amount);
    }

    public static void recordStationMetric(class_3222 player, String stationName, String action, class_2960 id, int amount) {
        if (player == null || player.method_5682() == null || id == null || action == null || action.isBlank() || amount <= 0) {
            return;
        }

        KoilGlobalActivityServer.recordStationMetric(player.method_5682(), player.method_5667(), player.method_7334().getName(), stationName, action, id, amount);
    }

    public static void setActivityValue(MinecraftServer server, UUID uuid, String playerName, String metric, int value) {
        if (server == null || uuid == null || metric == null || metric.isBlank()) {
            return;
        }

        KoilGlobalActivityServer.setExternalActivity(server, uuid, playerName, metric, Math.max(0, value));
    }

    public static void recordActivity(class_3222 player, String metric, int amount) {
        if (player == null || player.method_5682() == null) {
            return;
        }

        recordActivity(player.method_5682(), player.method_5667(), player.method_7334().getName(), metric, amount);
    }

    public static void setActivityValue(class_3222 player, String metric, int value) {
        if (player == null || player.method_5682() == null) {
            return;
        }

        setActivityValue(player.method_5682(), player.method_5667(), player.method_7334().getName(), metric, value);
    }

    public static boolean createMarket(MinecraftServer server, String id, String metric, String name, int basePrice) {
        return KoilGlobalActivityServer.createMarketFromApi(server, id, metric, name, basePrice);
    }

    public static boolean removeMarket(MinecraftServer server, String id) {
        return KoilGlobalActivityServer.removeMarketFromApi(server, id);
    }

    public static void forceSync(MinecraftServer server) {
        KoilGlobalActivityServer.forceSyncFromApi(server);
    }



    public static KoilMarketValueConfig marketValueConfig() {
        return KoilMarketValueConfig.current();
    }

    public static KoilMarketValueConfig reloadMarketValueConfig() {
        return KoilMarketValueConfig.reload();
    }

    public static KoilMarketPriceSnapshot marketPriceSnapshot(KoilGlobalMarketViewRow row, List<KoilGlobalMarketViewRow> marketRows) {
        return KoilMarketValueEngine.priceSnapshot(row, marketRows);
    }

    public static List<KoilMarketPriceSnapshot> marketPriceSnapshots(List<KoilGlobalMarketViewRow> marketRows) {
        return KoilMarketValueEngine.priceSnapshots(marketRows);
    }

    public static KoilGlobalMarketViewRow findMarket(List<KoilGlobalMarketViewRow> marketRows, String query) {
        return KoilMarketValueEngine.findMarket(marketRows, query);
    }

    public static String compareMarkets(KoilGlobalMarketViewRow first, KoilGlobalMarketViewRow second, List<KoilGlobalMarketViewRow> marketRows) {
        return KoilMarketValueEngine.compare(first, second, marketRows);
    }

    public static int[] marketValueSeries(KoilGlobalMarketViewRow row, List<KoilGlobalMarketViewRow> marketRows) {
        return KoilMarketValueEngine.valueSeries(row, marketRows);
    }

    public static List<String> reserveBasket() {
        return KoilMarketValueEngine.reserveBasketLabels();
    }


    public static String selectedMomensBase(List<KoilGlobalMarketViewRow> marketRows) {
        return KoilMarketValueEngine.selectedReserveBaseLabel(marketRows, KoilMarketValueConfig.current());
    }

    public static String oneMomenReserveLine(List<KoilGlobalMarketViewRow> marketRows) {
        return KoilMarketValueEngine.oneMomenReserveLine(marketRows);
    }

    public static boolean physicalMomensCurrencyAvailable() {
        return KoilPhysicalMomensCurrency.available();
    }

    public static List<String> physicalMomensCurrencyNotes() {
        return KoilPhysicalMomensCurrency.detectedNotes();
    }

    public static int physicalMomensValue(class_2960 id) {
        return KoilPhysicalMomensCurrency.momensValue(id);
    }

    public static int physicalMomensValue(class_1799 stack) {
        return KoilPhysicalMomensCurrency.stackMomensValue(stack);
    }

    public static boolean isPhysicalMomens(class_1799 stack) {
        return KoilPhysicalMomensCurrency.isMomens(stack);
    }

    public static List<KoilPhysicalMomensCurrency.SourceEntry> physicalMomensSources(class_1799 stack) {
        return KoilPhysicalMomensCurrency.sources(stack);
    }

    public static int givePhysicalMomens(class_3222 player, int amount, KoilPhysicalMomensCurrency.SourceInfo source) {
        return KoilPhysicalMomensCurrency.giveMomens(player, amount, source);
    }

    public static String ledgerCategory(String metric) {
        return KoilMarketLedger.categoryForMetric(metric);
    }

    public static boolean ledgerCategoryAffectsPrice(String category) {
        return KoilMarketLedger.shouldAffectPrice(category);
    }


    public static String momensIcon() {
        return KoilMarketValueConfig.current().momensIcon();
    }

    public static KoilMarketValueQuote quoteMarket(KoilGlobalMarketViewRow row, List<KoilGlobalMarketViewRow> marketRows) {
        return KoilMarketValueEngine.quote(row, marketRows);
    }

    public static double marketMomensValue(KoilGlobalMarketViewRow row, List<KoilGlobalMarketViewRow> marketRows) {
        return KoilMarketValueEngine.quote(row, marketRows).momensValue();
    }

    public static List<KoilGlobalActivityRow> clientRows() {
        return GlobalActivityClient.rows();
    }

    public static List<KoilGlobalActivityRow> clientMarkets() {
        return GlobalActivityClient.marketRows();
    }

    public static List<KoilGlobalActivityRow> clientActivities() {
        return GlobalActivityClient.activityRows();
    }

    public static boolean clientHasServerData() {
        return GlobalActivityClient.hasServerData();
    }

    public static boolean clientHasObservedData() {
        return GlobalActivityClient.hasObservedData();
    }

    public static String clientContextKey() {
        return GlobalActivityClient.contextKey();
    }
}
