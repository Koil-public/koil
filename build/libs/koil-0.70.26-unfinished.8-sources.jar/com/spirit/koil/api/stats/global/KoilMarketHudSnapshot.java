package com.spirit.koil.api.stats.global;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_2540;

public record KoilMarketHudSnapshot(String mode, boolean watch, long createdAt, String watchQuery, String title, String subtitle, String reserveLine, String sourceLine, List<Entry> entries, List<String> notes) {
    public KoilMarketHudSnapshot {
        mode = safe(mode, "quote");
        watchQuery = safe(watchQuery, "");
        title = safe(title, "Market");
        subtitle = safe(subtitle, "");
        reserveLine = safe(reserveLine, "");
        sourceLine = safe(sourceLine, "");
        entries = entries == null ? List.of() : List.copyOf(entries);
        notes = notes == null ? List.of() : List.copyOf(notes);
    }

    public KoilMarketHudSnapshot(String mode, boolean watch, long createdAt, String watchQuery, String title, String subtitle, String reserveLine, String sourceLine, List<Entry> entries) {
        this(mode, watch, createdAt, watchQuery, title, subtitle, reserveLine, sourceLine, entries, List.of());
    }

    public void write(class_2540 buf) {
        buf.method_10788(this.mode, 32);
        buf.writeBoolean(this.watch);
        buf.writeLong(this.createdAt);
        buf.method_10788(this.watchQuery, 192);
        buf.method_10788(this.title, 96);
        buf.method_10788(this.subtitle, 160);
        buf.method_10788(this.reserveLine, 180);
        buf.method_10788(this.sourceLine, 120);
        buf.method_10804(Math.min(2, this.entries.size()));

        for (int i = 0; i < this.entries.size() && i < 2; i++) {
            this.entries.get(i).write(buf);
        }

        buf.method_10804(Math.min(12, this.notes.size()));

        for (int i = 0; i < this.notes.size() && i < 12; i++) {
            buf.method_10788(this.notes.get(i) == null ? "" : this.notes.get(i), 160);
        }
    }

    public static KoilMarketHudSnapshot read(class_2540 buf) {
        String mode = buf.method_10800(32);
        boolean watch = buf.readBoolean();
        long createdAt = buf.readLong();
        String watchQuery = buf.method_10800(192);
        String title = buf.method_10800(96);
        String subtitle = buf.method_10800(160);
        String reserveLine = buf.method_10800(180);
        String sourceLine = buf.method_10800(120);
        int size = Math.min(2, Math.max(0, buf.method_10816()));
        List<Entry> entries = new ArrayList<>();

        for (int i = 0; i < size; i++) {
            entries.add(Entry.read(buf));
        }

        List<String> notes = new ArrayList<>();

        try {
            int noteCount = Math.min(12, Math.max(0, buf.method_10816()));

            for (int i = 0; i < noteCount; i++) {
                notes.add(buf.method_10800(160));
            }
        } catch (Exception ignored) {
            notes.clear();
        }

        return new KoilMarketHudSnapshot(mode, watch, createdAt, watchQuery, title, subtitle, reserveLine, sourceLine, entries, notes);
    }

    private static String safe(String value, String fallback) {
        return value == null || value.isBlank() ? fallback : value;
    }

    public record Entry(String id, String title, String subject, String value, String exchange, String reserve, int confidence, boolean authoritative, double demand, double supply, double scarcity, double trend, int[] series, String valueDelta, String demandDelta, String supplyDelta, String scarcityDelta, String trendDelta, String chartDelta) {
        public Entry {
            id = safe(id, "");
            title = safe(title, "Market");
            subject = safe(subject, "unit");
            value = safe(value, "ƒ0");
            exchange = safe(exchange, "");
            reserve = safe(reserve, "");
            confidence = Math.max(0, Math.min(100, confidence));
            series = series == null ? new int[0] : series.clone();
            valueDelta = safe(valueDelta, "");
            demandDelta = safe(demandDelta, "");
            supplyDelta = safe(supplyDelta, "");
            scarcityDelta = safe(scarcityDelta, "");
            trendDelta = safe(trendDelta, "");
            chartDelta = safe(chartDelta, "");
        }

        public Entry(String id, String title, String subject, String value, String exchange, String reserve, int confidence, boolean authoritative, double demand, double supply, double scarcity, double trend, int[] series) {
            this(id, title, subject, value, exchange, reserve, confidence, authoritative, demand, supply, scarcity, trend, series, "", "", "", "", "", "");
        }

        private void write(class_2540 buf) {
            buf.method_10788(this.id, 160);
            buf.method_10788(this.title, 96);
            buf.method_10788(this.subject, 64);
            buf.method_10788(this.value, 32);
            buf.method_10788(this.exchange, 120);
            buf.method_10788(this.reserve, 120);
            buf.method_10804(this.confidence);
            buf.writeBoolean(this.authoritative);
            buf.writeDouble(this.demand);
            buf.writeDouble(this.supply);
            buf.writeDouble(this.scarcity);
            buf.writeDouble(this.trend);
            int length = Math.min(KoilMarketSeriesWindow.historySampleLimit(), this.series.length);
            buf.method_10804(length);

            for (int i = 0; i < length; i++) {
                buf.method_10804(Math.max(0, this.series[i]));
            }

            buf.method_10788(this.valueDelta, 48);
            buf.method_10788(this.demandDelta, 48);
            buf.method_10788(this.supplyDelta, 48);
            buf.method_10788(this.scarcityDelta, 48);
            buf.method_10788(this.trendDelta, 48);
            buf.method_10788(this.chartDelta, 48);
        }

        private static Entry read(class_2540 buf) {
            String id = buf.method_10800(160);
            String title = buf.method_10800(96);
            String subject = buf.method_10800(64);
            String value = buf.method_10800(32);
            String exchange = buf.method_10800(120);
            String reserve = buf.method_10800(120);
            int confidence = buf.method_10816();
            boolean authoritative = buf.readBoolean();
            double demand = buf.readDouble();
            double supply = buf.readDouble();
            double scarcity = buf.readDouble();
            double trend = buf.readDouble();
            int length = Math.min(KoilMarketSeriesWindow.historySampleLimit(), Math.max(0, buf.method_10816()));
            int[] series = new int[length];

            for (int i = 0; i < length; i++) {
                series[i] = buf.method_10816();
            }

            String valueDelta = "";
            String demandDelta = "";
            String supplyDelta = "";
            String scarcityDelta = "";
            String trendDelta = "";
            String chartDelta = "";

            try {
                valueDelta = buf.method_10800(48);
                demandDelta = buf.method_10800(48);
                supplyDelta = buf.method_10800(48);
                scarcityDelta = buf.method_10800(48);
                trendDelta = buf.method_10800(48);
                chartDelta = buf.method_10800(48);
            } catch (Exception ignored) {
                valueDelta = "";
                demandDelta = "";
                supplyDelta = "";
                scarcityDelta = "";
                trendDelta = "";
                chartDelta = "";
            }

            return new Entry(id, title, subject, value, exchange, reserve, confidence, authoritative, demand, supply, scarcity, trend, series, valueDelta, demandDelta, supplyDelta, scarcityDelta, trendDelta, chartDelta);
        }
    }
}
