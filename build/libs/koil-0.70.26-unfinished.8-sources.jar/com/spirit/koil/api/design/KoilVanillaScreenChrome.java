package com.spirit.koil.api.design;

import java.awt.*;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;

import static com.spirit.koil.api.design.uiColorVal.*;

public final class KoilVanillaScreenChrome {
    private static final int HEADER_HEIGHT = 36;
    private static final int HEADER_STRIPE_Y = 32;
    private static final int HEADER_STRIPE_HEIGHT = 3;
    private static final int FOOTER_HEIGHT = 35;
    private static final int FOOTER_STRIPE_HEIGHT = 3;
    private static final int CONTENT_SIDE_INSET = 35;
    private static final int CONTENT_STRIPE_LEFT_X_OFFSET = 37;
    private static final int CONTENT_STRIPE_RIGHT_X_OFFSET = 39;

    private KoilVanillaScreenChrome() {
    }

    public static void renderOptionsShell(class_332 context, class_310 client, int width, int height) {
        KoilScreenBackgrounds.render(context, client, width, height);
        renderFrame(context, width, height);
        if (KoilScreenBackgrounds.canRender(client)) {
            context.method_25294(0, 0, width, height, KoilScreenBackgrounds.overlayColor(client));
        }
    }

    public static void renderOptionsShellForcedBackground(class_332 context, class_310 client, int width, int height) {
        KoilScreenBackgrounds.renderForced(context, client, width, height);
        renderFrame(context, width, height);
        context.method_25294(0, 0, width, height, KoilScreenBackgrounds.overlayColor(client));
    }

    public static void renderListShell(class_332 context, class_310 client, int width, int height, int listTop, int listBottom) {
        KoilScreenBackgrounds.render(context, client, width, height);
        renderFrame(context, width, height, listTop, listBottom);
        if (KoilScreenBackgrounds.canRender(client)) {
            context.method_25294(0, 0, width, height, KoilScreenBackgrounds.overlayColor(client));
        }
    }

    public static void renderPanelSideStripes(class_332 context, int width, int height) {
        int footerTop = Math.max(HEADER_HEIGHT, height - FOOTER_HEIGHT);
        if (width <= CONTENT_SIDE_INSET * 2 || footerTop <= HEADER_STRIPE_Y) {
            return;
        }
        int left = CONTENT_SIDE_INSET;
        int right = width - CONTENT_SIDE_INSET;
        int top = HEADER_STRIPE_Y + 8;
        int bottom = footerTop - 8;
        int stripeLeft = new Color(uiColorContentStripeLeft, true).getRGB();
        int stripeRight = new Color(uiColorContentStripeRight, true).getRGB();
        int dash = new Color(uiColorBackgroundBorder, true).getRGB();
        context.method_25294(left - 7, top, left - 5, bottom, stripeLeft);
        context.method_25294(left - 3, top + 10, left - 2, bottom - 10, dash);
        context.method_25294(right + 5, top, right + 7, bottom, stripeRight);
        context.method_25294(right + 2, top + 10, right + 3, bottom - 10, dash);
    }

    public static void renderCreditsTextPanel(class_332 context, int width, int height) {
        if (width <= CONTENT_SIDE_INSET * 2 || height <= 12) {
            return;
        }
        int left = CONTENT_SIDE_INSET;
        int right = width - CONTENT_SIDE_INSET;
        int panelColor = new Color(uiColorContentBase, true).getRGB();
        int borderColor = new Color(uiColorBackgroundBorder, true).getRGB();
        int stripeLeft = new Color(uiColorContentStripeLeft, true).getRGB();
        int stripeRight = new Color(uiColorContentStripeRight, true).getRGB();
        int dash = borderColor;
        context.method_25294(left, 0, right, height, panelColor);
        context.method_49601(left, 0, right - left, height, borderColor);
        context.method_25294(left + 2, 8, left + 4, height - 8, stripeLeft);
        context.method_25294(left + 7, 18, left + 8, height - 18, dash);
        context.method_25294(right - 4, 8, right - 2, height - 8, stripeRight);
        context.method_25294(right - 8, 18, right - 7, height - 18, dash);
    }

    public static void renderTitle(class_332 context, class_327 textRenderer, class_2561 mainTitle, class_2561 subTitle) {
        context.method_51448().method_22903();
        context.method_51448().method_22905(1.5F, 1.5F, 1.0F);
        context.method_51439(textRenderer, mainTitle, 25, 3, new Color(uiColorHeaderTitleText, true).getRGB(), true);
        context.method_51448().method_22909();

        if (subTitle != null) {
            context.method_51439(textRenderer, subTitle, 37, 18, new Color(uiColorHeaderSubTitleText, true).getRGB(), true);
        }
    }

    public static int listTop(boolean hasExtendedControls) {
        return hasExtendedControls ? 56 : 42;
    }

    public static int listBottom(int screenHeight) {
        return Math.max(42, screenHeight - 42);
    }

    public static int languageListBottom(int screenHeight) {
        return Math.max(42, screenHeight - 61);
    }

    public static int keybindListBottom(int screenHeight, boolean hasControllingLayout) {
        return Math.max(42, screenHeight - (hasControllingLayout ? 57 : 42));
    }

    private static void renderFrame(class_332 context, int width, int height) {
        renderFrame(context, width, height, HEADER_HEIGHT, Math.max(HEADER_HEIGHT, height - FOOTER_HEIGHT));
    }

    private static void renderFrame(class_332 context, int width, int height, int headerBottom, int footerTop) {
        headerBottom = Math.max(HEADER_HEIGHT, Math.min(height, headerBottom));
        footerTop = Math.max(headerBottom, Math.min(height, footerTop));
        context.method_25294(0, 0, width, headerBottom, new Color(uiColorHeader, true).getRGB());
        int headerStripeY = Math.max(0, headerBottom - HEADER_STRIPE_HEIGHT);
        context.method_25294(0, headerStripeY, width, headerBottom, new Color(uiColorHeaderStripe, true).getRGB());
        context.method_25294(0, footerTop, width, height, new Color(uiColorFooter, true).getRGB());
        context.method_25294(0, footerTop, width, Math.min(height, footerTop + FOOTER_STRIPE_HEIGHT), new Color(uiColorFooterStripe, true).getRGB());

        if (width > CONTENT_SIDE_INSET * 2 && footerTop > headerBottom) {
            context.method_25294(CONTENT_SIDE_INSET, headerBottom, width - CONTENT_SIDE_INSET, footerTop, new Color(uiColorContentBase, true).getRGB());
            context.method_25294(CONTENT_STRIPE_LEFT_X_OFFSET, headerBottom, CONTENT_STRIPE_LEFT_X_OFFSET + 2, footerTop, new Color(uiColorContentStripeLeft, true).getRGB());
            context.method_25294(width - CONTENT_STRIPE_RIGHT_X_OFFSET, headerBottom, width - CONTENT_STRIPE_RIGHT_X_OFFSET + 2, footerTop, new Color(uiColorContentStripeRight, true).getRGB());
        }
    }
}
