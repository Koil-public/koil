package com.spirit.koil.api.design;

import com.google.gson.JsonElement;
import com.spirit.koil.api.util.file.json.JSONFileEditor;
import java.awt.*;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;

import static com.spirit.koil.api.design.uiColorVal.uiColorBackgroundOverlay;

public final class KoilScreenBackgrounds {
    private static final class_2960 VANILLA_DIRT_BACKGROUND = new class_2960("textures/gui/options_background.png");

    private KoilScreenBackgrounds() {
    }

    public static void render(class_332 context, class_310 client, int width, int height) {
        if (!canRender(client)) {
            return;
        }
        renderForced(context, client, width, height);
    }

    public static void renderForced(class_332 context, class_310 client, int width, int height) {
        if (client == null) {
            return;
        }
        if (!uiRedesignEnabled()) {
            renderVanillaDirt(context, width, height);
            return;
        }
        context.method_25293(DesignLoader.getLoadingTexture(), 0, 0, client.method_22683().method_4486(), client.method_22683().method_4502(), 0.0F, 0.0F, 319, 192, 319, 192);
    }

    public static int overlayColor(class_310 client) {
        if (client == null) {
            return 0x00000000;
        }
        if (!uiRedesignEnabled()) {
            return 0x00000000;
        }
        return new Color(uiColorBackgroundOverlay, true).getRGB();
    }

    public static boolean uiRedesignEnabled() {
        try {
            JsonElement element = JSONFileEditor.getValueFromJson("./koil/sys/config.json", "uiRedesign");
            return element != null && element.isJsonPrimitive() && element.getAsBoolean();
        } catch (Exception ignored) {
            return false;
        }
    }

    public static boolean canRender(class_310 client) {
        return client != null && client.field_1687 == null;
    }

    private static void renderVanillaDirt(class_332 context, int width, int height) {
        for (int x = 0; x < width; x += 32) {
            for (int y = 0; y < height; y += 32) {
                int tileWidth = Math.min(32, width - x);
                int tileHeight = Math.min(32, height - y);
                context.method_25290(VANILLA_DIRT_BACKGROUND, x, y, 0, 0, tileWidth, tileHeight, 32, 32);
            }
        }
        context.method_25294(0, 0, width, height, 0xB8000000);
    }
}
