package com.spirit.koil.api.performance;

import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_310;
import net.minecraft.class_4063;
import net.minecraft.class_4066;
import net.minecraft.class_5365;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public final class PerformanceConfigApplier {
    private PerformanceConfigApplier() {
    }

    public static ApplyResult applySafe(class_310 client, List<PerformanceRecommendation> recommendations) {
        if (client == null || recommendations == null || recommendations.isEmpty()) {
            return new ApplyResult(false, "No recommendations to apply.", List.of());
        }
        Path backup = backupOptions();
        List<String> applied = new ArrayList<>();
        List<PerformanceApplyEntryResult> entries = new ArrayList<>();
        for (PerformanceRecommendation recommendation : recommendations) {
            if (!recommendation.safeAutoFix()) {
                entries.add(new PerformanceApplyEntryResult(recommendation.id(), recommendation.settingKey(), "skipped", false, "Recommendation requires review."));
                continue;
            }
            if (!supportsVanillaSetting(recommendation.settingKey())) {
                entries.add(new PerformanceApplyEntryResult(recommendation.id(), recommendation.settingKey(), "provider-or-unsupported", false, "Not a vanilla GameOptions setting; provider apply may handle it."));
                continue;
            }
            if (applyOne(client, recommendation)) {
                applied.add(recommendation.id());
                entries.add(new PerformanceApplyEntryResult(recommendation.id(), recommendation.settingKey(), "applied", true, "Vanilla option updated."));
            } else {
                entries.add(new PerformanceApplyEntryResult(recommendation.id(), recommendation.settingKey(), "failed", false, "Vanilla option could not be updated."));
            }
        }
        try {
            client.field_1690.method_1640();
        } catch (Throwable ignored) {
        }
        Map<String, Object> history = new LinkedHashMap<>();
        history.put("appliedAtMillis", System.currentTimeMillis());
        history.put("backup", backup == null ? "" : backup.toString());
        history.put("appliedRecommendationIds", applied);
        history.put("entryResults", entries);
        history.put("recommendations", recommendations.stream().map(PerformanceRecommendation::toJsonMap).toList());
        PerformanceJsonStore.append(PerformancePaths.OPTIMIZATION_HISTORY, history);
        return new ApplyResult(!applied.isEmpty(), applied.isEmpty() ? "No safe vanilla recommendations were applied." : "Applied " + applied.size() + " safe vanilla recommendation(s).", applied, entries);
    }

    public static boolean revertLastBackup(class_310 client) {
        try {
            Path options = FabricLoader.getInstance().getGameDir().resolve("options.txt");
            if (!Files.exists(PerformancePaths.BACKUPS)) {
                return false;
            }
            Path latest = Files.list(PerformancePaths.BACKUPS)
                    .filter(path -> path.getFileName().toString().startsWith("options-"))
                    .max(java.util.Comparator.comparingLong(path -> path.toFile().lastModified()))
                    .orElse(null);
            if (latest == null) {
                return false;
            }
            Files.copy(latest, options, StandardCopyOption.REPLACE_EXISTING);
            PerformanceJsonStore.append(PerformancePaths.OPTIMIZATION_HISTORY, Map.of(
                    "revertedAtMillis", System.currentTimeMillis(),
                    "restoredBackup", latest.toString()
            ));
            return true;
        } catch (Exception ignored) {
            return false;
        }
    }

    private static Path backupOptions() {
        try {
            Path options = FabricLoader.getInstance().getGameDir().resolve("options.txt");
            if (!Files.exists(options)) {
                return null;
            }
            Files.createDirectories(PerformancePaths.BACKUPS);
            Path backup = PerformancePaths.BACKUPS.resolve("options-" + System.currentTimeMillis() + ".txt");
            Files.copy(options, backup, StandardCopyOption.REPLACE_EXISTING);
            return backup;
        } catch (Exception ignored) {
            return null;
        }
    }

    private static boolean applyOne(class_310 client, PerformanceRecommendation recommendation) {
        return switch (recommendation.settingKey()) {
            case "render_distance" -> setRenderDistance(client, parseInt(recommendation.afterValue(), 8));
            case "simulation_distance" -> setSimulationDistance(client, parseInt(recommendation.afterValue(), 6));
            case "max_fps" -> setMaxFps(client, recommendation.afterValue());
            case "clouds" -> setClouds(client, recommendation.afterValue());
            case "entity_distance" -> setEntityDistance(client, parseDouble(recommendation.afterValue(), 0.75D));
            case "mipmaps" -> setMipmaps(client, recommendation.afterValue());
            case "particles" -> setParticles(client, recommendation.afterValue());
            case "graphics_mode" -> setGraphicsMode(client, recommendation.afterValue());
            case "smooth_lighting" -> setSmoothLighting(client, Boolean.parseBoolean(recommendation.afterValue()));
            case "biome_blend" -> setBiomeBlend(client, parseInt(recommendation.afterValue(), 0));
            case "entity_shadows" -> setEntityShadows(client, Boolean.parseBoolean(recommendation.afterValue()));
            case "vsync" -> setVsync(client, false);
            default -> false;
        };
    }

    private static boolean supportsVanillaSetting(String key) {
        return switch (key) {
            case "render_distance", "simulation_distance", "max_fps", "clouds", "entity_distance", "mipmaps", "particles", "graphics_mode", "smooth_lighting", "biome_blend", "entity_shadows", "vsync" -> true;
            default -> false;
        };
    }

    private static int parseInt(String value, int fallback) {
        try {
            return Integer.parseInt(value.trim());
        } catch (Exception ignored) {
            return fallback;
        }
    }

    private static double parseDouble(String value, double fallback) {
        try {
            return Double.parseDouble(value.trim());
        } catch (Exception ignored) {
            return fallback;
        }
    }

    private static boolean setRenderDistance(class_310 client, int value) {
        try {
            client.field_1690.method_42503().method_41748(Math.max(2, value));
            requestTerrainUpdate(client);
            return true;
        } catch (Throwable ignored) {
            return false;
        }
    }

    private static boolean setSimulationDistance(class_310 client, int value) {
        try {
            client.field_1690.method_42510().method_41748(Math.max(2, value));
            requestTerrainUpdate(client);
            return true;
        } catch (Throwable ignored) {
            return false;
        }
    }

    private static boolean setMaxFps(class_310 client, String value) {
        try {
            client.field_1690.method_42524().method_41748(resolveMaxFps(value));
            return true;
        } catch (Throwable ignored) {
            return false;
        }
    }

    private static int resolveMaxFps(String value) {
        if (value != null) {
            String normalized = value.trim().toLowerCase(java.util.Locale.ROOT);
            if ("unlimited".equals(normalized) || "max".equals(normalized)) {
                return 260;
            }
        }
        return Math.max(10, parseInt(value, 120));
    }

    private static boolean setEntityDistance(class_310 client, double value) {
        try {
            client.field_1690.method_42517().method_41748(Math.max(0.5D, Math.min(1.0D, value)));
            return true;
        } catch (Throwable ignored) {
            return false;
        }
    }

    private static void requestTerrainUpdate(class_310 client) {
        try {
            if (client.field_1769 != null) {
                client.field_1769.method_3279();
            }
        } catch (Throwable ignored) {
        }
    }

    private static boolean setClouds(class_310 client, String value) {
        try {
            String normalized = value == null ? "" : value.trim().toLowerCase(java.util.Locale.ROOT);
            class_4063 mode = switch (normalized) {
                case "fancy" -> class_4063.field_18164;
                case "fast" -> class_4063.field_18163;
                default -> class_4063.field_18162;
            };
            client.field_1690.method_42528().method_41748(mode);
            return true;
        } catch (Throwable ignored) {
            return false;
        }
    }

    private static boolean setMipmaps(class_310 client, String value) {
        try {
            int current = client.field_1690.method_42563().method_41753();
            int target = value == null || value.toLowerCase(java.util.Locale.ROOT).contains("one step")
                    ? Math.max(0, current - 1)
                    : Math.max(0, Math.min(4, parseInt(value, current)));
            client.field_1690.method_42563().method_41748(target);
            client.method_1521();
            return true;
        } catch (Throwable ignored) {
            return false;
        }
    }

    private static boolean setParticles(class_310 client, String value) {
        try {
            String normalized = value == null ? "" : value.trim().toLowerCase(java.util.Locale.ROOT);
            class_4066 mode = switch (normalized) {
                case "minimal" -> class_4066.field_18199;
                case "all" -> class_4066.field_18197;
                default -> class_4066.field_18198;
            };
            client.field_1690.method_42475().method_41748(mode);
            return true;
        } catch (Throwable ignored) {
            return false;
        }
    }

    private static boolean setGraphicsMode(class_310 client, String value) {
        try {
            String normalized = value == null ? "" : value.trim().toLowerCase(java.util.Locale.ROOT);
            client.field_1690.method_42534().method_41748("fancy".equals(normalized) ? class_5365.field_25428 : class_5365.field_25427);
            requestTerrainUpdate(client);
            return true;
        } catch (Throwable ignored) {
            return false;
        }
    }

    private static boolean setSmoothLighting(class_310 client, boolean value) {
        try {
            client.field_1690.method_41792().method_41748(value);
            requestTerrainUpdate(client);
            return true;
        } catch (Throwable ignored) {
            return false;
        }
    }

    private static boolean setBiomeBlend(class_310 client, int value) {
        try {
            client.field_1690.method_41805().method_41748(Math.max(0, value));
            requestTerrainUpdate(client);
            return true;
        } catch (Throwable ignored) {
            return false;
        }
    }

    private static boolean setEntityShadows(class_310 client, boolean value) {
        try {
            client.field_1690.method_42435().method_41748(value);
            return true;
        } catch (Throwable ignored) {
            return false;
        }
    }

    private static boolean setVsync(class_310 client, boolean value) {
        try {
            client.field_1690.method_42433().method_41748(value);
            return true;
        } catch (Throwable ignored) {
            return false;
        }
    }

    public record ApplyResult(boolean changed, String message, List<String> appliedRecommendationIds, List<PerformanceApplyEntryResult> entryResults) {
        public ApplyResult(boolean changed, String message, List<String> appliedRecommendationIds) {
            this(changed, message, appliedRecommendationIds, List.of());
        }
    }
}
