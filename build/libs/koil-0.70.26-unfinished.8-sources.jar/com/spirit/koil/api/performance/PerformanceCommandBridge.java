package com.spirit.koil.api.performance;

import com.mojang.brigadier.arguments.StringArgumentType;
import com.spirit.client.gui.tool.PerformanceOptimizerScreen;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import java.util.List;

import static com.mojang.brigadier.arguments.StringArgumentType.getString;
import static net.fabricmc.fabric.api.client.command.v2.ClientCommandManager.argument;
import static net.fabricmc.fabric.api.client.command.v2.ClientCommandManager.literal;

@Environment(EnvType.CLIENT)
public final class PerformanceCommandBridge {
    private PerformanceCommandBridge() {
    }

    public static void registerClientCommands() {
        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) -> dispatcher.register(literal("optimize")
                .executes(context -> {
                    openScreen();
                    return 1;
                })
                .then(literal("benchmark").executes(context -> {
                    class_310 client = class_310.method_1551();
                    boolean started = PerformanceOptimizationTestService.start(client, PerformanceProfileMode.AUTO, client == null ? null : client.field_1755);
                    send(started ? "Benchmark started. In-world UI will hide during sampling." : "Benchmark is already running.");
                    return started ? 1 : 0;
                }))
                .then(literal("auto").executes(context -> {
                    class_310 client = class_310.method_1551();
                    PerformanceHardwareScanner.scan(client);
                    boolean started = PerformanceOptimizationTestService.start(client, PerformanceProfileMode.AUTO, client == null ? null : new PerformanceOptimizerScreen(client.field_1755));
                    send(started ? "Auto benchmark started. Review recommendations before applying supported changes." : "Benchmark is already running.");
                    return started ? 1 : 0;
                }))
                .then(literal("revert").executes(context -> {
                    boolean reverted = PerformanceConfigApplier.revertLastBackup(class_310.method_1551());
                    send(reverted ? "Reverted last Koil optimization backup. Restart or reload options if Minecraft does not update immediately." : "No Koil optimization backup was found.");
                    return reverted ? 1 : 0;
                }))
                .then(literal("profile").then(argument("mode", StringArgumentType.word()).executes(context -> {
                    PerformanceProfileMode mode = PerformanceProfileMode.fromCommand(getString(context, "mode"));
                    class_310 client = class_310.method_1551();
                    PerformanceSnapshot snapshot = PerformanceMonitor.latestSnapshot(client);
                    List<PerformanceRecommendation> recommendations = PerformanceRecommendationEngine.recommend(client, mode, snapshot);
                    java.util.Map<String, Object> profile = PerformanceProfileManager.saveProfileSuggestion(client, mode, snapshot);
                    profile.put("recommendations", recommendations.stream().map(PerformanceRecommendation::toJsonMap).toList());
                    PerformanceJsonStore.write(PerformancePaths.PERFORMANCE_PROFILES, profile);
                    send("Selected optimizer profile: " + mode.label());
                    return 1;
                })))
                .then(literal("report").executes(context -> {
                    PerformanceReportService.writeReport(class_310.method_1551(), PerformanceProfileMode.AUTO, List.of());
                    send("Performance report written to " + PerformancePaths.PERFORMANCE_REPORT);
                    return 1;
                }))
        ));
    }

    private static void openScreen() {
        class_310 client = class_310.method_1551();
        if (client != null) {
            client.method_18858(() -> client.method_1507(new PerformanceOptimizerScreen(client.field_1755)));
        }
    }

    private static void send(String message) {
        class_310 client = class_310.method_1551();
        if (client != null && client.field_1724 != null) {
            client.field_1724.method_7353(class_2561.method_43470("[Koil Performance] " + message), false);
        }
    }
}
