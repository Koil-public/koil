package com.spirit.koil.api.performance;

import java.util.List;
import net.minecraft.class_310;

public interface PerformanceOptimizationProvider {
    String id();

    String label();

    boolean installed();

    boolean configAvailable();

    String status();

    List<PerformanceSettingDescriptor> settings(class_310 client, PerformanceSnapshot snapshot);

    PerformanceProviderApplyResult apply(class_310 client, PerformanceSettingDescriptor setting);
}
