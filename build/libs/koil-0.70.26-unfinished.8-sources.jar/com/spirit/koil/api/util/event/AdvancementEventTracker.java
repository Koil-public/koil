package com.spirit.koil.api.util.event;

import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.minecraft.class_161;
import net.minecraft.class_167;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import java.util.*;
import java.util.function.Consumer;

public class AdvancementEventTracker {
    private static final Map<UUID, Set<class_2960>> completedAdvancements = new HashMap<>();

    public static void trackAdvancement(class_3222 player, class_2960 advancementId, Consumer<class_3222> action) {
        class_161 advancement = player.field_13995.method_3851().method_12896(advancementId);
        if (advancement != null) {
            class_167 progress = player.method_14236().method_12882(advancement);
            UUID playerId = player.method_5667();

            completedAdvancements.putIfAbsent(playerId, new HashSet<>());

            if (progress.method_740() && !completedAdvancements.get(playerId).contains(advancementId)) {
                action.accept(player);
                completedAdvancements.get(playerId).add(advancementId);
            }

            if (!progress.method_740() && completedAdvancements.get(playerId).contains(advancementId)) {
                completedAdvancements.get(playerId).remove(advancementId);
            }
        }
    }

    public static void trackAdvancement(class_2960 advancementId, Consumer<class_3222> action) {
        ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> {
            class_3222 player = handler.field_14140;
            checkAdvancementOnJoin(player, advancementId, action);
        });

        ServerTickEvents.END_SERVER_TICK.register(server -> server.method_3760().method_14571().forEach(player ->
                trackAdvancement(player, advancementId, action)
        ));
    }

    private static void checkAdvancementOnJoin(class_3222 player, class_2960 advancementId, Consumer<class_3222> action) {
        class_161 advancement = player.field_13995.method_3851().method_12896(advancementId);
        if (advancement != null) {
            class_167 progress = player.method_14236().method_12882(advancement);
            UUID playerId = player.method_5667();

            completedAdvancements.putIfAbsent(playerId, new HashSet<>());

            if (progress.method_740() && !completedAdvancements.get(playerId).contains(advancementId)) {
                completedAdvancements.get(playerId).add(advancementId);
            }
        }
    }
}
