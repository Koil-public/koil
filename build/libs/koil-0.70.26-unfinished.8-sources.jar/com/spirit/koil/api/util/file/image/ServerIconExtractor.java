package com.spirit.koil.api.util.file.image;

import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Base64;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2507;

import static com.spirit.Main.*;

public class ServerIconExtractor {
    public static void extractAndSaveServerIcons() {
        File serverDat = new File("./servers.dat");
        SUBLOGGER.logI("File-Management thread", "Finding servers.dat file in Minecraft instance");

        if (!serverDat.exists()) {
            SUBLOGGER.logW("File-Management thread", "Unable to Find servers.dat file in Minecraft instance | ~instance");
            return;
        } else {
            SUBLOGGER.logI("File-Management thread", "Found servers.dat file in Minecraft instance");
        }

        try (FileInputStream fis = new FileInputStream(serverDat);
            DataInputStream dis = new DataInputStream(fis)) {
            class_2487 rootTag = class_2507.method_10627(dis);
            class_2499 servers = rootTag.method_10554("servers", 10);
            for (int i = 0; i < servers.size(); i++) {
                class_2487 server = servers.method_10602(i);
                String serverIp = server.method_10558("ip");
                String iconBase64 = server.method_10558("icon");

                if (iconBase64 != null && !iconBase64.isEmpty()) {
                    byte[] iconBytes = Base64.getDecoder().decode(iconBase64.substring(iconBase64.indexOf(",") + 1));
                    File outputFile = new File(uiImageServerIconDirectory + serverIp + ".png");

                    outputFile.getParentFile().mkdirs();
                    java.nio.file.Files.write(outputFile.toPath(), iconBytes);
                    SUBLOGGER.logI("File-Management thread", "Saved server icon for " + serverIp + " to " + outputFile.getPath());
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
