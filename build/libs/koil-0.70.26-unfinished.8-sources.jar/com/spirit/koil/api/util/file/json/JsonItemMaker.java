package com.spirit.koil.api.util.file.json;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.item.v1.FabricItemSettings;
import net.minecraft.class_1291;
import net.minecraft.class_1293;
import net.minecraft.class_1299;
import net.minecraft.class_1530;
import net.minecraft.class_1688;
import net.minecraft.class_1739;
import net.minecraft.class_1742;
import net.minecraft.class_1743;
import net.minecraft.class_1744;
import net.minecraft.class_1751;
import net.minecraft.class_1752;
import net.minecraft.class_1753;
import net.minecraft.class_1754;
import net.minecraft.class_1756;
import net.minecraft.class_1757;
import net.minecraft.class_1758;
import net.minecraft.class_1759;
import net.minecraft.class_1762;
import net.minecraft.class_1763;
import net.minecraft.class_1764;
import net.minecraft.class_1765;
import net.minecraft.class_1767;
import net.minecraft.class_1769;
import net.minecraft.class_1770;
import net.minecraft.class_1771;
import net.minecraft.class_1772;
import net.minecraft.class_1773;
import net.minecraft.class_1774;
import net.minecraft.class_1775;
import net.minecraft.class_1776;
import net.minecraft.class_1777;
import net.minecraft.class_1778;
import net.minecraft.class_1779;
import net.minecraft.class_1780;
import net.minecraft.class_1781;
import net.minecraft.class_1786;
import net.minecraft.class_1787;
import net.minecraft.class_1788;
import net.minecraft.class_1792;
import net.minecraft.class_1794;
import net.minecraft.class_1795;
import net.minecraft.class_1798;
import net.minecraft.class_1801;
import net.minecraft.class_1803;
import net.minecraft.class_1804;
import net.minecraft.class_1805;
import net.minecraft.class_1806;
import net.minecraft.class_1807;
import net.minecraft.class_1808;
import net.minecraft.class_1809;
import net.minecraft.class_1810;
import net.minecraft.class_1812;
import net.minecraft.class_1813;
import net.minecraft.class_1814;
import net.minecraft.class_1816;
import net.minecraft.class_1819;
import net.minecraft.class_1820;
import net.minecraft.class_1821;
import net.minecraft.class_1823;
import net.minecraft.class_1824;
import net.minecraft.class_1825;
import net.minecraft.class_1826;
import net.minecraft.class_1827;
import net.minecraft.class_1828;
import net.minecraft.class_1829;
import net.minecraft.class_1830;
import net.minecraft.class_1833;
import net.minecraft.class_1834;
import net.minecraft.class_1835;
import net.minecraft.class_1840;
import net.minecraft.class_1841;
import net.minecraft.class_1843;
import net.minecraft.class_2248;
import net.minecraft.class_2350;
import net.minecraft.class_2378;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_3414;
import net.minecraft.class_3734;
import net.minecraft.class_4059;
import net.minecraft.class_4174;
import net.minecraft.class_4480;
import net.minecraft.class_4537;
import net.minecraft.class_5537;
import net.minecraft.class_5538;
import net.minecraft.class_5953;
import net.minecraft.class_7409;
import net.minecraft.class_7923;
import net.minecraft.class_8052;
import net.minecraft.class_8162;
import net.minecraft.class_8232;
import net.minecraft.class_8233;
import net.minecraft.item.*;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.Enumeration;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

import static com.spirit.Main.SUBLOGGER;

public class JsonItemMaker {
    public static void makeTheJsonItem() {
        ServerLifecycleEvents.SERVER_STARTING.register(server -> {
            Path customItemsDir = Paths.get(server.method_3831().getPath(), "./koil/json/", server.method_27728().method_150() + "/items");
            if (!Files.exists(customItemsDir)) {
                try {
                    Files.createDirectories(customItemsDir);
                    SUBLOGGER.logI("Json-Item-API thread", "Created custom items directory: " + customItemsDir);
                } catch (IOException e) {
                    SUBLOGGER.logE("Json-Item-API thread", "Failed to create custom items directory: " + e);
                    return;
                }
            }
            Path datapacksDir = Paths.get(server.method_3831().getPath(), "./saves/", server.method_27728().method_150() + "/datapacks/");
            SUBLOGGER.logI("Json-Item-API thread", "Searching for datapacks in: " + datapacksDir);
            searchAndCopyItems(datapacksDir, customItemsDir);
        });
    }

    private static void searchAndCopyItems(Path sourceDir, Path targetDir) {
        if (!Files.isDirectory(sourceDir)) {
            SUBLOGGER.logW("Json-Item-API thread", "Datapacks directory does not exist or is not a directory: " + sourceDir);
            return;
        }

        try {
            Files.walk(sourceDir)
                    .filter(path -> Files.isDirectory(path) || path.toString().endsWith(".zip"))
                    .forEach(path -> {
                        if (Files.isDirectory(path)) {
                            copyItemsFromFolder(path, targetDir);
                        } else if (path.toString().endsWith(".zip")) {
                            extractAndCopyItemsFromZip(path, targetDir);
                        }
                    });
        } catch (IOException e) {
            SUBLOGGER.logE("Json-Item-API thread", "Failed to walk through the datapacks directory: " + e);
        }
    }

    private static void copyItemsFromFolder(Path sourceDir, Path targetDir) {
        Path koilItemsDir = sourceDir.resolve("data/koil/json/items");
        if (Files.exists(koilItemsDir) && Files.isDirectory(koilItemsDir)) {
            try {
                Files.walk(koilItemsDir)
                        .filter(Files::isRegularFile)
                        .forEach(sourcePath -> {
                            Path relativePath = koilItemsDir.relativize(sourcePath);
                            Path targetPath = targetDir.resolve(relativePath);
                            try {
                                Files.createDirectories(targetPath.getParent());
                                Files.copy(sourcePath, targetPath, StandardCopyOption.REPLACE_EXISTING);
                                SUBLOGGER.logI("Json-Item-API thread", "Copied item from folder: " + sourcePath + " to: " + targetPath);
                            } catch (IOException e) {
                                SUBLOGGER.logE("Json-Item-API thread", "Failed to copy item from folder: " + sourcePath + "\n" + e);
                            }
                        });
            } catch (IOException e) {
                SUBLOGGER.logE("Json-Item-API thread", "Failed to walk through the koil/json/items directory: " + e);
            }
        }
    }

    private static void extractAndCopyItemsFromZip(Path zipFile, Path targetDir) {
        try (ZipFile zip = new ZipFile(zipFile.toFile())) {
            Enumeration<? extends ZipEntry> entries = zip.entries();
            while (entries.hasMoreElements()) {
                ZipEntry entry = entries.nextElement();
                if (entry.getName().startsWith("data/koil/json/items/") && !entry.isDirectory()) {
                    Path targetPath = targetDir.resolve(entry.getName().substring("data/koil/json/items/".length()));
                    try (InputStream is = zip.getInputStream(entry)) {
                        Files.createDirectories(targetPath.getParent());
                        Files.copy(is, targetPath, StandardCopyOption.REPLACE_EXISTING);
                        SUBLOGGER.logI("Json-Item-API thread", "Extracted and copied item from zip: " + entry.getName() + " to: " + targetPath);
                    } catch (IOException e) {
                        SUBLOGGER.logE("Json-Item-API thread", "Failed to extract and copy item from zip: " + entry.getName() + "\n" + e);
                    }
                }
            }
        } catch (IOException e) {
            SUBLOGGER.logE("Json-Item-API thread", "Failed to extract items from zip file: " + zipFile + "\n" + e);
        }
    }

    public static void registerItemsFromJson() {
        Path koilDirectory = Paths.get("./koil/json/").toAbsolutePath();

        try {
            Files.walk(koilDirectory)
                    .filter(Files::isDirectory)
                    .forEach(worldDirectory -> {
                        String worldName = worldDirectory.getFileName().toString();
                        Path itemsDirectory = worldDirectory.resolve("items");

                        try {
                            Files.walk(itemsDirectory)
                                    .filter(path -> path.toString().endsWith(".json"))
                                    .forEach(path -> {
                                        try (FileReader reader = new FileReader(path.toFile())) {
                                            JsonObject jsonObject = JsonParser.parseReader(reader).getAsJsonObject();

                                            if (jsonObject.has("type")) {
                                                registerItemFromJson(jsonObject, worldName, path.toString());
                                            } else {
                                                SUBLOGGER.logE("Json-Item-API thread", "Missing 'type' field in JSON file: " + path);
                                            }
                                        } catch (Exception e) {
                                            SUBLOGGER.logE("Json-Item-API thread", "Failed to read the JSON file: " + path);
                                            e.printStackTrace();
                                        }
                                    });
                        } catch (IOException ignored) {
                        }
                    });
        } catch (IOException e) {
            SUBLOGGER.logE("Json-Item-API thread", "Failed to walk through the koil directory");
            e.printStackTrace();
        }
    }


    private static void registerItemFromJson(JsonObject jsonObject, String path, String string) {
        String modId = jsonObject.get("mod-id").getAsString();
        String itemName = jsonObject.get("name").getAsString().toLowerCase();
        String type = jsonObject.get("type").getAsString();
        String rarity = jsonObject.has("rarity") ? jsonObject.get("rarity").getAsString() : "common";
        class_2960 itemId = new class_2960(modId, itemName.toLowerCase().replace(" ", "_"));
        int maxCount = jsonObject.has("max-count") ? jsonObject.get("max-count").getAsInt() : 64;
        int durability = jsonObject.has("durability") ? jsonObject.get("durability").getAsInt() : 0;

        class_1792.class_1793 itemSettings = new FabricItemSettings().method_7894(getRarity(rarity)).method_7889(maxCount).method_7895(durability);

        boolean fireproof = jsonObject.has("fireproof") && jsonObject.get("fireproof").getAsBoolean();
        if (fireproof) {itemSettings.method_24359();}


        class_1792 newItem;
        switch (type) {
            case "normal":
                newItem = new class_1792(itemSettings);
                break;

            case "food":
                float saturationModifier = jsonObject.has("saturation-modifier") ? jsonObject.get("saturation-modifier").getAsFloat() : 0.1F;
                int hunger = jsonObject.has("hunger") ? jsonObject.get("hunger").getAsInt() : 1;

                class_4174.class_4175 foodBuilder = new class_4174.class_4175().method_19238(hunger).method_19237(saturationModifier);

                if (jsonObject.has("status-effects")) {
                    JsonArray statusEffectsArray = jsonObject.getAsJsonArray("status-effects");
                    for (JsonElement element : statusEffectsArray) {
                        JsonObject statusEffectObject = element.getAsJsonObject();
                        String statusEffectName = statusEffectObject.get("name").getAsString();
                        int duration = statusEffectObject.get("duration").getAsInt();
                        int amplifier = statusEffectObject.get("amplifier").getAsInt();
                        float chance = statusEffectObject.get("chance").getAsFloat();
                        class_1291 statusEffect = class_7923.field_41174.method_10223(new class_2960(statusEffectName));
                        if (statusEffect != null) {
                            foodBuilder.method_19239(new class_1293(statusEffect, duration, amplifier), chance);
                        }
                    }
                }
                newItem = new class_1792(itemSettings.method_19265(foodBuilder.method_19242()));
                break;


            case "air":
                class_2248 airBlock = class_7923.field_41175.method_10223(new class_2960(jsonObject.has("block") ? jsonObject.get("block").getAsString() : "air"));
                newItem = new class_1739(airBlock, itemSettings);
                break;
            case "aliased_block":
                class_2248 aliasedBlock = class_7923.field_41175.method_10223(new class_2960(jsonObject.has("block") ? jsonObject.get("block").getAsString() : "air"));
                newItem = new class_1798(aliasedBlock, itemSettings);
                break;
                /*
            case "armor":
                String armorMaterial = jsonObject.has("armor-material") ? jsonObject.get("armor-material").getAsString() : "wood";
                String armorType = jsonObject.get("armor-type").getAsString();
                newItem = new ArmorItem(getArmorMaterial(armorMaterial), getArmorType(armorType), itemSettings);
                break;
                 */
            case "armor_stand":
                newItem = new class_1742(itemSettings);
                break;
            case "arrow":
                newItem = new class_1744(itemSettings);
                break;
            case "axe":
                String axeToolMaterial = jsonObject.get("tool-material").getAsString();
                int axeAttackDamage = jsonObject.has("attack-damage") ? jsonObject.get("attack-damage").getAsInt() : 0;
                float axeAttackSpeed = jsonObject.has("attack-speed") ? jsonObject.get("attack-speed").getAsFloat() : 0F;
                newItem = new class_1743(getToolMaterial(axeToolMaterial), axeAttackDamage, axeAttackSpeed, itemSettings);
                break;
            case "bone_meal":
                newItem = new class_1752(itemSettings);
                break;
            case "book":
                newItem = new class_1751(itemSettings);
                break;
            case "bow":
                newItem = new class_1753(itemSettings);
                break;
            case "brush":
                newItem = new class_8162(itemSettings);
                break;
            case "bundle":
                newItem = new class_5537(itemSettings);
                break;
            case "chorus_fruit":
                newItem = new class_1757(itemSettings);
                break;
            case "compass":
                newItem = new class_1759(itemSettings);
                break;
            case "crossbow":
                newItem = new class_1764(itemSettings);
                break;
            case "debug_stick":
                newItem = new class_1763(itemSettings);
                break;
            case "disc_fragment":
                newItem = new class_7409(itemSettings);
                break;
            case "dye":
                String getDyeItemColorString = jsonObject.get("dye-color").getAsString();
                newItem = new class_1769(getDyeColor(getDyeItemColorString), itemSettings);
                break;
            case "egg":
                newItem = new class_1771(itemSettings);
                break;
            case "elytra":
                newItem = new class_1770(itemSettings);
                break;
            case "empty_map":
                newItem = new class_1773(itemSettings);
                break;
            case "enchanted_book":
                newItem = new class_1772(itemSettings);
                break;
            case "enchanted_golden_apple":
                newItem = new class_1775(itemSettings);
                break;
            case "end_crystal":
                newItem = new class_1774(itemSettings);
                break;
            case "ender_eye":
                newItem = new class_1777(itemSettings);
                break;
            case "ender_pearl":
                newItem = new class_1776(itemSettings);
                break;
            case "experience_bottle":
                newItem = new class_1779(itemSettings);
                break;
            case "filled_map":
                newItem = new class_1806(itemSettings);
                break;
            case "fire_charge":
                newItem = new class_1778(itemSettings);
                break;
            case "firework_rocket":
                newItem = new class_1781(itemSettings);
                break;
            case "firework_star":
                newItem = new class_1780(itemSettings);
                break;
            case "fishing_rod":
                newItem = new class_1787(itemSettings);
                break;
            case "flint_and_steel":
                newItem = new class_1786(itemSettings);
                break;
            case "glass_bottle":
                newItem = new class_1754(itemSettings);
                break;
            case "glow_ink_sac":
                newItem = new class_8232(itemSettings);
                break;
            case "hoe":
                String hoeToolMaterial = jsonObject.get("tool-material").getAsString();
                int hoeAttackDamage = jsonObject.has("attack-damage") ? jsonObject.get("attack-damage").getAsInt() : 0;
                float hoeAttackSpeed = jsonObject.has("attack-speed") ? jsonObject.get("attack-speed").getAsFloat() : 0F;
                newItem = new class_1794(getToolMaterial(hoeToolMaterial), hoeAttackDamage, hoeAttackSpeed, itemSettings);
                break;
            case "honey_bottle":
                newItem = new class_4480(itemSettings);
                break;
            case "honeycomb":
                newItem = new class_5953(itemSettings);
                break;
            case "horse_armor":
                int bonus = jsonObject.has("bonus") ? jsonObject.get("bonus").getAsInt() : 0;
                newItem = new class_4059(bonus, itemName, itemSettings);
                break;
            case "ink_sac":
                newItem = new class_8233(itemSettings);
                break;
            case "item":
                newItem = new class_1792(itemSettings);
                break;
            case "item_frame":
                class_1299<?> entityType = class_7923.field_41177.method_10223(new class_2960(jsonObject.get("entity-type").getAsString()));
                newItem = new class_1795((class_1299<? extends class_1530>) entityType, itemSettings);
                break;
            case "knowledge_book":
                newItem = new class_1801(itemSettings);
                break;
            case "lead":
                newItem = new class_1804(itemSettings);
                break;
            case "lingering_potion":
                newItem = new class_1803(itemSettings);
                break;
            case "milk_bucket":
                newItem = new class_1805(itemSettings);
                break;
            case "minecart":
                String getMinecartItemTypeString = jsonObject.get("minecart-item-type").getAsString();
                newItem = new class_1808(getMinecartItemType(getMinecartItemTypeString), itemSettings);
                break;
            case "music_disc":
                int comparatorOutput = jsonObject.has("comparator-output") ? jsonObject.get("comparator-output").getAsInt() : 1;
                class_3414 musicDiscSound = class_7923.field_41172.method_10223(new class_2960(jsonObject.get("sound").getAsString()));
                int lengthInSeconds = jsonObject.has("length-in-seconds") ? jsonObject.get("length-in-seconds").getAsInt() : 1;
                newItem = new class_1813(comparatorOutput, musicDiscSound, itemSettings, lengthInSeconds);
                break;
            case "name_tag":
                newItem = new class_1807(itemSettings);
                break;
            case "nether_star":
                newItem = new class_1824(itemSettings);
                break;
            case "network_synced":
                newItem = new class_1762(itemSettings);
                break;
            case "on_a_stick":
                class_1299 onAStickEntityType = class_7923.field_41177.method_10223(new class_2960(jsonObject.get("entity-target").getAsString()));
                int damagePerUse = jsonObject.has("damage-per-use") ? jsonObject.get("damage-per-use").getAsInt() : 1;
                newItem = new class_1758(itemSettings, onAStickEntityType, damagePerUse);
                break;
            case "operator_only_block":
                class_2248 operatorOnlyBlock = class_7923.field_41175.method_10223(new class_2960(jsonObject.has("block") ? jsonObject.get("block").getAsString() : "air"));
                newItem = new class_1788(operatorOnlyBlock, itemSettings);
                break;
            case "pickaxe":
                String pickaxeToolMaterial = jsonObject.get("tool-material").getAsString();
                int pickaxeAttackDamage = jsonObject.has("attack-damage") ? jsonObject.get("attack-damage").getAsInt() : 0;
                float pickaxeAttackSpeed = jsonObject.has("attack-speed") ? jsonObject.get("attack-speed").getAsFloat() : 0F;
                newItem = new class_1810(getToolMaterial(pickaxeToolMaterial), pickaxeAttackDamage, pickaxeAttackSpeed, itemSettings);
                break;
            case "placeable_on_water":
                class_2248 placeableOnWaterBlock = class_7923.field_41175.method_10223(new class_2960(jsonObject.has("block") ? jsonObject.get("block").getAsString() : "air"));
                newItem = new class_1841(placeableOnWaterBlock, itemSettings);
                break;
            case "potion":
                newItem = new class_1812(itemSettings);
                break;
            case "saddle":
                newItem = new class_1816(itemSettings);
                break;
            case "scaffolding":
                class_2248 scaffoldingBlock = class_7923.field_41175.method_10223(new class_2960(jsonObject.has("block") ? jsonObject.get("block").getAsString() : "air"));
                newItem = new class_3734(scaffoldingBlock,itemSettings);
                break;
            case "shears":
                newItem = new class_1820(itemSettings);
                break;
            case "shield":
                newItem = new class_1819(itemSettings);
                break;
            case "shovel":
                String shovelToolMaterial = jsonObject.get("tool-material").getAsString();
                int shovelAttackDamage = jsonObject.has("attack-damage") ? jsonObject.get("attack-damage").getAsInt() : 0;
                float shovelAttackSpeed = jsonObject.has("attack-speed") ? jsonObject.get("attack-speed").getAsFloat() : 0F;
                newItem = new class_1821(getToolMaterial(shovelToolMaterial), shovelAttackDamage, shovelAttackSpeed, itemSettings);
                break;
            case "skull":
                class_2248 skullBlock = class_7923.field_41175.method_10223(new class_2960(jsonObject.has("skull") ? jsonObject.get("skull").getAsString() : "air"));
                class_2248 skullwallBlock = class_7923.field_41175.method_10223(new class_2960(jsonObject.has("skull-wall") ? jsonObject.get("skull-wall").getAsString() : "air"));
                newItem = new class_1809(skullBlock, skullwallBlock, itemSettings);
                break;
            case "smithing_template":
                class_2561 appliedToText = class_2561.method_30163(jsonObject.get("applied-to-text").getAsString());
                class_2561 ingredientsText = class_2561.method_30163(jsonObject.get("ingredients-text").getAsString());
                class_2561 additionsSlotDescriptionText = class_2561.method_30163(jsonObject.get("additions-slot-description-text").getAsString());
                class_2561 baseSlotDescriptionText = class_2561.method_30163(jsonObject.get("base-slot-description-text").getAsString());
                class_2561 emptyAdditionsSlotTextures = class_2561.method_30163(jsonObject.get("empty-additions-slot-textures").getAsString());
                class_2561 emptyBaseSlotTextures = class_2561.method_30163(jsonObject.get("empty-base-slot-textures").getAsString());
                newItem = new class_8052(appliedToText, ingredientsText, additionsSlotDescriptionText, baseSlotDescriptionText, emptyAdditionsSlotTextures, (List<class_2960>) emptyBaseSlotTextures, (List<class_2960>) emptyAdditionsSlotTextures);
                break;
            case "snowball":
                newItem = new class_1823(itemSettings);
                break;
            case "spawn_egg":
                class_1299 SpawnEggEntityType = class_7923.field_41177.method_10223(new class_2960(jsonObject.has("entity-type") ? jsonObject.get("entity-type").getAsString() : "air"));
                int primaryColor = jsonObject.has("primary-color") ? jsonObject.get("primary-color").getAsInt() : 0;
                int secondaryColor = jsonObject.has("secondary-color") ? jsonObject.get("secondary-color").getAsInt() : 0;
                newItem = new class_1826(SpawnEggEntityType, primaryColor, secondaryColor, itemSettings);
                break;
            case "spectral_arrow":
                newItem = new class_1825(itemSettings);
                break;
            case "splash_potion":
                newItem = new class_1828(itemSettings);
                break;
            case "spyglass":
                newItem = new class_5538(itemSettings);
                break;
            case "stew":
                newItem = new class_1756(itemSettings);
                break;
            case "suspicious_stew":
                newItem = new class_1830(itemSettings);
                break;
            case "sword":
                String swordToolMaterial = jsonObject.get("tool-material").getAsString();
                int swordAttackDamage = jsonObject.has("attack-damage") ? jsonObject.get("attack-damage").getAsInt() : 0;
                float swordAttackSpeed = jsonObject.has("attack-speed") ? jsonObject.get("attack-speed").getAsFloat() : 0F;
                newItem = new class_1829(getToolMaterial(swordToolMaterial), swordAttackDamage, swordAttackSpeed, itemSettings);
                break;
            case "tall_block":
                class_2248 tallBlock = class_7923.field_41175.method_10223(new class_2960(jsonObject.has("skull") ? jsonObject.get("skull").getAsString() : "air"));
                newItem = new class_1765(tallBlock, itemSettings);
                break;
            case "throwable_potion":
                newItem = new class_4537(itemSettings);
                break;
            case "tipped_arrow":
                newItem = new class_1833(itemSettings);
                break;
            case "trident":
                newItem = new class_1835(itemSettings);
                break;
            case "vertically_attachable_block":
                class_2248 standingBlock = class_7923.field_41175.method_10223(new class_2960(jsonObject.has("skull") ? jsonObject.get("skull").getAsString() : "air"));
                class_2248 wallBlock = class_7923.field_41175.method_10223(new class_2960(jsonObject.has("skull-wall") ? jsonObject.get("skull").getAsString() : "air"));
                String getverticalAttachmentDirectionString = jsonObject.get("vertical-attachment-direction").getAsString();
                newItem = new class_1827(standingBlock, wallBlock, itemSettings, getDirectionType(getverticalAttachmentDirectionString));
                break;
            case "writable_book":
                newItem = new class_1840(itemSettings);
                break;
            case "written_book":
                newItem = new class_1843(itemSettings);
                break;
            default:
                SUBLOGGER.logE("Json-Item-API thread", "Unrecognized item type: " + type + " in JSON file: " + path);
                return;
        }
        class_2378.method_10230(class_7923.field_41178, itemId, newItem);
        SUBLOGGER.logI("Json-Item-API thread", "Registered " + type + " item: " + itemName + " with ID: " + itemId);
    }


    private static class_1814 getRarity(String rarityString) {
        return switch (rarityString) {
            case "common" -> class_1814.field_8906;
            case "uncommon" -> class_1814.field_8907;
            case "rare" -> class_1814.field_8903;
            case "epic" -> class_1814.field_8904;
            default -> class_1814.field_8906;
        };
    }

    private static class_1834 getToolMaterial(String toolMaterialString) {
        return switch (toolMaterialString) {
            case "wood" -> class_1834.field_8922;
            case "stone" -> class_1834.field_8927;
            case "iron" -> class_1834.field_8923;
            case "gold" -> class_1834.field_8929;
            case "diamond" -> class_1834.field_8930;
            case "netherite" -> class_1834.field_22033;
            default -> class_1834.field_8922;
        };
    }

    private static class_1688.class_1689 getMinecartItemType(String minecartItemTypeString) {
        return switch (minecartItemTypeString) {
            case "chest" -> class_1688.class_1689.field_7678;
            case "command_block" -> class_1688.class_1689.field_7681;
            case "tnt" -> class_1688.class_1689.field_7675;
            case "furnace" -> class_1688.class_1689.field_7679;
            case "hopper" -> class_1688.class_1689.field_7677;
            case "rideable" -> class_1688.class_1689.field_7674;
            case "spawner" -> class_1688.class_1689.field_7680;
            default -> class_1688.class_1689.field_7678;
        };
    }

    /*
    private static ArmorItem.Type getArmorType(String armorTypeString) {
        return switch (armorTypeString) {
            case "helmet" -> ArmorItem.Type.HELMET;
            case "chestplate" -> ArmorItem.Type.CHESTPLATE;
            case "leggings" -> ArmorItem.Type.LEGGINGS;
            case "boots" -> ArmorItem.Type.BOOTS;
            default -> ArmorItem.Type.HELMET;
        };
    }
     */

    private static class_2350 getDirectionType(String directionTypeString) {
        return switch (directionTypeString) {
            case "north" -> class_2350.field_11043;
            case "east" -> class_2350.field_11034;
            case "south" -> class_2350.field_11035;
            case "west" -> class_2350.field_11039;
            case "up" -> class_2350.field_11036;
            case "down" -> class_2350.field_11033;
            default -> class_2350.field_11043;
        };
    }

    private static class_1767 getDyeColor(String dyeColorString) {
        return switch (dyeColorString) {
            case "white" -> class_1767.field_7952;
            case "light_gray" -> class_1767.field_7967;
            case "gray" -> class_1767.field_7944;
            case "black" -> class_1767.field_7963;
            case "brown" -> class_1767.field_7957;
            case "red" -> class_1767.field_7964;
            case "orange" -> class_1767.field_7946;
            case "yellow" -> class_1767.field_7947;
            case "lime" -> class_1767.field_7961;
            case "green" -> class_1767.field_7942;
            case "cyan" -> class_1767.field_7955;
            case "light_blue" -> class_1767.field_7951;
            case "blue" -> class_1767.field_7966;
            case "purple" -> class_1767.field_7945;
            case "magenta" -> class_1767.field_7958;
            case "pink" -> class_1767.field_7954;
            default -> class_1767.field_7952;
        };
    }
}