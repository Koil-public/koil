package com.spirit.koil.api.util.rendering.model;

import com.spirit.koil.api.render.VoxelShapeRotator;
import org.jetbrains.annotations.Nullable;

import java.util.Map;
import java.util.Objects;
import net.minecraft.class_1309;
import net.minecraft.class_1750;
import net.minecraft.class_1799;
import net.minecraft.class_1922;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2741;
import net.minecraft.class_2753;
import net.minecraft.class_3726;

public abstract class RotatedModelBlock extends class_2248 {
    final class_265 NORTH_SHAPE;
    final Map<class_2350, class_265> SHAPE_MAP;
    public static final class_2753 FACING = class_2741.field_12481;

    public RotatedModelBlock(class_2251 settings, class_265 SHAPE) {
        super(settings);
        this.NORTH_SHAPE = SHAPE;
        this.SHAPE_MAP = VoxelShapeRotator.rotateAllDirections(NORTH_SHAPE);
    }

    public RotatedModelBlock(class_2251 settings) {
        super(settings);
        this.NORTH_SHAPE = null;
        this.SHAPE_MAP = null;
    }


    @Override
    public void method_9567(class_1937 world, class_2338 pos, class_2680 state, @Nullable class_1309 placer, class_1799 itemStack) {
        if (placer != null) {
            class_2350 direction = placer.method_5735();
            world.method_8652(pos, state.method_11657(FACING, direction), 2);
        }
    }

    @Override
    @SuppressWarnings("deprecation")
    public class_265 method_9530(class_2680 state, class_1922 world, class_2338 pos, class_3726 context) {
        class_2350 facing = state.method_11654(FACING);
        return SHAPE_MAP.get(facing);
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
        builder.method_11667(FACING);
    }

    @Nullable
    @Override
    public class_2680 method_9605(class_1750 ctx) {
        float yaw = Objects.requireNonNull(ctx.method_8036()).method_36454();
        class_2350 dir = class_2350.method_10139(Math.floorMod((int)Math.floor((double)(yaw * 4.0F / 360.0F) + 0.5D), 4));
        return this.method_9564().method_11657(FACING, dir);
    }
}

