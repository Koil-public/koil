package com.spirit.koil.api.util.file.image;

import com.spirit.koil.api.util.file.media.image.ImageTexture;
import com.spirit.koil.api.util.file.media.image.ImageTextureService;
import java.io.IOException;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;

public class ExternalImageRenderer {
    private static class_310 getReadyClient() {
        class_310 client = class_310.method_1551();
        return client != null && client.method_1531() != null ? client : null;
    }

    public static class_2960 registerImage(String path) {
        try {
            ImageTexture texture = ImageTextureService.loadTexture(new java.io.File(path), "koil", "external_image/" + path);
            return texture == null ? null : texture.textureId();
        } catch (IOException e) {
            return null;
        }
    }

    public static class_2960 registerScaledImage(String path, int maxWidth, int maxHeight) {
        try {
            ImageTexture texture = ImageTextureService.loadScaledTexture(new java.io.File(path), "koil", "external_image/" + path, maxWidth, maxHeight);
            return texture == null ? null : texture.textureId();
        } catch (IOException e) {
            return null;
        }
    }

    public static void drawImage(class_332 context, class_2960 textureId, int x, int y, int width, int height) {
        class_310 client = getReadyClient();
        if (textureId != null && client != null) {
            client.method_1531().method_22813(textureId);
            context.method_25290(textureId, x, y, 0, 0, width, height, width, height);
        }
    }
}
