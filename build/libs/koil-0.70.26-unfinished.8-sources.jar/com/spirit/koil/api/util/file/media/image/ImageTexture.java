package com.spirit.koil.api.util.file.media.image;

import net.minecraft.class_2960;

public record ImageTexture(class_2960 textureId, int width, int height) {
}
