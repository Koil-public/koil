package com.spirit.koil.api.util.text;

import org.jetbrains.annotations.Nullable;

import java.util.Optional;
import net.minecraft.class_1297;
import net.minecraft.class_2168;
import net.minecraft.class_2583;
import net.minecraft.class_5250;
import net.minecraft.class_5348;
import net.minecraft.class_7417;

public class StringTextContent implements class_7417 {
    private final String content;

    public StringTextContent(String content) {
        this.content = content;
    }

    @Override
    public <T> Optional<T> method_27660(class_5348.class_5246<T> visitor, class_2583 style) {
        return Optional.empty();
    }

    @Override
    public <T> Optional<T> method_27659(class_5348.class_5245<T> visitor) {
        return Optional.empty();
    }

    @Override
    public class_5250 method_10890(@Nullable class_2168 source, @Nullable class_1297 sender, int depth) {
        return class_5250.method_43477(this); // Assumes MutableText.of() exists in your version
    }

    @Override
    public String toString() {
        return content;
    }

}
