package com.spirit.koil.api.util.file.media;

import java.awt.image.BufferedImage;
import java.io.IOException;
import java.util.Locale;
import net.minecraft.class_1011;
import net.minecraft.class_1043;
import net.minecraft.class_2960;
import net.minecraft.class_310;

public final class ManagedFrameTexture implements AutoCloseable {
    private final class_2960 textureId;
    private final class_1043 texture;
    private final int width;
    private final int height;
    private boolean closed;

    public ManagedFrameTexture(String namespace, String uniqueKey, int width, int height) throws IOException {
        class_310 client = readyClient();
        if (client == null) {
            throw new IOException("Minecraft texture manager is not available.");
        }
        this.width = Math.max(1, width);
        this.height = Math.max(1, height);
        this.textureId = new class_2960(namespace, sanitizeKey(uniqueKey));
        this.texture = new class_1043(this.width, this.height, true);
        client.method_1531().method_4616(this.textureId, this.texture);
    }

    public class_2960 textureId() {
        return this.textureId;
    }

    public int width() {
        return this.width;
    }

    public int height() {
        return this.height;
    }

    public void updateRgbaFrame(byte[] rgbaBytes) {
        if (this.closed || rgbaBytes == null || rgbaBytes.length < this.width * this.height * 4) {
            return;
        }
        class_1011 image = this.texture.method_4525();
        if (image == null) {
            return;
        }

        int index = 0;
        for (int y = 0; y < this.height; y++) {
            for (int x = 0; x < this.width; x++) {
                int red = rgbaBytes[index++] & 0xFF;
                int green = rgbaBytes[index++] & 0xFF;
                int blue = rgbaBytes[index++] & 0xFF;
                int alpha = rgbaBytes[index++] & 0xFF;
                int abgr = (alpha << 24) | (blue << 16) | (green << 8) | red;
                image.method_4305(x, y, abgr);
            }
        }
        this.texture.method_4524();
    }

    public void updateBufferedImage(BufferedImage frame) {
        if (this.closed || frame == null) {
            return;
        }
        class_1011 image = this.texture.method_4525();
        if (image == null) {
            return;
        }

        for (int y = 0; y < this.height; y++) {
            for (int x = 0; x < this.width; x++) {
                int argb = frame.getRGB(Math.min(x, frame.getWidth() - 1), Math.min(y, frame.getHeight() - 1));
                int alpha = (argb >> 24) & 0xFF;
                int red = (argb >> 16) & 0xFF;
                int green = (argb >> 8) & 0xFF;
                int blue = argb & 0xFF;
                int abgr = (alpha << 24) | (blue << 16) | (green << 8) | red;
                image.method_4305(x, y, abgr);
            }
        }
        this.texture.method_4524();
    }

    @Override
    public void close() {
        if (this.closed) {
            return;
        }
        this.closed = true;
        class_310 client = readyClient();
        if (client != null) {
            client.method_1531().method_4615(this.textureId);
        }
        this.texture.close();
    }

    private static class_310 readyClient() {
        class_310 client = class_310.method_1551();
        return client != null && client.method_1531() != null ? client : null;
    }

    private static String sanitizeKey(String raw) {
        if (raw == null || raw.isBlank()) {
            return "unknown";
        }
        return raw.toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9/._-]", "_");
    }
}
