package com.spirit.koil.api.util.file.json;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.object.builder.v1.block.FabricBlockSettings;
import net.minecraft.*;
import net.minecraft.block.*;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.Enumeration;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

import static com.spirit.Main.SUBLOGGER;

public class JsonBlockMaker {
    public static void makeTheJsonBlocks() {
        ServerLifecycleEvents.SERVER_STARTING.register(server -> {
            Path customBlocksDir = Paths.get(server.method_3831().getPath(), "./koil/json/", server.method_27728().method_150() + "/blocks");
            if (!Files.exists(customBlocksDir)) {
                try {
                    Files.createDirectories(customBlocksDir);
                    SUBLOGGER.logE("Json-Block-API thread", "Created custom blocks directory: " + customBlocksDir);
                } catch (IOException e) {
                    SUBLOGGER.logE("Json-Block-API thread", "Failed to create custom blocks directory: " + e);
                    return;
                }
            }
            Path datapacksDir = Paths.get(server.method_3831().getPath(), "./saves/", server.method_27728().method_150() + "/datapacks/");
            SUBLOGGER.logI("Json-Block-API thread", "Searching for datapacks in: " + datapacksDir);
            searchAndCopyBlocks(datapacksDir, customBlocksDir);
        });
    }

    private static void searchAndCopyBlocks(Path sourceDir, Path targetDir) {
        if (!Files.isDirectory(sourceDir)) {
            SUBLOGGER.logW("Json-Block-API thread", "Datapacks directory does not exist or is not a directory: " + sourceDir);
            return;
        }

        try {
            Files.walk(sourceDir)
                    .filter(path -> Files.isDirectory(path) || path.toString().endsWith(".zip"))
                    .forEach(path -> {
                        if (Files.isDirectory(path)) {
                            copyBlocksFromFolder(path, targetDir);
                        } else if (path.toString().endsWith(".zip")) {
                            extractAndCopyBlocksFromZip(path, targetDir);
                        }
                    });
        } catch (IOException e) {
            SUBLOGGER.logE("Json-Block-API thread", "Failed to walk through the datapacks directory: " + e);
        }
    }

    private static void copyBlocksFromFolder(Path sourceDir, Path targetDir) {
        Path koilBlocksDir = sourceDir.resolve("data/koil/json/blocks");
        if (Files.exists(koilBlocksDir) && Files.isDirectory(koilBlocksDir)) {
            try {
                Files.walk(koilBlocksDir)
                        .filter(Files::isRegularFile)
                        .forEach(sourcePath -> {
                            Path relativePath = koilBlocksDir.relativize(sourcePath);
                            Path targetPath = targetDir.resolve(relativePath);
                            try {
                                Files.createDirectories(targetPath.getParent());
                                Files.copy(sourcePath, targetPath, StandardCopyOption.REPLACE_EXISTING);
                                SUBLOGGER.logI("Json-Block-API thread", "Copied block from folder: " + sourcePath + " to: " + targetPath);
                            } catch (IOException e) {
                                SUBLOGGER.logE("Json-Block-API thread", "Failed to copy block from folder: " + sourcePath + "\n" + e);
                            }
                        });
            } catch (IOException e) {
                SUBLOGGER.logE("Json-Block-API thread", "Failed to walk through the koil/json/blocks directory: " + e);
            }
        }
    }

    private static void extractAndCopyBlocksFromZip(Path zipFile, Path targetDir) {
        try (ZipFile zip = new ZipFile(zipFile.toFile())) {
            Enumeration<? extends ZipEntry> entries = zip.entries();
            while (entries.hasMoreElements()) {
                ZipEntry entry = entries.nextElement();
                if (entry.getName().startsWith("data/koil/json/blocks/") && !entry.isDirectory()) {
                    Path targetPath = targetDir.resolve(entry.getName().substring("data/koil/json/blocks/".length()));
                    try (InputStream is = zip.getInputStream(entry)) {
                        Files.createDirectories(targetPath.getParent());
                        Files.copy(is, targetPath, StandardCopyOption.REPLACE_EXISTING);
                        SUBLOGGER.logI("Json-Block-API thread", "Extracted and copied block from zip: " + entry.getName() + " to: " + targetPath);
                    } catch (IOException e) {
                        SUBLOGGER.logE("Json-Block-API thread", "Failed to extract and copy block from zip: " + entry.getName() + "\n" + e);
                    }
                }
            }
        } catch (IOException e) {
            SUBLOGGER.logE("Json-Block-API thread", "Failed to extract blocks from zip file: " + zipFile  + "\n" + e);
        }
    }

    public static void registerBlocksFromJson() {
        Path koilDirectory = Paths.get("./koil/json/").toAbsolutePath();

        try {
            Files.walk(koilDirectory)
                    .filter(Files::isDirectory)
                    .forEach(worldDirectory -> {
                        String worldName = worldDirectory.getFileName().toString();
                        Path blocksDirectory = worldDirectory.resolve("blocks");

                        try {
                            Files.walk(blocksDirectory)
                                    .filter(path -> path.toString().endsWith(".json"))
                                    .forEach(path -> {
                                        try (FileReader reader = new FileReader(path.toFile())) {
                                            JsonObject jsonObject = JsonParser.parseReader(reader).getAsJsonObject();

                                            if (jsonObject.has("type")) {
                                                registerBlockFromJson(jsonObject, worldName, path.toString());
                                            } else {
                                                SUBLOGGER.logE("Json-Block-API thread", "Missing 'type' field in JSON file: " + path);
                                            }
                                        } catch (Exception e) {
                                            SUBLOGGER.logE("Json-Block-API thread", "Failed to read the JSON file: " + path);
                                            e.printStackTrace();
                                        }
                                    });
                        } catch (IOException ignored) {
                        }
                    });
        } catch (IOException e) {
            SUBLOGGER.logE("Json-Block-API thread", "Failed to walk through the koil directory");
            e.printStackTrace();
        }
    }


    private static void registerBlockFromJson(JsonObject jsonObject, String path, String string) {
        String type = jsonObject.get("type").getAsString();
        String modId = jsonObject.get("mod-id").getAsString();
        String blockName = jsonObject.get("name").getAsString();
        class_2960 blockId = new class_2960(modId, blockName.toLowerCase().replace(" ", "_"));

        float hardness = jsonObject.get("hardness").getAsFloat();
        float resistance = jsonObject.get("resistance").getAsFloat();
        String copyBlockSettings = jsonObject.get("copy-block-settings").getAsString();
        class_2248 copyBlock = getBlockFromString(copyBlockSettings);


        class_3414 breakSound = class_7923.field_41172.method_10223(new class_2960(jsonObject.get("break-sound").getAsString()));
        class_3414 stepSound = class_7923.field_41172.method_10223(new class_2960(jsonObject.get("step-sound").getAsString()));
        class_3414 placeSound = class_7923.field_41172.method_10223(new class_2960(jsonObject.get("place-sound").getAsString()));
        class_3414 hitSound = class_7923.field_41172.method_10223(new class_2960(jsonObject.get("hit-sound").getAsString()));
        class_3414 fallSound = class_7923.field_41172.method_10223(new class_2960(jsonObject.get("fall-sound").getAsString()));



        float volume = jsonObject.get("volume").getAsFloat();
        float pitch = jsonObject.get("pitch").getAsFloat();

        class_2498 blockSoundGroup = new class_2498(volume, pitch, breakSound, stepSound, placeSound, hitSound, fallSound);

        class_2248.Settings blockSettings = FabricBlockSettings.method_9630(copyBlock)
                .method_9629(hardness, resistance)
                .method_9626(blockSoundGroup);


        boolean requiresTool = jsonObject.has("requires-tool") && jsonObject.get("requires-tool").getAsBoolean();
        if (requiresTool) {blockSettings.method_29292();}
        boolean breakInstantly = jsonObject.has("break-instantly") && jsonObject.get("break-instantly").getAsBoolean();
        if (breakInstantly) {blockSettings.method_9618();}
        boolean burnable = jsonObject.has("burnable") && jsonObject.get("burnable").getAsBoolean();
        if (burnable) {blockSettings.method_50013();}
        boolean dropsNothing = jsonObject.has("drops-nothing") && jsonObject.get("drops-nothing").getAsBoolean();
        if (dropsNothing) {blockSettings.method_42327();}
        boolean noCollision = jsonObject.has("no-collision") && jsonObject.get("no-collision").getAsBoolean();
        if (noCollision) {blockSettings.method_9634();}
        boolean nonOpaque = jsonObject.has("non-opaque") && jsonObject.get("non-opaque").getAsBoolean();
        if (nonOpaque) {blockSettings.method_22488();}
        boolean ticksRandomly = jsonObject.has("ticks-randomly") && jsonObject.get("ticks-randomly").getAsBoolean();
        if (ticksRandomly) {blockSettings.method_9640();}
        boolean hasLuminance = jsonObject.has("has-luminance") && jsonObject.get("has-luminance").getAsBoolean();
        if (hasLuminance) {
            int luminance = jsonObject.get("luminance").getAsInt();
            blockSettings.method_9631((state) -> luminance);
        }

        String pistonBehaviorString = jsonObject.get("piston-behavior").getAsString();
        class_2248.Settings blockSettingsWithPistonBehavior = setPistonBehavior(blockSettings, pistonBehaviorString);


        class_2248 newBlock;
        switch (type) {
            case "air":
                newBlock = new class_2189(blockSettingsWithPistonBehavior);
                break;
            case "amethyst":
                newBlock = new class_5541(blockSettingsWithPistonBehavior);
                break;
            case "amethyst_cluster":
                int cluster_height = jsonObject.get("cluster-height").getAsInt();
                int cluster_xzOffset = jsonObject.get("cluster-xz-offset").getAsInt();
                newBlock = new class_5542(cluster_height, cluster_xzOffset, blockSettingsWithPistonBehavior);
                break;
            case "anvil":
                newBlock = new class_2199(blockSettingsWithPistonBehavior);
                break;
            case "azalea":
                newBlock = new class_5800(blockSettingsWithPistonBehavior);
                break;
            case "bamboo":
                newBlock = new class_2211(blockSettingsWithPistonBehavior);
                break;
            case "bamboo_sapling":
                newBlock = new class_2202(blockSettingsWithPistonBehavior);
                break;
            case "banner":
                String getBannerDyeColorString = jsonObject.get("dye-color").getAsString();
                newBlock = new class_2215(getDyeColor(getBannerDyeColorString), blockSettingsWithPistonBehavior);
                break;
            case "barrel":
                newBlock = new class_3708(blockSettingsWithPistonBehavior);
                break;
            case "beacon":
                newBlock = new class_2238(blockSettingsWithPistonBehavior);
                break;
            case "bed":
                String getBedDyeColorString = jsonObject.get("dye-color").getAsString();
                newBlock = new class_2244(getDyeColor(getBedDyeColorString), blockSettingsWithPistonBehavior);
                break;
            case "beehive":
                newBlock = new class_4481(blockSettingsWithPistonBehavior);
                break;
            case "beetroots":
                newBlock = new class_2242(blockSettingsWithPistonBehavior);
                break;
            case "bell":
                newBlock = new class_3709(blockSettingsWithPistonBehavior);
                break;
            case "big_drip_leaf":
                newBlock = new class_5801(blockSettingsWithPistonBehavior);
                break;
            case "blast_furnace":
                newBlock = new class_3710(blockSettingsWithPistonBehavior);
                break;
            case "block":
                newBlock = new class_2248(blockSettingsWithPistonBehavior);
                break;
            case "brewing_stand":
                newBlock = new class_2260(blockSettingsWithPistonBehavior);
                break;
            case "brushable":
                String baseBlockJson = jsonObject.get("base-block").getAsString();
                class_3414 brushing_sound = class_7923.field_41172.method_10223(new class_2960(jsonObject.get("brushing-sound").getAsString()));
                class_3414 brushing_complete_sound = class_7923.field_41172.method_10223(new class_2960(jsonObject.get("brushing-complete-sound").getAsString()));
                newBlock = new class_8170(getBlockFromString(baseBlockJson), blockSettingsWithPistonBehavior, brushing_sound, brushing_complete_sound);
                break;
            case "bubble_column":
                newBlock = new class_2258(blockSettingsWithPistonBehavior);
                break;
            case "budding_amethyst":
                newBlock = new class_5543(blockSettingsWithPistonBehavior);
                break;
            case "button":
                String blockSetType = jsonObject.has("set-type") ? jsonObject.get("set-type").getAsString() : "oak";
                int pressTicks = jsonObject.get("press-ticks").getAsInt();
                boolean wooden = jsonObject.has("is-wooden") && jsonObject.get("is-wooden").getAsBoolean();
                newBlock = new class_2269(blockSettingsWithPistonBehavior, getBlockSetTypeFromString(blockSetType), pressTicks, wooden);
                break;
            case "cactus":
                newBlock = new class_2266(blockSettingsWithPistonBehavior);
                break;
            case "cake":
                newBlock = new class_2272(blockSettingsWithPistonBehavior);
                break;
            case "calibrated_sculk_sensor":
                newBlock = new class_8236(blockSettingsWithPistonBehavior);
                break;
            case "campfire":
                boolean emitsParticles = jsonObject.has("emits-particles") && jsonObject.get("emits-particles").getAsBoolean();
                int fireDamage = jsonObject.has("fire-damage") ? jsonObject.get("fire-damage").getAsInt() : 1;
                newBlock = new class_3922(emitsParticles, fireDamage, blockSettingsWithPistonBehavior);
                break;
            case "candle":
                newBlock = new class_5544(blockSettingsWithPistonBehavior);
                break;
            case "candle_cake":
                String getCandleColorString = jsonObject.get("candle-color").getAsString();
                newBlock = new class_5545(getCandleColor(getCandleColorString), blockSettingsWithPistonBehavior);
                break;
            case "carpet":
                newBlock = new class_2577(blockSettingsWithPistonBehavior);
                break;
            case "carrots":
                newBlock = new class_2271(blockSettingsWithPistonBehavior);
                break;
            case "cartography_table":
                newBlock = new class_3711(blockSettingsWithPistonBehavior);
                break;
            case "carved_pumpkin":
                newBlock = new class_2276(blockSettingsWithPistonBehavior);
                break;
            case "cauldron":
                newBlock = new class_5546(blockSettingsWithPistonBehavior);
                break;
            case "cave_vines_body":
                newBlock = new class_5804(blockSettingsWithPistonBehavior);
                break;
            case "cave_vines_head":
                newBlock = new class_5805(blockSettingsWithPistonBehavior);
                break;
            case "chain":
                newBlock = new class_5172(blockSettingsWithPistonBehavior);
                break;
            case "cherry_leaves":
                newBlock = new class_8167(blockSettingsWithPistonBehavior);
                break;
            case "chiseled_bookshelf":
                newBlock = new class_7714(blockSettingsWithPistonBehavior);
                break;
            case "chorus_plant":
                newBlock = new class_2283(blockSettingsWithPistonBehavior);
                break;
            case "cobweb":
                newBlock = new class_2560(blockSettingsWithPistonBehavior);
                break;
            case "cocoa":
                newBlock = new class_2282(blockSettingsWithPistonBehavior);
                break;
            case "command_block":
                boolean auto = jsonObject.has("command-block-auto") && jsonObject.get("command-block-auto").getAsBoolean();
                newBlock = new class_2288(blockSettingsWithPistonBehavior, auto);
                break;
            case "comparator":
                newBlock = new class_2286(blockSettingsWithPistonBehavior);
                break;
            case "composter":
                newBlock = new class_3962(blockSettingsWithPistonBehavior);
                break;
            case "concrete_powder":
                String getHardenedConcreteString = jsonObject.get("concrete-color").getAsString();
                newBlock = new class_2292(getHardenedConcrete(getHardenedConcreteString), blockSettingsWithPistonBehavior);
                break;
            case "conduit":
                newBlock = new class_2289(blockSettingsWithPistonBehavior);
                break;
            case "connecting":
                float radius = jsonObject.get("radius").getAsFloat();
                newBlock = new class_2429(radius, blockSettingsWithPistonBehavior);
                break;
            case "coral":
                String getDeadCoralBlockString = jsonObject.get("dead-coral-block").getAsString();
                newBlock = new class_2301(getDeadCoralBlock(getDeadCoralBlockString), blockSettingsWithPistonBehavior);
                break;
            case "coral_coral":
                String getDeadCoralCoralBlockString = jsonObject.get("dead-coral-coral-block").getAsString();
                newBlock = new class_2298(getDeadCoralBlock(getDeadCoralCoralBlockString), blockSettingsWithPistonBehavior);
                break;
            case "coral_fan":
                String getDeadCoralFanBlockString = jsonObject.get("dead-coral-fan-block").getAsString();
                newBlock = new class_2297(getDeadCoralFanBlock(getDeadCoralFanBlockString), blockSettingsWithPistonBehavior);
                break;
            case "coral_parent":
                newBlock = new class_2230(blockSettingsWithPistonBehavior);
                break;
            case "coral_wall_fan":
                String getDeadCoralWallFanBlockString = jsonObject.get("dead-coral-wall-fan-block").getAsString();
                newBlock = new class_2299(getDeadCoralWallFanBlock(getDeadCoralWallFanBlockString), blockSettingsWithPistonBehavior);
                break;
            case "crafting_table":
                newBlock = new class_2304(blockSettingsWithPistonBehavior);
                break;
            case "crop_block":
                newBlock = new class_2302(blockSettingsWithPistonBehavior);
                break;
            case "crying_obsidian":
                newBlock = new class_4848(blockSettingsWithPistonBehavior);
                break;
            case "daylight_detector":
                newBlock = new class_2309(blockSettingsWithPistonBehavior);
                break;
            case "dead_bush":
                newBlock = new class_2311(blockSettingsWithPistonBehavior);
                break;
            case "dead_coral":
                newBlock = new class_2217(blockSettingsWithPistonBehavior);
                break;
            case "dead_coral_fan":
                newBlock = new class_2221(blockSettingsWithPistonBehavior);
                break;
            case "dead_coral_wall_fan":
                newBlock = new class_2222(blockSettingsWithPistonBehavior);
                break;
            case "decorated_pot":
                newBlock = new class_8168(blockSettingsWithPistonBehavior);
                break;
            case "detector_rail":
                newBlock = new class_2313(blockSettingsWithPistonBehavior);
                break;
            case "dirt_path":
                newBlock = new class_2369(blockSettingsWithPistonBehavior);
                break;
            case "dispenser":
                newBlock = new class_2315(blockSettingsWithPistonBehavior);
                break;
            case "door":
                String doorSetType = jsonObject.has("set-type") ? jsonObject.get("set-type").getAsString() : "oak";
                newBlock = new class_2323(blockSettingsWithPistonBehavior, getBlockSetTypeFromString(doorSetType));
                break;
            case "dragon_egg":
                newBlock = new class_2328(blockSettingsWithPistonBehavior);
                break;
            case "dropper":
                newBlock = new class_2325(blockSettingsWithPistonBehavior);
                break;
            case "dyed_carpet":
                String getCarpetDyeColorString = jsonObject.get("dye-color").getAsString();
                newBlock = new class_5815(getDyeColor(getCarpetDyeColorString), blockSettingsWithPistonBehavior);
                break;
            case "enchanting_table":
                newBlock = new class_2331(blockSettingsWithPistonBehavior);
                break;
            case "ender_chest":
                newBlock = new class_2336(blockSettingsWithPistonBehavior);
                break;
            case "end_gateway":
                newBlock = new class_2329(blockSettingsWithPistonBehavior);
                break;
            case "end_portal":
                newBlock = new class_2334(blockSettingsWithPistonBehavior);
                break;
            case "end_portal_frame":
                newBlock = new class_2333(blockSettingsWithPistonBehavior);
                break;
            case "end_rod":
                newBlock = new class_5551(blockSettingsWithPistonBehavior);
                break;
            case "experience_dropping":
                newBlock = new class_2431(blockSettingsWithPistonBehavior);
                break;
            case "falling_block":
                newBlock = new class_2346(blockSettingsWithPistonBehavior);
                break;
            case "farmland":
                newBlock = new class_2344(blockSettingsWithPistonBehavior);
                break;
            case "fence":
                newBlock = new class_2354(blockSettingsWithPistonBehavior);
                break;
            case "fence_gate":
                String fenceGateWoodType = jsonObject.has("wood-type") ? jsonObject.get("wood-type").getAsString() : "oak";
                newBlock = new class_2349(blockSettingsWithPistonBehavior, getWoodTypeFromString(fenceGateWoodType));
                break;
            case "fern":
                newBlock = new class_2526(blockSettingsWithPistonBehavior);
                break;
            case "fire":
                newBlock = new class_2358(blockSettingsWithPistonBehavior);
                break;
            case "fletching_table":
                newBlock = new class_3712(blockSettingsWithPistonBehavior);
                break;
            case "flowerbed":
                newBlock = new class_8169(blockSettingsWithPistonBehavior);
                break;
            case "flower":
                class_1291 suspiciousStewEffect = class_7923.field_41174.method_10223(new class_2960(jsonObject.get("suspicious-stew-effect").getAsString()));
                int effectDuration = jsonObject.has("effect-duration") ? jsonObject.get("effect-duration").getAsInt() : 20;
                assert suspiciousStewEffect != null;
                newBlock = new class_2356(suspiciousStewEffect, effectDuration, blockSettingsWithPistonBehavior);
                break;
            case "flower_pot":
                String content = jsonObject.has("pot-content") ? jsonObject.get("pot-content").getAsString() : "poppy";
                newBlock = new class_2362(getContentFromString(content), blockSettingsWithPistonBehavior);
                break;
            case "frogspawn":
                newBlock = new class_7113(blockSettingsWithPistonBehavior);
                break;
            case "frosted_ice":
                newBlock = new class_2360(blockSettingsWithPistonBehavior);
                break;
            case "furnace":
                newBlock = new class_3865(blockSettingsWithPistonBehavior);
                break;
            case "glass":
                newBlock = new class_2368(blockSettingsWithPistonBehavior);
                break;
            case "glazed_terracotta":
                newBlock = new class_2366(blockSettingsWithPistonBehavior);
                break;
            case "glow_lichen":
                newBlock = new class_5777(blockSettingsWithPistonBehavior);
                break;
            case "grass":
                newBlock = new class_2372(blockSettingsWithPistonBehavior);
                break;
            case "gravel":
                newBlock = new class_2375(blockSettingsWithPistonBehavior);
                break;
            case "grindstone":
                newBlock = new class_3713(blockSettingsWithPistonBehavior);
                break;
            case "hanging_roots":
                newBlock = new class_5806(blockSettingsWithPistonBehavior);
                break;
            case "hanging_sign":
                String hangingSignWoodType = jsonObject.has("wood-type") ? jsonObject.get("wood-type").getAsString() : "oak";
                newBlock = new class_7713(blockSettingsWithPistonBehavior, getWoodTypeFromString(hangingSignWoodType));
                break;
            case "hay":
                newBlock = new class_2380(blockSettingsWithPistonBehavior);
                break;
            case "honey":
                newBlock = new class_4622(blockSettingsWithPistonBehavior);
                break;
            case "hopper":
                newBlock = new class_2377(blockSettingsWithPistonBehavior);
                break;
            case "horizontal_connecting":
                float radius1 = jsonObject.has("radius-1") ? jsonObject.get("radius-1").getAsFloat() : 1;
                float radius2 = jsonObject.has("radius-2") ? jsonObject.get("radius-2").getAsFloat() : 1;
                float boundingHeight1 = jsonObject.has("bounding-height-1") ? jsonObject.get("bounding-height-1").getAsFloat() : 1;
                float boundingHeight2 = jsonObject.has("bounding-height-2") ? jsonObject.get("bounding-height-2").getAsFloat() : 1;
                float collisionHeight = jsonObject.has("collision-height") ? jsonObject.get("collision-height").getAsFloat() : 1;
                newBlock = new class_2310(radius1, radius2, boundingHeight1, boundingHeight2, collisionHeight, blockSettingsWithPistonBehavior);
                break;
            case "ice":
                newBlock = new class_2386(blockSettingsWithPistonBehavior);
                break;
            case "infested":
                class_2248 regularBlock = class_7923.field_41175.method_10223(new class_2960(jsonObject.get("normal-block").getAsString()));
                newBlock = new class_2384(regularBlock, blockSettingsWithPistonBehavior);
                break;
            case "jigsaw":
                newBlock = new class_3748(blockSettingsWithPistonBehavior);
                break;
            case "jukebox":
                newBlock = new class_2387(blockSettingsWithPistonBehavior);
                break;
            case "kelp":
                newBlock = new class_2393(blockSettingsWithPistonBehavior);
                break;
            case "kelp_plant":
                newBlock = new class_2391(blockSettingsWithPistonBehavior);
                break;
            case "ladder":
                newBlock = new class_2399(blockSettingsWithPistonBehavior);
                break;
            case "lantern":
                newBlock = new class_3749(blockSettingsWithPistonBehavior);
                break;
            case "lava_cauldron":
                newBlock = new class_5553(blockSettingsWithPistonBehavior);
                break;
            case "leaves":
                newBlock = new class_2397(blockSettingsWithPistonBehavior);
                break;
            case "lectern":
                newBlock = new class_3715(blockSettingsWithPistonBehavior);
                break;
            case "lever":
                newBlock = new class_2401(blockSettingsWithPistonBehavior);
                break;
            case "light":
                newBlock = new class_6089(blockSettingsWithPistonBehavior);
                break;
            case "lightning_rod":
                newBlock = new class_5554(blockSettingsWithPistonBehavior);
                break;
            case "lily_pad":
                newBlock = new class_2553(blockSettingsWithPistonBehavior);
                break;
            case "loom":
                newBlock = new class_2406(blockSettingsWithPistonBehavior);
                break;
            case "magma":
                newBlock = new class_2413(blockSettingsWithPistonBehavior);
                break;
            case "mangrove_leaves":
                newBlock = new class_7114(blockSettingsWithPistonBehavior);
                break;
            case "mangrove_roots":
                newBlock = new class_7116(blockSettingsWithPistonBehavior);
                break;
            case "melon":
                newBlock = new class_2411(blockSettingsWithPistonBehavior);
                break;
            case "moss":
                newBlock = new class_5807(blockSettingsWithPistonBehavior);
                break;
            case "mud":
                newBlock = new class_7117(blockSettingsWithPistonBehavior);
                break;
            case "mushroom":
                newBlock = new class_2381(blockSettingsWithPistonBehavior);
                break;
            case "mycelium":
                newBlock = new class_2418(blockSettingsWithPistonBehavior);
                break;
            case "nether_portal":
                newBlock = new class_2423(blockSettingsWithPistonBehavior);
                break;
            case "netherrack":
                newBlock = new class_4773(blockSettingsWithPistonBehavior);
                break;
            case "nether_wart":
                newBlock = new class_2421(blockSettingsWithPistonBehavior);
                break;
            case "note":
                newBlock = new class_2428(blockSettingsWithPistonBehavior);
                break;
            case "nylium":
                newBlock = new class_4849(blockSettingsWithPistonBehavior);
                break;
            case "observer":
                newBlock = new class_2426(blockSettingsWithPistonBehavior);
                break;
            case "oxidizable":
                class_5955.class_5811 oxidationBlockLevel = class_5955.class_5811.valueOf(jsonObject.get("oxidation-level").getAsString());
                newBlock = new class_5812(oxidationBlockLevel, blockSettingsWithPistonBehavior);
                break;
            case "oxidizable_slab":
                class_5955.class_5811 oxidationSlabLevel = class_5955.class_5811.valueOf(jsonObject.get("oxidation-level").getAsString());
                newBlock = new class_5813(oxidationSlabLevel, blockSettingsWithPistonBehavior);
                break;
            case "pane":
                newBlock = new class_2389(blockSettingsWithPistonBehavior);
                break;
            case "pillar":
                newBlock = new class_2465(blockSettingsWithPistonBehavior);
                break;
            case "piston":
                boolean sticky = jsonObject.has("sticky") && jsonObject.get("sticky").getAsBoolean();
                newBlock = new class_2665(sticky, blockSettingsWithPistonBehavior);
                break;
            case "piston_extension":
                newBlock = new class_2667(blockSettingsWithPistonBehavior);
                break;
            case "piston_head":
                newBlock = new class_2671(blockSettingsWithPistonBehavior);
                break;
            case "pitcher_crop":
                newBlock = new class_8237(blockSettingsWithPistonBehavior);
                break;
            case "plant":
                newBlock = new class_2261(blockSettingsWithPistonBehavior);
                break;
            case "player_skull":
                newBlock = new class_2435(blockSettingsWithPistonBehavior);
                break;
            case "pointed_dripstone":
                newBlock = new class_5689(blockSettingsWithPistonBehavior);
                break;
            case "potatoes":
                newBlock = new class_2439(blockSettingsWithPistonBehavior);
                break;
            case "powder_snow":
                newBlock = new class_5635(blockSettingsWithPistonBehavior);
                break;
            case "powered_rail":
                newBlock = new class_2442(blockSettingsWithPistonBehavior);
                break;
            case "pressure_plate":
                String pressurePlateActivationString = jsonObject.get("pressure-plate-activation").getAsString();
                class_2440.class_2441 blockSettingsWithPressurePlateActivation = setPressurePlateActivation(pressurePlateActivationString);
                String pressurePlateSetType = jsonObject.has("set-type") ? jsonObject.get("set-type").getAsString() : "oak";
                newBlock = new class_2440(blockSettingsWithPressurePlateActivation, blockSettingsWithPistonBehavior, getBlockSetTypeFromString(pressurePlateSetType));
                break;
            case "propagule":
                newBlock = new class_7115(blockSettingsWithPistonBehavior);
                break;
            case "pumpkin":
                newBlock = new class_2445(blockSettingsWithPistonBehavior);
                break;
            case "rail":
                newBlock = new class_2443(blockSettingsWithPistonBehavior);
                break;
            case "redstone":
                newBlock = new class_2436(blockSettingsWithPistonBehavior);
                break;
            case "redstone_lamp":
                newBlock = new class_2453(blockSettingsWithPistonBehavior);
                break;
            case "redstone_ore":
                newBlock = new class_2449(blockSettingsWithPistonBehavior);
                break;
            case "redstone_torch":
                newBlock = new class_2459(blockSettingsWithPistonBehavior);
                break;
            case "redstone_wire":
                newBlock = new class_2457(blockSettingsWithPistonBehavior);
                break;
            case "repeater":
                newBlock = new class_2462(blockSettingsWithPistonBehavior);
                break;
            case "respawn_anchor":
                newBlock = new class_4969(blockSettingsWithPistonBehavior);
                break;
            case "rod":
                newBlock = new class_2337(blockSettingsWithPistonBehavior);
                break;
            case "rooted_dirt":
                newBlock = new class_5954(blockSettingsWithPistonBehavior);
                break;
            case "roots":
                newBlock = new class_4774(blockSettingsWithPistonBehavior);
                break;
            case "rotated_infested":
                class_2248 regularRotatedBlock = class_7923.field_41175.method_10223(new class_2960(jsonObject.get("normal-block").getAsString()));
                newBlock = new class_6348(regularRotatedBlock,blockSettingsWithPistonBehavior);
                break;
            case "sand":
                int color = jsonObject.has("sand-color") ? jsonObject.get("sand-color").getAsInt() : 1;
                newBlock = new class_2468(color, blockSettingsWithPistonBehavior);
                break;
            case "scaffolding":
                newBlock = new class_3736(blockSettingsWithPistonBehavior);
                break;
            case "sculk":
                newBlock = new class_7125(blockSettingsWithPistonBehavior);
                break;
            case "sculk_catalyst":
                newBlock = new class_7126(blockSettingsWithPistonBehavior);
                break;
            case "sculk_sensor":
                newBlock = new class_5703(blockSettingsWithPistonBehavior);
                break;
            case "sculk_shrieker":
                newBlock = new class_7268(blockSettingsWithPistonBehavior);
                break;
            case "sculk_vein":
                newBlock = new class_7130(blockSettingsWithPistonBehavior);
                break;
            case "seagrass":
                newBlock = new class_2476(blockSettingsWithPistonBehavior);
                break;
            case "sea_pickle":
                newBlock = new class_2472(blockSettingsWithPistonBehavior);
                break;
            case "shulker_box":
                String getShulkerBoxDyeColorString = jsonObject.get("dye-color").getAsString();
                newBlock = new class_2480(getDyeColor(getShulkerBoxDyeColorString),blockSettingsWithPistonBehavior);
                break;
            case "sign":
                String signWoodType = jsonObject.has("wood-type") ? jsonObject.get("wood-type").getAsString() : "oak";
                newBlock = new class_2508(blockSettingsWithPistonBehavior, getWoodTypeFromString(signWoodType));
                break;
            case "slab":
                newBlock = new class_2482(blockSettingsWithPistonBehavior);
                break;
            case "slime":
                newBlock = new class_2490(blockSettingsWithPistonBehavior);
                break;
            case "small_dripleaf":
                newBlock = new class_5808(blockSettingsWithPistonBehavior);
                break;
            case "smithing_table":
                newBlock = new class_3717(blockSettingsWithPistonBehavior);
                break;
            case "smoker":
                newBlock = new class_3716(blockSettingsWithPistonBehavior);
                break;
            case "sniffer_egg":
                newBlock = new class_8238(blockSettingsWithPistonBehavior);
                break;
            case "snow":
                newBlock = new class_2488(blockSettingsWithPistonBehavior);
                break;
            case "snowy":
                newBlock = new class_2493(blockSettingsWithPistonBehavior);
                break;
            case "soul_fire":
                newBlock = new class_4775(blockSettingsWithPistonBehavior);
                break;
            case "soul_sand":
                newBlock = new class_2492(blockSettingsWithPistonBehavior);
                break;
            case "spawner":
                newBlock = new class_2496(blockSettingsWithPistonBehavior);
                break;
            case "sponge":
                newBlock = new class_2502(blockSettingsWithPistonBehavior);
                break;
            case "spore_blossom":
                newBlock = new class_5809(blockSettingsWithPistonBehavior);
                break;
            case "sprouts":
                newBlock = new class_4772(blockSettingsWithPistonBehavior);
                break;
            case "stained_glass":
                String getStainedGlassDyeColorString = jsonObject.get("dye-color").getAsString();
                newBlock = new class_2506(getDyeColor(getStainedGlassDyeColorString),blockSettingsWithPistonBehavior);
                break;
            case "stained_glass_pane":
                String getStainedGlassPaneDyeColorString = jsonObject.get("dye-color").getAsString();
                newBlock = new class_2504(getDyeColor(getStainedGlassPaneDyeColorString), blockSettingsWithPistonBehavior);
                break;
            case "stairs":
                newBlock = new class_2510(copyBlock.method_9564(), blockSettingsWithPistonBehavior);
                break;
            case "stonecutter":
                newBlock = new class_3718(blockSettingsWithPistonBehavior);
                break;
            case "structure":
                newBlock = new class_2515(blockSettingsWithPistonBehavior);
                break;
            case "structure_void":
                newBlock = new class_2518(blockSettingsWithPistonBehavior);
                break;
            case "sugar_cane":
                newBlock = new class_2523(blockSettingsWithPistonBehavior);
                break;
            case "sweet_berry_bush":
                newBlock = new class_3830(blockSettingsWithPistonBehavior);
                break;
            case "tall_flower":
                newBlock = new class_2521(blockSettingsWithPistonBehavior);
                break;
            case "tall_plant":
                newBlock = new class_2320(blockSettingsWithPistonBehavior);
                break;
            case "tall_seagrass":
                newBlock = new class_2525(blockSettingsWithPistonBehavior);
                break;
            case "target":
                newBlock = new class_4850(blockSettingsWithPistonBehavior);
                break;
            case "tinted_glass":
                newBlock = new class_5555(blockSettingsWithPistonBehavior);
                break;
            case "tnt":
                newBlock = new class_2530(blockSettingsWithPistonBehavior);
                break;
            case "torch":
                class_2394 torchParticle = (class_2394) class_7923.field_41180.method_10223(new class_2960(jsonObject.get("particle").getAsString()));
                newBlock = new class_2527(blockSettingsWithPistonBehavior, torchParticle);
                break;
            case "torch_flower":
                newBlock = new class_8171(blockSettingsWithPistonBehavior);
                break;
            case "transparent":
                newBlock = new class_2373(blockSettingsWithPistonBehavior);
                break;
            case "trapdoor":
                String trapdoorSetType = jsonObject.has("set-type") ? jsonObject.get("set-type").getAsString() : "oak";
                newBlock = new class_2533(blockSettingsWithPistonBehavior, getBlockSetTypeFromString(trapdoorSetType));
                break;
            case "trapped_chest":
                newBlock = new class_2531(blockSettingsWithPistonBehavior);
                break;
            case "tripwire":
                class_2537 hookBlock = (class_2537) class_7923.field_41175.method_10223(new class_2960(jsonObject.get("hook-block").getAsString()));
                newBlock = new class_2538(hookBlock, blockSettingsWithPistonBehavior);
                break;
            case "tripwire_hook":
                newBlock = new class_2537(blockSettingsWithPistonBehavior);
                break;
            case "turtle_egg":
                newBlock = new class_2542(blockSettingsWithPistonBehavior);
                break;
            case "twisting_vines":
                newBlock = new class_4777(blockSettingsWithPistonBehavior);
                break;
            case "twisting_vines_plant":
                newBlock = new class_4950(blockSettingsWithPistonBehavior);
                break;
            case "vine":
                newBlock = new class_2541(blockSettingsWithPistonBehavior);
                break;
            case "wall_banner":
                String getWallBannerDyeColorString = jsonObject.get("dye-color").getAsString();
                newBlock = new class_2546(getDyeColor(getWallBannerDyeColorString),blockSettingsWithPistonBehavior);
                break;
            case "wall":
                newBlock = new class_2544(blockSettingsWithPistonBehavior);
                break;
            case "wall_hanging_sign":
                String hangingWallSignWoodType = jsonObject.has("wood-type") ? jsonObject.get("wood-type").getAsString() : "oak";
                newBlock = new class_7715(blockSettingsWithPistonBehavior, getWoodTypeFromString(hangingWallSignWoodType));
                break;
            case "wall_mounted":
                newBlock = new class_2341(blockSettingsWithPistonBehavior);
                break;
            case "wall_piglin_head":
                newBlock = new class_7938(blockSettingsWithPistonBehavior);
                break;
            case "wall_player_skull":
                newBlock = new class_2433(blockSettingsWithPistonBehavior);
                break;
            case "wall_redstone_torch":
                newBlock = new class_2458(blockSettingsWithPistonBehavior);
                break;
            case "wall_sign":
                String wallSignWoodType = jsonObject.has("wood-type") ? jsonObject.get("wood-type").getAsString() : "oak";
                newBlock = new class_2551(blockSettingsWithPistonBehavior, getWoodTypeFromString(wallSignWoodType));
                break;
            case "wall_torch":
                class_2394 wallTorchParticle = (class_2394) class_7923.field_41180.method_10223(new class_2960(jsonObject.get("particle").getAsString()));
                newBlock = new class_2555(blockSettingsWithPistonBehavior, wallTorchParticle);
                break;
            case "wall_wither_skull":
                newBlock = new class_2567(blockSettingsWithPistonBehavior);
                break;
            case "wearable_carved_pumpkin":
                newBlock = new class_8574(blockSettingsWithPistonBehavior);
                break;
            case "weeping_vines":
                newBlock = new class_4776(blockSettingsWithPistonBehavior);
                break;
            case "weeping_vines_plant":
                newBlock = new class_4951(blockSettingsWithPistonBehavior);
                break;
            case "weighted_pressure_plate":
                String blockWeightedSetType = jsonObject.has("set-type") ? jsonObject.get("set-type").getAsString() : "oak";
                int weight = jsonObject.has("weight") ? jsonObject.get("weight").getAsInt() : 1;
                newBlock = new class_2557(weight, blockSettingsWithPistonBehavior, getBlockSetTypeFromString(blockWeightedSetType));
                break;
            case "wet_sponge":
                newBlock = new class_2565(blockSettingsWithPistonBehavior);
                break;
            case "wither_rose":
                class_1291 effect = class_7923.field_41174.method_10223(new class_2960(jsonObject.get("status-effect").getAsString()));
                assert effect != null;
                newBlock = new class_2563(effect, blockSettingsWithPistonBehavior);
                break;
            case "wither_skull":
                newBlock = new class_2570(blockSettingsWithPistonBehavior);
                break;
            default:
                SUBLOGGER.logE("Json-Block-API thread", "Unrecognized block type: " + type + " in JSON file: " + path);
                return;
        }

        class_2378.method_10230(class_7923.field_41175, blockId, newBlock);
        class_2378.method_10230(class_7923.field_41178, blockId, new class_1747(newBlock, new class_1792.class_1793()));
        SUBLOGGER.logI("Json-Block-API thread", "Registered " + type + " block: " + blockName + " with ID: " + blockId);
    }

    private static class_2248 getBlockFromString(String blockName) {
        class_2960 identifier = class_2960.method_12829(blockName);
        if (identifier != null) {
            return class_7923.field_41175.method_10223(identifier);
        } else {
            return class_2246.field_10124;
        }
    }

    private static class_2248.Settings setPistonBehavior(class_2248.Settings settings, String pistonBehaviorString) {
        class_2248.Settings updatedSettings = settings;
        updatedSettings = switch (pistonBehaviorString) {
            case "normal" -> updatedSettings.method_50012(class_3619.field_15974);
            case "destroy" -> updatedSettings.method_50012(class_3619.field_15971);
            case "block" -> updatedSettings.method_50012(class_3619.field_15972);
            default -> updatedSettings;
        };
        return updatedSettings;
    }

    private static class_1767 getDyeColor(String dyeColorString) {
        return switch (dyeColorString) {
            case "white" -> class_1767.field_7952;
            case "light_gray" -> class_1767.field_7967;
            case "gray" -> class_1767.field_7944;
            case "black" -> class_1767.field_7963;
            case "brown" -> class_1767.field_7957;
            case "red" -> class_1767.field_7964;
            case "orange" -> class_1767.field_7946;
            case "yellow" -> class_1767.field_7947;
            case "lime" -> class_1767.field_7961;
            case "green" -> class_1767.field_7942;
            case "cyan" -> class_1767.field_7955;
            case "light_blue" -> class_1767.field_7951;
            case "blue" -> class_1767.field_7966;
            case "purple" -> class_1767.field_7945;
            case "magenta" -> class_1767.field_7958;
            case "pink" -> class_1767.field_7954;
            default -> class_1767.field_7952;
        };
    }

    private static class_2248 getCandleColor(String candleColorString) {
        return switch (candleColorString) {
            case "white" -> class_2246.field_27100;
            case "light_gray" -> class_2246.field_27108;
            case "gray" -> class_2246.field_27107;
            case "black" -> class_2246.field_27141;
            case "brown" -> class_2246.field_27112;
            case "red" -> class_2246.field_27140;
            case "orange" -> class_2246.field_27101;
            case "yellow" -> class_2246.field_27104;
            case "lime" -> class_2246.field_27105;
            case "green" -> class_2246.field_27113;
            case "cyan" -> class_2246.field_27109;
            case "light_blue" -> class_2246.field_27103;
            case "blue" -> class_2246.field_27111;
            case "purple" -> class_2246.field_27110;
            case "magenta" -> class_2246.field_27102;
            case "pink" -> class_2246.field_27106;
            case "default" -> class_2246.field_27099;
            default -> class_2246.field_27099;
        };
    }

    private static class_2248 getHardenedConcrete(String hardenedConcreteString) {
        return switch (hardenedConcreteString) {
            case "white" -> class_2246.field_10107;
            case "light_gray" -> class_2246.field_10172;
            case "gray" -> class_2246.field_10038;
            case "black" -> class_2246.field_10458;
            case "brown" -> class_2246.field_10439;
            case "red" -> class_2246.field_10058;
            case "orange" -> class_2246.field_10210;
            case "yellow" -> class_2246.field_10542;
            case "lime" -> class_2246.field_10421;
            case "green" -> class_2246.field_10367;
            case "cyan" -> class_2246.field_10308;
            case "light_blue" -> class_2246.field_10242;
            case "blue" -> class_2246.field_10011;
            case "purple" -> class_2246.field_10206;
            case "magenta" -> class_2246.field_10585;
            case "pink" -> class_2246.field_10434;
            default -> class_2246.field_10107;
        };
    }

    private static class_2248 getDeadCoralBlock(String deadCoralBlockString) {
        return switch (deadCoralBlockString) {
            case "tube_coral" -> class_2246.field_10614;
            case "brain_coral" -> class_2246.field_10264;
            case "bubble_coral" -> class_2246.field_10396;
            case "horn_coral" -> class_2246.field_10488;
            default -> class_2246.field_10614;
        };
    }

    private static class_2248 getDeadCoralFanBlock(String deadCoralFanBlockString) {
        return switch (deadCoralFanBlockString) {
            case "tube_coral_fan" -> class_2246.field_10448;
            case "brain_coral_fan" -> class_2246.field_10097;
            case "bubble_coral_fan" -> class_2246.field_10047;
            case "horn_coral_fan" -> class_2246.field_10221;
            default -> class_2246.field_10448;
        };
    }

    private static class_2248 getDeadCoralWallFanBlock(String deadCoralWallFanBlockString) {
        return switch (deadCoralWallFanBlockString) {
            case "tube_coral_wall_fan" -> class_2246.field_10347;
            case "brain_coral_wall_fan" -> class_2246.field_10116;
            case "bubble_coral_wall_fan" -> class_2246.field_10094;
            case "horn_coral_wall_fan" -> class_2246.field_10239;
            default -> class_2246.field_10347;
        };
    }

    private static class_2440.class_2441 setPressurePlateActivation(String pressurePlateActivationString) {
        class_2440.class_2441 pressurePlateBehavior = class_2440.class_2441.valueOf(pressurePlateActivationString);
        pressurePlateBehavior = switch (pressurePlateActivationString) {
            case "everything" -> pressurePlateBehavior.field_11361;
            case "mobs" -> pressurePlateBehavior.field_11362;
            default -> pressurePlateBehavior;
        };
        return pressurePlateBehavior;
    }

    private static class_2248 getContentFromString(String flowerTypeString) {
        return switch (flowerTypeString) {
            case "dandelion" -> class_2246.field_10182;
            case "poppy" -> class_2246.field_10449;
            case "blue_orchid" -> class_2246.field_10086;
            case "allium" -> class_2246.field_10226;
            case "azure_bluet" -> class_2246.field_10573;
            case "red_tulip" -> class_2246.field_10270;
            case "orange_tulip" -> class_2246.field_10048;
            case "white_tulip" -> class_2246.field_10156;
            case "pink_tulip" -> class_2246.field_10315;
            case "oxeye_daisy" -> class_2246.field_10554;
            case "cornflower" -> class_2246.field_9995;
            case "lily_of_the_valley" -> class_2246.field_10548;
            case "wither_rose" -> class_2246.field_10606;
            default -> class_2246.field_10449;
        };
    }

    private static class_4719 getWoodTypeFromString(String woodTypeString) {
        return switch (woodTypeString) {
            case "acacia" -> class_4719.field_21679;
            case "birch" -> class_4719.field_21678;
            case "dark_oak" -> class_4719.field_21681;
            case "jungle" -> class_4719.field_21680;
            case "spruce" -> class_4719.field_21677;
            case "crimson" -> class_4719.field_22183;
            case "warped" -> class_4719.field_22184;
            case "mangrove" -> class_4719.field_37657;
            default -> class_4719.field_21676;
        };
    }

    private static class_8177 getBlockSetTypeFromString(String blockSetTypeString) {
        return switch (blockSetTypeString) {
            case "acacia" -> class_8177.field_42826;
            case "birch" -> class_8177.field_42825;
            case "dark_oak" -> class_8177.field_42829;
            case "jungle" -> class_8177.field_42828;
            case "spruce" -> class_8177.field_42824;
            case "crimson" -> class_8177.field_42830;
            case "warped" -> class_8177.field_42831;
            case "mangrove" -> class_8177.field_42832;
            default -> class_8177.field_42823;
        };
    }
}
