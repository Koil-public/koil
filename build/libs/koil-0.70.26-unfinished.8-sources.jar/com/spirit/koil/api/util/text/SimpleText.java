package com.spirit.koil.api.util.text;

import java.util.Collections;
import java.util.List;
import java.util.Optional;
import net.minecraft.class_2561;
import net.minecraft.class_2583;
import net.minecraft.class_5481;
import net.minecraft.class_7417;


public class SimpleText implements class_2561 {
    private final class_7417 content;
    public SimpleText(class_7417 content) {
        this.content = content;
    }

    @Override
    public class_7417 method_10851() {
        return content;
    }

    @Override
    public String method_10858(int length) {
        return class_2561.super.method_10858(length);
    }

    @Override
    public List<class_2561> method_10855() {
        return Collections.emptyList(); // No siblings for simplicity
    }

    @Override
    public class_5481 method_30937() {
        return null;
    }

    @Override
    public <T> Optional<T> method_27658(class_5246<T> styledVisitor, class_2583 style) {
        return class_2561.super.method_27658(styledVisitor, style);
    }

    @Override
    public <T> Optional<T> method_27657(class_5245<T> visitor) {
        return class_2561.super.method_27657(visitor);
    }

    @Override
    public List<class_2561> method_36136(class_2583 style) {
        return class_2561.super.method_36136(style);
    }

    @Override
    public boolean method_44745(class_2561 text) {
        return class_2561.super.method_44745(text);
    }

    @Override
    public class_2583 method_10866() {
        return class_2583.field_24360;
    }
}
