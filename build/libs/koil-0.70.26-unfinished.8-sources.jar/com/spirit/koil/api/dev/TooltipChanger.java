package com.spirit.koil.api.dev;

import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import net.minecraft.class_124;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_5250;

public class TooltipChanger {
    public static ArrayList<class_2561> Main(class_1799 itemStack, ArrayList<class_2561> list) {
        ArrayList<class_2561> temp = new ArrayList<>();

        temp.add(class_2561.method_43469("item.nbt_tags", itemStack.method_7969().method_10541().size()).method_27692(class_124.field_1063));
        int index = list.indexOf(temp.get(0));
        int indexInsertLocation = list.indexOf(temp.get(0));
        list.remove(index);

        String nbtList = String.valueOf(itemStack.method_7969());
        Pattern p = Pattern.compile("[{}:\"\\[\\],']", Pattern.CASE_INSENSITIVE);
        Matcher m = p.matcher(nbtList);

        class_5250 mutableText = class_2561.method_43473();
        mutableText.method_10852(class_2561.method_43470("NBT: ").method_27692(class_124.field_1063));

        int lineStep = 50;
        class_124 stringColour = class_124.field_1060;
        class_124 quotationColour = class_124.field_1068;
        class_124 separationColour = class_124.field_1068;
        class_124 integerColour = class_124.field_1065;
        class_124 typeColour = class_124.field_1061;
        class_124 fieldColour = class_124.field_1075;
        class_124 lstringColour = class_124.field_1054;

        int lineLimit = lineStep;
        int removedCharters = 0;
        int lastIndex = 0;
        Boolean singleQuotationMark = Boolean.FALSE;
        Boolean lineAdded = Boolean.FALSE;
        String lastString = "";


        while (m.find()) {
            lineAdded = Boolean.FALSE;

            if (nbtList.charAt(m.start()) == '\'') {
                if (singleQuotationMark.equals(Boolean.FALSE)) {
                    mutableText.method_10852(class_2561.method_43470(String.valueOf(nbtList.charAt(m.start()))).method_27692(quotationColour));
                    singleQuotationMark = Boolean.TRUE;
                } else {
                    mutableText.method_10852(class_2561.method_43470(nbtList.substring(lastIndex + 1, m.start())).method_27692(stringColour));
                    mutableText.method_10852(class_2561.method_43470(String.valueOf(nbtList.charAt(m.start()))).method_27692(quotationColour));
                    singleQuotationMark = Boolean.FALSE;
                }
                lastString = String.valueOf(nbtList.charAt(m.start()));
                lastIndex = m.start();
            }

            if (singleQuotationMark == Boolean.FALSE) {

                if (nbtList.charAt(m.start()) == '{' || nbtList.charAt(m.start()) == '[') {
                    mutableText.method_10852(class_2561.method_43470(String.valueOf(nbtList.charAt(m.start()))).method_27692(separationColour));
                    lastString = String.valueOf(nbtList.charAt(m.start()));
                    lastIndex = m.start();
                }

                if (nbtList.charAt(m.start()) == '}' || nbtList.charAt(m.start()) == ']' || nbtList.charAt(m.start()) == ',') {
                    if (nbtList.charAt(m.start() - 1) == 's' || nbtList.charAt(m.start() - 1) == 'S' ||
                            nbtList.charAt(m.start() - 1) == 'b' || nbtList.charAt(m.start() - 1) == 'B' ||
                            nbtList.charAt(m.start() - 1) == 'l' || nbtList.charAt(m.start() - 1) == 'L' ||
                            nbtList.charAt(m.start() - 1) == 'f' || nbtList.charAt(m.start() - 1) == 'F'
                    ) {
                        mutableText.method_10852(class_2561.method_43470(nbtList.substring(lastIndex + 1, m.start() - 1)).method_27692(integerColour));
                        mutableText.method_10852(class_2561.method_43470(nbtList.substring(m.start() - 1, m.start())).method_27692(typeColour));

                    } else {
                        mutableText.method_10852(class_2561.method_43470(nbtList.substring(lastIndex + 1, m.start())).method_27692(integerColour));
                    }

                    mutableText.method_10852(class_2561.method_43470(String.valueOf(nbtList.charAt(m.start())))).method_27692(separationColour);

                    if (nbtList.charAt(m.start()) == ',') {
                        mutableText.method_10852(class_2561.method_43470(" ").method_27692(separationColour));
                    }
                    lastString = String.valueOf(nbtList.charAt(m.start()));
                    lastIndex = m.start();
                }

                if (nbtList.charAt(m.start()) == ':') { // 4).
                    if (!lastString.equals("\"")) {
                        mutableText.method_10852(class_2561.method_43470(nbtList.substring(lastIndex + 1, m.start())).method_27692(fieldColour));

                        mutableText.method_10852((class_2561.method_43470(String.valueOf(nbtList.charAt(m.start())))).method_27692(separationColour));
                        mutableText.method_10852(class_2561.method_43470(" ").method_27692(separationColour));
                        lastString = String.valueOf(nbtList.charAt(m.start()));
                        lastIndex = m.start();
                    }
                }

                if (nbtList.charAt(m.start()) == '"') {
                    if (lastString.equals("\"")) {

                        if (m.start() - lineLimit > lineStep) {
                            mutableText.method_10852(class_2561.method_43470("....").method_27692(lstringColour));
                            removedCharters += m.start() - lineLimit;
                        } else {
                            mutableText.method_10852(class_2561.method_43470(nbtList.substring(lastIndex + 1, m.start())).method_27692(stringColour));
                        }

                        mutableText.method_10852(class_2561.method_43470(String.valueOf(nbtList.charAt(m.start()))).method_27692(quotationColour));
                    } else {
                        mutableText.method_10852(class_2561.method_43470(String.valueOf(nbtList.charAt(m.start()))).method_27692(quotationColour));
                    }
                    lastString = String.valueOf(nbtList.charAt(m.start()));
                    lastIndex = m.start();

                }
            }

            if (m.start() - removedCharters >= lineLimit) { // 1).
                if (nbtList.charAt(m.start()) == '}' || nbtList.charAt(m.start()) == ']' || nbtList.charAt(m.start()) == ',') { // 2).

                    if (lastString.equals("'")) { // 3).
                        mutableText.method_10852(class_2561.method_43470(nbtList.substring(lastIndex + 1, m.start())).method_27692(stringColour));
                        lastIndex = m.start();
                    }

                    list.add(indexInsertLocation, mutableText);
                    indexInsertLocation += 1;
                    mutableText = class_2561.method_43470("     ");
                    lineAdded = Boolean.TRUE;
                    lineLimit = lineLimit + lineStep;
                }
            }
        }

        if (lineAdded.equals(Boolean.FALSE)) {
            list.add(indexInsertLocation, mutableText);
        }

        return list;
    }
}