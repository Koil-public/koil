package com.spirit.koil.api.render;

import java.util.EnumMap;
import java.util.Map;
import net.minecraft.class_2248;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import net.minecraft.class_259;
import net.minecraft.class_265;

public class VoxelShapeRotator extends class_2248 {

    public VoxelShapeRotator(class_2251 settings) {
        super(settings);
    }

    // Existing method
    public static Map<class_2350, class_265> rotateAllDirections(class_265 originalShape) {
        Map<class_2350, class_265> rotatedShapes = new EnumMap<>(class_2350.class);

        rotatedShapes.put(class_2350.field_11035, originalShape);
        rotatedShapes.put(class_2350.field_11039, rotate90Degrees(originalShape));
        rotatedShapes.put(class_2350.field_11043, rotate180Degrees(originalShape));
        rotatedShapes.put(class_2350.field_11034, rotate270Degrees(originalShape));

        return rotatedShapes;
    }

    /**
     * Rotates the given VoxelShape 90 degrees clockwise.
     *
     * @param originalShape The original VoxelShape to rotate.
     * @return The rotated VoxelShape.
     */
    public static class_265 rotate90Degrees(class_265 originalShape) {
        return rotate(originalShape, 0.5, 0.5, 0.5, 90);
    }

    /**
     * Rotates the given VoxelShape 180 degrees.
     *
     * @param originalShape The original VoxelShape to rotate.
     * @return The rotated VoxelShape.
     */
    public static class_265 rotate180Degrees(class_265 originalShape) {
        return rotate(originalShape, 0.5, 0.5, 0.5, 180);
    }

    /**
     * Rotates the given VoxelShape 270 degrees clockwise.
     *
     * @param originalShape The original VoxelShape to rotate.
     * @return The rotated VoxelShape.
     */
    public static class_265 rotate270Degrees(class_265 originalShape) {
        return rotate(originalShape, 0.5, 0.5, 0.5, 270);
    }

    /**
     * Rotates the given VoxelShape around the specified point by the given angle.
     *
     * @param originalShape The original VoxelShape to rotate.
     * @param centerX       The x-coordinate of the rotation center.
     * @param centerY       The y-coordinate of the rotation center.
     * @param centerZ       The z-coordinate of the rotation center.
     * @param angle         The rotation angle in degrees.
     * @return The rotated VoxelShape.
     */
    public static class_265 rotate(class_265 originalShape, double centerX, double centerY, double centerZ, double angle) {
        class_265 rotatedShape = class_259.method_1073();

        // Loop through the boxes in the original shape
        for (class_238 box : originalShape.method_1090()) {
            // Rotate the box
            class_238 rotatedBox = rotateBox(box, centerX, centerY, centerZ, angle);
            // Combine the rotated box into the final shape
            rotatedShape = class_259.method_1084(rotatedShape, class_259.method_1078(rotatedBox));
        }

        return rotatedShape;
    }

    /**
     * Rotates the given Box around the specified point by the given angle.
     *
     * @param box      The original Box to rotate.
     * @param centerX  The x-coordinate of the rotation center.
     * @param centerY  The y-coordinate of the rotation center.
     * @param centerZ  The z-coordinate of the rotation center.
     * @param angle    The rotation angle in degrees.
     * @return The rotated Box.
     */
    public static class_238 rotateBox(class_238 box, double centerX, double centerY, double centerZ, double angle) {
        double rad = Math.toRadians(angle);

        // The Y coordinate is unchanged, only X and Z are affected by rotation
        double minX = Math.cos(rad) * (box.field_1323 - centerX) - Math.sin(rad) * (box.field_1321 - centerZ) + centerX;
        double minZ = Math.sin(rad) * (box.field_1323 - centerX) + Math.cos(rad) * (box.field_1321 - centerZ) + centerZ;
        double maxX = Math.cos(rad) * (box.field_1320 - centerX) - Math.sin(rad) * (box.field_1324 - centerZ) + centerX;
        double maxZ = Math.sin(rad) * (box.field_1320 - centerX) + Math.cos(rad) * (box.field_1324 - centerZ) + centerZ;

        return new class_238(Math.min(minX, maxX), box.field_1322, Math.min(minZ, maxZ),
                Math.max(minX, maxX), box.field_1325, Math.max(minZ, maxZ));
    }
}
