package com.spirit.koil.api.automation;

import net.minecraft.class_2960;

public final class AutomationPresenceNetwork {
    public static final class_2960 STATE_SYNC_PACKET = new class_2960("koil", "automation_state_sync");
    public static final class_2960 STATE_BROADCAST_PACKET = new class_2960("koil", "automation_state_broadcast");

    private AutomationPresenceNetwork() {
    }
}
