package com.spirit.koil.api.automation;

import com.spirit.koil.api.automation.cli.AutomationPresenceState;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.minecraft.class_2540;
import net.minecraft.class_310;

public final class AutomationPresenceClientBridge {
    private static boolean lastSentAutomationMode;
    private static String lastSentState = "idle";
    private static String lastSentDetail = "";
    private static long lastSentAt;

    private AutomationPresenceClientBridge() {
    }

    public static void registerReceiver() {
        ClientPlayNetworking.registerGlobalReceiver(AutomationPresenceNetwork.STATE_BROADCAST_PACKET, (client, handler, buffer, responseSender) -> {
            String uuid = buffer.method_10800(64);
            boolean automationMode = buffer.readBoolean();
            String state = buffer.method_10800(64);
            String detail = buffer.method_10800(256);
            long updatedAt = buffer.readLong();
            client.execute(() -> {
                try {
                    AutomationPresenceState.receiveRemote(java.util.UUID.fromString(uuid), automationMode, state, detail, updatedAt);
                } catch (IllegalArgumentException ignored) {
                }
            });
        });
    }

    public static void tick(class_310 client) {
        if (client == null || client.field_1724 == null || client.method_1562() == null || !ClientPlayNetworking.canSend(AutomationPresenceNetwork.STATE_SYNC_PACKET)) {
            return;
        }
        boolean automationMode = AutomationPresenceState.localAutomationMode();
        String state = AutomationPresenceState.localState();
        String detail = AutomationPresenceState.localDetail();
        long now = System.currentTimeMillis();
        boolean changed = automationMode != lastSentAutomationMode || !state.equals(lastSentState) || !detail.equals(lastSentDetail);
        if (!changed && (!automationMode || now - lastSentAt < 1000L)) {
            return;
        }
        class_2540 buffer = PacketByteBufs.create();
        buffer.writeBoolean(automationMode);
        buffer.method_10788(state, 64);
        buffer.method_10788(detail, 256);
        buffer.writeLong(AutomationPresenceState.localUpdatedAt());
        ClientPlayNetworking.send(AutomationPresenceNetwork.STATE_SYNC_PACKET, buffer);
        lastSentAutomationMode = automationMode;
        lastSentState = state;
        lastSentDetail = detail;
        lastSentAt = now;
    }
}
