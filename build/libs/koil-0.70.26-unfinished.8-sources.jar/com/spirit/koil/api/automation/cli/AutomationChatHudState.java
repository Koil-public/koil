package com.spirit.koil.api.automation.cli;

import java.util.List;
import net.minecraft.class_2561;

public final class AutomationChatHudState {
    private static class_2561 header = class_2561.method_43473();
    private static class_2561 prompt = class_2561.method_43473();
    private static class_2561 active = class_2561.method_43473();
    private static boolean visible;
    private static long updatedAt;
    private static String state = "idle";
    private static List<Action> actions = List.of();

    private AutomationChatHudState() {
    }

    public static synchronized void show(class_2561 text, String newState) {
        header = class_2561.method_43473();
        prompt = class_2561.method_43473();
        active = text == null ? class_2561.method_43473() : text;
        actions = List.of();
        visible = true;
        updatedAt = System.currentTimeMillis();
        state = newState == null || newState.isBlank() ? "idle" : newState;
        AutomationPresenceState.updateLocal(state, active.getString());
    }

    public static synchronized void showHeader(class_2561 headerText, class_2561 promptText) {
        showHeader(headerText, promptText, class_2561.method_43473(), "header", List.of());
    }

    public static synchronized void showHeader(class_2561 headerText, class_2561 promptText, class_2561 activeText, String newState) {
        showHeader(headerText, promptText, activeText, newState, List.of());
    }

    public static synchronized void showHeader(class_2561 headerText, class_2561 promptText, class_2561 activeText, String newState, List<Action> newActions) {
        header = headerText == null ? class_2561.method_43473() : headerText;
        prompt = promptText == null ? class_2561.method_43473() : promptText;
        active = activeText == null ? class_2561.method_43473() : activeText;
        actions = newActions == null ? List.of() : List.copyOf(newActions);
        visible = true;
        updatedAt = System.currentTimeMillis();
        state = newState == null || newState.isBlank() ? "header" : newState;
        String status = !prompt.getString().isBlank() ? prompt.getString() : active.getString();
        AutomationPresenceState.updateLocal(state, status);
    }

    public static synchronized void hide() {
        header = class_2561.method_43473();
        prompt = class_2561.method_43473();
        active = class_2561.method_43473();
        actions = List.of();
        visible = false;
        state = "idle";
        AutomationPresenceState.updateLocal("idle", "");
    }

    public static synchronized boolean visible() {
        return visible;
    }

    public static synchronized class_2561 header() {
        return header;
    }

    public static synchronized class_2561 prompt() {
        return prompt;
    }

    public static synchronized class_2561 active() {
        return active;
    }

    public static synchronized List<Action> actions() {
        return actions;
    }

    public static synchronized long updatedAt() {
        return updatedAt;
    }

    public static synchronized String state() {
        return state;
    }

    public record Action(String id, String label, String command, String value, String kind) {
        public Action {
            id = id == null ? "" : id;
            label = label == null ? "" : label;
            command = command == null ? "" : command;
            value = value == null ? "" : value;
            kind = kind == null ? "" : kind;
        }
    }
}
