package com.spirit.koil.api.automation;

import com.mojang.brigadier.arguments.StringArgumentType;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.class_1297;
import net.minecraft.class_2170;
import net.minecraft.class_2540;
import net.minecraft.class_2561;
import net.minecraft.class_3222;

public final class AutomationRemoteRunServerBridge {
    private AutomationRemoteRunServerBridge() {
    }

    public static void registerCommands() {
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> dispatcher.register(class_2170.method_9247("run")
                .then(class_2170.method_9244("input", StringArgumentType.greedyString())
                        .executes(context -> {
                            String input = StringArgumentType.getString(context, "input");
                            class_1297 entity = context.getSource().method_9228();
                            class_3222 target = entity instanceof class_3222 player ? player : context.getSource().method_9207();
                            class_2540 buffer = PacketByteBufs.create();
                            buffer.method_10788(input, 32767);
                            buffer.method_10788(target.method_5477().getString(), 256);
                            ServerPlayNetworking.send(target, AutomationRemoteRunNetwork.RUN_AS_PACKET, buffer);
                            context.getSource().method_9226(() -> class_2561.method_43470("Koil automation sent to " + target.method_5477().getString()), false);
                            return 1;
                        }))
        ));
    }
}
