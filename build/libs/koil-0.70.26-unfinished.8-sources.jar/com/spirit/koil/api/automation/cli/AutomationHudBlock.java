package com.spirit.koil.api.automation.cli;

import java.util.List;
import net.minecraft.class_5481;

public final class AutomationHudBlock {
    public final List<class_5481> lines;
    public final int width;
    public final int height;
    public final int paddingX;
    public final int paddingY;
    public final int lineHeight;

    public AutomationHudBlock(List<class_5481> lines, int width, int height, int paddingX, int paddingY, int lineHeight) {
        this.lines = lines;
        this.width = width;
        this.height = height;
        this.paddingX = paddingX;
        this.paddingY = paddingY;
        this.lineHeight = lineHeight;
    }
}
