package com.spirit.koil.api.automation;

import net.minecraft.class_2960;

public final class AutomationRemoteRunNetwork {
    public static final class_2960 RUN_AS_PACKET = new class_2960("koil", "automation_run_as");

    private AutomationRemoteRunNetwork() {
    }
}
