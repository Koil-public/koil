package com.spirit.koil.api.automation.runtime;

import com.spirit.koil.api.automation.AutomationReporter;
import com.spirit.koil.api.automation.AutomationRequest;
import com.spirit.koil.api.automation.AutomationRouter;
import com.spirit.koil.api.automation.AutomationRuntimeStatus;
import com.spirit.koil.api.automation.cli.AutomationCliViewModel;
import com.spirit.koil.api.automation.ktl.KtlCompilerService;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1297;
import net.minecraft.class_1542;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1713;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2846;
import net.minecraft.class_2960;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_3965;
import net.minecraft.class_3966;
import net.minecraft.class_490;
import net.minecraft.class_5498;
import net.minecraft.class_636;
import net.minecraft.class_638;
import net.minecraft.class_746;
import net.minecraft.class_7923;
import net.minecraft.util.math.*;
import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;

public final class AutomationExecutor {
    private static final AtomicInteger FRAME_SEQUENCE = new AtomicInteger();
    private static final double ENTITY_LOOKUP_RADIUS = 96.0D;
    private static final double ENTITY_LOOKUP_FALLBACK_RADIUS = 256.0D;
    private static final double NAV_PROGRESS_EPSILON = 0.03D;
    private static final int NAV_STUCK_TICKS = 22;
    private static final int NAV_ESCAPE_TICKS = 10;
    private static final int NAV_RECOVERY_LIMIT = 18;
    private static final int NAV_PERSISTENT_RECOVERY_LIMIT = 28;
    private static final int NAV_TRACE_WINDOW = 12;
    private static final int NAV_WAYPOINT_RADIUS = 8;
    private static final int NAV_ROUTE_RADIUS = 24;
    private static final int NAV_ROUTE_MAX_EXPANSIONS = 900;
    private static final int NAV_STEER_LOCK_TICKS = 10;
    private static final int NAV_WAYPOINT_VERTICAL_UP = 3;
    private static final int NAV_WAYPOINT_VERTICAL_DOWN = 5;
    private static final int NAV_DECISION_INTERVAL_TICKS = 8;
    private static final int NAV_AVOID_MEMORY_TICKS = 80;
    private static final int NAV_ROUTE_LOOKAHEAD_SHORT = 3;
    private static final int NAV_ROUTE_LOOKAHEAD_LONG = 5;
    private static final double NAV_POCKET_LIMIT = 0.78D;
    private static final double NAV_CORRIDOR_POCKET_LIMIT = 0.52D;
    private static final double NAV_HUMAN_STEERING_BLEND = 0.74D;
    private static final double NAV_HUMAN_SPRINT_STEERING_BLEND = 0.82D;
    private static final double NAV_MIN_COMPLETION_DISPLACEMENT = 0.35D;
    private static final double AUTOMATION_RAY_DISTANCE = 6.0D;
    private static final double AUTOMATION_RAY_STEP = 0.08D;
    private static final double NAV_PRECISE_STOP_DISTANCE = 0.28D;
    private static final double NAV_PRECISE_DIRECT_DISTANCE = 2.25D;
    private static final double NAV_PRECISE_SLOW_DISTANCE = 0.55D;
    private static final float NAV_LOOK_MAX_YAW_STEP = 52.0F;
    private static final float LOOK_MAX_YAW_STEP = 14.0F;
    private static final float LOOK_MAX_PITCH_STEP = 9.0F;
    private static final float LOOK_SNAP_EPSILON = 0.35F;
    private static final double PARKOUR_SINGLE_MAX_HORIZONTAL = 2.85D;
    private static final double PARKOUR_SPRINT_MAX_HORIZONTAL = 4.35D;
    private static final double PARKOUR_ADVANCED_MAX_HORIZONTAL = 5.05D;
    private static final double PARKOUR_ALIGN_DISTANCE = 0.34D;
    private static final double PARKOUR_LANDING_DISTANCE = 0.85D;
    private static final int PARKOUR_ALIGN_TICKS = 3;
    private static final int PARKOUR_SPRINT_CHARGE_TICKS = 5;
    private static final int PARKOUR_SINGLE_CHARGE_TICKS = 1;
    private static final int PARKOUR_AIR_TIMEOUT_TICKS = 34;
    private static final int PARKOUR_APPROACH_TIMEOUT_TICKS = 90;

    private final KtlCompilerService compilerService;
    private final Deque<ActiveExecution> executionStack = new ArrayDeque<>();
    private final Map<String, HeldInput> heldInputs = new LinkedHashMap<>();
    private final Map<String, CachedEntityRef> cachedEntities = new LinkedHashMap<>();

    public AutomationExecutor(KtlCompilerService compilerService) {
        this.compilerService = compilerService;
    }

    public void execute(ExecutionPlan plan, InterpretationResult interpretationResult) {
        AutomationRuntimeStatus.running(interpretationResult.selectedTemplateId());
        startExecution(plan, interpretationResult, null, null, null);
    }

    public boolean hasActiveExecutions() {
        return !this.executionStack.isEmpty();
    }

    public void cancel(String reason) {
        boolean hadActiveExecution = !this.executionStack.isEmpty();
        String detail = reason == null || reason.isBlank() ? "canceled" : reason;
        this.executionStack.clear();
        releaseAllInputs();
        this.cachedEntities.clear();
        AutomationRuntimeStatus.canceled(detail);
        AutomationCliViewModel.activeState("failed", "", detail);
        AutomationReporter.fail("[fail]", "automation canceled: " + detail);
        if (hadActiveExecution) {
            AutomationCliViewModel.offerFeedbackPrompt("task stopped: " + detail);
        }
    }

    public void tick() {
        class_310 client = class_310.method_1551();
        class_746 player = client == null ? null : client.field_1724;
        class_638 world = client == null ? null : client.field_1687;

        updateHeldInputs();
        updateTapInputs();
        updateMouseLook(player);

        if (this.executionStack.isEmpty()) {
            releaseAllInputs();
            AutomationRuntimeStatus.idle("no active task");
            AutomationCliViewModel.activeState("idle", "", "no active task");
            return;
        }

        ActiveExecution current = this.executionStack.peek();
        AutomationCliViewModel.activeState("thinking", current.frameId, "tick");

        updateActiveConsumption(current);
        updateActiveAttack(current);
        updateActiveMining(current);
        updateRelativeMovement(current, player);
        updateTargetMovement(current, player, world);
        updateWorldDiagnostics(current, client, player, world);
        updateActiveContainerTransfer(current, player);

        if (Boolean.TRUE.equals(current.state.get("consume.failed"))) {
            String reason = stringParam(current.state, "consume.failure_reason", "consume_failed");
            AutomationReporter.block("[block]", "consume -> " + reason);
            AutomationCliViewModel.blocked(current.frameId, "consume", reason);
            current.state.remove("consume.failed");
            current.state.remove("consume.failure_reason");
            finishCurrentExecution("blocked");
            return;
        }

        if (Boolean.TRUE.equals(current.state.get("attack.failed"))) {
            String reason = stringParam(current.state, "attack.failure_reason", "attack_failed");
            AutomationReporter.block("[block]", "attack -> " + reason);
            AutomationCliViewModel.blocked(current.frameId, "attack", reason);
            current.state.remove("attack.failed");
            current.state.remove("attack.failure_reason");
            finishCurrentExecution("blocked");
            return;
        }

        if (Boolean.TRUE.equals(current.state.get("mine.failed"))) {
            String reason = stringParam(current.state, "mine.failure_reason", "mine_failed");
            AutomationReporter.block("[block]", "mine -> " + reason);
            AutomationCliViewModel.blocked(current.frameId, "mine", reason);
            current.state.remove("mine.failed");
            current.state.remove("mine.failure_reason");
            finishCurrentExecution("blocked");
            return;
        }

        if (Boolean.TRUE.equals(current.state.get("container.transfer.failed"))) {
            String reason = stringParam(current.state, "container.transfer.failure_reason", "transfer_failed");
            AutomationReporter.block("[block]", "container -> " + reason);
            AutomationCliViewModel.blocked(current.frameId, "container.transfer", reason);
            current.state.remove("container.transfer.failed");
            current.state.remove("container.transfer.failure_reason");
            finishCurrentExecution("blocked");
            return;
        }

        if (Boolean.TRUE.equals(current.state.get("move.failed"))) {
            String reason = stringParam(current.state, "move.failure_reason", "movement_failed");
            AutomationReporter.block("[block]", "movement -> " + reason);
            AutomationCliViewModel.blocked(current.frameId, "movement", reason);
            current.state.remove("move.failed");
            current.state.remove("move.failure_reason");
            finishCurrentExecution("blocked");
            return;
        }

        if (Boolean.TRUE.equals(current.state.get("consume.active"))) {
            AutomationCliViewModel.activeState("using", current.frameId, stringParam(current.state, "consume.phase", "consume"));
            return;
        }

        if (Boolean.TRUE.equals(current.state.get("attack.active"))) {
            AutomationCliViewModel.activeState("attacking", current.frameId, stringParam(current.state, "attack.phase", "attack"));
            return;
        }

        if (Boolean.TRUE.equals(current.state.get("mine.active"))) {
            AutomationCliViewModel.activeState("mining", current.frameId, stringParam(current.state, "mine.phase", "mine"));
            return;
        }

        if (Boolean.TRUE.equals(current.state.get("container.transfer.active"))) {
            AutomationCliViewModel.activeState("using", current.frameId, stringParam(current.state, "container.transfer.phase", "container"));
            return;
        }

        if (Boolean.TRUE.equals(current.state.get("move.relative.active"))) {
            AutomationCliViewModel.activeState("moving", current.frameId, stringParam(current.state, "move.relative.direction", "relative"));
            return;
        }

        if (Boolean.TRUE.equals(current.state.get("move.target.active"))) {
            AutomationCliViewModel.activeState("moving", current.frameId, stringParam(current.state, "move.nav.phase", "target"));
            return;
        }

        if (intState(current.state, "wait.ticks", 0) > 0) {
            int remaining = intState(current.state, "wait.ticks", 0) - 1;
            current.state.put("wait.ticks", remaining);
            AutomationReporter.mem("wait.ticks", remaining);
            if (current.activeNodeId != null) {
                AutomationCliViewModel.runtimeFlow(current.frameId, current.activeNodeId, "wait.phase", "flow_phase", "[wait]", "wait.phase", "countdown");
                AutomationCliViewModel.runtimeFlow(current.frameId, current.activeNodeId, "wait.remaining", "flow_metric", "[info]", "wait.remaining_ticks", remaining);
            }
            AutomationCliViewModel.activeState("waiting", current.frameId, remaining + " ticks");
            return;
        }

        if (current.index >= current.steps.size()) {
            finishCurrentExecution("success");
            return;
        }

        KtlCompilerService.CompiledStep step = current.steps.get(current.index);
        String label = step.label().isBlank() ? step.type() : step.label();
        String nodeId = label + "#" + current.index;

        AutomationReporter.mem("current.step", label);
        String source = step.sourcePath().isBlank() ? "" : "  source.file=" + step.sourcePath() + "  source.line=" + step.sourceLine();
        AutomationCliViewModel.enterNode(current.frameId, nodeId, label, step.type() + (step.action().isBlank() ? "" : " -> " + step.action()) + source);
        current.activeNodeId = nodeId;
        current.activeNodeLabel = label;
        current.activeAction = step.action();

        switch (step.type()) {
            case "run_primitive" -> {
                AutomationReporter.run("[run ]", label + " -> " + step.action());
                Map<String, Object> beforeState = new LinkedHashMap<>(current.state);
                PrimitiveRunResult primitiveResult = runPrimitive(step.action(), step.params(), current.state);
                AutomationCliViewModel.primitiveCall(current.frameId, nodeId, step.action(), primitiveResult.resolvedParams());
                emitPrimitiveStateDiff(current.frameId, nodeId, beforeState, current.state);
                AutomationCliViewModel.primitiveResult(current.frameId, nodeId, step.action(), primitiveResult.success(), stringParam(current.state, "result.action", ""));
                if (!primitiveResult.success()) {
                    AutomationReporter.block("[block]", label + " -> " + step.action());
                    AutomationCliViewModel.blocked(current.frameId, nodeId, step.action());
                    finishCurrentExecution("blocked");
                    return;
                }
                AutomationReporter.ok("[ok  ]", label);
                if (!holdsRuntimePhase(current.state)) {
                    current.activeNodeId = null;
                    current.activeNodeLabel = null;
                    current.activeAction = null;
                }
                current.index++;
            }
            case "branch" -> {
                String conditionKey = resolveString(step.condition(), current.state);
                boolean condition = evaluateCondition(conditionKey, current.state);
                AutomationReporter.pipeline("[branch]", conditionKey + " = " + condition);
                String delegatedInput = condition ? step.thenInput() : step.elseInput();
                AutomationReporter.info("[info]", "path = " + (condition ? "THEN" : "ELSE"));
                AutomationCliViewModel.branch(current.frameId, nodeId, conditionKey, condition ? "THEN" : "ELSE");
                AutomationCliViewModel.branchCandidates(current.frameId, nodeId, step.thenInput(), step.elseInput(), condition ? "THEN" : "ELSE");

                current.index++;

                if (delegatedInput != null && !delegatedInput.isBlank()) {
                    String resolved = resolveString(delegatedInput, current.state);
                    InterpretationResult child = this.compilerService.interpret(new AutomationRequest(resolved, false, resolved.endsWith(".ktl") || resolved.contains(".ktl ")));
                    String childFrameId = startExecution(child.plan(), child, current.frameId, label, current.state);
                    AutomationCliViewModel.delegate(current.frameId, nodeId, childFrameId, resolved);
                    return;
                }

                AutomationReporter.ok("[ok  ]", label);
            }
            case "goto" -> {
                String scope = step.scope() == null || step.scope().isBlank() ? "local" : step.scope();
                if ("parent".equalsIgnoreCase(scope)) {
                    if (this.executionStack.size() < 2) {
                        throw new IllegalStateException("goto scope=parent used without a parent frame");
                    }
                    ActiveExecution child = this.executionStack.pop();
                    ActiveExecution parent = this.executionStack.peek();
                    parent.state.putAll(child.state);
                    parent.index = gotoIndex(parent.steps, step.gotoLabel());
                    AutomationCliViewModel.returned(child.frameId, parent.frameId, "goto_parent", child.resumeLabel);
                    AutomationReporter.ok("[goto ]", "parent -> " + step.gotoLabel());
                    return;
                }
                current.index = gotoIndex(current.steps, step.gotoLabel());
            }
            case "delegate" -> {
                String resolved = resolveString(step.delegate(), current.state);
                AutomationReporter.run("[delegate]", label + " -> " + resolved);
                current.index++;
                InterpretationResult child = this.compilerService.interpret(new AutomationRequest(resolved, false, resolved.endsWith(".ktl") || resolved.contains(".ktl ")));
                String childFrameId = startExecution(child.plan(), child, current.frameId, label, current.state);
                AutomationCliViewModel.delegate(current.frameId, nodeId, childFrameId, resolved);
                return;
            }
            case "return" -> finishCurrentExecution("success");
            default -> throw new IllegalStateException("Unsupported step type: " + step.type());
        }
    }

    private String startExecution(ExecutionPlan plan, InterpretationResult interpretationResult, String parentFrameId, String resumeLabel, Map<String, Object> inheritedState) {
        String frameId = String.format("frame-%04d", FRAME_SEQUENCE.incrementAndGet());
        Map<String, Object> state = new LinkedHashMap<>();
        if (inheritedState != null) {
            state.putAll(inheritedState);
        }
        state.putAll(plan.params());

        AutomationReporter.run("[run ]", "objective -> " + interpretationResult.selectedTemplateId());
        AutomationReporter.mem("active.template", interpretationResult.selectedTemplateId());
        AutomationCliViewModel.beginFrame(frameId, parentFrameId, interpretationResult.selectedTemplateId(), interpretationResult.semanticOperationId());
        AutomationCliViewModel.frameContext(frameId, parentFrameId, resumeLabel, interpretationResult.semanticOperationId(), interpretationResult.boundParams(), interpretationResult.diagnostics());

        this.executionStack.push(new ActiveExecution(frameId, parentFrameId, resumeLabel, interpretationResult, plan.template().steps(), state));
        return frameId;
    }

    private void finishCurrentExecution(String status) {
        if (this.executionStack.isEmpty()) {
            return;
        }

        ActiveExecution finished = this.executionStack.pop();

        if (finished.state.containsKey("state.counter") && finished.state.containsKey("count.value")) {
            AutomationReporter.info("[info]", "final.progress = [ " + finished.state.get("state.counter") + " / " + finished.state.get("count.value") + " ]");
        }

        AutomationReporter.mem("result.frame", finished.frameId);
        AutomationReporter.mem("result.template", finished.interpretationResult.selectedTemplateId());
        AutomationReporter.mem("result.state", status);
        for (Map.Entry<String, Object> entry : finished.state.entrySet()) {
            if (entry.getKey().startsWith("result.")) {
                AutomationCliViewModel.frameResult(finished.frameId, entry.getKey(), entry.getValue());
            }
        }
        AutomationCliViewModel.frameStateSnapshot(finished.frameId, finished.state, "final");
        AutomationCliViewModel.completeFrame(finished.frameId, status);
        AutomationReporter.done("[done]", "state = " + status);

        if (!this.executionStack.isEmpty()) {
            ActiveExecution parent = this.executionStack.peek();
            parent.state.putAll(finished.state);
            AutomationCliViewModel.returned(finished.frameId, parent.frameId, status, finished.resumeLabel);
            if (finished.resumeLabel != null && !finished.resumeLabel.isBlank()) {
                AutomationReporter.ok("[return]", "return_to = " + finished.resumeLabel);
            }
            if (!"success".equals(status)) {
                parent.state.put("child.failed", true);
                parent.state.put("child.failure_status", status);
                parent.state.put("child.failure_frame", finished.frameId);
                parent.state.put("child.failure_template", finished.interpretationResult.selectedTemplateId());
                finishCurrentExecution(status);
            }
        } else {
            runCompletionCommand(status, finished.state);
            AutomationRuntimeStatus.idle(status);
            AutomationCliViewModel.offerFeedbackPrompt();
        }
    }

    private void runCompletionCommand(String status, Map<String, Object> state) {
        if (state == null) {
            return;
        }
        String key = "success".equalsIgnoreCase(status) ? "completion.success.command" : "completion.failure.command";
        String command = stringParam(state, key, "");
        if (command.isBlank()) {
            return;
        }
        if (command.startsWith("/")) {
            command = command.substring(1).trim();
        }
        if (command.isBlank()) {
            return;
        }
        AutomationReporter.run("[cmd ]", key + " -> /" + command);
        AutomationRouter.sendRawCommand(command);
    }

    private boolean holdsRuntimePhase(Map<String, Object> state) {
        return Boolean.TRUE.equals(state.get("consume.active"))
                || Boolean.TRUE.equals(state.get("attack.active"))
                || Boolean.TRUE.equals(state.get("mine.active"))
                || Boolean.TRUE.equals(state.get("move.relative.active"))
                || Boolean.TRUE.equals(state.get("move.target.active"))
                || Boolean.TRUE.equals(state.get("container.transfer.active"))
                || intState(state, "wait.ticks", 0) > 0;
    }

    private PrimitiveRunResult runPrimitive(String action, Map<String, Object> params, Map<String, Object> state) {
        Map<String, Object> resolvedParams = resolveParams(params, state);
        AutomationReporter.info("[info]", "primitive = " + action);
        class_310 client = class_310.method_1551();
        class_746 player = client == null ? null : client.field_1724;
        class_638 world = client == null ? null : client.field_1687;
        class_636 interactionManager = client == null ? null : client.field_1761;

        boolean success = switch (action) {
            case "cap.command.execute_raw" -> {
                String rawCommand = stringParam(resolvedParams, "raw.command", "");
                if (rawCommand.isBlank()) {
                    yield false;
                }
                AutomationRouter.sendRawCommand(rawCommand);
                yield true;
            }
            case "cap.report.say" -> {
                String message = stringParam(resolvedParams, "message", "");
                if (message.isBlank()) {
                    yield false;
                }
                AutomationRouter.sendChatMessage(message);
                yield true;
            }
            case "cap.report.status_line" -> {
                String message = stringParam(resolvedParams, "message", "");
                if (message.isBlank()) {
                    yield false;
                }
                AutomationReporter.info("[stat]", message);
                yield true;
            }
            case "cap.report.error_line" -> {
                String message = stringParam(resolvedParams, "message", "");
                if (message.isBlank()) {
                    yield false;
                }
                AutomationReporter.info("[fail]", message);
                yield true;
            }
            case "cap.state.write_memory" -> {
                for (Map.Entry<String, Object> entry : resolvedParams.entrySet()) {
                    state.put(entry.getKey(), entry.getValue());
                    AutomationReporter.mem(entry.getKey(), entry.getValue());
                }
                yield true;
            }
            case "cap.state.remove_memory" -> {
                String key = stringParam(resolvedParams, "state.key", "");
                if (key.isBlank()) {
                    yield false;
                }
                state.remove(key);
                AutomationReporter.mem(key, null);
                yield true;
            }
            case "cap.state.copy_value" -> {
                String fromKey = stringParam(resolvedParams, "from.key", "");
                String toKey = stringParam(resolvedParams, "to.key", "");
                if (fromKey.isBlank() || toKey.isBlank() || !state.containsKey(fromKey)) {
                    yield false;
                }
                Object value = state.get(fromKey);
                state.put(toKey, value);
                AutomationReporter.mem(toKey, value);
                yield true;
            }
            case "cap.state.increment_counter" -> {
                String key = stringParam(resolvedParams, "state.key", "state.counter");
                int current = intState(state, key, 0);
                int next = current + intParam(resolvedParams, "delta", 1);
                state.put(key, next);
                AutomationReporter.mem(key, next);
                if ("state.counter".equals(key) && state.containsKey("count.value")) {
                    AutomationReporter.info("[prog]", "[ " + next + " / " + state.get("count.value") + " ]");
                }
                yield true;
            }
            case "cap.state.capture_player_position" -> {
                if (player == null) {
                    yield false;
                }
                String prefix = stringParam(resolvedParams, "state.prefix", "player.position");
                state.put(prefix + ".x", player.method_23317());
                state.put(prefix + ".y", player.method_23318());
                state.put(prefix + ".z", player.method_23321());
                AutomationReporter.mem(prefix + ".x", player.method_23317());
                AutomationReporter.mem(prefix + ".y", player.method_23318());
                AutomationReporter.mem(prefix + ".z", player.method_23321());
                yield true;
            }
            case "cap.state.decrement_counter" -> {
                String key = stringParam(resolvedParams, "state.key", "state.counter");
                int current = intState(state, key, 0);
                int next = current - intParam(resolvedParams, "delta", 1);
                state.put(key, next);
                AutomationReporter.mem(key, next);
                yield true;
            }
            case "cap.state.set_counter" -> {
                String key = stringParam(resolvedParams, "state.key", "state.counter");
                int value = intParam(resolvedParams, "value", 0);
                state.put(key, value);
                AutomationReporter.mem(key, value);
                yield true;
            }
            case "cap.state.read_stat" -> {
                if (player == null) {
                    yield false;
                }
                String statRef = stringParam(resolvedParams, "stat.ref", "");
                String resultKey = stringParam(resolvedParams, "result.key", "result.value");
                Object value = readStatValue(player, statRef);
                if (value == null) {
                    yield false;
                }
                state.put(resultKey, value);
                AutomationReporter.mem(resultKey, value);
                yield true;
            }

            case "cap.input.press_key" -> {
                String keyId = stringParam(resolvedParams, "input.key", "");
                if (keyId.isBlank()) {
                    yield false;
                }
                setHeldInput(keyId, true);
                state.put("result.action", "SUCCESS");
                AutomationReporter.mem("result.action", "SUCCESS");
                yield true;
            }
            case "cap.input.release_key" -> {
                String keyId = stringParam(resolvedParams, "input.key", "");
                if (keyId.isBlank()) {
                    yield false;
                }
                setHeldInput(keyId, false);
                state.put("result.action", "SUCCESS");
                AutomationReporter.mem("result.action", "SUCCESS");
                yield true;
            }
            case "cap.input.tap_key" -> {
                String keyId = stringParam(resolvedParams, "input.key", "");
                int ticks = Math.max(1, intParam(resolvedParams, "count.value", 2));
                if (keyId.isBlank()) {
                    yield false;
                }
                tapInput(keyId, ticks);
                performImmediateTapAction(keyId, client, player);
                state.put("result.action", "SUCCESS");
                AutomationReporter.mem("result.action", "SUCCESS");
                yield true;
            }
            case "cap.input.release_all" -> {
                releaseAllInputs();
                state.put("result.action", "SUCCESS");
                AutomationReporter.mem("result.action", "SUCCESS");
                yield true;
            }
            case "cap.movement.release_all" -> {
                releaseMovementInputs();
                writeMovementResult(state, true, "success", "movement_inputs_released");
                yield true;
            }
            case "cap.movement.set_forward" -> {
                boolean pressed = booleanParam(resolvedParams, "pressed", true);
                setHeldInput("forward", pressed);
                writeMovementResult(state, true, pressed ? "running" : "success", "forward_" + (pressed ? "held" : "released"));
                yield true;
            }
            case "cap.movement.set_backward" -> {
                boolean pressed = booleanParam(resolvedParams, "pressed", true);
                setHeldInput("back", pressed);
                writeMovementResult(state, true, pressed ? "running" : "success", "backward_" + (pressed ? "held" : "released"));
                yield true;
            }
            case "cap.movement.set_left_strafe" -> {
                boolean pressed = booleanParam(resolvedParams, "pressed", true);
                setHeldInput("left", pressed);
                writeMovementResult(state, true, pressed ? "running" : "success", "left_strafe_" + (pressed ? "held" : "released"));
                yield true;
            }
            case "cap.movement.set_right_strafe" -> {
                boolean pressed = booleanParam(resolvedParams, "pressed", true);
                setHeldInput("right", pressed);
                writeMovementResult(state, true, pressed ? "running" : "success", "right_strafe_" + (pressed ? "held" : "released"));
                yield true;
            }
            case "cap.movement.set_sprint" -> {
                boolean pressed = booleanParam(resolvedParams, "pressed", true);
                setHeldInput("sprint", pressed);
                if (player != null) {
                    player.method_5728(pressed);
                }
                writeMovementResult(state, true, pressed ? "running" : "success", "sprint_" + (pressed ? "held" : "released"));
                yield true;
            }
            case "cap.movement.set_sneak" -> {
                boolean pressed = booleanParam(resolvedParams, "pressed", true);
                setHeldInput("sneak", pressed);
                writeMovementResult(state, true, pressed ? "running" : "success", "sneak_" + (pressed ? "held" : "released"));
                yield true;
            }
            case "cap.movement.set_jump" -> {
                boolean pressed = booleanParam(resolvedParams, "pressed", true);
                setHeldInput("jump", pressed);
                writeMovementResult(state, true, pressed ? "running" : "success", "jump_" + (pressed ? "held" : "released"));
                yield true;
            }
            case "cap.movement.timed_jump" -> {
                int ticks = Math.max(1, intParam(resolvedParams, "ticks", 4));
                tapInput("jump", ticks);
                if (player != null && player.method_24828()) {
                    player.method_6043();
                }
                writeMovementResult(state, true, "running", "timed_jump");
                yield true;
            }
            case "cap.input.mouse_delta" -> {
                if (player == null) {
                    yield false;
                }
                float yawDelta = (float) doubleParam(resolvedParams, "yaw.delta", 0.0D);
                float pitchDelta = (float) doubleParam(resolvedParams, "pitch.delta", 0.0D);
                queueMouseDelta(yawDelta, pitchDelta);
                state.put("result.action", "SUCCESS");
                AutomationReporter.mem("result.action", "SUCCESS");
                yield true;
            }

            case "cap.inventory.open_inventory_screen" -> {
                if (client == null || player == null) {
                    yield false;
                }
                if (client.field_1755 != null) {
                    yield true;
                }
                tapInput("inventory", 2);
                state.put("result.action", "SUCCESS");
                AutomationReporter.mem("result.action", "SUCCESS");
                yield true;
            }
            case "cap.container.find_item_in_open_screen" -> {
                if (player == null) {
                    yield false;
                }
                String itemId = stringParam(resolvedParams, "item.id", "");
                String resultKey = stringParam(resolvedParams, "result.key", "result.container.slot");
                if (itemId.isBlank()) {
                    yield false;
                }
                int slotIndex = findMatchingOpenScreenSlot(player, itemId, Boolean.TRUE.equals(resolvedParams.get("container.only")));
                state.put(resultKey, slotIndex);
                state.put("result.found", slotIndex >= 0);
                AutomationReporter.mem(resultKey, slotIndex);
                AutomationReporter.mem("result.found", slotIndex >= 0);
                yield slotIndex >= 0;
            }
            case "cap.container.quick_move_slot" -> {
                if (player == null || interactionManager == null) {
                    yield false;
                }
                int slotIndex = intParam(resolvedParams, "slot.index", -1);
                if (slotIndex < 0 || slotIndex >= player.field_7512.field_7761.size()) {
                    yield false;
                }
                yield startContainerTransfer(interactionManager, player, slotIndex, resolvedParams, state, "take");
            }
            case "cap.container.quick_move_selected_hotbar" -> {
                if (player == null || interactionManager == null) {
                    yield false;
                }
                int selectedSlot = openScreenHotbarSlot(player);
                if (selectedSlot < 0 || selectedSlot >= player.field_7512.field_7761.size()) {
                    yield false;
                }
                yield startContainerTransfer(interactionManager, player, selectedSlot, resolvedParams, state, "store");
            }

            case "cap.inventory.count_item" -> {
                if (player == null) {
                    yield false;
                }
                String itemId = stringParam(resolvedParams, "item.id", "");
                if (itemId.isBlank()) {
                    yield false;
                }
                int count = countInventory(player.method_31548(), itemId);
                String resultKey = stringParam(resolvedParams, "result.key", "result.count");
                state.put(resultKey, count);
                AutomationReporter.mem(resultKey, count);
                yield true;
            }
            case "cap.inventory.has_item" -> {
                if (player == null) {
                    yield false;
                }
                String itemId = stringParam(resolvedParams, "item.id", "");
                if (itemId.isBlank()) {
                    yield false;
                }
                boolean hasItem = countInventory(player.method_31548(), itemId) > 0;
                String resultKey = stringParam(resolvedParams, "result.key", "result.present");
                state.put(resultKey, hasItem);
                AutomationReporter.mem(resultKey, hasItem);
                yield true;
            }
            case "cap.inventory.require_count" -> {
                if (player == null) {
                    yield false;
                }
                String itemId = stringParam(resolvedParams, "item.id", "");
                if (itemId.isBlank()) {
                    yield false;
                }
                int count = countInventory(player.method_31548(), itemId);
                int threshold = intParam(resolvedParams, "count.value", 1);
                String op = stringParam(resolvedParams, "condition.op", "gte");
                boolean matched = compareNumbers(count, threshold, op);
                String resultKey = stringParam(resolvedParams, "result.key", "result.inventory_ok");
                state.put(resultKey, matched);
                state.put("result.action", matched ? "SUCCESS" : "FAIL");
                AutomationReporter.mem(resultKey, matched);
                AutomationReporter.mem("result.action", matched ? "SUCCESS" : "FAIL");
                yield matched;
            }
            case "cap.inventory.consume_item" -> {
                if (player == null) {
                    yield false;
                }
                String itemId = stringParam(resolvedParams, "item.id", "");
                int amount = Math.max(1, intParam(resolvedParams, "count.value", 1));
                if (itemId.isBlank()) {
                    yield false;
                }
                boolean removed = removeInventoryItems(player.method_31548(), itemId, amount);
                if (!removed) {
                    yield false;
                }
                String resultKey = stringParam(resolvedParams, "result.key", "result.consumed");
                state.put(resultKey, amount);
                AutomationReporter.mem(resultKey, amount);
                yield true;
            }
            case "cap.inventory.select_hotbar_item" -> {
                if (player == null) {
                    yield false;
                }
                String itemId = stringParam(resolvedParams, "item.id", "");
                if (itemId.isBlank()) {
                    yield false;
                }
                int slot = findHotbarSlot(player.method_31548(), itemId);
                if (slot < 0) {
                    slot = moveInventoryItemToSelectedHotbar(player.method_31548(), itemId);
                }
                if (slot < 0) {
                    yield false;
                }
                player.method_31548().field_7545 = slot;
                state.put("selected.slot", slot);
                state.put("selected.item.id", itemId);
                AutomationReporter.mem("selected.slot", slot);
                AutomationReporter.mem("selected.item.id", itemId);
                yield true;
            }
            case "cap.inventory.drop_selected_item" -> {
                if (player == null) {
                    yield false;
                }
                boolean all = Boolean.parseBoolean(stringParam(resolvedParams, "drop.all", "false"));
                boolean dropped = player.method_7290(all);
                state.put("result.dropped", dropped);
                state.put("result.action", dropped ? "SUCCESS" : "FAIL");
                AutomationReporter.mem("result.dropped", dropped);
                AutomationReporter.mem("result.action", dropped ? "SUCCESS" : "FAIL");
                yield dropped;
            }
            case "cap.inventory.equip_item" -> {
                if (player == null) {
                    yield false;
                }
                String itemId = stringParam(resolvedParams, "item.id", "");
                if (itemId.isBlank()) {
                    yield false;
                }
                int slot = findHotbarSlot(player.method_31548(), itemId);
                if (slot < 0) {
                    yield false;
                }
                player.method_31548().field_7545 = slot;
                state.put("equipped.item.id", itemId);
                AutomationReporter.mem("equipped.item.id", itemId);
                yield true;
            }

            case "cap.world.scan_entities" -> {
                if (player == null || world == null) {
                    yield false;
                }
                String entityId = stringParam(resolvedParams, "target.id", "");
                double radius = doubleParam(resolvedParams, "radius", 24.0D);
                if (entityId.isBlank()) {
                    yield false;
                }
                writeScanTelemetry(state, "entity", entityId, "nearest", radius, countMatchingEntities(player, entityId, radius));
                class_1297 nearest = findEntityBySelector(player, entityId, radius, "nearest");
                if (nearest == null) {
                    state.put("scan.failure_reason", "no_matching_entity");
                    yield false;
                }
                writeEntityState(state, nearest, entityId);
                writeSelectedTargetTelemetry(state, player, nearest.method_19538());
                yield true;
            }
            case "cap.world.scan_players" -> {
                if (player == null || world == null) {
                    yield false;
                }
                String name = stringParam(resolvedParams, "player.name", "");
                if (name.isBlank()) {
                    yield false;
                }
                double radius = doubleParam(resolvedParams, "radius", 64.0D);
                writeScanTelemetry(state, "player", name, "nearest", radius, countMatchingPlayers(player, name, radius));
                class_1657 nearest = findPlayerByName(player, name, radius, "nearest");
                if (nearest == null) {
                    state.put("scan.failure_reason", "no_matching_player");
                    yield false;
                }
                state.put("current.target.kind", "player");
                state.put("current.target.id", nearest.method_5845());
                state.put("current.target.uuid", nearest.method_5845());
                state.put("current.target.name", nearest.method_5477().getString());
                state.put("current.target.x", nearest.method_23317());
                state.put("current.target.y", nearest.method_23318());
                state.put("current.target.z", nearest.method_23321());
                AutomationReporter.mem("current.target.name", nearest.method_5477().getString());
                AutomationReporter.mem("current.target.uuid", nearest.method_5845());
                writeSelectedTargetTelemetry(state, player, nearest.method_19538());
                yield true;
            }
            case "cap.world.scan_blocks" -> {
                if (player == null || world == null) {
                    yield false;
                }
                String blockId = stringParam(resolvedParams, "target.id", "");
                int radius = Math.max(1, intParam(resolvedParams, "radius", 6));
                if (blockId.isBlank()) {
                    yield false;
                }
                writeScanTelemetry(state, "block", blockId, "nearest", radius, countMatchingBlocks(player, blockId, radius));
                class_2338 pos = findNearestBlock(player, blockId, radius);
                if (pos == null) {
                    state.put("scan.failure_reason", "no_matching_block");
                    yield false;
                }
                class_2680 blockState = world.method_8320(pos);
                state.put("current.target.kind", "block");
                state.put("current.target.id", blockId);
                state.put("current.target.x", pos.method_10263());
                state.put("current.target.y", pos.method_10264());
                state.put("current.target.z", pos.method_10260());
                state.put("current.target.block_state", blockState.method_26204().toString());
                AutomationReporter.mem("current.target.id", blockId);
                AutomationReporter.mem("current.target.x", pos.method_10263());
                AutomationReporter.mem("current.target.y", pos.method_10264());
                AutomationReporter.mem("current.target.z", pos.method_10260());
                writeSelectedTargetTelemetry(state, player, class_243.method_24953(pos));
                yield true;
            }
            case "cap.world.scan_target" -> {
                if (player == null || world == null) {
                    yield false;
                }
                String targetKind = stringParam(resolvedParams, "target.kind", "").toLowerCase(Locale.ROOT);
                String selectorId = stringParam(resolvedParams, "target.selector", "nearest").toLowerCase(Locale.ROOT);
                String targetId = stringParam(resolvedParams, "target.id", "");
                if (canReuseCurrentTarget(player, world, state, targetKind, targetId)) {
                    state.put("scan.cache_hit", true);
                    AutomationReporter.mem("scan.cache_hit", true);
                    yield true;
                }
                state.put("scan.cache_hit", false);
                yield switch (targetKind) {
                    case "player" -> {
                        String name = targetId;
                        if (name.isBlank()) {
                            yield false;
                        }
                        double radius = doubleParam(resolvedParams, "radius", 64.0D);
                        writeScanTelemetry(state, "player", name, selectorId, radius, countMatchingPlayers(player, name, radius));
                        class_1657 nearest = findPlayerByName(player, name, radius, selectorId);
                        if (nearest == null) {
                            state.put("scan.failure_reason", "no_matching_player");
                            yield false;
                        }
                        state.put("current.target.kind", "player");
                        state.put("current.target.id", nearest.method_5845());
                        state.put("current.target.uuid", nearest.method_5845());
                        state.put("current.target.name", nearest.method_5477().getString());
                        state.put("current.target.x", nearest.method_23317());
                        state.put("current.target.y", nearest.method_23318());
                        state.put("current.target.z", nearest.method_23321());
                        AutomationReporter.mem("current.target.name", nearest.method_5477().getString());
                        AutomationReporter.mem("current.target.uuid", nearest.method_5845());
                        writeSelectedTargetTelemetry(state, player, nearest.method_19538());
                        yield true;
                    }
                    case "block" -> {
                        String blockId = targetId;
                        int radius = Math.max(1, intParam(resolvedParams, "radius", 6));
                        if (blockId.isBlank()) {
                            yield false;
                        }
                        writeScanTelemetry(state, "block", blockId, selectorId, radius, countMatchingBlocks(player, blockId, radius));
                        class_2338 pos = findNearestBlock(player, blockId, radius);
                        if (pos == null) {
                            state.put("scan.failure_reason", "no_matching_block");
                            yield false;
                        }
                        class_2680 blockState = world.method_8320(pos);
                        state.put("current.target.kind", "block");
                        state.put("current.target.id", blockId);
                        state.put("current.target.x", pos.method_10263());
                        state.put("current.target.y", pos.method_10264());
                        state.put("current.target.z", pos.method_10260());
                        state.put("current.target.block_state", blockState.method_26204().toString());
                        AutomationReporter.mem("current.target.id", blockId);
                        AutomationReporter.mem("current.target.x", pos.method_10263());
                        AutomationReporter.mem("current.target.y", pos.method_10264());
                        AutomationReporter.mem("current.target.z", pos.method_10260());
                        writeSelectedTargetTelemetry(state, player, class_243.method_24953(pos));
                        yield true;
                    }
                    case "item" -> {
                        String itemId = targetId;
                        double radius = doubleParam(resolvedParams, "radius", 24.0D);
                        if (itemId.isBlank()) {
                            yield false;
                        }
                        writeScanTelemetry(state, "item", itemId, selectorId, radius, countMatchingItems(player, itemId, radius));
                        class_1542 nearest = findItemEntityBySelector(player, itemId, radius, selectorId);
                        if (nearest == null) {
                            state.put("scan.failure_reason", "no_matching_item");
                            yield false;
                        }
                        writeEntityState(state, nearest, itemId);
                        state.put("current.target.kind", "item");
                        writeSelectedTargetTelemetry(state, player, nearest.method_19538());
                        yield true;
                    }
                    default -> {
                        String entityId = targetId;
                        double radius = doubleParam(resolvedParams, "radius", 24.0D);
                        if (entityId.isBlank()) {
                            yield false;
                        }
                        writeScanTelemetry(state, "entity", entityId, selectorId, radius, countMatchingEntities(player, entityId, radius));
                        class_1297 nearest = findEntityBySelector(player, entityId, radius, selectorId);
                        if (nearest == null) {
                            state.put("scan.failure_reason", "no_matching_entity");
                            yield false;
                        }
                        writeEntityState(state, nearest, entityId);
                        writeSelectedTargetTelemetry(state, player, nearest.method_19538());
                        yield true;
                    }
                };
            }
            case "cap.world.validate_target" -> {
                if (player == null || world == null) {
                    yield false;
                }
                String targetKind = stringParam(resolvedParams, "target.kind", stringParam(state, "current.target.kind", "")).toLowerCase(Locale.ROOT);
                boolean valid = switch (targetKind) {
                    case "block" -> {
                        if (!hasTargetPosition(state)) {
                            yield false;
                        }
                        String expected = stringParam(resolvedParams, "target.id", stringParam(state, "current.target.id", ""));
                        class_2960 actual = class_7923.field_41175.method_10221(world.method_8320(targetBlockPos(state)).method_26204());
                        yield actual != null && expected.equals(actual.toString());
                    }
                    case "entity", "player", "item" -> {
                        class_1297 entity = resolveTargetEntity(world, resolvedParams, state);
                        yield entity != null && entity.method_5805();
                    }
                    case "location" -> hasTargetPosition(state);
                    default -> false;
                };
                String resultKey = stringParam(resolvedParams, "result.key", "result.target.valid");
                state.put(resultKey, valid);
                AutomationReporter.mem(resultKey, valid);
                yield valid;
            }
            case "cap.world.target_in_range" -> {
                if (player == null || !hasTargetPosition(state)) {
                    yield false;
                }
                double distance = player.method_19538().method_1022(new class_243(
                        doubleState(state, "current.target.x", player.method_23317()),
                        doubleState(state, "current.target.y", player.method_23318()),
                        doubleState(state, "current.target.z", player.method_23321())
                ));
                double threshold = doubleParam(resolvedParams, "distance", doubleParam(resolvedParams, "stop.distance", 3.0D));
                boolean inRange = distance <= threshold;
                String resultKey = stringParam(resolvedParams, "result.key", "result.target.in_range");
                state.put(resultKey, inRange);
                AutomationReporter.mem(resultKey, inRange);
                yield inRange;
            }

            case "cap.look.face_target" -> {
                if (player == null || world == null) {
                    yield false;
                }
                String uuid = stringParam(state, "current.target.uuid", "");
                class_1297 entity = findEntityByUuid(world, uuid);
                if (entity != null) {
                    facePosition(player, entity.method_33571());
                    yield true;
                }
                if (hasTargetPosition(state)) {
                    facePosition(player, new class_243(doubleState(state, "current.target.x", player.method_23317()) + 0.5D, doubleState(state, "current.target.y", player.method_23320()), doubleState(state, "current.target.z", player.method_23321()) + 0.5D));
                    yield true;
                }
                yield false;
            }
            case "cap.look.face_target_horizontal" -> {
                if (player == null || world == null) {
                    yield false;
                }
                String uuid = stringParam(state, "current.target.uuid", "");
                class_1297 entity = findEntityByUuid(world, uuid);
                if (entity != null) {
                    facePositionHorizontal(player, entity.method_19538());
                    yield true;
                }
                if (hasTargetPosition(state)) {
                    facePositionHorizontal(player, new class_243(
                            doubleState(state, "current.target.x", player.method_23317()) + 0.5D,
                            doubleState(state, "current.target.y", player.method_23318()),
                            doubleState(state, "current.target.z", player.method_23321()) + 0.5D
                    ));
                    yield true;
                }
                yield false;
            }
            case "cap.look.face_position" -> {
                if (player == null) {
                    yield false;
                }
                double x = resolvedParams.containsKey("target.x") ? doubleParam(resolvedParams, "target.x", player.method_23317()) : doubleState(state, "current.target.x", player.method_23317());
                double y = resolvedParams.containsKey("target.y") ? doubleParam(resolvedParams, "target.y", player.method_23318()) : doubleState(state, "current.target.y", player.method_23318());
                double z = resolvedParams.containsKey("target.z") ? doubleParam(resolvedParams, "target.z", player.method_23321()) : doubleState(state, "current.target.z", player.method_23321());
                facePosition(player, new class_243(x + 0.5D, y, z + 0.5D));
                yield true;
            }
            case "cap.look.set_yaw" -> {
                if (player == null) {
                    yield false;
                }
                player.method_36456((float) doubleParam(resolvedParams, "yaw", player.method_36454()));
                writeMovementResult(state, true, "success", "yaw_set");
                yield true;
            }
            case "cap.look.set_pitch" -> {
                if (player == null) {
                    yield false;
                }
                player.method_36457(class_3532.method_15363((float) doubleParam(resolvedParams, "pitch", player.method_36455()), -90.0F, 90.0F));
                writeMovementResult(state, true, "success", "pitch_set");
                yield true;
            }
            case "cap.look.face_block_center" -> {
                if (player == null) {
                    yield false;
                }
                class_2338 pos = resolveTargetBlockPos(resolvedParams, state);
                if (pos == null) {
                    yield false;
                }
                facePosition(player, class_243.method_24953(pos));
                writeMovementResult(state, true, "success", "look_block_center");
                yield true;
            }
            case "cap.look.face_block_face" -> {
                if (player == null) {
                    yield false;
                }
                class_3965 hit = resolveBlockHitResult(player, resolvedParams, state);
                if (hit == null) {
                    yield false;
                }
                facePosition(player, hit.method_17784());
                writeMovementResult(state, true, "success", "look_block_face");
                yield true;
            }
            case "cap.look.face_movement_direction" -> {
                if (player == null) {
                    yield false;
                }
                class_243 velocity = player.method_18798();
                class_243 direction = new class_243(velocity.field_1352, 0.0D, velocity.field_1350);
                if (direction.method_1027() < 1.0E-4D) {
                    direction = movementDirectionFromState(state);
                }
                if (direction.method_1027() >= 1.0E-4D) {
                    facePositionHorizontal(player, player.method_19538().method_1019(direction.method_1029()));
                }
                smoothPitchToward(player, class_3532.method_15363(player.method_36455(), -20.0F, 20.0F), LOOK_MAX_PITCH_STEP);
                writeMovementResult(state, true, "success", "look_movement_direction");
                yield true;
            }
            case "cap.look.face_parkour_landing" -> {
                if (player == null) {
                    yield false;
                }
                class_243 landing = resolveTargetVector(world, resolvedParams, state);
                if (landing == null) {
                    yield false;
                }
                facePosition(player, landing.method_1031(0.0D, 0.35D, 0.0D));
                smoothPitchToward(player, class_3532.method_15363(player.method_36455(), -35.0F, 20.0F), LOOK_MAX_PITCH_STEP);
                writeMovementResult(state, true, "success", "look_parkour_landing");
                yield true;
            }
            case "cap.look.turn_yaw" -> {
                if (player == null) {
                    yield false;
                }
                float amount = (float) doubleParam(resolvedParams, "count.value", 90.0D);
                String direction = stringParam(resolvedParams, "direction.id", "left").toLowerCase(Locale.ROOT);
                player.method_36456(player.method_36454() + ("left".equals(direction) ? amount : -amount));
                yield true;
            }
            case "cap.look.turn_pitch" -> {
                if (player == null) {
                    yield false;
                }
                float amount = (float) doubleParam(resolvedParams, "count.value", 20.0D);
                String direction = stringParam(resolvedParams, "direction.id", "up").toLowerCase(Locale.ROOT);
                float next = player.method_36455() + ("up".equals(direction) ? -amount : amount);
                player.method_36457(class_3532.method_15363(next, -90.0F, 90.0F));
                yield true;
            }
            case "cap.look.turn_relative" -> {
                if (player == null) {
                    yield false;
                }
                float amount = (float) doubleParam(resolvedParams, "count.value", 90.0D);
                String direction = stringParam(resolvedParams, "direction.id", "left").toLowerCase(Locale.ROOT);
                switch (direction) {
                    case "up", "down" -> {
                        float next = player.method_36455() + ("up".equals(direction) ? -amount : amount);
                        player.method_36457(class_3532.method_15363(next, -90.0F, 90.0F));
                    }
                    default -> player.method_36456(player.method_36454() + ("left".equals(direction) ? amount : -amount));
                }
                yield true;
            }

            case "cap.movement.walk_relative" -> {
                if (player == null) {
                    yield false;
                }
                String direction = stringParam(resolvedParams, "direction.id", "forward");
                int ticks = Math.max(1, intParam(resolvedParams, "ticks", blocksToTicks(doubleParam(resolvedParams, "count.value", 1.0D))));
                beginRelativeMovement(state, player, direction, ticks, booleanParam(resolvedParams, "sprint", false));
                yield true;
            }
            case "cap.path.compute_relative_target" -> {
                if (player == null) {
                    yield false;
                }
                writeRelativeTargetState(state, player, resolvedParams);
                yield true;
            }
            case "cap.path.move_relative_verified" -> {
                if (player == null || world == null) {
                    yield false;
                }
                class_243 target = writeRelativeTargetState(state, player, resolvedParams);
                Map<String, Object> navParams = new LinkedHashMap<>(resolvedParams);
                navParams.putIfAbsent("movement.precise", true);
                navParams.putIfAbsent("movement.precision.distance", Math.max(NAV_PRECISE_DIRECT_DISTANCE, doubleState(state, "current.target.relative_distance", NAV_PRECISE_DIRECT_DISTANCE)));
                navParams.putIfAbsent("movement.precision.slow_distance", NAV_PRECISE_SLOW_DISTANCE);
                double stopDistance = navigationStopDistance(navParams, state, NAV_PRECISE_STOP_DISTANCE);
                boolean useY = Boolean.TRUE.equals(state.get("current.target.use_y")) || "true".equalsIgnoreCase(stringParam(state, "current.target.use_y", "false"));
                beginPointNavigation(state, player, target, stopDistance, booleanParam(navParams, "movement.allow_sprint", true), useY, navParams);
                state.put("move.target.precise", booleanParam(navParams, "movement.precise", true));
                state.put("move.target.precision_distance", doubleParam(navParams, "movement.precision.distance", Math.max(NAV_PRECISE_DIRECT_DISTANCE, doubleState(state, "current.target.relative_distance", NAV_PRECISE_DIRECT_DISTANCE))));
                state.put("move.target.slow_distance", doubleParam(navParams, "movement.precision.slow_distance", NAV_PRECISE_SLOW_DISTANCE));
                writeStateValue(state, "path.status", "relative_navigating");
                yield true;
            }
            case "cap.movement.stop" -> {
                clearMovementState(state);
                releaseMovementInputs();
                if (player != null) {
                    player.method_5728(false);
                }
                writeMovementResult(state, true, "success", "movement_stopped");
                yield true;
            }
            case "cap.movement.snapshot" -> {
                if (player == null || world == null) {
                    yield false;
                }
                writeMovementSnapshot(state, player, world);
                writeMovementResult(state, true, "success", "snapshot");
                yield true;
            }
            case "cap.movement.check_progress" -> {
                if (player == null) {
                    yield false;
                }
                MovementProgress progress = evaluateMovementProgress(state, player, doubleParam(resolvedParams, "target.distance", doubleState(state, "path.distance", Double.MAX_VALUE)));
                writeProgressState(state, progress);
                yield progress.ok();
            }
            case "cap.movement.check_safety" -> {
                if (player == null || world == null) {
                    yield false;
                }
                MovementSafety safety = movementSafetyAt(world, player.method_24515(), 3);
                writeSafetyState(state, safety);
                writeMovementResult(state, safety.safe(), safety.safe() ? "success" : "unsafe", safety.reason());
                yield safety.safe();
            }
            case "cap.movement.choose_recovery" -> {
                if (player == null || world == null) {
                    yield false;
                }
                String tactic = chooseRecoveryTactic(state, player, world);
                state.put("move.recovery.tactic", tactic);
                state.put("move.recovery.mode", tactic);
                AutomationReporter.info("[move]", "recovery selected: " + tactic);
                writeMovementResult(state, !"fail".equals(tactic), "needs_recovery", tactic);
                yield !"fail".equals(tactic);
            }
            case "cap.movement.run_recovery" -> {
                if (player == null || world == null) {
                    yield false;
                }
                String tactic = stringParam(resolvedParams, "recovery.tactic", stringParam(state, "move.recovery.tactic", "auto"));
                boolean recovered = runRecoveryTactic(state, player, world, tactic);
                writeMovementResult(state, recovered, recovered ? "running" : "failed", stringParam(state, "move.recovery.reason", tactic));
                yield recovered;
            }
            case "cap.path.resolve_target" -> {
                if (player == null || world == null) {
                    yield false;
                }
                boolean resolved = resolveMovementTarget(world, player, resolvedParams, state);
                if (!resolved && (hasResolvedParam(resolvedParams, "target.x") || hasResolvedParam(resolvedParams, "target.z"))) {
                    double x = hasResolvedParam(resolvedParams, "target.x") ? doubleParam(resolvedParams, "target.x", player.method_23317()) : doubleState(state, "current.target.x", player.method_23317());
                    double y = hasResolvedParam(resolvedParams, "target.y") ? doubleParam(resolvedParams, "target.y", player.method_23318()) : player.method_23318();
                    double z = hasResolvedParam(resolvedParams, "target.z") ? doubleParam(resolvedParams, "target.z", player.method_23321()) : doubleState(state, "current.target.z", player.method_23321());
                    state.put("current.target.kind", "location");
                    state.put("current.target.id", "coordinate");
                    state.put("current.target.x", x);
                    state.put("current.target.y", y);
                    state.put("current.target.z", z);
                    state.put("current.target.use_y", hasResolvedParam(resolvedParams, "target.y"));
                    state.put("movement.resolve.reason", "coordinate_forced_live");
                    writeMovementTargetDetails(state, "coordinate", new class_243(x, y, z), new class_243(x, y + player.method_18381(player.method_18376()), z), doubleParam(resolvedParams, "stop.distance", 1.0D), hasResolvedParam(resolvedParams, "target.y") ? 0.86D : 0.72D, 0.0D, "coordinate_forced_live");
                    resolved = true;
                }
                state.put("movement.resolve.params", resolvedParams.toString());
                AutomationReporter.mem("movement.resolve.params", resolvedParams);
                writeMovementResult(state, resolved, resolved ? "success" : "target_unreachable", stringParam(state, "movement.resolve.reason", "unresolved"));
                yield resolved;
            }
            case "cap.path.plan_local" -> {
                if (player == null || world == null || !hasTargetPosition(state)) {
                    yield false;
                }
                MovementPlan plan = planLocalMovement(world, player, new class_243(doubleState(state, "current.target.x", player.method_23317()), doubleState(state, "current.target.y", player.method_23318()), doubleState(state, "current.target.z", player.method_23321())), resolvedParams, state);
                writePlanState(state, plan);
                yield true;
            }
            case "cap.path.replan_local_segment" -> {
                if (player == null || world == null || !hasTargetPosition(state)) {
                    yield false;
                }
                incrementStateCounter(state, "move.replan.count");
                MovementPlan plan = planLocalMovement(world, player, new class_243(doubleState(state, "current.target.x", player.method_23317()), doubleState(state, "current.target.y", player.method_23318()), doubleState(state, "current.target.z", player.method_23321())), resolvedParams, state);
                writePlanState(state, plan);
                writeMovementResult(state, plan.ok(), plan.ok() ? "needs_replan" : "target_unreachable", plan.reason());
                yield plan.ok();
            }
            case "cap.path.verify_relative_arrival" -> {
                if (player == null) {
                    yield false;
                }
                boolean ok = verifyRelativeArrival(player, resolvedParams, state);
                yield ok;
            }
            case "cap.path.verify_target_arrival" -> {
                if (player == null) {
                    yield false;
                }
                boolean ok = verifyTargetArrival(player, resolvedParams, state);
                yield ok;
            }
            case "cap.path.move_to_target" -> {
                if (player == null || world == null) {
                    yield false;
                }
                class_243 target = resolveTargetVector(world, resolvedParams, state);
                if (target == null && resolveMovementTarget(world, player, resolvedParams, state)) {
                    target = new class_243(
                            doubleState(state, "current.target.x", player.method_23317()),
                            doubleState(state, "current.target.y", player.method_23318()),
                            doubleState(state, "current.target.z", player.method_23321())
                    );
                }
                if (target == null) {
                    writeMovementResult(state, false, "failed", stringParam(state, "movement.resolve.reason", "target_unresolved"));
                    yield false;
                }
                double stopDistance = navigationStopDistance(resolvedParams, state, 1.5D);
                boolean useY = Boolean.parseBoolean(stringParam(resolvedParams, "path.use_y", stringParam(state, "current.target.use_y", hasResolvedParam(resolvedParams, "target.y") ? "true" : "false")));
                if (hasResolvedParam(resolvedParams, "target.x") && hasResolvedParam(resolvedParams, "target.z")) {
                    state.put("current.target.kind", "location");
                    state.put("current.target.id", "coordinate");
                    state.put("current.target.x", target.field_1352);
                    state.put("current.target.y", target.field_1351);
                    state.put("current.target.z", target.field_1350);
                    state.put("current.target.use_y", useY);
                }
                MovementPlan plan = planLocalMovement(world, player, target, resolvedParams, state);
                beginPointNavigation(state, player, target, stopDistance, booleanParam(resolvedParams, "sprint", plan.sprint()), useY, resolvedParams);
                boolean precise = booleanParam(resolvedParams, "movement.precise", isCoordinateTarget(state, resolvedParams));
                state.put("move.target.precise", precise);
                state.put("move.target.precision_distance", doubleParam(resolvedParams, "movement.precision.distance", precise ? NAV_PRECISE_DIRECT_DISTANCE : NAV_PRECISE_SLOW_DISTANCE));
                state.put("move.target.slow_distance", doubleParam(resolvedParams, "movement.precision.slow_distance", NAV_PRECISE_SLOW_DISTANCE));
                writePlanState(state, plan);
                yield true;
            }
            case "cap.path.follow_target" -> {
                if (player == null || world == null) {
                    yield false;
                }
                class_1297 entity = resolveTargetEntity(world, resolvedParams, state);
                if (entity == null) {
                    yield false;
                }
                double stopDistance = doubleParam(resolvedParams, "stop.distance", 1.8D);
                beginFollowNavigation(state, player, entity, stopDistance, booleanParam(resolvedParams, "sprint", false), resolvedParams);
                yield true;
            }
            case "cap.parkour.analyze_jump" -> {
                if (player == null || world == null) {
                    yield false;
                }
                class_243 target = resolveTargetVector(world, resolvedParams, state);
                if (target == null) {
                    yield false;
                }
                ParkourAnalysis analysis = analyzeParkourJump(world, player, target, resolvedParams);
                writeParkourAnalysis(state, analysis);
                yield analysis.ok();
            }
            case "cap.parkour.execute_jump" -> {
                if (player == null || world == null) {
                    yield false;
                }
                class_243 target = resolveTargetVector(world, resolvedParams, state);
                if (target == null) {
                    yield false;
                }
                ParkourAnalysis analysis = analyzeParkourJump(world, player, target, resolvedParams);
                writeParkourAnalysis(state, analysis);
                if (!analysis.ok()) {
                    yield false;
                }
                class_243 landing = normalizeParkourLanding(world, target);
                class_243 takeoff = findParkourTakeoff(world, player, landing, analysis);
                if (takeoff == null) {
                    writeMovementResult(state, false, "failed", "no_parkour_takeoff");
                    yield false;
                }
                beginPointNavigation(state, player, landing, doubleParam(resolvedParams, "stop.distance", PARKOUR_LANDING_DISTANCE), analysis.sprint(), true, resolvedParams);
                state.put("move.target.mode", "parkour");
                state.put("parkour.active", true);
                state.put("parkour.phase", "approach_takeoff");
                state.put("parkour.takeoff.x", takeoff.field_1352);
                state.put("parkour.takeoff.y", takeoff.field_1351);
                state.put("parkour.takeoff.z", takeoff.field_1350);
                state.put("parkour.landing.x", landing.field_1352);
                state.put("parkour.landing.y", landing.field_1351);
                state.put("parkour.landing.z", landing.field_1350);
                state.put("parkour.sprint", analysis.sprint());
                state.put("parkour.charge_ticks", 0);
                state.put("parkour.air_ticks", 0);
                state.put("parkour.approach_ticks", 0);
                state.put("parkour.attempt", intState(state, "parkour.attempt", 0) + 1);
                writeStateValue(state, "parkour.takeoff", round(takeoff.field_1352) + "," + round(takeoff.field_1351) + "," + round(takeoff.field_1350));
                writeStateValue(state, "parkour.landing", round(landing.field_1352) + "," + round(landing.field_1351) + "," + round(landing.field_1350));
                writeMovementResult(state, true, "running", "parkour_jump_started");
                yield true;
            }
            case "cap.goal.execute_named" -> {
                if (player == null || world == null) {
                    yield false;
                }
                String goalName = normalizeGoalName(stringParam(resolvedParams, "goal.name", stringParam(resolvedParams, "target.name", "")));
                if (goalName.isBlank()) {
                    yield false;
                }
                state.put("goal.name", goalName);
                AutomationReporter.mem("goal.name", goalName);
                boolean goalStarted = executeNamedGoal(goalName, resolvedParams, state, client, player, world);
                state.put("result.action", goalStarted ? "STARTED" : "FAIL");
                AutomationReporter.mem("result.action", goalStarted ? "STARTED" : "FAIL");
                yield goalStarted;
            }
            case "cap.player.jump" -> {
                if (player == null) {
                    yield false;
                }
                player.method_6043();
                yield true;
            }
            case "cap.player.dismount" -> {
                if (player == null) {
                    yield false;
                }
                if (player.method_5765()) {
                    player.method_29239();
                }
                state.put("result.action", "SUCCESS");
                AutomationReporter.mem("result.action", "SUCCESS");
                yield true;
            }
            case "cap.player.crouch" -> {
                setHeldInput("sneak", true);
                yield true;
            }
            case "cap.player.uncrouch" -> {
                setHeldInput("sneak", false);
                yield true;
            }
            case "cap.player.sprint" -> {
                setHeldInput("sprint", true);
                yield true;
            }
            case "cap.player.unsprint" -> {
                setHeldInput("sprint", false);
                yield true;
            }

            case "cap.interaction.use_item" -> {
                if (player == null || interactionManager == null || world == null) {
                    yield false;
                }
                class_1268 hand = resolveHand(resolvedParams);
                class_1269 result = interactionManager.method_2919(player, hand);
                player.method_6104(hand);
                writeActionResult(state, "result.action", result);
                yield result != class_1269.field_5814;
            }
            case "cap.interaction.use_main_hand_item" -> {
                if (player == null || interactionManager == null || world == null) {
                    yield false;
                }
                class_1269 result = interactionManager.method_2919(player, class_1268.field_5808);
                player.method_6104(class_1268.field_5808);
                writeActionResult(state, "result.action", result);
                yield result != class_1269.field_5814;
            }
            case "cap.interaction.use_off_hand_item" -> {
                if (player == null || interactionManager == null || world == null) {
                    yield false;
                }
                class_1269 result = interactionManager.method_2919(player, class_1268.field_5810);
                player.method_6104(class_1268.field_5810);
                writeActionResult(state, "result.action", result);
                yield result != class_1269.field_5814;
            }
            case "cap.interaction.use_selected_item" -> {
                if (player == null || interactionManager == null || world == null) {
                    yield false;
                }
                class_1268 hand = resolveHand(resolvedParams);
                class_1269 result = interactionManager.method_2919(player, hand);
                player.method_6104(hand);
                writeActionResult(state, "result.action", result);
                yield result != class_1269.field_5814;
            }
            case "cap.interaction.use_item_on_block_target" -> {
                if (player == null || interactionManager == null || world == null) {
                    yield false;
                }
                class_3965 hitResult = resolveBlockHitResult(player, resolvedParams, state);
                if (hitResult == null) {
                    yield false;
                }
                class_1268 hand = resolveHand(resolvedParams);
                class_1269 result = interactionManager.method_2896(player, hand, hitResult);
                player.method_6104(hand);
                writeActionResult(state, "result.action", result);
                yield result != class_1269.field_5814;
            }
            case "cap.interaction.use_item_on_current_block" -> {
                if (player == null || interactionManager == null || world == null) {
                    yield false;
                }
                if (!hasTargetPosition(state)) {
                    yield false;
                }
                class_3965 hitResult = createCenterHit(player, targetBlockPos(state));
                class_1268 hand = resolveHand(resolvedParams);
                class_1269 result = interactionManager.method_2896(player, hand, hitResult);
                player.method_6104(hand);
                writeActionResult(state, "result.action", result);
                yield result != class_1269.field_5814;
            }
            case "cap.interaction.interact_entity_target" -> {
                if (player == null || interactionManager == null || world == null) {
                    yield false;
                }
                class_1297 entity = resolveTargetEntity(world, resolvedParams, state);
                if (entity == null) {
                    yield false;
                }
                class_1268 hand = resolveHand(resolvedParams);
                class_1269 result = interactionManager.method_2905(player, entity, hand);
                player.method_6104(hand);
                writeActionResult(state, "result.action", result);
                yield result != class_1269.field_5814;
            }
            case "cap.interaction.interact_target" -> {
                if (player == null || interactionManager == null || world == null) {
                    yield false;
                }
                String targetKind = stringParam(state, "current.target.kind", stringParam(resolvedParams, "target.kind", ""));
                class_1268 hand = resolveHand(resolvedParams);
                if ("block".equalsIgnoreCase(targetKind) && hasTargetPosition(state)) {
                    class_3965 hitResult = resolveBlockHitResult(player, resolvedParams, state);
                    if (hitResult == null) {
                        yield false;
                    }
                    class_1269 result = interactionManager.method_2896(player, hand, hitResult);
                    player.method_6104(hand);
                    writeActionResult(state, "result.action", result);
                    yield result != class_1269.field_5814;
                }
                class_1297 entity = resolveTargetEntity(world, resolvedParams, state);
                if (entity == null) {
                    yield false;
                }
                class_1269 result = interactionManager.method_2905(player, entity, hand);
                player.method_6104(hand);
                writeActionResult(state, "result.action", result);
                yield result != class_1269.field_5814;
            }
            case "cap.interaction.use_item_on_entity_target" -> {
                if (player == null || interactionManager == null || world == null) {
                    yield false;
                }
                class_1297 entity = resolveTargetEntity(world, resolvedParams, state);
                if (entity == null) {
                    yield false;
                }
                class_1268 hand = resolveHand(resolvedParams);
                class_1269 result = interactionManager.method_2905(player, entity, hand);
                player.method_6104(hand);
                writeActionResult(state, "result.action", result);
                yield result != class_1269.field_5814;
            }
            case "cap.interaction.open_target" -> {
                if (player == null || interactionManager == null || world == null) {
                    yield false;
                }
                if (!hasTargetPosition(state)) {
                    yield false;
                }
                class_2338 pos = targetBlockPos(state);
                class_3965 hitResult = createCenterHit(player, pos);
                class_1268 hand = resolveHand(resolvedParams);
                class_1269 result = interactionManager.method_2896(player, hand, hitResult);
                player.method_6104(hand);
                writeActionResult(state, "result.action", result);
                yield result != class_1269.field_5814;
            }
            case "cap.interaction.close_screen" -> {
                if (player == null) {
                    yield false;
                }
                player.method_7346();
                yield true;
            }
            case "cap.interaction.attack_target" -> {
                if (player == null || interactionManager == null || world == null) {
                    yield false;
                }
                class_1297 entity = resolveTargetEntity(world, resolvedParams, state);
                if (entity == null) {
                    yield false;
                }
                interactionManager.method_2918(player, entity);
                player.method_6104(class_1268.field_5808);
                state.put("result.action", "SUCCESS");
                AutomationReporter.mem("result.action", "SUCCESS");
                yield true;
            }
            case "cap.interaction.break_block_target" -> {
                if (player == null || interactionManager == null || world == null) {
                    yield false;
                }
                class_2338 pos = resolveTargetBlockPos(resolvedParams, state);
                if (pos == null) {
                    yield false;
                }
                String expectedId = stringParam(resolvedParams, "target.id", stringParam(state, "current.target.id", ""));
                state.put("mine.active", true);
                state.put("mine.target.x", pos.method_10263());
                state.put("mine.target.y", pos.method_10264());
                state.put("mine.target.z", pos.method_10260());
                state.put("mine.target.id", expectedId);
                state.put("mine.ticks", 0);
                state.put("mine.started", false);
                state.put("mine.failure_reason", "");
                state.put("result.action", "STARTED");
                AutomationReporter.mem("mine.active", true);
                AutomationReporter.mem("mine.target.x", pos.method_10263());
                AutomationReporter.mem("mine.target.y", pos.method_10264());
                AutomationReporter.mem("mine.target.z", pos.method_10260());
                AutomationReporter.mem("mine.target.id", expectedId);
                AutomationReporter.mem("result.action", "STARTED");
                yield true;
            }
            case "cap.interaction.stop_using_item" -> {
                if (player == null) {
                    yield false;
                }
                player.method_6075();
                state.put("result.action", "SUCCESS");
                AutomationReporter.mem("result.action", "SUCCESS");
                yield true;
            }

            case "cap.combat.attack_target", "cap.combat.attack_until_dead" -> {
                if (player == null || world == null || interactionManager == null) {
                    yield false;
                }
                class_1297 entity = resolveTargetEntity(world, resolvedParams, state);
                if (entity == null) {
                    yield false;
                }
                double distance = player.method_19538().method_1022(entity.method_19538());
                double maxDistance = doubleParam(resolvedParams, "attack.range", 3.4D);
                if (distance > maxDistance) {
                    state.put("attack.failed", true);
                    state.put("attack.failure_reason", "target_out_of_range");
                    yield true;
                }
                state.put("attack.active", true);
                state.put("attack.target.uuid", entity.method_5845());
                state.put("attack.phase", "prepare");
                state.put("attack.ticks", 0);
                state.put("attack.crit.enabled", Boolean.parseBoolean(stringParam(resolvedParams, "crit.enabled", "true")));
                state.put("attack.crit.jump_wait_ticks", intParam(resolvedParams, "crit.jump_wait_ticks", 3));
                state.put("attack.range", maxDistance);
                state.put("attack.until_dead", "cap.combat.attack_until_dead".equals(action));
                AutomationReporter.mem("attack.active", true);
                AutomationReporter.mem("attack.phase", "prepare");
                yield true;
            }
            case "cap.interaction.consume_selected_item" -> {
                if (player == null || world == null || interactionManager == null) {
                    yield false;
                }
                class_1799 stack = player.method_6047();
                if (stack.method_7960()) {
                    yield false;
                }
                String requiredItemId = stringParam(resolvedParams, "item.id", "");
                if (!requiredItemId.isBlank() && !itemMatches(stack, requiredItemId)) {
                    yield false;
                }
                if (!stack.method_19267()) {
                    yield false;
                }
                if (player.method_7337()) {
                    state.put(stringParam(resolvedParams, "result.key", "result.consumed"), 1);
                    state.put("result.action", "SUCCESS");
                    AutomationReporter.mem(stringParam(resolvedParams, "result.key", "result.consumed"), 1);
                    AutomationReporter.mem("result.action", "SUCCESS");
                    yield true;
                }
                int beforeCount = stack.method_7947();
                int beforeHunger = player.method_7344().method_7586();
                float beforeSaturation = player.method_7344().method_7589();

                class_1269 result = interactionManager.method_2919(player, class_1268.field_5808);
                if (result == class_1269.field_5814) {
                    yield false;
                }

                state.put("consume.active", true);
                state.put("consume.item.id", requiredItemId.isBlank() ? String.valueOf(class_7923.field_41178.method_10221(stack.method_7909())) : requiredItemId);
                state.put("consume.before_count", beforeCount);
                state.put("consume.before_total_count", countInventory(player.method_31548(), requiredItemId.isBlank() ? String.valueOf(class_7923.field_41178.method_10221(stack.method_7909())) : requiredItemId));
                state.put("consume.before_hunger", beforeHunger);
                state.put("consume.before_saturation", beforeSaturation);
                state.put("consume.result.key", stringParam(resolvedParams, "result.key", "result.consumed"));
                state.put("consume.started", player.method_6115());
                state.put("consume.ticks", 0);
                state.put("consume.max_ticks", Math.max(40, stack.method_7935() + 20));
                state.put("consume.failure_reason", "");
                state.put("consume.hold_use", true);
                setHeldInput("use", true);

                AutomationReporter.mem("consume.active", true);
                AutomationReporter.mem("consume.item.id", state.get("consume.item.id"));
                AutomationReporter.mem("consume.before_count", beforeCount);
                yield true;
            }
            case "cap.combat.confirm_target_death" -> {
                if (player == null || world == null) {
                    yield false;
                }
                String uuid = stringParam(state, "current.target.uuid", stringParam(state, "attack.target.uuid", ""));
                class_1297 entity = findEntityByUuid(world, uuid);
                boolean dead = entity == null || !entity.method_5805();
                String resultKey = stringParam(resolvedParams, "result.key", "result.dead");
                state.put(resultKey, dead);
                AutomationReporter.mem(resultKey, dead);
                yield true;
            }
            case "cap.wait.ticks" -> {
                int ticks = Math.max(0, intParam(resolvedParams, "count.value", 0));
                state.put("wait.ticks", ticks);
                AutomationReporter.mem("wait.ticks", ticks);
                yield true;
            }
            default -> false;
        };
        return new PrimitiveRunResult(success, resolvedParams);
    }

    private class_1268 resolveHand(Map<String, Object> params) {
        String handId = stringParam(params, "hand.id", "main").toLowerCase(Locale.ROOT);
        return switch (handId) {
            case "off", "off_hand", "offhand", "secondary" -> class_1268.field_5810;
            default -> class_1268.field_5808;
        };
    }

    private void writeActionResult(Map<String, Object> state, String key, class_1269 result) {
        String value = result == null ? "FAIL" : result.name();
        state.put(key, value);
        AutomationReporter.mem(key, value);
    }

    private class_1297 resolveTargetEntity(class_1937 world, Map<String, Object> params, Map<String, Object> state) {
        String requestedKind = stringParam(params, "target.kind", stringParam(state, "current.target.kind", "")).toLowerCase(Locale.ROOT);
        if ("block".equals(requestedKind) || "location".equals(requestedKind)) {
            return null;
        }
        String explicitUuid = stringParam(params, "target.uuid", "");
        if (!explicitUuid.isBlank()) {
            class_1297 entity = findEntityByUuid(world, explicitUuid);
            if (entity != null) {
                return entity;
            }
        }

        String stateUuid = stringParam(state, "current.target.uuid", "");
        if (!stateUuid.isBlank()) {
            class_1297 entity = findEntityByUuid(world, stateUuid);
            if (entity != null) {
                return entity;
            }
        }

        class_310 client = class_310.method_1551();
        class_746 player = client == null ? null : client.field_1724;
        if (player == null) {
            return null;
        }

        String targetId = stringParam(params, "target.id", stringParam(state, "current.target.id", ""));
        double radius = doubleParam(params, "radius", 6.0D);
        if (!targetId.isBlank()) {
            return findEntityBySelector(player, targetId, radius, stringParam(params, "target.selector", "nearest"));
        }

        return null;
    }

    private boolean resolveMovementTarget(class_638 world, class_746 player, Map<String, Object> params, Map<String, Object> state) {
        String targetKind = stringParam(params, "target.kind", stringParam(state, "current.target.kind", "")).toLowerCase(Locale.ROOT);
        boolean coordinateParams = hasResolvedParam(params, "target.x") || hasResolvedParam(params, "target.z");
        if (coordinateParams && (targetKind.isBlank() || "block".equals(targetKind) || "item".equals(targetKind))) {
            targetKind = "location";
        }
        String targetId = "location".equals(targetKind) ? "" : stringParam(params, "target.id", "");
        boolean allowStatePosition = targetId.isBlank() || "location".equals(targetKind) || state.containsKey("current.target.x") && state.containsKey("current.target.z");
        boolean hasX = hasResolvedParam(params, "target.x") || state.containsKey("current.target.x");
        boolean hasZ = hasResolvedParam(params, "target.z") || state.containsKey("current.target.z");
        if (hasX && hasZ) {
            double x = hasResolvedParam(params, "target.x") ? doubleParam(params, "target.x", player.method_23317()) : doubleState(state, "current.target.x", player.method_23317());
            double z = hasResolvedParam(params, "target.z") ? doubleParam(params, "target.z", player.method_23321()) : doubleState(state, "current.target.z", player.method_23321());
            boolean explicitY = hasResolvedParam(params, "target.y");
            boolean hasY = explicitY || state.containsKey("current.target.y");
            double y = hasY ? (explicitY ? doubleParam(params, "target.y", player.method_23318()) : doubleState(state, "current.target.y", player.method_23318())) : player.method_23318();
            class_243 resolved = null;
            String reason = "coordinate_resolved";
            if (explicitY) {
                class_2338 feet = class_2338.method_49637(x, y, z);
                if (canStandAt(world, feet)) {
                    resolved = new class_243(x, y, z);
                } else {
                    resolved = resolveStandablePositionNearY(world, player, x, y, z, booleanParam(params, "movement.allow_swim", false));
                    reason = resolved == null ? "coordinate_explicit_y_unverified" : "coordinate_near_y_resolved";
                }
            } else {
                resolved = resolveStandablePosition(world, player, x, z, booleanParam(params, "movement.allow_swim", false));
                reason = resolved == null ? "coordinate_xz_unverified" : "coordinate_resolved";
            }
            if (resolved == null) {
                resolved = new class_243(x, y, z);
            }
            state.put("current.target.kind", targetKind.isBlank() ? "location" : targetKind);
            state.put("current.target.id", targetId.isBlank() ? "coordinate" : targetId);
            state.put("current.target.x", resolved.field_1352);
            state.put("current.target.y", resolved.field_1351);
            state.put("current.target.z", resolved.field_1350);
            state.put("current.target.use_y", hasY);
            state.put("movement.resolve.reason", reason);
            writeMovementTargetDetails(state, "coordinate", resolved, resolved.method_1031(0.0D, player.method_18381(player.method_18376()), 0.0D), doubleParam(params, "stop.distance", 1.0D), hasY ? 0.86D : 0.72D, pocketRisk(world, class_2338.method_49638(resolved)), reason);
            return true;
        }

        class_1297 entity = resolveTargetEntity(world, params, state);
        if (entity != null) {
            writeEntityState(state, entity, stringParam(params, "target.id", stringParam(state, "current.target.id", entity.method_5845())));
            writeMovementTargetDetails(state, "entity", entity.method_19538(), entity.method_33571(), doubleParam(params, "stop.distance", 1.8D), 0.95D, 0.0D, "entity_resolved");
            return true;
        }

        class_2338 blockPos = resolveTargetBlockPos(params, state);
        if (targetId.isBlank()) {
            targetId = stringParam(state, "current.target.id", "");
        }
        if (blockPos == null && "block".equals(targetKind) && !targetId.isBlank()) {
            blockPos = findNearestBlock(player, targetId, Math.max(6, intParam(params, "radius", 32)));
            if (blockPos != null) {
                state.put("current.target.id", targetId);
            }
        }
        if (blockPos != null) {
            class_243 approach = resolveApproachPosition(world, player, blockPos, booleanParam(params, "movement.allow_swim", false));
            if (approach == null) {
                state.put("movement.resolve.reason", "no_block_approach");
                return false;
            }
            state.put("current.target.kind", "block");
            state.put("current.target.x", approach.field_1352);
            state.put("current.target.y", approach.field_1351);
            state.put("current.target.z", approach.field_1350);
            writeMovementTargetDetails(state, "block", approach, class_243.method_24953(blockPos), doubleParam(params, "stop.distance", 2.2D), 0.82D, pocketRisk(world, class_2338.method_49638(approach)), "block_approach_resolved");
            return true;
        }

        state.put("movement.resolve.reason", "missing_target");
        return false;
    }

    private class_2338 resolveTargetBlockPos(Map<String, Object> params, Map<String, Object> state) {
        if (hasResolvedParam(params, "target.x") && hasResolvedParam(params, "target.y") && hasResolvedParam(params, "target.z")) {
            return new class_2338(
                    (int) Math.floor(doubleParam(params, "target.x", 0.0D)),
                    (int) Math.floor(doubleParam(params, "target.y", 0.0D)),
                    (int) Math.floor(doubleParam(params, "target.z", 0.0D))
            );
        }
        if (hasTargetPosition(state)) {
            String requestedId = stringParam(params, "target.id", "");
            String currentId = stringParam(state, "current.target.id", "");
            if (requestedId.isBlank() || requestedId.equals(currentId)) {
                return targetBlockPos(state);
            }
        }
        return null;
    }

    private class_243 resolveTargetVector(class_1937 world, Map<String, Object> params, Map<String, Object> state) {
        class_1297 entity = resolveTargetEntity(world, params, state);
        if (entity != null) {
            return entity.method_19538();
        }
        class_310 client = class_310.method_1551();
        class_746 player = client == null ? null : client.field_1724;
        if (player != null && world instanceof class_638 clientWorld && (hasResolvedParam(params, "target.x") || hasResolvedParam(params, "target.z")) && !hasResolvedParam(params, "target.y")) {
            double x = doubleParam(params, "target.x", doubleState(state, "current.target.x", player.method_23317()));
            double z = doubleParam(params, "target.z", doubleState(state, "current.target.z", player.method_23321()));
            class_243 standable = resolveStandablePosition(clientWorld, player, x, z, booleanParam(params, "movement.allow_swim", false));
            if (standable != null) {
                state.put("current.target.x", standable.field_1352);
                state.put("current.target.y", standable.field_1351);
                state.put("current.target.z", standable.field_1350);
                state.put("current.target.use_y", false);
                return standable;
            }
            state.put("current.target.x", x);
            state.put("current.target.y", player.method_23318());
            state.put("current.target.z", z);
            state.put("current.target.use_y", false);
            return new class_243(x, player.method_23318(), z);
        }
        String targetKind = stringParam(params, "target.kind", stringParam(params, "target.type", stringParam(state, "current.target.kind", ""))).toLowerCase(Locale.ROOT);
        if ((hasResolvedParam(params, "target.x") || state.containsKey("current.target.x"))
                && (hasResolvedParam(params, "target.y") || state.containsKey("current.target.y"))
                && (hasResolvedParam(params, "target.z") || state.containsKey("current.target.z"))
                && (targetKind.equals("location") || targetKind.equals("coordinate") || targetKind.equals("landing") || targetKind.equals("parkour"))) {
            double x = hasResolvedParam(params, "target.x") ? doubleParam(params, "target.x", doubleState(state, "current.target.x", 0.0D)) : doubleState(state, "current.target.x", 0.0D);
            double y = hasResolvedParam(params, "target.y") ? doubleParam(params, "target.y", doubleState(state, "current.target.y", 0.0D)) : doubleState(state, "current.target.y", 0.0D);
            double z = hasResolvedParam(params, "target.z") ? doubleParam(params, "target.z", doubleState(state, "current.target.z", 0.0D)) : doubleState(state, "current.target.z", 0.0D);
            return new class_243(x, y, z);
        }

        class_2338 pos = resolveTargetBlockPos(params, state);
        if (pos != null) {
            if (world instanceof class_638 clientWorld && player != null) {
                class_243 approach = resolveApproachPosition(clientWorld, player, pos, booleanParam(params, "movement.allow_swim", false));
                return approach == null ? class_243.method_24953(pos) : approach;
            }
            return class_243.method_24953(pos);
        }
        return null;
    }

    private boolean verifyTargetArrival(class_746 player, Map<String, Object> params, Map<String, Object> state) {
        class_243 target = new class_243(
                doubleState(state, "current.target.x", doubleState(state, "move.target.x", player.method_23317())),
                doubleState(state, "current.target.y", doubleState(state, "move.target.y", player.method_23318())),
                doubleState(state, "current.target.z", doubleState(state, "move.target.z", player.method_23321()))
        );
        boolean useY = Boolean.parseBoolean(stringParam(state, "current.target.use_y", stringParam(state, "move.target.use_y", "false")));
        double stopDistance = doubleParam(params, "stop.distance", doubleState(state, "path.stop_distance", useY ? 1.0D : NAV_PRECISE_STOP_DISTANCE));
        double distance = navigationDistance(player.method_19538(), target, useY);
        writeStateValue(state, "move.verify.distance", round(distance));
        AutomationCliViewModel.runtimeFlow("", "verify_target_arrival", "move.verify.target", "flow_metric", "[debug]", "move.verify.target", round(target.field_1352) + "," + round(target.field_1351) + "," + round(target.field_1350));
        AutomationCliViewModel.runtimeFlow("", "verify_target_arrival", "move.verify.pos", "flow_metric", "[debug]", "move.verify.pos", round(player.method_23317()) + "," + round(player.method_23318()) + "," + round(player.method_23321()));
        AutomationCliViewModel.runtimeFlow("", "verify_target_arrival", "move.verify.distance", "flow_metric", "[debug]", "move.verify.distance", round(distance));
        if (distance > Math.max(stopDistance, useY ? 1.0D : NAV_PRECISE_STOP_DISTANCE)) {
            writeMovementResult(state, false, "failed", "target_not_reached");
            return false;
        }
        writeMovementResult(state, true, "success", "target_arrival_verified");
        return true;
    }

    private class_3965 resolveBlockHitResult(class_746 player, Map<String, Object> params, Map<String, Object> state) {
        class_2338 pos = resolveTargetBlockPos(params, state);
        if (pos == null) {
            return null;
        }

        class_2350 side = resolveBlockSide(params);
        boolean insideBlock = false;
        double hitX = params.containsKey("hit.x") ? doubleParam(params, "hit.x", pos.method_10263() + 0.5D) : pos.method_10263() + 0.5D;
        double hitY = params.containsKey("hit.y") ? doubleParam(params, "hit.y", pos.method_10264() + 0.5D) : pos.method_10264() + 0.5D;
        double hitZ = params.containsKey("hit.z") ? doubleParam(params, "hit.z", pos.method_10260() + 0.5D) : pos.method_10260() + 0.5D;
        return new class_3965(new class_243(hitX, hitY, hitZ), side, pos, insideBlock);
    }

    private class_2350 resolveBlockSide(Map<String, Object> params) {
        String sideId = stringParam(params, "target.face", "up").toLowerCase(Locale.ROOT);
        return switch (sideId) {
            case "down", "bottom" -> class_2350.field_11033;
            case "north", "front" -> class_2350.field_11043;
            case "south", "back" -> class_2350.field_11035;
            case "west", "left" -> class_2350.field_11039;
            case "east", "right" -> class_2350.field_11034;
            default -> class_2350.field_11036;
        };
    }

    private boolean evaluateCondition(String condition, Map<String, Object> state) {
        class_310 client = class_310.method_1551();
        class_746 player = client == null ? null : client.field_1724;
        class_638 world = client == null ? null : client.field_1687;

        return switch (condition) {
            case "cond.self_health_below" -> {
                if (player == null) {
                    yield false;
                }
                float threshold = (float) doubleState(state, "condition.threshold", 0.0D);
                yield player.method_6032() < threshold;
            }
            case "cond.self_health_above" -> {
                if (player == null) {
                    yield false;
                }
                float threshold = (float) doubleState(state, "condition.threshold", 0.0D);
                yield player.method_6032() > threshold;
            }
            case "cond.target_exists", "eval.target_exists" -> {
                if (world == null) {
                    yield false;
                }
                String uuid = stringParam(state, "current.target.uuid", "");
                if (!uuid.isBlank()) {
                    class_1297 entity = findEntityByUuid(world, uuid);
                    yield entity != null && entity.method_5805();
                }
                if (hasTargetPosition(state)) {
                    class_2338 pos = targetBlockPos(state);
                    yield !world.method_22347(pos);
                }
                yield false;
            }
            case "eval.inventory_count_compare" -> {
                if (player == null) {
                    yield false;
                }
                String itemId = stringParam(state, "item.id", "");
                if (itemId.isBlank()) {
                    yield false;
                }
                int count = countInventory(player.method_31548(), itemId);
                int threshold = intState(state, "condition.threshold", 0);
                String op = stringParam(state, "condition.op", "gte");
                yield compareNumbers(count, threshold, op);
            }
            case "counter_lt_target" -> {
                int current = intState(state, "state.counter", 0);
                int target = intState(state, "count.value", 0);
                yield current < target;
            }
            case "eval.compare_numbers" -> {
                double left = numberFromStateOrLiteral(state, "condition.left", 0.0D);
                double right = numberFromStateOrLiteral(state, "condition.right", 0.0D);
                String op = stringParam(state, "condition.op", "eq");
                yield compareNumbers(left, right, op);
            }
            case "eval.compare_stat" -> {
                if (player == null) {
                    yield false;
                }
                String statRef = stringParam(state, "stat.ref", "");
                Object rawValue = readStatValue(player, statRef);
                if (!(rawValue instanceof Number number)) {
                    yield false;
                }
                double left = number.doubleValue();
                double right = numberFromStateOrLiteral(state, "condition.right", doubleState(state, "condition.threshold", 0.0D));
                String op = stringParam(state, "condition.op", "eq");
                yield compareNumbers(left, right, op);
            }
            case "eval.time_of_day_compare" -> {
                if (world == null) {
                    yield false;
                }
                long timeOfDay = world.method_8532() % 24000L;
                String mode = stringParam(state, "condition.mode", "day");
                yield switch (mode) {
                    case "night" -> timeOfDay >= 13000L && timeOfDay < 23000L;
                    case "sunrise" -> timeOfDay >= 0L && timeOfDay < 1000L;
                    case "sunset" -> timeOfDay >= 12000L && timeOfDay < 13000L;
                    default -> timeOfDay < 13000L;
                };
            }
            case "eval.block_matches" -> {
                if (world == null || !hasTargetPosition(state)) {
                    yield false;
                }
                String expectedId = stringParam(state, "target.id", stringParam(state, "condition.expected.block.id", ""));
                if (expectedId.isBlank()) {
                    yield false;
                }
                class_2338 pos = targetBlockPos(state);
                class_2960 foundId = class_7923.field_41175.method_10221(world.method_8320(pos).method_26204());
                yield foundId != null && expectedId.equals(foundId.toString());
            }
            case "eval.automation_task_running", "cond.automation_task_running" -> AutomationRuntimeStatus.isTaskRunning();
            default -> false;
        };
    }

    private void setHeldInput(String keyId, boolean pressed) {
        HeldInput input = this.heldInputs.computeIfAbsent(normalizeInputKey(keyId), ignored -> new HeldInput());
        input.pressed = pressed;
        input.tapTicks = 0;
    }

    private void tapInput(String keyId, int ticks) {
        HeldInput input = this.heldInputs.computeIfAbsent(normalizeInputKey(keyId), ignored -> new HeldInput());
        input.pressed = true;
        input.tapTicks = ticks;
    }

    private void performImmediateTapAction(String keyId, class_310 client, class_746 player) {
        if (client == null || player == null) {
            return;
        }
        switch (normalizeInputKey(keyId)) {
            case "inventory", "e" -> {
                if (client.field_1755 == null) {
                    client.method_1507(new class_490(player));
                } else {
                    player.method_7346();
                }
            }
            case "swap_hands", "swap", "f" -> {
                if (player.field_3944 != null) {
                    player.field_3944.method_2883(new class_2846(class_2846.class_2847.field_12969, class_2338.field_10980, class_2350.field_11033));
                }
            }
            case "drop", "q" -> player.method_7290(false);
            case "perspective", "third_person", "camera" -> {
                class_5498 current = client.field_1690.method_31044();
                client.field_1690.method_31043(current.method_31036());
            }
            default -> {
            }
        }
    }

    private void queueMouseDelta(float yawDelta, float pitchDelta) {
        HeldInput mouse = this.heldInputs.computeIfAbsent("__mouse__", ignored -> new HeldInput());
        mouse.yawDelta += yawDelta;
        mouse.pitchDelta += pitchDelta;
    }

    private void updateHeldInputs() {
        class_310 client = class_310.method_1551();
        if (client == null || client.field_1690 == null) {
            return;
        }

        applyKeyState(resolveKeyBinding(client, "forward"), isInputPressed("forward"));
        applyKeyState(resolveKeyBinding(client, "back"), isInputPressed("back"));
        applyKeyState(resolveKeyBinding(client, "left"), isInputPressed("left"));
        applyKeyState(resolveKeyBinding(client, "right"), isInputPressed("right"));
        applyKeyState(resolveKeyBinding(client, "jump"), isInputPressed("jump"));
        applyKeyState(resolveKeyBinding(client, "sneak"), isInputPressed("sneak"));
        applyKeyState(resolveKeyBinding(client, "sprint"), isInputPressed("sprint"));
        applyKeyState(resolveKeyBinding(client, "attack"), isInputPressed("attack"));
        applyKeyState(resolveKeyBinding(client, "use"), isInputPressed("use"));
        applyKeyState(resolveKeyBinding(client, "inventory"), isInputPressed("inventory"));
        applyKeyState(resolveKeyBinding(client, "swap_hands"), isInputPressed("swap_hands"));
        applyKeyState(resolveKeyBinding(client, "drop"), isInputPressed("drop"));
        applyKeyState(resolveKeyBinding(client, "pick_block"), isInputPressed("pick_block"));
        applyKeyState(resolveKeyBinding(client, "perspective"), isInputPressed("perspective"));
        applyPlayerInputState(client.field_1724);
    }

    private void applyPlayerInputState(class_746 player) {
        if (player == null || player.field_3913 == null) {
            return;
        }
        boolean forward = isInputPressed("forward");
        boolean back = isInputPressed("back");
        boolean left = isInputPressed("left");
        boolean right = isInputPressed("right");
        boolean jump = isInputPressed("jump");
        boolean sneak = isInputPressed("sneak");
        player.field_3913.field_3910 = forward;
        player.field_3913.field_3909 = back;
        player.field_3913.field_3908 = left;
        player.field_3913.field_3906 = right;
        player.field_3913.field_3904 = jump;
        player.field_3913.field_3903 = sneak;
        player.field_3913.field_3905 = forward == back ? 0.0F : forward ? 1.0F : -1.0F;
        player.field_3913.field_3907 = left == right ? 0.0F : left ? 1.0F : -1.0F;
    }

    private void updateTapInputs() {
        for (Map.Entry<String, HeldInput> entry : this.heldInputs.entrySet()) {
            HeldInput input = entry.getValue();
            if (input.tapTicks > 0) {
                input.tapTicks--;
                if (input.tapTicks == 0) {
                    input.pressed = false;
                }
            }
        }
    }

    private void updateMouseLook(class_746 player) {
        if (player == null) {
            return;
        }
        HeldInput mouse = this.heldInputs.get("__mouse__");
        if (mouse == null) {
            return;
        }
        if (Math.abs(mouse.yawDelta) > LOOK_SNAP_EPSILON) {
            float applied = class_3532.method_15363(mouse.yawDelta, -LOOK_MAX_YAW_STEP, LOOK_MAX_YAW_STEP);
            player.method_36456(player.method_36454() + applied);
            mouse.yawDelta -= applied;
        } else {
            mouse.yawDelta = 0.0F;
        }
        if (Math.abs(mouse.pitchDelta) > LOOK_SNAP_EPSILON) {
            float applied = class_3532.method_15363(mouse.pitchDelta, -LOOK_MAX_PITCH_STEP, LOOK_MAX_PITCH_STEP);
            player.method_36457(class_3532.method_15363(player.method_36455() + applied, -90.0F, 90.0F));
            mouse.pitchDelta -= applied;
        } else {
            mouse.pitchDelta = 0.0F;
        }
    }

    private boolean isInputPressed(String keyId) {
        HeldInput input = this.heldInputs.get(normalizeInputKey(keyId));
        return input != null && input.pressed;
    }

    private void applyKeyState(class_304 keyBinding, boolean pressed) {
        if (keyBinding != null) {
            keyBinding.method_23481(pressed);
        }
    }

    private class_304 resolveKeyBinding(class_310 client, String keyId) {
        return switch (normalizeInputKey(keyId)) {
            case "forward", "straight", "w" -> client.field_1690.field_1894;
            case "back", "backward", "s" -> client.field_1690.field_1881;
            case "left", "a" -> client.field_1690.field_1913;
            case "right", "d" -> client.field_1690.field_1849;
            case "jump", "space" -> client.field_1690.field_1903;
            case "sneak", "shift", "crouch" -> client.field_1690.field_1832;
            case "sprint", "ctrl" -> client.field_1690.field_1867;
            case "attack", "left_click", "leftclick" -> client.field_1690.field_1886;
            case "use", "right_click", "rightclick" -> client.field_1690.field_1904;
            case "swap_hands", "swap", "f" -> client.field_1690.field_1831;
            case "drop", "q" -> client.field_1690.field_1869;
            case "pick_block", "pick", "middle_click" -> client.field_1690.field_1871;
            case "perspective", "third_person", "camera" -> client.field_1690.field_1824;
            case "inventory", "e" -> client.field_1690.field_1822;
            default -> null;
        };
    }

    private String normalizeInputKey(String keyId) {
        return keyId == null ? "" : keyId.toLowerCase(Locale.ROOT).trim();
    }

    private boolean isGameplayInput(String keyId) {
        return switch (normalizeInputKey(keyId)) {
            case "forward", "straight", "w", "back", "backward", "s", "left", "a", "right", "d",
                 "jump", "space", "sneak", "shift", "crouch", "sprint", "ctrl",
                 "attack", "left_click", "leftclick", "use", "right_click", "rightclick" -> true;
            default -> false;
        };
    }

    private void releaseAllInputs() {
        for (HeldInput input : this.heldInputs.values()) {
            input.pressed = false;
            input.tapTicks = 0;
        }
        class_310 client = class_310.method_1551();
        if (client != null) {
            applyKeyState(resolveKeyBinding(client, "forward"), false);
            applyKeyState(resolveKeyBinding(client, "back"), false);
            applyKeyState(resolveKeyBinding(client, "left"), false);
            applyKeyState(resolveKeyBinding(client, "right"), false);
            applyKeyState(resolveKeyBinding(client, "jump"), false);
            applyKeyState(resolveKeyBinding(client, "sneak"), false);
            applyKeyState(resolveKeyBinding(client, "sprint"), false);
            applyKeyState(resolveKeyBinding(client, "attack"), false);
            applyKeyState(resolveKeyBinding(client, "use"), false);
            applyKeyState(resolveKeyBinding(client, "inventory"), false);
            applyKeyState(resolveKeyBinding(client, "swap_hands"), false);
            applyKeyState(resolveKeyBinding(client, "drop"), false);
            applyKeyState(resolveKeyBinding(client, "pick_block"), false);
            applyKeyState(resolveKeyBinding(client, "perspective"), false);
            applyPlayerInputState(client.field_1724);
        }
    }

    private void releaseMovementInputs() {
        setHeldInput("forward", false);
        setHeldInput("back", false);
        setHeldInput("left", false);
        setHeldInput("right", false);
        setHeldInput("jump", false);
        setHeldInput("sprint", false);
        setHeldInput("sneak", false);
        class_310 client = class_310.method_1551();
        if (client != null) {
            applyKeyState(resolveKeyBinding(client, "forward"), false);
            applyKeyState(resolveKeyBinding(client, "back"), false);
            applyKeyState(resolveKeyBinding(client, "left"), false);
            applyKeyState(resolveKeyBinding(client, "right"), false);
            applyKeyState(resolveKeyBinding(client, "jump"), false);
            applyKeyState(resolveKeyBinding(client, "sprint"), false);
            applyKeyState(resolveKeyBinding(client, "sneak"), false);
            applyPlayerInputState(client.field_1724);
        }
    }

    private void beginRelativeMovement(Map<String, Object> state, class_746 player, String direction, int ticks, boolean sprint) {
        clearMovementState(state);
        state.put("move.relative.active", true);
        state.put("move.relative.direction", direction);
        state.put("move.relative.ticks", ticks);
        state.put("move.relative.start_x", player == null ? 0.0D : player.method_23317());
        state.put("move.relative.start_z", player == null ? 0.0D : player.method_23321());
        state.put("move.relative.sprint", sprint);
        AutomationReporter.mem("move.relative.active", true);
        AutomationReporter.mem("move.relative.direction", direction);
        AutomationReporter.mem("move.relative.ticks", ticks);
    }

    private void beginTargetMovement(Map<String, Object> state, class_243 target, double stopDistance, boolean sprint) {
        clearMovementState(state);
        state.put("move.target.active", true);
        state.put("move.target.x", target.field_1352);
        state.put("move.target.y", target.field_1351);
        state.put("move.target.z", target.field_1350);
        state.put("move.target.stop_distance", stopDistance);
        state.put("move.target.sprint", sprint);
        AutomationReporter.mem("move.target.active", true);
        AutomationReporter.mem("move.target.x", target.field_1352);
        AutomationReporter.mem("move.target.y", target.field_1351);
        AutomationReporter.mem("move.target.z", target.field_1350);
        writeStateValue(state, "path.status", "tracking");
        writeStateValue(state, "path.stop_distance", stopDistance);
    }

    private void beginFollowTargetMovement(Map<String, Object> state, class_1297 entity, double stopDistance, boolean sprint) {
        clearMovementState(state);
        state.put("move.target.active", true);
        state.put("move.target.follow", true);
        state.put("move.target.uuid", entity.method_5845());
        state.put("move.target.x", entity.method_23317());
        state.put("move.target.y", entity.method_23318());
        state.put("move.target.z", entity.method_23321());
        state.put("move.target.stop_distance", stopDistance);
        state.put("move.target.sprint", sprint);
        AutomationReporter.mem("move.target.active", true);
        AutomationReporter.mem("move.target.follow", true);
        AutomationReporter.mem("move.target.uuid", entity.method_5845());
        AutomationReporter.mem("move.target.x", entity.method_23317());
        AutomationReporter.mem("move.target.y", entity.method_23318());
        AutomationReporter.mem("move.target.z", entity.method_23321());
        writeStateValue(state, "path.status", "following");
        writeStateValue(state, "path.stop_distance", stopDistance);
    }

    private void clearMovementState(Map<String, Object> state) {
        state.remove("move.relative.active");
        state.remove("move.relative.direction");
        state.remove("move.relative.ticks");
        state.remove("move.relative.start_x");
        state.remove("move.relative.start_z");
        state.remove("move.relative.sprint");
        state.remove("move.target.active");
        state.remove("move.target.mode");
        state.remove("move.target.uuid");
        state.remove("move.target.x");
        state.remove("move.target.y");
        state.remove("move.target.z");
        state.remove("move.target.start_x");
        state.remove("move.target.start_z");
        state.remove("move.target.start_distance");
        state.remove("move.target.displacement");
        state.remove("move.target.required_displacement");
        state.remove("move.target.relative");
        state.remove("move.target.use_y");
        state.remove("move.target.stop_distance");
        state.remove("move.target.sprint");
        state.remove("move.target.precise");
        state.remove("move.target.precision_distance");
        state.remove("move.target.slow_distance");
        state.remove("move.nav.phase");
        state.remove("move.nav.blocked_ticks");
        state.remove("move.nav.last_distance");
        state.remove("move.nav.strafe_mode");
        state.remove("move.nav.steer_x");
        state.remove("move.nav.steer_z");
        state.remove("move.nav.steer_lock_ticks");
        state.remove("move.nav.policy");
        state.remove("move.nav.persistent");
        state.remove("move.nav.allow_break_blocks");
        state.remove("move.nav.allow_place_blocks");
        state.remove("move.nav.allow_combat_clear");
        state.remove("move.nav.jump_window");
        state.remove("move.nav.swim");
        state.remove("move.nav.avoid_drop");
        state.remove("move.nav.fail_reason");
        state.remove("move.failed");
        state.remove("move.failure_reason");
        state.remove("move.nav.escape_ticks");
        state.remove("move.nav.escape_side");
        state.remove("move.nav.waypoint.active");
        state.remove("move.nav.waypoint.x");
        state.remove("move.nav.waypoint.y");
        state.remove("move.nav.waypoint.z");
        state.remove("move.nav.waypoint.reason");
        state.remove("move.nav.waypoint.score");
        state.remove("move.nav.path_style");
        state.remove("move.nav.last_x");
        state.remove("move.nav.last_z");
        state.remove("move.nav.stall_ticks");
        state.remove("move.nav.decision_ticks");
        state.remove("move.nav.decision_x");
        state.remove("move.nav.decision_z");
        state.remove("move.nav.decision_look_x");
        state.remove("move.nav.decision_look_y");
        state.remove("move.nav.decision_look_z");
        state.remove("move.nav.decision_phase");
        state.remove("move.nav.decision_strafe");
        state.remove("move.nav.decision_sprint");
        state.remove("move.nav.clear_block");
        state.remove("move.nav.clear_block.x");
        state.remove("move.nav.clear_block.y");
        state.remove("move.nav.clear_block.z");
        state.remove("move.nav.clear_block.started");
        state.remove("move.nav.clear_block.ticks");
        state.remove("move.nav.route.active");
        state.remove("move.nav.route.x");
        state.remove("move.nav.route.y");
        state.remove("move.nav.route.z");
        state.remove("move.nav.route.nodes");
        state.remove("move.nav.route.expansions");
        state.remove("move.nav.route.reason");
        state.remove("move.recovery.mode");
        state.remove("move.recovery.tactic");
        state.remove("move.recovery.reason");
        state.remove("move.recovery.attempts");
        state.remove("parkour.active");
        state.remove("parkour.phase");
        state.remove("parkour.takeoff.x");
        state.remove("parkour.takeoff.y");
        state.remove("parkour.takeoff.z");
        state.remove("parkour.landing.x");
        state.remove("parkour.landing.y");
        state.remove("parkour.landing.z");
        state.remove("parkour.sprint");
        state.remove("parkour.charge_ticks");
        state.remove("parkour.air_ticks");
        state.remove("parkour.approach_ticks");
        state.remove("parkour.jump_started");
        state.remove("parkour.align_ticks");
        state.remove("path.lookups");
    }

    private void beginPointNavigation(Map<String, Object> state, class_746 player, class_243 target, double stopDistance, boolean sprint, boolean useY, Map<String, Object> params) {
        boolean relativeTarget = Boolean.TRUE.equals(state.get("current.target.relative")) || "relative_target".equals(stringParam(state, "current.target.id", ""));
        double requiredDisplacement = relativeTarget ? doubleState(state, "current.target.relative_distance", 0.0D) : 0.0D;
        clearMovementState(state);
        releaseMovementInputs();
        state.put("move.target.active", true);
        state.put("move.target.mode", "point");
        state.put("move.target.x", target.field_1352);
        state.put("move.target.y", target.field_1351);
        state.put("move.target.z", target.field_1350);
        state.put("move.target.start_x", player == null ? target.field_1352 : player.method_23317());
        state.put("move.target.start_z", player == null ? target.field_1350 : player.method_23321());
        state.put("move.target.use_y", useY);
        state.put("move.target.stop_distance", stopDistance);
        state.put("move.target.start_distance", player == null ? 0.0D : navigationDistance(player.method_19538(), target, useY));
        if (relativeTarget) {
            state.put("move.target.relative", true);
            state.put("move.target.required_displacement", requiredDisplacement);
        }
        state.put("move.target.sprint", sprint);
        state.put("move.target.precise", false);
        state.put("move.nav.phase", "navigating");
        state.put("move.nav.blocked_ticks", 0);
        state.put("move.nav.last_distance", Double.MAX_VALUE);
        state.put("move.nav.strafe_mode", "none");
        state.put("move.nav.steer_x", 0.0D);
        state.put("move.nav.steer_z", 0.0D);
        state.put("move.nav.steer_lock_ticks", 0);
        installMovementPolicy(state, params);
        state.put("move.nav.jump_window", 0);
        state.put("move.nav.swim", false);
        state.put("move.nav.avoid_drop", true);
        state.put("move.nav.escape_ticks", 0);
        state.put("move.nav.escape_side", "none");
        state.put("move.nav.stall_ticks", 0);
        state.put("move.nav.decision_ticks", 0);
        AutomationReporter.mem("move.target.active", true);
        AutomationReporter.mem("move.target.mode", "point");
        AutomationReporter.mem("move.target.x", target.field_1352);
        AutomationReporter.mem("move.target.y", target.field_1351);
        AutomationReporter.mem("move.target.z", target.field_1350);
        AutomationReporter.mem("move.target.use_y", useY);
        writeStateValue(state, "path.status", "navigating");
        writeStateValue(state, "path.stop_distance", stopDistance);
    }

    private void beginFollowNavigation(Map<String, Object> state, class_746 player, class_1297 entity, double stopDistance, boolean sprint, Map<String, Object> params) {
        clearMovementState(state);
        state.put("move.target.active", true);
        state.put("move.target.mode", "follow");
        state.put("move.target.uuid", entity.method_5845());
        state.put("move.target.x", entity.method_23317());
        state.put("move.target.y", entity.method_23318());
        state.put("move.target.z", entity.method_23321());
        state.put("move.target.start_x", player == null ? entity.method_23317() : player.method_23317());
        state.put("move.target.start_z", player == null ? entity.method_23321() : player.method_23321());
        state.put("move.target.use_y", false);
        state.put("move.target.stop_distance", stopDistance);
        state.put("move.target.start_distance", player == null ? 0.0D : navigationDistance(player.method_19538(), entity.method_19538(), false));
        state.put("move.target.sprint", sprint);
        state.put("move.nav.phase", "following");
        state.put("move.nav.blocked_ticks", 0);
        state.put("move.nav.last_distance", Double.MAX_VALUE);
        state.put("move.nav.strafe_mode", "none");
        state.put("move.nav.steer_x", 0.0D);
        state.put("move.nav.steer_z", 0.0D);
        state.put("move.nav.steer_lock_ticks", 0);
        installMovementPolicy(state, params);
        state.put("move.nav.jump_window", 0);
        state.put("move.nav.swim", false);
        state.put("move.nav.avoid_drop", true);
        state.put("move.nav.escape_ticks", 0);
        state.put("move.nav.escape_side", "none");
        state.put("move.nav.stall_ticks", 0);
        state.put("move.nav.decision_ticks", 0);
        AutomationReporter.mem("move.target.active", true);
        AutomationReporter.mem("move.target.mode", "follow");
        AutomationReporter.mem("move.target.uuid", entity.method_5845());
        AutomationReporter.mem("move.target.x", entity.method_23317());
        AutomationReporter.mem("move.target.y", entity.method_23318());
        AutomationReporter.mem("move.target.z", entity.method_23321());
        writeStateValue(state, "path.status", "following");
        writeStateValue(state, "path.stop_distance", stopDistance);
    }

    private void installMovementPolicy(Map<String, Object> state, Map<String, Object> params) {
        String policy = stringParam(params, "movement.policy", stringParam(params, "style.id", "smart")).toLowerCase(Locale.ROOT);
        boolean persistent = booleanParam(params, "movement.persistent", false)
                || policy.contains("persistent")
                || policy.contains("unstoppable")
                || policy.contains("everything");
        state.put("move.nav.policy", policy);
        state.put("move.nav.persistent", persistent);
        state.put("move.nav.allow_break_blocks", persistent || booleanParam(params, "movement.allow_break_blocks", false));
        state.put("move.nav.allow_place_blocks", persistent || booleanParam(params, "movement.allow_place_blocks", false));
        state.put("move.nav.allow_combat_clear", persistent || booleanParam(params, "movement.allow_combat_clear", false));
        writeStateValue(state, "move.nav.policy", policy);
        writeStateValue(state, "move.nav.persistent", persistent);
    }

    private boolean executeNamedGoal(String goalName, Map<String, Object> params, Map<String, Object> state, class_310 client, class_746 player, class_638 world) {
        String normalized = normalizeGoalName(goalName);
        if (normalized.equals("wander") || normalized.equals("wandergoal") || normalized.equals("wanderaroundgoal")) {
            String[] directions = {"forward", "left", "right", "back"};
            int index = (int) Math.floorMod(world.method_8510() + player.method_24515().method_10063(), directions.length);
            int ticks = Math.max(6, intParam(params, "goal.ticks", 42));
            beginRelativeMovement(state, player, directions[index], ticks, Boolean.TRUE.equals(params.get("sprint")));
            writeStateValue(state, "goal.adapter", "minecraft.wander");
            writeStateValue(state, "goal.phase", "moving");
            return true;
        }

        class_1297 entity = resolveTargetEntity(world, params, state);
        if (entity == null) {
            entity = crosshairEntity(client);
        }
        if (entity == null) {
            writeStateValue(state, "goal.failure_reason", "missing_target_entity");
            return false;
        }
        state.put("current.target.uuid", entity.method_5845());
        state.put("current.target.name", entity.method_5477().getString());
        state.put("current.target.x", entity.method_23317());
        state.put("current.target.y", entity.method_23318());
        state.put("current.target.z", entity.method_23321());
        AutomationReporter.mem("current.target.uuid", entity.method_5845());
        AutomationReporter.mem("current.target.name", entity.method_5477().getString());

        if (normalized.equals("follow") || normalized.equals("followgoal") || normalized.equals("followownergoal")) {
            double stopDistance = doubleParam(params, "stop.distance", 2.0D);
            beginFollowNavigation(state, player, entity, stopDistance, Boolean.TRUE.equals(params.get("sprint")), params);
            writeStateValue(state, "goal.adapter", "minecraft.follow");
            writeStateValue(state, "goal.phase", "following");
            return true;
        }
        if (normalized.equals("attack") || normalized.equals("attackgoal") || normalized.equals("meleeattackgoal")) {
            double stopDistance = doubleParam(params, "stop.distance", 2.0D);
            double attackRange = doubleParam(params, "attack.range", 3.4D);
            beginFollowNavigation(state, player, entity, stopDistance, true, params);
            state.put("attack.active", true);
            state.put("attack.target.uuid", entity.method_5845());
            state.put("attack.phase", "prepare");
            state.put("attack.ticks", 0);
            state.put("attack.crit.enabled", true);
            state.put("attack.crit.jump_wait_ticks", 3);
            state.put("attack.range", attackRange);
            AutomationReporter.mem("attack.active", true);
            AutomationReporter.mem("attack.phase", "prepare");
            writeStateValue(state, "goal.adapter", "minecraft.attack");
            writeStateValue(state, "goal.phase", "attack_and_follow");
            return true;
        }
        writeStateValue(state, "goal.failure_reason", "unknown_goal_" + normalized);
        return false;
    }

    private static String normalizeGoalName(String value) {
        return value == null ? "" : value.toLowerCase(Locale.ROOT).replace("minecraft:", "").replace("_", "").replace(" ", "");
    }

    private static class_1297 crosshairEntity(class_310 client) {
        if (client == null || !(client.field_1765 instanceof class_3966 hitResult)) {
            return null;
        }
        return hitResult.method_17782();
    }

    private void writeMovementResult(Map<String, Object> state, boolean ok, String status, String reason) {
        writeStateValue(state, "result.ok", ok);
        writeStateValue(state, "result.status", status);
        writeStateValue(state, "result.reason", reason);
        writeStateValue(state, "result.retryable", Set.of("blocked", "stuck", "unsafe", "needs_recovery", "needs_replan", "running").contains(status));
        writeStateValue(state, "result.debug_summary", status + ":" + reason);
    }

    private void writeMovementTargetDetails(Map<String, Object> state, String type, class_243 stand, class_243 look, double radius, double confidence, double danger, String reason) {
        writeStateValue(state, "movement.target.type", type);
        writeStateValue(state, "movement.target.stand.x", round(stand.field_1352));
        writeStateValue(state, "movement.target.stand.y", round(stand.field_1351));
        writeStateValue(state, "movement.target.stand.z", round(stand.field_1350));
        writeStateValue(state, "movement.target.look.x", round(look.field_1352));
        writeStateValue(state, "movement.target.look.y", round(look.field_1351));
        writeStateValue(state, "movement.target.look.z", round(look.field_1350));
        writeStateValue(state, "movement.target.approach_radius", radius);
        writeStateValue(state, "movement.target.confidence", round(confidence));
        writeStateValue(state, "movement.target.danger_score", round(danger));
        writeStateValue(state, "movement.resolve.reason", reason);
        AutomationReporter.info("[move]", "target resolved: " + type + " danger=" + round(danger) + " confidence=" + round(confidence));
    }

    private void writeMovementSnapshot(Map<String, Object> state, class_746 player, class_638 world) {
        class_2338 feet = player.method_24515();
        writeStateValue(state, "player.x", round(player.method_23317()));
        writeStateValue(state, "player.y", round(player.method_23318()));
        writeStateValue(state, "player.z", round(player.method_23321()));
        writeStateValue(state, "player.velocity.x", round(player.method_18798().field_1352));
        writeStateValue(state, "player.velocity.y", round(player.method_18798().field_1351));
        writeStateValue(state, "player.velocity.z", round(player.method_18798().field_1350));
        writeStateValue(state, "player.yaw", round(player.method_36454()));
        writeStateValue(state, "player.pitch", round(player.method_36455()));
        writeStateValue(state, "player.on_ground", player.method_24828());
        writeStateValue(state, "player.in_water", player.method_5799());
        writeStateValue(state, "player.submerged", player.method_5869());
        writeStateValue(state, "player.climbing", player.method_6101());
        writeStateValue(state, "player.fall_distance", round(player.field_6017));
        writeStateValue(state, "player.block.feet", blockId(world, feet));
        writeStateValue(state, "player.block.head", blockId(world, feet.method_10084()));
        writeStateValue(state, "player.block.under", blockId(world, feet.method_10074()));
        writeStateValue(state, "player.pocket_risk", round(pocketRisk(world, feet)));
    }

    private String blockId(class_638 world, class_2338 pos) {
        class_2960 id = class_7923.field_41175.method_10221(world.method_8320(pos).method_26204());
        return id == null ? "unknown" : id.toString();
    }

    private MovementProgress evaluateMovementProgress(Map<String, Object> state, class_746 player, double distance) {
        double lastDistance = doubleState(state, "move.progress.last_distance", Double.MAX_VALUE);
        double lastX = doubleState(state, "move.progress.last_x", player.method_23317());
        double lastY = doubleState(state, "move.progress.last_y", player.method_23318());
        double lastZ = doubleState(state, "move.progress.last_z", player.method_23321());
        double moved = player.method_19538().method_1022(new class_243(lastX, lastY, lastZ));
        boolean distanceImproved = distance < lastDistance - NAV_PROGRESS_EPSILON;
        boolean positionChanged = moved > 0.025D;
        boolean oscillating = isOscillating(state, player.method_19538());
        int noProgress = (distanceImproved || positionChanged) && !oscillating ? 0 : intState(state, "move.progress.no_progress_ticks", 0) + 1;
        writeStateValue(state, "move.progress.last_distance", distance);
        writeStateValue(state, "move.progress.last_x", player.method_23317());
        writeStateValue(state, "move.progress.last_y", player.method_23318());
        writeStateValue(state, "move.progress.last_z", player.method_23321());
        writeStateValue(state, "move.progress.no_progress_ticks", noProgress);
        if (player.method_24828() && !player.field_5976 && !player.method_5799()) {
            writeStateValue(state, "move.last_safe.x", player.method_23317());
            writeStateValue(state, "move.last_safe.y", player.method_23318());
            writeStateValue(state, "move.last_safe.z", player.method_23321());
        }
        boolean ok = noProgress < NAV_STUCK_TICKS && !oscillating;
        String reason = ok ? "progressing" : oscillating ? "oscillating" : "no_progress";
        return new MovementProgress(ok, reason, distanceImproved, positionChanged, oscillating, noProgress);
    }

    private boolean isOscillating(Map<String, Object> state, class_243 pos) {
        String key = "move.trace." + (intState(state, "move.trace.index", 0) % NAV_TRACE_WINDOW);
        String current = Math.round(pos.field_1352 * 8.0D) + ":" + Math.round(pos.field_1351 * 8.0D) + ":" + Math.round(pos.field_1350 * 8.0D);
        int matches = 0;
        for (int i = 0; i < NAV_TRACE_WINDOW; i++) {
            if (current.equals(state.get("move.trace." + i))) {
                matches++;
            }
        }
        state.put(key, current);
        state.put("move.trace.index", intState(state, "move.trace.index", 0) + 1);
        return matches >= 4;
    }

    private void recordMovementTrace(Map<String, Object> state, class_746 player, double distance) {
        MovementProgress progress = evaluateMovementProgress(state, player, distance);
        writeProgressState(state, progress);
    }

    private void writeProgressState(Map<String, Object> state, MovementProgress progress) {
        writeStateValue(state, "move.progress.ok", progress.ok());
        writeStateValue(state, "move.progress.reason", progress.reason());
        writeStateValue(state, "move.progress.distance_improved", progress.distanceImproved());
        writeStateValue(state, "move.progress.position_changed", progress.positionChanged());
        writeStateValue(state, "move.progress.oscillating", progress.oscillating());
        writeStateValue(state, "move.progress.no_progress_ticks", progress.noProgressTicks());
        writeMovementResult(state, progress.ok(), progress.ok() ? "running" : "needs_recovery", progress.reason());
    }

    private MovementSafety movementSafetyAt(class_638 world, class_2338 feet, int maxDrop) {
        if (isDangerBlock(world, feet) || isDangerBlock(world, feet.method_10074())) {
            return new MovementSafety(false, "danger_block", true, false, true, pocketRisk(world, feet));
        }
        if (!canPassThrough(world, feet) || !canPassThrough(world, feet.method_10084())) {
            return new MovementSafety(false, "body_blocked", false, false, false, 1.0D);
        }
        boolean water = isWaterBlock(world, feet) || isWaterBlock(world, feet.method_10074());
        boolean drop = isUnsafeDrop(world, feet.method_10074(), maxDrop);
        double pocket = pocketRisk(world, feet);
        boolean safe = !drop && pocket < 0.9D;
        String reason = safe ? "safe" : drop ? "unsafe_drop" : "pocket";
        return new MovementSafety(safe, reason, false, drop, water, pocket);
    }

    private void writeSafetyState(Map<String, Object> state, MovementSafety safety) {
        writeStateValue(state, "move.safety.safe", safety.safe());
        writeStateValue(state, "move.safety.reason", safety.reason());
        writeStateValue(state, "move.safety.danger", safety.danger());
        writeStateValue(state, "move.safety.drop", safety.drop());
        writeStateValue(state, "move.safety.water", safety.water());
        writeStateValue(state, "move.safety.pocket_risk", round(safety.pocketRisk()));
    }

    private MovementPlan planLocalMovement(class_638 world, class_746 player, class_243 target, Map<String, Object> params, Map<String, Object> state) {
        class_2338 feet = player.method_24515();
        class_2338 targetFeet = class_2338.method_49638(target);
        MovementSafety targetSafety = movementSafetyAt(world, targetFeet, 4);
        double dx = target.field_1352 - player.method_23317();
        double dz = target.field_1350 - player.method_23321();
        double horizontal = Math.sqrt(dx * dx + dz * dz);
        double vertical = target.field_1351 - player.method_23318();
        boolean allowParkour = booleanParam(params, "movement.allow_parkour", booleanParam(params, "allow.parkour", true));
        boolean allowSprint = booleanParam(params, "movement.allow_sprint", true);
        String segment;
        boolean sprint = false;
        if (!targetSafety.safe()) {
            segment = targetSafety.drop() ? "CONTROLLED_DROP" : "WAIT_STABLE";
        } else if (player.method_5799() || isWaterBlock(world, targetFeet)) {
            segment = "SWIM_TO";
        } else if (vertical > 0.75D && horizontal <= 1.8D) {
            segment = "JUMP_UP";
        } else if (vertical < -1.2D) {
            segment = "CONTROLLED_DROP";
        } else if (horizontal > 1.6D && horizontal <= 4.6D && allowParkour && !hasWalkableLine(world, feet, targetFeet)) {
            segment = horizontal > 2.4D ? "SPRINT_JUMP_GAP" : "JUMP_GAP";
            sprint = horizontal > 2.4D && allowSprint;
        } else if (isNearEdge(world, feet)) {
            segment = "SNEAK_EDGE";
        } else if (horizontal > 5.0D && allowSprint) {
            segment = "SPRINT_CLEAR";
            sprint = true;
        } else {
            segment = "WALK_TO";
        }
        boolean ok = targetSafety.safe() || "CONTROLLED_DROP".equals(segment) || "SWIM_TO".equals(segment);
        double danger = targetSafety.pocketRisk() + (targetSafety.danger() ? 1.0D : 0.0D) + (targetSafety.drop() ? 0.5D : 0.0D);
        return new MovementPlan(ok, segment, sprint, "plan_" + segment.toLowerCase(Locale.ROOT), danger, horizontal, vertical);
    }

    private boolean hasWalkableLine(class_638 world, class_2338 from, class_2338 to) {
        int steps = Math.max(Math.abs(to.method_10263() - from.method_10263()), Math.abs(to.method_10260() - from.method_10260()));
        if (steps <= 0) {
            return true;
        }
        for (int i = 1; i <= steps; i++) {
            double t = (double) i / (double) steps;
            int x = class_3532.method_15357(class_3532.method_16436(t, from.method_10263(), to.method_10263()));
            int z = class_3532.method_15357(class_3532.method_16436(t, from.method_10260(), to.method_10260()));
            class_2338 pos = new class_2338(x, from.method_10264(), z);
            if (!canStandAt(world, pos) || isUnsafeDrop(world, pos.method_10074(), 3)) {
                return false;
            }
        }
        return true;
    }

    private boolean isNearEdge(class_638 world, class_2338 feet) {
        for (class_2350 direction : class_2350.class_2353.field_11062) {
            if (isUnsafeDrop(world, feet.method_10093(direction).method_10074(), 3)) {
                return true;
            }
        }
        return false;
    }

    private void writePlanState(Map<String, Object> state, MovementPlan plan) {
        writeStateValue(state, "move.segment.type", plan.segment());
        writeStateValue(state, "move.segment.danger_score", round(plan.danger()));
        writeStateValue(state, "move.segment.horizontal_distance", round(plan.horizontal()));
        writeStateValue(state, "move.segment.vertical_delta", round(plan.vertical()));
        writeStateValue(state, "move.segment.sprint", plan.sprint());
        writeMovementResult(state, plan.ok(), plan.ok() ? "running" : "unsafe", plan.reason());
        AutomationReporter.info("[move]", "path planned: " + plan.segment() + " danger=" + round(plan.danger()));
    }

    private String chooseRecoveryTactic(Map<String, Object> state, class_746 player, class_638 world) {
        int attempts = intState(state, "move.recovery.attempts", 0);
        if (attempts >= NAV_RECOVERY_LIMIT) {
            return "fail";
        }
        class_2338 feet = player.method_24515();
        if (player.method_5799() || player.method_5869()) {
            return "swim_to_edge";
        }
        if (player.field_6017 > 2.5F || !player.method_24828()) {
            return "wait_for_ground";
        }
        if (isTreePocket(world, feet)) {
            return "escape_tree_pocket";
        }
        if (pocketRisk(world, feet) >= 0.75D) {
            return "jump_out_of_pocket";
        }
        if (player.field_5976) {
            return attempts % 2 == 0 ? "route_around_obstacle" : attempts % 3 == 0 ? "strafe_left" : "strafe_right";
        }
        if (Boolean.TRUE.equals(state.get("move.progress.oscillating"))) {
            return "step_backward";
        }
        return attempts % 3 == 0 ? "recenter" : attempts % 3 == 1 ? "strafe_left" : "jump_once";
    }

    private boolean runRecoveryTactic(Map<String, Object> state, class_746 player, class_638 world, String tactic) {
        String selected = "auto".equals(tactic) ? chooseRecoveryTactic(state, player, world) : tactic;
        writeStateValue(state, "move.recovery.mode", selected);
        writeStateValue(state, "move.recovery.attempts", intState(state, "move.recovery.attempts", 0) + 1);
        releaseMovementInputs();
        switch (selected) {
            case "swim_to_edge" -> {
                setHeldInput("jump", true);
                class_243 edge = nearestSafeHorizontalDirection(world, player.method_24515());
                applySwimToward(player, edge, player.method_19538().method_1019(edge));
            }
            case "wait_for_ground" -> releaseMovementInputs();
            case "jump_out_of_pocket", "escape_tree_pocket", "jump_once" -> {
                if (player.method_24828()) {
                    player.method_6043();
                }
                applyHorizontalMotion(player, bestRecoveryDirection(world, player, state), false);
            }
            case "route_around_obstacle" -> applyHorizontalMotion(player, bestRecoveryDirection(world, player, state), false);
            case "strafe_left" -> applyHorizontalMotion(player, rotateLeft(movementDirectionFromState(state)), false);
            case "strafe_right" -> applyHorizontalMotion(player, rotateRight(movementDirectionFromState(state)), false);
            case "step_backward" -> applyHorizontalMotion(player, movementDirectionFromState(state).method_1021(-1.0D), false);
            case "recenter" -> {
                class_243 center = class_243.method_24953(player.method_24515());
                applyMoveToward(player, new class_243(center.field_1352, player.method_23318(), center.field_1350), false);
            }
            default -> {
                state.put("move.recovery.reason", "no_recovery_available");
                return false;
            }
        }
        state.put("move.recovery.reason", selected);
        AutomationReporter.info("[move]", "recovery running: " + selected);
        return true;
    }

    private class_243 movementDirectionFromState(Map<String, Object> state) {
        class_243 direction = new class_243(doubleState(state, "move.target.x", 0.0D) - doubleState(state, "move.progress.last_x", 0.0D), 0.0D, doubleState(state, "move.target.z", 0.0D) - doubleState(state, "move.progress.last_z", 0.0D));
        if (direction.method_1027() < 1.0E-4D) {
            return new class_243(0.0D, 0.0D, 1.0D);
        }
        return direction.method_1029();
    }

    private class_243 nearestSafeHorizontalDirection(class_638 world, class_2338 feet) {
        class_243 best = class_243.field_1353;
        double bestScore = Double.NEGATIVE_INFINITY;
        for (class_2350 direction : class_2350.class_2353.field_11062) {
            class_243 vec = class_243.method_24954(direction.method_10163());
            CandidateSafety safety = candidateSafety(world, feet, vec);
            if (!safety.safe()) {
                continue;
            }
            double score = safety.clearance() * 2.0D - safety.pocketRisk() * 8.0D - naturalPocketPressure(world, feet.method_10093(direction)) * 1.5D;
            if (score > bestScore) {
                bestScore = score;
                best = vec;
            }
        }
        return best.method_1027() < 1.0E-4D ? new class_243(0.0D, 0.0D, 1.0D) : best.method_1029();
    }

    private class_243 bestRecoveryDirection(class_638 world, class_746 player, Map<String, Object> state) {
        class_2338 feet = player.method_24515();
        class_243 targetDirection = movementDirectionFromState(state);
        List<class_243> options = List.of(
                rotateLeft(targetDirection),
                rotateRight(targetDirection),
                targetDirection.method_1021(-1.0D),
                rotateYaw(targetDirection, 135.0D),
                rotateYaw(targetDirection, -135.0D),
                nearestSafeHorizontalDirection(world, feet)
        );
        class_243 best = class_243.field_1353;
        double bestScore = Double.NEGATIVE_INFINITY;
        for (class_243 option : options) {
            if (option.method_1027() < 1.0E-4D) {
                continue;
            }
            class_243 normalized = option.method_1029();
            CandidateSafety safety = candidateSafety(world, feet, normalized);
            double score = safety.clearance() * 2.2D - safety.blocked() * 5.0D - safety.drop() * 8.0D - safety.pocketRisk() * 10.0D - safety.naturalBlockers() * 1.4D;
            if (safety.safe()) {
                score += 5.0D;
            }
            if (score > bestScore) {
                bestScore = score;
                best = normalized;
            }
        }
        return best.method_1027() < 1.0E-4D ? nearestSafeHorizontalDirection(world, feet) : best.method_1029();
    }

    private ParkourAnalysis analyzeParkourJump(class_638 world, class_746 player, class_243 landing, Map<String, Object> params) {
        class_243 normalizedLanding = normalizeParkourLanding(world, landing);
        class_2338 landingFeet = class_2338.method_49638(normalizedLanding);
        MovementSafety safety = movementSafetyAt(world, landingFeet, 5);
        double horizontal = horizontalDistance(player.method_19538(), normalizedLanding);
        double vertical = normalizedLanding.field_1351 - player.method_23318();
        boolean allowSprint = booleanParam(params, "movement.allow_sprint", booleanParam(params, "parkour.allow_sprint_jump", true));
        boolean advancedAllowed = booleanParam(params, "parkour.allow_advanced", true);
        boolean sprint = allowSprint && horizontal > PARKOUR_SINGLE_MAX_HORIZONTAL - 0.25D;
        boolean headHitAssist = hasParkourHeadHitAssist(world, player.method_24515(), normalizedLanding);
        boolean downwardAssist = vertical < -0.75D;
        double maxHorizontal = allowSprint ? PARKOUR_SPRINT_MAX_HORIZONTAL : PARKOUR_SINGLE_MAX_HORIZONTAL;
        if (allowSprint && advancedAllowed && (headHitAssist || downwardAssist)) {
            maxHorizontal = PARKOUR_ADVANCED_MAX_HORIZONTAL;
        }
        boolean distancePossible = horizontal <= maxHorizontal && horizontal >= 0.65D;
        boolean verticalPossible = vertical <= 1.25D && vertical >= -4.0D;
        boolean ceilingClear = canPassThrough(world, player.method_24515().method_10086(2)) || headHitAssist;
        boolean landingClear = canStandAt(world, landingFeet);
        boolean flightClear = isParkourFlightPathClear(world, player.method_19538(), normalizedLanding);
        boolean possible = safety.safe() && landingClear && distancePossible && verticalPossible && ceilingClear && flightClear;
        String reason = possible ? (headHitAssist ? "advanced_headhit_jump_possible" : downwardAssist ? "downward_sprint_jump_possible" : "jump_possible") : !landingClear ? "landing_not_standable" : !safety.safe() ? safety.reason() : !distancePossible ? (horizontal < 0.65D ? "landing_too_close" : "gap_too_far") : !verticalPossible ? (vertical > 1.25D ? "landing_too_high" : "landing_too_low") : !ceilingClear ? "ceiling_blocked" : "flight_path_blocked";
        return new ParkourAnalysis(possible, reason, sprint, horizontal, vertical, safety.pocketRisk());
    }

    private class_243 normalizeParkourLanding(class_638 world, class_243 target) {
        class_2338 base = class_2338.method_49638(target);
        if (canStandAt(world, base)) {
            return new class_243(base.method_10263() + 0.5D, base.method_10264(), base.method_10260() + 0.5D);
        }
        if (canStandAt(world, base.method_10084())) {
            return new class_243(base.method_10263() + 0.5D, base.method_10264() + 1.0D, base.method_10260() + 0.5D);
        }
        if (canStandAt(world, base.method_10074())) {
            return new class_243(base.method_10263() + 0.5D, base.method_10264() - 1.0D, base.method_10260() + 0.5D);
        }
        return new class_243(target.field_1352, target.field_1351, target.field_1350);
    }

    private class_243 findParkourTakeoff(class_638 world, class_746 player, class_243 landing, ParkourAnalysis analysis) {
        class_243 horizontal = new class_243(landing.field_1352 - player.method_23317(), 0.0D, landing.field_1350 - player.method_23321());
        if (horizontal.method_1027() < 1.0E-4D) {
            return null;
        }
        class_243 direction = horizontal.method_1029();
        class_2338 playerFeet = player.method_24515();
        if (canUseParkourTakeoff(world, playerFeet, landing, direction, analysis)) {
            return new class_243(player.method_23317(), player.method_23318(), player.method_23321());
        }
        double maxDistance = analysis.sprint() ? PARKOUR_SPRINT_MAX_HORIZONTAL : PARKOUR_SINGLE_MAX_HORIZONTAL;
        class_243 best = null;
        double bestScore = Double.MAX_VALUE;
        for (double travel = Math.min(maxDistance, Math.max(1.15D, analysis.horizontal() - 0.2D)); travel >= 1.0D; travel -= 0.25D) {
            class_243 sample = landing.method_1020(direction.method_1021(travel));
            class_2338 base = class_2338.method_49638(sample);
            for (int dy = 1; dy >= -1; dy--) {
                class_2338 feet = base.method_10069(0, dy, 0);
                if (!canUseParkourTakeoff(world, feet, landing, direction, analysis)) {
                    continue;
                }
                class_243 candidate = new class_243(feet.method_10263() + 0.5D, feet.method_10264(), feet.method_10260() + 0.5D);
                double jumpDistance = horizontalDistance(candidate, landing);
                if (jumpDistance > maxDistance || jumpDistance < 0.85D) {
                    continue;
                }
                double score = player.method_19538().method_1025(candidate) + Math.abs(jumpDistance - Math.min(analysis.horizontal(), maxDistance - 0.25D));
                if (score < bestScore) {
                    bestScore = score;
                    best = candidate;
                }
            }
        }
        return best;
    }

    private boolean canUseParkourTakeoff(class_638 world, class_2338 feet, class_243 landing, class_243 direction, ParkourAnalysis analysis) {
        if (!canStandAt(world, feet)) {
            return false;
        }
        if (!canPassThrough(world, feet.method_10086(2))) {
            return false;
        }
        if (movementSafetyAt(world, feet, 3).danger()) {
            return false;
        }
        class_243 takeoff = new class_243(feet.method_10263() + 0.5D, feet.method_10264(), feet.method_10260() + 0.5D);
        double horizontal = horizontalDistance(takeoff, landing);
        double maxHorizontal = analysis.sprint() && analysis.reason().contains("advanced") ? PARKOUR_ADVANCED_MAX_HORIZONTAL : analysis.sprint() ? PARKOUR_SPRINT_MAX_HORIZONTAL : PARKOUR_SINGLE_MAX_HORIZONTAL;
        if (horizontal < 0.85D || horizontal > maxHorizontal) {
            return false;
        }
        return isParkourFlightPathClear(world, takeoff, landing);
    }

    private boolean isParkourFlightPathClear(class_638 world, class_243 from, class_243 landing) {
        class_243 delta = new class_243(landing.field_1352 - from.field_1352, 0.0D, landing.field_1350 - from.field_1350);
        double horizontal = delta.method_1033();
        if (horizontal < 0.5D) {
            return true;
        }
        class_243 direction = delta.method_1029();
        int samples = Math.max(2, (int) Math.ceil(horizontal / 0.35D));
        for (int i = 1; i < samples; i++) {
            double t = i / (double) samples;
            class_243 sample = from.method_1019(direction.method_1021(horizontal * t));
            double y = class_3532.method_16436(t, from.field_1351, landing.field_1351);
            double arcHeight = Math.sin(Math.PI * t) * 0.95D;
            class_2338 body = class_2338.method_49637(sample.field_1352, y + 0.65D + arcHeight * 0.35D, sample.field_1350);
            class_2338 head = class_2338.method_49637(sample.field_1352, y + 1.65D + arcHeight, sample.field_1350);
            if (!canPassThrough(world, body) || !canPassThrough(world, head)) {
                return false;
            }
        }
        return true;
    }

    private void updateParkourPhase(Map<String, Object> state, class_746 player, class_638 world, class_243 target) {
        class_243 landing = new class_243(doubleState(state, "parkour.landing.x", target.field_1352), doubleState(state, "parkour.landing.y", target.field_1351), doubleState(state, "parkour.landing.z", target.field_1350));
        class_243 takeoff = new class_243(doubleState(state, "parkour.takeoff.x", player.method_23317()), doubleState(state, "parkour.takeoff.y", player.method_23318()), doubleState(state, "parkour.takeoff.z", player.method_23321()));
        boolean sprint = Boolean.TRUE.equals(state.get("parkour.sprint"));
        String phase = stringParam(state, "parkour.phase", "approach_takeoff");
        double landingDistance = horizontalDistance(player.method_19538(), landing);
        double takeoffDistance = horizontalDistance(player.method_19538(), takeoff);
        writeStateValue(state, "parkour.distance_remaining", round(landingDistance));
        writeStateValue(state, "parkour.takeoff_distance", round(takeoffDistance));

        if ("approach_takeoff".equals(phase)) {
            int ticks = intState(state, "parkour.approach_ticks", 0) + 1;
            writeStateValue(state, "parkour.approach_ticks", ticks);
            if (takeoffDistance > PARKOUR_ALIGN_DISTANCE) {
                NavigatorDecision decision = buildNavigationDecision(player, world, takeoff, state, false, 0.25D, 0, 0, 0, "none");
                facePositionHorizontal(player, takeoffDistance > 1.4D ? takeoff : landing);
                applyNavigationDecision(player, decision, precisionSpeedScale(takeoffDistance, 0.18D));
                if (ticks > PARKOUR_APPROACH_TIMEOUT_TICKS) {
                    parkourFail(state, "takeoff_unreachable");
                }
                return;
            }
            releaseMovementInputs();
            writeStateValue(state, "parkour.phase", "align");
            writeStateValue(state, "parkour.align_ticks", PARKOUR_ALIGN_TICKS);
            return;
        }

        if ("align".equals(phase)) {
            facePosition(player, landing.method_1031(0.0D, 0.35D, 0.0D));
            releaseMovementInputs();
            int alignTicks = intState(state, "parkour.align_ticks", PARKOUR_ALIGN_TICKS);
            if (alignTicks > 0) {
                writeStateValue(state, "parkour.align_ticks", alignTicks - 1);
                return;
            }
            writeStateValue(state, "parkour.phase", "charge");
            writeStateValue(state, "parkour.charge_ticks", 0);
            return;
        }

        if ("charge".equals(phase)) {
            class_243 direction = horizontalDirection(player.method_19538(), landing);
            if (direction.method_1027() < 1.0E-4D) {
                parkourFail(state, "bad_jump_direction");
                return;
            }
            facePosition(player, landing.method_1031(0.0D, 0.35D, 0.0D));
            int chargeTicks = intState(state, "parkour.charge_ticks", 0) + 1;
            writeStateValue(state, "parkour.charge_ticks", chargeTicks);
            applyHorizontalMotion(player, direction, sprint, sprint ? 1.0D : 0.92D);
            int requiredCharge = sprint ? PARKOUR_SPRINT_CHARGE_TICKS : PARKOUR_SINGLE_CHARGE_TICKS;
            if (player.method_24828() && chargeTicks >= requiredCharge) {
                player.method_6043();
                setHeldInput("jump", true);
                writeStateValue(state, "parkour.phase", "air_control");
                writeStateValue(state, "parkour.air_ticks", 0);
                writeStateValue(state, "parkour.jump_started", true);
                AutomationReporter.info("[move]", "parkour jump committed sprint=" + sprint);
            }
            return;
        }

        if ("air_control".equals(phase)) {
            class_243 direction = horizontalDirection(player.method_19538(), landing);
            int airTicks = intState(state, "parkour.air_ticks", 0) + 1;
            writeStateValue(state, "parkour.air_ticks", airTicks);
            facePosition(player, landing.method_1031(0.0D, 0.25D, 0.0D));
            applyHorizontalMotion(player, direction, sprint, sprint ? 1.0D : 0.95D);
            if (airTicks > 4) {
                setHeldInput("jump", false);
            }
            if (player.method_24828() && airTicks > 5) {
                writeStateValue(state, "parkour.phase", "landing_verify");
            } else if (airTicks > PARKOUR_AIR_TIMEOUT_TICKS) {
                parkourFail(state, "air_timeout");
            }
            return;
        }

        if ("landing_verify".equals(phase)) {
            releaseMovementInputs();
            class_2338 feet = player.method_24515();
            if (landingDistance <= PARKOUR_LANDING_DISTANCE + 0.25D && movementSafetyAt(world, feet, 3).safe()) {
                writeStateValue(state, "parkour.phase", "landed");
                state.put("parkour.active", false);
                state.put("move.target.active", false);
                writeMovementResult(state, true, "landed", "parkour_landing_verified");
                AutomationReporter.ok("[move]", "parkour landed");
                return;
            }
            parkourFail(state, "landing_missed");
        }
    }

    private void writeParkourAnalysis(Map<String, Object> state, ParkourAnalysis analysis) {
        writeStateValue(state, "parkour.ok", analysis.ok());
        writeStateValue(state, "parkour.reason", analysis.reason());
        writeStateValue(state, "parkour.sprint", analysis.sprint());
        writeStateValue(state, "parkour.horizontal_distance", round(analysis.horizontal()));
        writeStateValue(state, "parkour.vertical_delta", round(analysis.vertical()));
        writeStateValue(state, "parkour.landing_risk", round(analysis.landingRisk()));
        writeMovementResult(state, analysis.ok(), analysis.ok() ? "needs_parkour" : "failed", analysis.reason());
        AutomationReporter.info("[move]", "parkour analyzed: " + analysis.reason() + " sprint=" + analysis.sprint());
    }

    private void parkourFail(Map<String, Object> state, String reason) {
        releaseMovementInputs();
        writeStateValue(state, "parkour.phase", "failed");
        state.put("parkour.active", false);
        state.put("move.target.active", false);
        state.put("move.recovery.reason", reason);
        writeMovementResult(state, false, "failed", reason);
        AutomationReporter.block("[move]", "parkour -> " + reason);
    }

    private double horizontalDistance(class_243 a, class_243 b) {
        double dx = a.field_1352 - b.field_1352;
        double dz = a.field_1350 - b.field_1350;
        return Math.sqrt(dx * dx + dz * dz);
    }

    private class_243 horizontalDirection(class_243 from, class_243 to) {
        class_243 direction = new class_243(to.field_1352 - from.field_1352, 0.0D, to.field_1350 - from.field_1350);
        return direction.method_1027() < 1.0E-4D ? class_243.field_1353 : direction.method_1029();
    }

    private void updateRelativeMovement(ActiveExecution execution, class_746 player) {
        Map<String, Object> state = execution.state;
        if (!Boolean.TRUE.equals(state.get("move.relative.active")) || player == null) {
            return;
        }

        int remaining = intState(state, "move.relative.ticks", 0);
        String direction = stringParam(state, "move.relative.direction", "forward");
        boolean sprint = Boolean.TRUE.equals(state.get("move.relative.sprint"));

        applyRelativeMotion(player, direction, sprint);
        AutomationCliViewModel.runtimeFlow(execution.frameId, execution.activeNodeId, "move.relative.phase", "flow_phase", "[run ]", "move.relative.phase", "stepping");
        AutomationCliViewModel.runtimeFlow(execution.frameId, execution.activeNodeId, "move.relative.direction", "flow_metric", "[info]", "move.relative.direction", direction);
        AutomationCliViewModel.runtimeFlow(execution.frameId, execution.activeNodeId, "move.relative.remaining", "flow_metric", "[info]", "move.relative.remaining_ticks", remaining);

        remaining--;
        state.put("move.relative.ticks", remaining);
        AutomationReporter.mem("move.relative.ticks", remaining);

        if (remaining <= 0) {
            double startX = doubleState(state, "move.relative.start_x", player.method_23317());
            double startZ = doubleState(state, "move.relative.start_z", player.method_23321());
            double displacement = Math.sqrt(Math.pow(player.method_23317() - startX, 2.0D) + Math.pow(player.method_23321() - startZ, 2.0D));
            state.remove("move.relative.active");
            state.remove("move.relative.direction");
            state.remove("move.relative.ticks");
            state.remove("move.relative.sprint");
            state.remove("move.relative.start_x");
            state.remove("move.relative.start_z");
            releaseMovementInputs();
            player.method_5728(false);
            AutomationReporter.mem("move.relative.active", false);
            writeStateValue(state, "move.relative.displacement", round(displacement));
            if (displacement < NAV_MIN_COMPLETION_DISPLACEMENT) {
                state.put("move.failed", true);
                state.put("move.failure_reason", "no_player_displacement");
                writeStateValue(state, "path.status", "failed");
                AutomationCliViewModel.runtimeFlow(execution.frameId, execution.activeNodeId, "move.relative.phase", "flow_decision", "[fail]", "move.relative.phase", "no_player_displacement");
            } else {
                writeStateValue(state, "path.status", "idle");
                AutomationCliViewModel.runtimeFlow(execution.frameId, execution.activeNodeId, "move.relative.phase", "flow_decision", "[done]", "move.relative.phase", "complete");
            }
            execution.activeNodeId = null;
            execution.activeNodeLabel = null;
            execution.activeAction = null;
        }
    }

    private class_243 writeRelativeTargetState(Map<String, Object> state, class_746 player, Map<String, Object> params) {
        releaseMovementInputs();
        String direction = stringParam(params, "direction.id", "forward").toLowerCase(Locale.ROOT);
        double distance = Math.max(0.25D, doubleParam(params, "count.value", 1.0D));
        class_243 origin = player.method_19538();
        class_243 forward = class_243.method_1030(0.0F, player.method_36454()).method_1029();
        class_243 side = new class_243(forward.field_1350, 0.0D, -forward.field_1352).method_1029();
        class_243 delta = switch (direction) {
            case "back", "backward", "backwards" -> forward.method_1021(-distance);
            case "left" -> side.method_1021(distance);
            case "right" -> side.method_1021(-distance);
            case "north" -> new class_243(0.0D, 0.0D, -distance);
            case "south" -> new class_243(0.0D, 0.0D, distance);
            case "east" -> new class_243(distance, 0.0D, 0.0D);
            case "west" -> new class_243(-distance, 0.0D, 0.0D);
            case "up" -> new class_243(0.0D, distance, 0.0D);
            case "down" -> new class_243(0.0D, -distance, 0.0D);
            default -> forward.method_1021(distance);
        };
        class_243 target = origin.method_1019(delta);
        boolean useY = "up".equals(direction) || "down".equals(direction);
        state.put("current.target.kind", "location");
        state.put("current.target.id", "relative_target");
        state.put("current.target.x", target.field_1352);
        state.put("current.target.y", target.field_1351);
        state.put("current.target.z", target.field_1350);
        state.put("current.target.use_y", useY);
        state.put("current.target.relative", true);
        state.put("current.target.relative_direction", direction);
        state.put("current.target.relative_distance", distance);
        state.put("current.target.start_x", origin.field_1352);
        state.put("current.target.start_z", origin.field_1350);
        AutomationReporter.mem("current.target.kind", "location");
        AutomationReporter.mem("current.target.id", "relative_target");
        AutomationReporter.mem("current.target.x", target.field_1352);
        AutomationReporter.mem("current.target.y", target.field_1351);
        AutomationReporter.mem("current.target.z", target.field_1350);
        AutomationReporter.mem("current.target.use_y", useY);
        AutomationReporter.mem("current.target.relative_distance", distance);
        AutomationCliViewModel.runtimeFlow("", "relative_target", "move.relative.start", "flow_metric", "[info]", "move.relative.start", round(origin.field_1352) + "," + round(origin.field_1351) + "," + round(origin.field_1350));
        AutomationCliViewModel.runtimeFlow("", "relative_target", "move.relative.target", "flow_metric", "[info]", "move.relative.target", round(target.field_1352) + "," + round(target.field_1351) + "," + round(target.field_1350));
        AutomationCliViewModel.runtimeFlow("", "relative_target", "move.relative.yaw", "flow_metric", "[info]", "move.relative.yaw", round(player.method_36454()));
        AutomationCliViewModel.runtimeFlow("", "relative_target", "move.relative.forward", "flow_metric", "[debug]", "move.relative.forward", round(forward.field_1352) + "," + round(forward.field_1350));
        AutomationCliViewModel.runtimeFlow("", "relative_target", "move.relative.request", "flow_metric", "[info]", "move.relative.request", direction + " " + round(distance));
        return target;
    }

    private void updateTargetMovement(ActiveExecution execution, class_746 player, class_638 world) {
        Map<String, Object> state = execution.state;
        if (!Boolean.TRUE.equals(state.get("move.target.active")) || player == null || world == null) {
            return;
        }

        String mode = stringParam(state, "move.target.mode", "point");
        class_1297 followedEntity = null;

        if ("follow".equals(mode)) {
            String uuid = stringParam(state, "move.target.uuid", "");
            followedEntity = findEntityByUuid(world, uuid);
            if (followedEntity == null || !followedEntity.method_5805()) {
                state.put("move.target.active", false);
                state.put("move.nav.fail_reason", "target_lost");
                writeStateValue(state, "path.status", "target_lost");
                AutomationReporter.mem("move.target.active", false);
                releaseMovementInputs();
                execution.activeNodeId = null;
                execution.activeNodeLabel = null;
                execution.activeAction = null;
                return;
            }
            writeStateValue(state, "move.target.x", followedEntity.method_23317());
            writeStateValue(state, "move.target.y", followedEntity.method_23318());
            writeStateValue(state, "move.target.z", followedEntity.method_23321());
            writeStateValue(state, "current.target.x", followedEntity.method_23317());
            writeStateValue(state, "current.target.y", followedEntity.method_23318());
            writeStateValue(state, "current.target.z", followedEntity.method_23321());
            writeStateValue(state, "current.target.uuid", followedEntity.method_5845());
            writeStateValue(state, "current.target.name", followedEntity.method_5477().getString());
        }

        class_243 target = new class_243(
                doubleState(state, "move.target.x", player.method_23317()),
                doubleState(state, "move.target.y", player.method_23318()),
                doubleState(state, "move.target.z", player.method_23321())
        );

        double stopDistance = doubleState(state, "move.target.stop_distance", 1.5D);
        boolean sprint = Boolean.TRUE.equals(state.get("move.target.sprint"));
        boolean useY = Boolean.TRUE.equals(state.get("move.target.use_y")) || "true".equalsIgnoreCase(stringParam(state, "move.target.use_y", "false"));
        double distance = navigationDistance(player.method_19538(), target, useY);
        boolean precise = Boolean.TRUE.equals(state.get("move.target.precise")) || "true".equalsIgnoreCase(stringParam(state, "move.target.precise", "false"));
        double precisionDistance = doubleState(state, "move.target.precision_distance", NAV_PRECISE_DIRECT_DISTANCE);
        double slowDistance = doubleState(state, "move.target.slow_distance", NAV_PRECISE_SLOW_DISTANCE);
        recordMovementTrace(state, player, distance);
        int avoidTicks = intState(state, "move.nav.avoid.ticks", 0);
        if (avoidTicks > 0) {
            writeStateValue(state, "move.nav.avoid.ticks", avoidTicks - 1);
        }

        writeStateValue(state, "path.status", "follow".equals(mode) ? "following" : "navigating");
        writeStateValue(state, "path.distance", round(distance));
        writeStateValue(state, "path.stop_distance", stopDistance);
        incrementStateCounter(state, "path.lookups");

        AutomationCliViewModel.runtimeFlow(execution.frameId, execution.activeNodeId, "move.target.phase", "flow_phase", "[run ]", "move.target.phase", stringParam(state, "move.nav.phase", "navigating"));
        AutomationCliViewModel.runtimeFlow(execution.frameId, execution.activeNodeId, "move.target.distance", "flow_metric", "[info]", "move.target.distance", round(distance));
        AutomationCliViewModel.runtimeFlow(execution.frameId, execution.activeNodeId, "move.target.stop", "flow_metric", "[info]", "move.target.stop_distance", stopDistance);
        AutomationCliViewModel.runtimeFlow(execution.frameId, execution.activeNodeId, "move.target.use_y", "flow_metric", "[info]", "move.target.use_y", useY);
        AutomationCliViewModel.runtimeFlow(execution.frameId, execution.activeNodeId, "move.target.precise", "flow_metric", "[info]", "move.target.precise", precise);
        AutomationCliViewModel.runtimeFlow(execution.frameId, execution.activeNodeId, "move.target.lookups", "flow_metric", "[info]", "move.target.lookups", intState(state, "path.lookups", 0));
        AutomationCliViewModel.runtimeFlow(execution.frameId, execution.activeNodeId, "move.nav.phase", "flow_metric", "[info]", "move.nav.phase", stringParam(state, "move.nav.phase", "navigating"));
        AutomationCliViewModel.runtimeFlow(execution.frameId, execution.activeNodeId, "move.nav.stall", "flow_metric", "[info]", "move.nav.stall_ticks", intState(state, "move.nav.stall_ticks", 0));
        AutomationCliViewModel.runtimeFlow(execution.frameId, execution.activeNodeId, "move.nav.escape", "flow_metric", "[info]", "move.nav.escape", stringParam(state, "move.nav.escape_side", "none") + " / " + intState(state, "move.nav.escape_ticks", 0));
        AutomationCliViewModel.runtimeFlow(execution.frameId, execution.activeNodeId, "move.recovery.mode", "flow_metric", "[info]", "move.recovery.mode", stringParam(state, "move.recovery.mode", "none"));
        emitMovementDebug(execution, player, target, state, distance);

        if (distance <= stopDistance) {
            double startX = doubleState(state, "move.target.start_x", player.method_23317());
            double startZ = doubleState(state, "move.target.start_z", player.method_23321());
            double displacement = Math.sqrt(Math.pow(player.method_23317() - startX, 2.0D) + Math.pow(player.method_23321() - startZ, 2.0D));
            double startDistance = doubleState(state, "move.target.start_distance", distance);
            double requiredDisplacement = doubleState(state, "move.target.required_displacement", 0.0D);
            boolean startedNearTarget = startDistance <= stopDistance + NAV_MIN_COMPLETION_DISPLACEMENT;
            writeStateValue(state, "move.target.displacement", round(displacement));
            if (requiredDisplacement > 0.0D) {
                writeStateValue(state, "move.target.required_displacement", round(requiredDisplacement));
            }
            if (!startedNearTarget && displacement < NAV_MIN_COMPLETION_DISPLACEMENT) {
                state.put("move.target.active", false);
                state.put("move.failed", true);
                state.put("move.failure_reason", "no_player_displacement");
                writeStateValue(state, "path.status", "failed");
                writeStateValue(state, "path.distance", round(distance));
                releaseMovementInputs();
                AutomationReporter.mem("move.target.active", false);
                AutomationCliViewModel.runtimeFlow(execution.frameId, execution.activeNodeId, "move.target.phase", "flow_decision", "[fail]", "move.target.phase", "no_player_displacement");
                execution.activeNodeId = null;
                execution.activeNodeLabel = null;
                execution.activeAction = null;
                return;
            }
            if (requiredDisplacement > 0.0D && displacement < Math.max(NAV_MIN_COMPLETION_DISPLACEMENT, requiredDisplacement - Math.max(0.35D, stopDistance))) {
                state.put("move.target.active", false);
                state.put("move.failed", true);
                state.put("move.failure_reason", "relative_arrival_unproven");
                writeStateValue(state, "path.status", "failed");
                writeStateValue(state, "path.distance", round(distance));
                releaseMovementInputs();
                AutomationReporter.mem("move.target.active", false);
                AutomationCliViewModel.runtimeFlow(execution.frameId, execution.activeNodeId, "move.target.phase", "flow_decision", "[fail]", "move.target.phase", "relative_arrival_unproven");
                execution.activeNodeId = null;
                execution.activeNodeLabel = null;
                execution.activeAction = null;
                return;
            }
            if (precise) {
                player.method_5728(false);
            }
            clearMovementState(state);
            releaseMovementInputs();
            state.remove("parkour.active");
            state.remove("parkour.phase");
            AutomationReporter.mem("move.target.active", false);
            writeStateValue(state, "path.status", "complete");
            writeStateValue(state, "path.distance", round(distance));
            AutomationCliViewModel.runtimeFlow(execution.frameId, execution.activeNodeId, "move.target.phase", "flow_decision", "[done]", "move.target.phase", "arrived");
            execution.activeNodeId = null;
            execution.activeNodeLabel = null;
            execution.activeAction = null;
            return;
        }

        double lastX = doubleState(state, "move.nav.last_x", player.method_23317());
        double lastZ = doubleState(state, "move.nav.last_z", player.method_23321());
        double movedSquared = Math.pow(player.method_23317() - lastX, 2.0D) + Math.pow(player.method_23321() - lastZ, 2.0D);
        boolean groundedOrSwimming = player.method_24828() || player.method_5799() || player.method_5869();
        if (!groundedOrSwimming) {
            writeStateValue(state, "move.nav.stall_ticks", 0);
        } else if (movedSquared < 0.0025D) {
            writeStateValue(state, "move.nav.stall_ticks", intState(state, "move.nav.stall_ticks", 0) + 1);
        } else {
            writeStateValue(state, "move.nav.stall_ticks", 0);
        }
        writeStateValue(state, "move.nav.last_x", player.method_23317());
        writeStateValue(state, "move.nav.last_z", player.method_23321());

        double lastDistance = doubleState(state, "move.nav.last_distance", Double.MAX_VALUE);
        if (!groundedOrSwimming) {
            writeStateValue(state, "move.nav.blocked_ticks", 0);
        } else if (distance >= lastDistance - NAV_PROGRESS_EPSILON && movedSquared < 0.04D) {
            writeStateValue(state, "move.nav.blocked_ticks", intState(state, "move.nav.blocked_ticks", 0) + 1);
        } else {
            writeStateValue(state, "move.nav.blocked_ticks", 0);
        }
        writeStateValue(state, "move.nav.last_distance", distance);

        int blockedTicks = intState(state, "move.nav.blocked_ticks", 0);
        int stallTicks = intState(state, "move.nav.stall_ticks", 0);
        int escapeTicks = intState(state, "move.nav.escape_ticks", 0);
        boolean persistent = Boolean.TRUE.equals(state.get("move.nav.persistent"));
        if ((blockedTicks >= NAV_STUCK_TICKS || stallTicks >= NAV_STUCK_TICKS) && escapeTicks <= 0) {
            writeStateValue(state, "move.nav.escape_ticks", NAV_ESCAPE_TICKS);
            writeStateValue(state, "move.nav.escape_side", chooseEscapeSide(player, world, target, stringParam(state, "move.nav.escape_side", "none")));
            rememberNavigationAvoidance(state, player, world, target);
            String tactic = chooseRecoveryTactic(state, player, world);
            writeStateValue(state, "move.recovery.mode", tactic);
            writeStateValue(state, "move.recovery.attempts", intState(state, "move.recovery.attempts", 0) + 1);
            AutomationReporter.info("[move]", "progress stalled, recovery=" + tactic);
        }
        if ("wait_for_ground".equals(stringParam(state, "move.recovery.mode", "none")) && !groundedOrSwimming) {
            releaseMovementInputs();
            player.method_5728(false);
            writeStateValue(state, "move.nav.phase", "wait_for_ground");
            writeStateValue(state, "move.nav.airborne_wait", true);
            return;
        }
        if (escapeTicks > 0) {
            writeStateValue(state, "move.nav.escape_ticks", escapeTicks - 1);
        }
        int recoveryLimit = persistent ? NAV_PERSISTENT_RECOVERY_LIMIT : NAV_RECOVERY_LIMIT;
        if (intState(state, "move.recovery.attempts", 0) > recoveryLimit) {
            clearMovementState(state);
            releaseMovementInputs();
            state.put("move.target.active", false);
            writeStateValue(state, "path.status", "failed");
            writeStateValue(state, "move.nav.fail_reason", "recovery_limit_reached");
            AutomationCliViewModel.runtimeFlow(execution.frameId, execution.activeNodeId, "move.target.phase", "flow_decision", "[fail]", "move.target.phase", "recovery_limit_reached");
            execution.activeNodeId = null;
            execution.activeNodeLabel = null;
            execution.activeAction = null;
            return;
        }

        if (Boolean.TRUE.equals(state.get("move.nav.allow_break_blocks")) && (blockedTicks >= NAV_STUCK_TICKS / 2 || stallTicks >= NAV_STUCK_TICKS / 2)) {
            if (tryBreakNavigationBlock(player, world, target, state)) {
                writeStateValue(state, "move.nav.phase", "clear_block");
                releaseMovementInputs();
                facePositionHorizontal(player, target, NAV_LOOK_MAX_YAW_STEP);
                return;
            }
        }

        if ("parkour".equals(mode)) {
            updateParkourPhase(state, player, world, target);
            return;
        }

        boolean precisionApproach = precise && distance <= precisionDistance;
        boolean precisionSlow = precise && distance <= Math.max(stopDistance + 0.25D, slowDistance);
        boolean sprintNow = sprint && !(precise && distance <= Math.max(stopDistance + 0.45D, 0.65D));
        NavigatorDecision decision = intervalNavigationDecision(player, world, target, state, sprintNow, stopDistance, blockedTicks, stallTicks, intState(state, "move.nav.escape_ticks", 0), stringParam(state, "move.nav.escape_side", "none"), useY, precisionApproach, distance);
        writeStateValue(state, "move.nav.phase", decision.phase());
        writeStateValue(state, "move.nav.swim", decision.swim());
        writeStateValue(state, "move.nav.strafe_mode", decision.strafeMode());
        writeStateValue(state, "move.nav.steer_lock_ticks", intState(state, "move.nav.steer_lock_ticks", 0));

        if (intState(state, "move.nav.blocked_ticks", 0) >= NAV_STUCK_TICKS && player.method_24828()) {
            player.method_6043();
            writeStateValue(state, "move.nav.jump_window", 4);
            writeStateValue(state, "move.nav.phase", "unstick_jump");
        }

        int jumpWindow = intState(state, "move.nav.jump_window", 0);
        if (jumpWindow > 0) {
            writeStateValue(state, "move.nav.jump_window", jumpWindow - 1);
        }

        faceNavigationLook(player, decision, distance, blockedTicks, stallTicks);
        smoothPitchToward(player, class_3532.method_15363(player.method_36455(), -12.0F, 12.0F), 4.0F);
        applyNavigationDecision(player, decision, precise ? precisionSpeedScale(distance, stopDistance) : 1.0D);
    }

    private NavigatorDecision intervalNavigationDecision(class_746 player, class_638 world, class_243 target, Map<String, Object> state, boolean sprint, double stopDistance, int blockedTicks, int stallTicks, int escapeTicks, String escapeSide, boolean useY, boolean precisionApproach, double distance) {
        boolean forcedReplan = precisionApproach || blockedTicks >= NAV_STUCK_TICKS || stallTicks >= NAV_STUCK_TICKS || escapeTicks > 0;
        int decisionTicks = intState(state, "move.nav.decision_ticks", 0);
        class_243 cachedDirection = new class_243(
                doubleState(state, "move.nav.decision_x", 0.0D),
                0.0D,
                doubleState(state, "move.nav.decision_z", 0.0D)
        );
        if (!forcedReplan && decisionTicks > 0 && cachedDirection.method_1027() > 1.0E-4D) {
            writeStateValue(state, "move.nav.decision_ticks", decisionTicks - 1);
            class_243 lookTarget = player.method_19538().method_1019(cachedDirection.method_1029().method_1021(7.0D));
            return new NavigatorDecision(cachedDirection.method_1029(), lookTarget, Boolean.TRUE.equals(state.get("move.nav.decision_sprint")), false, Boolean.TRUE.equals(state.get("move.nav.decision_jump")), stringParam(state, "move.nav.decision_phase", "advance_interval"), stringParam(state, "move.nav.decision_strafe", "none"));
        }

        class_243 navigationTarget = precisionApproach ? target : chooseNavigationWaypoint(world, player, target, state, useY, blockedTicks, stallTicks, escapeTicks);
        NavigatorDecision decision = buildNavigationDecision(player, world, navigationTarget, state, sprint, stopDistance, blockedTicks, stallTicks, escapeTicks, escapeSide);
        if (precisionApproach && !decision.swim()) {
            class_243 direct = new class_243(target.field_1352 - player.method_23317(), 0.0D, target.field_1350 - player.method_23321());
            if (direct.method_1027() > 1.0E-4D) {
                boolean sprintPrecision = sprint && distance > Math.max(stopDistance + 0.75D, 1.15D);
                decision = new NavigatorDecision(direct.method_1029(), target, sprintPrecision, false, false, distance <= 0.55D ? "precision_finish" : "precision_approach", "none");
            }
        }
        decision = stabilizeNavigationDecision(state, player, world, decision, blockedTicks, stallTicks, escapeTicks);
        if (!decision.swim() && decision.moveDirection().method_1027() > 1.0E-4D) {
            class_243 normalized = decision.moveDirection().method_1029();
            writeStateValue(state, "move.nav.decision_ticks", NAV_DECISION_INTERVAL_TICKS);
            writeStateValue(state, "move.nav.decision_x", normalized.field_1352);
            writeStateValue(state, "move.nav.decision_z", normalized.field_1350);
            writeStateValue(state, "move.nav.decision_look_x", decision.lookTarget().field_1352);
            writeStateValue(state, "move.nav.decision_look_y", decision.lookTarget().field_1351);
            writeStateValue(state, "move.nav.decision_look_z", decision.lookTarget().field_1350);
            writeStateValue(state, "move.nav.decision_phase", decision.phase());
            writeStateValue(state, "move.nav.decision_strafe", decision.strafeMode());
            writeStateValue(state, "move.nav.decision_sprint", decision.sprint());
            writeStateValue(state, "move.nav.decision_jump", decision.jump());
        }
        return decision;
    }

    private void emitMovementDebug(ActiveExecution execution, class_746 player, class_243 target, Map<String, Object> state, double distance) {
        double startX = doubleState(state, "move.target.start_x", player.method_23317());
        double startZ = doubleState(state, "move.target.start_z", player.method_23321());
        double displacement = Math.sqrt(Math.pow(player.method_23317() - startX, 2.0D) + Math.pow(player.method_23321() - startZ, 2.0D));
        double requiredDisplacement = doubleState(state, "move.target.required_displacement", 0.0D);
        class_638 world = class_310.method_1551() == null ? null : class_310.method_1551().field_1687;
        class_2338 feet = player.method_24515();
        class_243 decisionDirection = new class_243(doubleState(state, "move.nav.decision_x", doubleState(state, "move.nav.steer_x", 0.0D)), 0.0D, doubleState(state, "move.nav.decision_z", doubleState(state, "move.nav.steer_z", 0.0D)));
        class_2338 ahead = decisionDirection.method_1027() > 1.0E-4D
                ? feet.method_10069((int) Math.signum(decisionDirection.field_1352), 0, (int) Math.signum(decisionDirection.field_1350))
                : feet;
        String blockSummary = world == null
                ? "world=null"
                : "feet=" + blockId(world, feet) + " head=" + blockId(world, feet.method_10084()) + " under=" + blockId(world, feet.method_10074()) + " ahead=" + blockId(world, ahead) + " ahead_under=" + blockId(world, ahead.method_10074());
        String routeSummary = "phase=" + stringParam(state, "move.nav.phase", "none")
                + " style=" + stringParam(state, "move.nav.path_style", "none")
                + " route=" + state.getOrDefault("move.nav.route.active", false)
                + " waypoint=" + state.getOrDefault("move.nav.waypoint.active", false)
                + " blocked=" + intState(state, "move.nav.blocked_ticks", 0)
                + " stall=" + intState(state, "move.nav.stall_ticks", 0)
                + " recovery=" + stringParam(state, "move.recovery.mode", "none");
        String motionSummary = "on_ground=" + player.method_24828()
                + " h_collision=" + player.field_5976
                + " sprinting=" + player.method_5624()
                + " vel=" + round(player.method_18798().field_1352) + "," + round(player.method_18798().field_1351) + "," + round(player.method_18798().field_1350)
                + " decision=" + round(decisionDirection.field_1352) + "," + round(decisionDirection.field_1350);
        String keySummary = "F=" + isInputPressed("forward") + " B=" + isInputPressed("back") + " L=" + isInputPressed("left") + " R=" + isInputPressed("right") + " J=" + isInputPressed("jump") + " S=" + isInputPressed("sprint");
        String inputSummary = player.field_3913 == null
                ? "input=null"
                : "forward=" + player.field_3913.field_3905 + " sideways=" + player.field_3913.field_3907 + " pf=" + player.field_3913.field_3910 + " pb=" + player.field_3913.field_3909 + " pl=" + player.field_3913.field_3908 + " pr=" + player.field_3913.field_3906 + " jump=" + player.field_3913.field_3904;
        int recorderTick = intState(state, "move.debug.recorder_tick", 0) + 1;
        int recorderSlot = recorderTick % 20;
        writeStateValue(state, "move.debug.recorder_tick", recorderTick);
        String recorderLine = "#" + recorderTick
                + " pos=" + round(player.method_23317()) + "," + round(player.method_23318()) + "," + round(player.method_23321())
                + " target=" + round(target.field_1352) + "," + round(target.field_1351) + "," + round(target.field_1350)
                + " dist=" + round(distance)
                + " yaw=" + round(player.method_36454())
                + " " + routeSummary
                + " " + motionSummary
                + " keys[" + keySummary + "]"
                + " input[" + inputSummary + "]"
                + " blocks[" + blockSummary + "]";
        writeStateValue(state, "move.debug.latest", recorderLine);
        writeStateValue(state, "move.debug.tick." + recorderSlot, recorderLine);
        AutomationCliViewModel.runtimeFlow(execution.frameId, execution.activeNodeId, "move.debug.pos", "flow_metric", "[debug]", "move.debug.pos", round(player.method_23317()) + "," + round(player.method_23318()) + "," + round(player.method_23321()));
        AutomationCliViewModel.runtimeFlow(execution.frameId, execution.activeNodeId, "move.debug.target", "flow_metric", "[debug]", "move.debug.target", round(target.field_1352) + "," + round(target.field_1351) + "," + round(target.field_1350));
        AutomationCliViewModel.runtimeFlow(execution.frameId, execution.activeNodeId, "move.debug.yaw", "flow_metric", "[debug]", "move.debug.yaw", round(player.method_36454()));
        AutomationCliViewModel.runtimeFlow(execution.frameId, execution.activeNodeId, "move.debug.distance", "flow_metric", "[debug]", "move.debug.distance", round(distance));
        AutomationCliViewModel.runtimeFlow(execution.frameId, execution.activeNodeId, "move.debug.displacement", "flow_metric", "[debug]", "move.debug.displacement", round(displacement) + " / " + round(requiredDisplacement));
        AutomationCliViewModel.runtimeFlow(execution.frameId, execution.activeNodeId, "move.debug.route", "flow_metric", "[debug]", "move.debug.route", routeSummary);
        AutomationCliViewModel.runtimeFlow(execution.frameId, execution.activeNodeId, "move.debug.motion", "flow_metric", "[debug]", "move.debug.motion", motionSummary);
        AutomationCliViewModel.runtimeFlow(execution.frameId, execution.activeNodeId, "move.debug.blocks", "flow_metric", "[debug]", "move.debug.blocks", blockSummary);
        AutomationCliViewModel.runtimeFlow(execution.frameId, execution.activeNodeId, "move.debug.keys", "flow_metric", "[debug]", "move.debug.keys", keySummary);
        if (player.field_3913 != null) {
            AutomationCliViewModel.runtimeFlow(execution.frameId, execution.activeNodeId, "move.debug.input", "flow_metric", "[debug]", "move.debug.input", inputSummary);
        }
        AutomationCliViewModel.runtimeFlow(execution.frameId, execution.activeNodeId, "move.debug.latest", "flow_metric", "[debug]", "move.debug.latest", recorderLine);
    }

    private boolean verifyRelativeArrival(class_746 player, Map<String, Object> params, Map<String, Object> state) {
        if (!Boolean.TRUE.equals(state.get("current.target.relative")) && !"relative_target".equals(stringParam(state, "current.target.id", ""))) {
            writeMovementResult(state, true, "success", "not_relative_target");
            return true;
        }
        class_243 target = new class_243(
                doubleState(state, "current.target.x", player.method_23317()),
                doubleState(state, "current.target.y", player.method_23318()),
                doubleState(state, "current.target.z", player.method_23321())
        );
        double stopDistance = doubleParam(params, "stop.distance", doubleState(state, "path.stop_distance", NAV_PRECISE_STOP_DISTANCE));
        double required = doubleState(state, "current.target.relative_distance", 0.0D);
        double startX = doubleState(state, "current.target.start_x", player.method_23317());
        double startZ = doubleState(state, "current.target.start_z", player.method_23321());
        double displacement = Math.sqrt(Math.pow(player.method_23317() - startX, 2.0D) + Math.pow(player.method_23321() - startZ, 2.0D));
        double distance = navigationDistance(player.method_19538(), target, false);
        double requiredMinimum = required <= 0.0D ? NAV_MIN_COMPLETION_DISPLACEMENT : Math.max(NAV_MIN_COMPLETION_DISPLACEMENT, required - Math.max(0.35D, stopDistance));
        writeStateValue(state, "move.verify.distance", round(distance));
        writeStateValue(state, "move.verify.displacement", round(displacement));
        writeStateValue(state, "move.verify.required_displacement", round(requiredMinimum));
        AutomationCliViewModel.runtimeFlow("", "verify_relative_arrival", "move.verify.target", "flow_metric", "[debug]", "move.verify.target", round(target.field_1352) + "," + round(target.field_1351) + "," + round(target.field_1350));
        AutomationCliViewModel.runtimeFlow("", "verify_relative_arrival", "move.verify.pos", "flow_metric", "[debug]", "move.verify.pos", round(player.method_23317()) + "," + round(player.method_23318()) + "," + round(player.method_23321()));
        AutomationCliViewModel.runtimeFlow("", "verify_relative_arrival", "move.verify.distance", "flow_metric", "[debug]", "move.verify.distance", round(distance));
        AutomationCliViewModel.runtimeFlow("", "verify_relative_arrival", "move.verify.displacement", "flow_metric", "[debug]", "move.verify.displacement", round(displacement) + " / " + round(requiredMinimum));
        if (distance > Math.max(stopDistance, NAV_PRECISE_STOP_DISTANCE)) {
            writeMovementResult(state, false, "failed", "relative_target_not_reached");
            return false;
        }
        if (displacement < requiredMinimum) {
            writeMovementResult(state, false, "failed", "relative_arrival_unproven");
            return false;
        }
        writeMovementResult(state, true, "success", "relative_arrival_verified");
        return true;
    }

    private void updateActiveAttack(ActiveExecution execution) {
        Map<String, Object> state = execution.state;
        if (!Boolean.TRUE.equals(state.get("attack.active"))) {
            return;
        }

        class_310 client = class_310.method_1551();
        class_746 player = client == null ? null : client.field_1724;
        class_638 world = client == null ? null : client.field_1687;
        class_636 interactionManager = client == null ? null : client.field_1761;

        if (player == null || world == null || interactionManager == null) {
            state.put("attack.failed", true);
            state.put("attack.failure_reason", "no_client_context");
            state.remove("attack.active");
            return;
        }

        class_1297 entity = findEntityByUuid(world, stringParam(state, "attack.target.uuid", ""));
        if (entity == null || !entity.method_5805()) {
            state.put("result.target.dead", true);
            state.put("attack.active", false);
            state.put("attack.phase", "done");
            state.remove("attack.until_dead");
            AutomationReporter.mem("result.target.dead", true);
            AutomationReporter.mem("attack.active", false);
            return;
        }

        double distance = player.method_19538().method_1022(entity.method_19538());
        double maxDistance = doubleState(state, "attack.range", 3.4D);
        boolean critEnabled = Boolean.TRUE.equals(state.get("attack.crit.enabled")) || "true".equalsIgnoreCase(stringParam(state, "attack.crit.enabled", "false"));
        boolean attackUntilDead = Boolean.TRUE.equals(state.get("attack.until_dead")) || "true".equalsIgnoreCase(stringParam(state, "attack.until_dead", "false"));
        int jumpDelayTicks = intState(state, "attack.crit.jump_wait_ticks", 3);
        int ticks = intState(state, "attack.ticks", 0) + 1;
        String phase = stringParam(state, "attack.phase", "prepare");

        state.put("attack.ticks", ticks);
        facePosition(player, entity.method_33571());
        writeStateValue(state, "current.target.distance", round(distance));
        AutomationCliViewModel.runtimeFlow(execution.frameId, execution.activeNodeId, "attack.phase", "flow_phase", "[run ]", "attack.phase", phase);
        AutomationCliViewModel.runtimeFlow(execution.frameId, execution.activeNodeId, "attack.distance", "flow_metric", "[info]", "attack.distance", round(distance));
        AutomationCliViewModel.runtimeFlow(execution.frameId, execution.activeNodeId, "attack.range", "flow_metric", "[info]", "attack.range", maxDistance);

        if (distance > maxDistance) {
            state.put("attack.failed", true);
            state.put("attack.failure_reason", "target_out_of_range");
            state.remove("attack.active");
            AutomationCliViewModel.runtimeFlow(execution.frameId, execution.activeNodeId, "attack.phase", "flow_decision", "[block]", "attack.phase", "target_out_of_range");
            return;
        }

        switch (phase) {
            case "prepare" -> {
                if (critEnabled && player.method_24828()) {
                    player.method_6043();
                    state.put("attack.phase", "jump_delay");
                    state.put("attack.ticks", 0);
                    AutomationReporter.mem("attack.phase", "jump_delay");
                    AutomationCliViewModel.runtimeFlow(execution.frameId, execution.activeNodeId, "attack.phase", "flow_phase", "[branch]", "attack.phase", "jump_delay");
                    return;
                }
                state.put("attack.phase", "strike");
                state.put("attack.ticks", 0);
                AutomationReporter.mem("attack.phase", "strike");
                AutomationCliViewModel.runtimeFlow(execution.frameId, execution.activeNodeId, "attack.phase", "flow_phase", "[branch]", "attack.phase", "strike");
            }
            case "jump_delay" -> {
                if (ticks >= Math.max(1, jumpDelayTicks)) {
                    state.put("attack.phase", "strike");
                    state.put("attack.ticks", 0);
                    AutomationReporter.mem("attack.phase", "strike");
                    AutomationCliViewModel.runtimeFlow(execution.frameId, execution.activeNodeId, "attack.phase", "flow_phase", "[branch]", "attack.phase", "strike");
                }
                return;
            }
            case "strike" -> {
                if (!isCrosshairOnEntity(client, entity)) {
                    state.put("attack.phase", "align");
                    state.put("attack.ticks", 0);
                    AutomationReporter.mem("attack.phase", "align");
                    AutomationCliViewModel.runtimeFlow(execution.frameId, execution.activeNodeId, "attack.phase", "flow_phase", "[info]", "attack.phase", "align");
                    return;
                }
                interactionManager.method_2918(player, entity);
                player.method_6104(class_1268.field_5808);
                state.put("result.action", "SUCCESS");
                state.put("attack.phase", "cooldown");
                state.put("attack.ticks", 0);
                AutomationReporter.mem("result.action", "SUCCESS");
                AutomationReporter.mem("attack.phase", "cooldown");
                AutomationCliViewModel.runtimeFlow(execution.frameId, execution.activeNodeId, "attack.phase", "flow_phase", "[run ]", "attack.phase", "cooldown");
                return;
            }
            case "align" -> {
                if (isCrosshairOnEntity(client, entity) || ticks >= 8) {
                    state.put("attack.phase", "strike");
                    state.put("attack.ticks", 0);
                    AutomationReporter.mem("attack.phase", "strike");
                    AutomationCliViewModel.runtimeFlow(execution.frameId, execution.activeNodeId, "attack.phase", "flow_phase", "[branch]", "attack.phase", "strike");
                }
                return;
            }
            case "cooldown" -> {
                if (entity == null || !entity.method_5805()) {
                    state.put("result.target.dead", true);
                    state.put("attack.active", false);
                    state.put("attack.phase", "done");
                    state.remove("attack.until_dead");
                    AutomationReporter.mem("result.target.dead", true);
                    AutomationReporter.mem("attack.active", false);
                    AutomationCliViewModel.runtimeFlow(execution.frameId, execution.activeNodeId, "attack.phase", "flow_decision", "[done]", "attack.phase", "target_dead");
                    execution.activeNodeId = null;
                    execution.activeNodeLabel = null;
                    execution.activeAction = null;
                    return;
                }
                if (ticks >= 4) {
                    if (attackUntilDead) {
                        state.put("attack.phase", "prepare");
                        state.put("attack.ticks", 0);
                        AutomationReporter.mem("attack.phase", "prepare");
                        AutomationCliViewModel.runtimeFlow(execution.frameId, execution.activeNodeId, "attack.phase", "flow_decision", "[loop]", "attack.phase", "target_alive_continue");
                    } else {
                        state.put("result.target.dead", !entity.method_5805());
                        state.put("attack.active", false);
                        state.put("attack.phase", "done");
                        state.remove("attack.until_dead");
                        AutomationReporter.mem("result.target.dead", !entity.method_5805());
                        AutomationReporter.mem("attack.active", false);
                        AutomationCliViewModel.runtimeFlow(execution.frameId, execution.activeNodeId, "attack.phase", "flow_decision", "[done]", "attack.phase", Boolean.TRUE.equals(state.get("result.target.dead")) ? "dead_confirmed" : "cooldown_complete");
                        execution.activeNodeId = null;
                        execution.activeNodeLabel = null;
                        execution.activeAction = null;
                    }
                }
                return;
            }
            default -> {
                state.put("attack.active", false);
                state.put("attack.phase", "done");
                state.remove("attack.until_dead");
                AutomationReporter.mem("attack.active", false);
                AutomationReporter.mem("attack.phase", "done");
                AutomationCliViewModel.runtimeFlow(execution.frameId, execution.activeNodeId, "attack.phase", "flow_decision", "[done]", "attack.phase", "done");
                execution.activeNodeId = null;
                execution.activeNodeLabel = null;
                execution.activeAction = null;
            }
        }
    }

    private void updateActiveMining(ActiveExecution execution) {
        Map<String, Object> state = execution.state;
        if (!Boolean.TRUE.equals(state.get("mine.active"))) {
            return;
        }
        class_310 client = class_310.method_1551();
        class_746 player = client == null ? null : client.field_1724;
        class_638 world = client == null ? null : client.field_1687;
        class_636 interactionManager = client == null ? null : client.field_1761;
        if (player == null || world == null || interactionManager == null) {
            state.put("mine.failed", true);
            state.put("mine.failure_reason", "no_client_context");
            state.remove("mine.active");
            return;
        }
        class_2338 pos = new class_2338(intState(state, "mine.target.x", 0), intState(state, "mine.target.y", 0), intState(state, "mine.target.z", 0));
        String expectedId = stringParam(state, "mine.target.id", "");
        int ticks = intState(state, "mine.ticks", 0) + 1;
        state.put("mine.ticks", ticks);
        class_2680 blockState = world.method_8320(pos);
        class_2960 currentId = class_7923.field_41175.method_10221(blockState.method_26204());
        boolean gone = world.method_22347(pos) || (!expectedId.isBlank() && currentId != null && !expectedId.equals(currentId.toString()));
        AutomationCliViewModel.runtimeFlow(execution.frameId, execution.activeNodeId, "mine.phase", "flow_phase", "[run ]", "mine.phase", gone ? "complete" : "breaking");
        AutomationCliViewModel.runtimeFlow(execution.frameId, execution.activeNodeId, "mine.ticks", "flow_metric", "[info]", "mine.ticks", ticks);
        if (gone) {
            state.put("result.block.broken", true);
            state.put("result.action", "SUCCESS");
            state.remove("mine.active");
            AutomationReporter.mem("result.block.broken", true);
            AutomationReporter.mem("result.action", "SUCCESS");
            AutomationReporter.mem("mine.active", false);
            return;
        }
        double distance = player.method_19538().method_1022(class_243.method_24953(pos));
        if (distance > 5.2D) {
            state.put("mine.failed", true);
            state.put("mine.failure_reason", "target_out_of_range");
            state.remove("mine.active");
            return;
        }
        facePosition(player, class_243.method_24953(pos));
        if (!isCrosshairOnBlock(client, pos)) {
            AutomationCliViewModel.runtimeFlow(execution.frameId, execution.activeNodeId, "mine.phase", "flow_phase", "[info]", "mine.phase", "align");
            return;
        }
        boolean started = Boolean.TRUE.equals(state.get("mine.started"));
        if (!started) {
            boolean began = interactionManager.method_2910(pos, class_2350.field_11036);
            player.method_6104(class_1268.field_5808);
            state.put("mine.started", began);
            if (!began && !player.method_7337()) {
                state.put("mine.failed", true);
                state.put("mine.failure_reason", "attack_block_failed");
                state.remove("mine.active");
            }
            return;
        }
        interactionManager.method_2902(pos, class_2350.field_11036);
        if (ticks % 4 == 0) {
            player.method_6104(class_1268.field_5808);
        }
        if (ticks >= 200) {
            interactionManager.method_2925();
            state.put("mine.failed", true);
            state.put("mine.failure_reason", "mine_timeout");
            state.remove("mine.active");
        }
    }


    private boolean isCrosshairOnEntity(class_310 client, class_1297 entity) {
        if (client == null || entity == null) {
            return false;
        }
        class_239 hitResult = piercingRaycast(client, AUTOMATION_RAY_DISTANCE).hit();
        if (!(hitResult instanceof class_3966 entityHitResult)) {
            return false;
        }
        return entityHitResult.method_17782() != null && entityHitResult.method_17782().method_5628() == entity.method_5628();
    }

    private boolean isCrosshairOnBlock(class_310 client, class_2338 pos) {
        if (client == null || pos == null) {
            return false;
        }
        class_239 hitResult = piercingRaycast(client, AUTOMATION_RAY_DISTANCE).hit();
        if (!(hitResult instanceof class_3965 blockHitResult)) {
            return false;
        }
        return pos.equals(blockHitResult.method_17777());
    }

    private void updateWorldDiagnostics(ActiveExecution execution, class_310 client, class_746 player, class_638 world) {
        Map<String, Object> state = execution.state;
        if (client == null || player == null || world == null) {
            return;
        }

        PiercingRayResult rayResult = piercingRaycast(client, AUTOMATION_RAY_DISTANCE);
        class_239 hitResult = rayResult.hit();
        if (hitResult != null) {
            writeStateValue(state, "world.ray.kind", hitResult.method_17783().name().toLowerCase(Locale.ROOT));
            writeStateValue(state, "world.ray.distance", round(hitResult.method_17784().method_1022(player.method_33571())));
            writeStateValue(state, "world.ray.pierced_blocks", rayResult.piercedBlocks());
            writeStateValue(state, "world.ray.last_pass_block", rayResult.lastPassThroughBlock());
            AutomationCliViewModel.worldProbe(execution.frameId, "ray.kind", "flow_phase", "[run ]", "world.ray.kind", hitResult.method_17783().name().toLowerCase(Locale.ROOT));
            AutomationCliViewModel.worldProbe(execution.frameId, "ray.distance", "flow_metric", "[info]", "world.ray.distance", round(hitResult.method_17784().method_1022(player.method_33571())));
            AutomationCliViewModel.worldProbe(execution.frameId, "ray.pierced", "flow_metric", rayResult.piercedBlocks() > 0 ? "[ok  ]" : "[info]", "world.ray.pierced_blocks", rayResult.piercedBlocks());
            if (!rayResult.lastPassThroughBlock().isBlank()) {
                AutomationCliViewModel.worldProbe(execution.frameId, "ray.pass_block", "flow_metric", "[info]", "world.ray.pass_block", rayResult.lastPassThroughBlock());
            }
            switch (hitResult.method_17783()) {
                case field_1332 -> {
                    class_3965 blockHitResult = (class_3965) hitResult;
                    class_2338 blockPos = blockHitResult.method_17777();
                    class_2960 blockId = class_7923.field_41175.method_10221(world.method_8320(blockPos).method_26204());
                    writeStateValue(state, "world.ray.face", blockHitResult.method_17780().method_15434());
                    writeStateValue(state, "world.ray.block.id", blockId == null ? "unknown" : blockId.toString());
                    AutomationCliViewModel.worldProbe(execution.frameId, "ray.block", "flow_metric", "[info]", "world.ray.block", blockId == null ? "unknown" : blockId.toString());
                    AutomationCliViewModel.worldProbe(execution.frameId, "ray.face", "flow_metric", "[info]", "world.ray.face", blockHitResult.method_17780().method_15434());
                }
                case field_1331 -> {
                    class_3966 entityHitResult = (class_3966) hitResult;
                    class_1297 entity = entityHitResult.method_17782();
                    class_2960 entityId = class_7923.field_41177.method_10221(entity.method_5864());
                    writeStateValue(state, "world.ray.entity.id", entityId == null ? entity.method_5477().getString() : entityId.toString());
                    writeStateValue(state, "world.ray.entity.name", entity.method_5477().getString());
                    AutomationCliViewModel.worldProbe(execution.frameId, "ray.entity", "flow_metric", "[info]", "world.ray.entity", entityId == null ? entity.method_5477().getString() : entityId.toString());
                }
                case field_1333 -> {
                    writeStateValue(state, "world.ray.face", "none");
                    writeStateValue(state, "world.ray.block.id", "none");
                    writeStateValue(state, "world.ray.entity.id", "none");
                    AutomationCliViewModel.worldProbe(execution.frameId, "ray.miss", "flow_decision", "[info]", "world.ray.result", "miss");
                }
            }
        }

        if (hasTargetPosition(state)) {
            class_243 target = new class_243(
                    doubleState(state, "current.target.x", player.method_23317()),
                    doubleState(state, "current.target.y", player.method_23320()),
                    doubleState(state, "current.target.z", player.method_23321())
            );
            double distance = player.method_19538().method_1022(target);
            PiercingVisibilityResult visibility = piercingVisibility(world, player, target);
            boolean visible = visibility.visible();
            writeStateValue(state, "current.target.distance", round(distance));
            writeStateValue(state, "current.target.visible", visible);
            writeStateValue(state, "current.target.visibility_blocker", visibility.blocker());
            writeStateValue(state, "current.target.visibility_pierced", visibility.piercedBlocks());
            writeStateValue(state, "current.target.reachable", distance <= 4.5D);
            AutomationCliViewModel.worldProbe(execution.frameId, "target.distance", "flow_metric", "[info]", "target.distance", round(distance));
            AutomationCliViewModel.worldProbe(execution.frameId, "target.visible", "flow_decision", visible ? "[ok  ]" : "[warn]", "target.visible", visible);
            AutomationCliViewModel.worldProbe(execution.frameId, "target.visibility_pierced", "flow_metric", visibility.piercedBlocks() > 0 ? "[ok  ]" : "[info]", "target.visibility_pierced", visibility.piercedBlocks());
            if (!visibility.blocker().isBlank()) {
                AutomationCliViewModel.worldProbe(execution.frameId, "target.visibility_blocker", "flow_metric", "[warn]", "target.visibility_blocker", visibility.blocker());
            }
            AutomationCliViewModel.worldProbe(execution.frameId, "target.reachable", "flow_decision", distance <= 4.5D ? "[ok  ]" : "[wait]", "target.reachable", distance <= 4.5D);
        } else {
            writeStateValue(state, "current.target.distance", "none");
            writeStateValue(state, "current.target.visible", false);
            writeStateValue(state, "current.target.reachable", false);
            AutomationCliViewModel.worldProbe(execution.frameId, "target.none", "flow_decision", "[info]", "target.probe", "no active target");
        }

        writeStateValue(state, "world.ui.screen", client.field_1755 == null ? "world" : client.field_1755.getClass().getSimpleName());
        writeStateValue(state, "world.executor.frames", this.executionStack.size());
        writeStateValue(state, "world.executor.inputs_held", countHeldInputs());
        if (!state.containsKey("path.status")) {
            writeStateValue(state, "path.status", "idle");
        }
    }

    private void writeStateValue(Map<String, Object> state, String key, Object value) {
        Object existing = state.get(key);
        if (Objects.equals(existing, value)) {
            return;
        }
        state.put(key, value);
        AutomationReporter.mem(key, value);
    }

    private double round(double value) {
        return Math.round(value * 100.0D) / 100.0D;
    }

    private void incrementStateCounter(Map<String, Object> state, String key) {
        writeStateValue(state, key, intState(state, key, 0) + 1);
    }

    private int countHeldInputs() {
        int count = 0;
        for (HeldInput input : this.heldInputs.values()) {
            if (input != null && input.pressed) {
                count++;
            }
        }
        return count;
    }

    private void applyRelativeMotion(class_746 player, String direction, boolean sprint) {
        float yawRadians = (float) Math.toRadians(player.method_36454());
        class_243 forward = new class_243(-Math.sin(yawRadians), 0.0D, Math.cos(yawRadians));
        class_243 side = new class_243(forward.field_1350, 0.0D, -forward.field_1352);
        class_243 directionVector = switch (direction.toLowerCase(Locale.ROOT)) {
            case "back", "backward" -> forward.method_1021(-1.0D);
            case "left" -> side;
            case "right" -> side.method_1021(-1.0D);
            default -> forward;
        };
        applyHorizontalMotion(player, directionVector, sprint);
    }

    private void applyMoveToward(class_746 player, class_243 target, boolean sprint) {
        class_243 delta = new class_243(target.field_1352 - player.method_23317(), 0.0D, target.field_1350 - player.method_23321());
        if (delta.method_1027() < 1.0E-4D) {
            player.method_5728(false);
            return;
        }
        applyHorizontalMotion(player, delta.method_1029(), sprint);
    }

    private void applyHorizontalMotion(class_746 player, class_243 direction, boolean sprint) {
        applyHorizontalMotion(player, direction, sprint, 1.0D, true);
    }

    private void applyHorizontalMotion(class_746 player, class_243 direction, boolean sprint, double speedScale) {
        applyHorizontalMotion(player, direction, sprint, speedScale, true);
    }

    private void applyHorizontalMotion(class_746 player, class_243 direction, boolean sprint, double speedScale, boolean allowBackInput) {
        class_243 normalized = direction.method_1027() < 1.0E-4D ? class_243.field_1353 : direction.method_1029();
        double scale = class_3532.method_15350(speedScale, 0.18D, 1.0D);
        boolean sprinting = sprint && scale > 0.85D;
        player.method_5728(sprinting);
        applyLocomotionInputs(player, normalized, sprinting, allowBackInput);
        applyPlayerInputState(player);
    }

    private void applyLocomotionInputs(class_746 player, class_243 desiredDirection, boolean sprint) {
        applyLocomotionInputs(player, desiredDirection, sprint, true);
    }

    private void applyLocomotionInputs(class_746 player, class_243 desiredDirection, boolean sprint, boolean allowBackInput) {
        if (desiredDirection.method_1027() < 1.0E-4D) {
            releaseMovementInputs();
            return;
        }
        float yawRadians = (float) Math.toRadians(player.method_36454());
        class_243 forward = new class_243(-Math.sin(yawRadians), 0.0D, Math.cos(yawRadians));
        class_243 left = new class_243(forward.field_1350, 0.0D, -forward.field_1352);
        double forwardAmount = desiredDirection.method_1026(forward);
        double leftAmount = desiredDirection.method_1026(left);
        setHeldInput("forward", forwardAmount > 0.18D);
        setHeldInput("back", allowBackInput && forwardAmount < -0.35D);
        setHeldInput("left", leftAmount > 0.32D);
        setHeldInput("right", leftAmount < -0.32D);
        setHeldInput("sprint", sprint && forwardAmount > 0.62D);
    }

    private int blocksToTicks(double blocks) {
        return Math.max(1, (int) Math.round(blocks * 6.0D));
    }

    private String stringParam(Map<String, Object> map, String key, String fallback) {
        Object value = map.get(key);
        return value == null ? fallback : String.valueOf(value);
    }

    private int intParam(Map<String, Object> map, String key, int fallback) {
        Object value = map.get(key);
        if (value instanceof Number number) {
            return number.intValue();
        }
        if (value instanceof String text) {
            try {
                return Integer.parseInt(text);
            } catch (NumberFormatException ignored) {
            }
        }
        return fallback;
    }

    private double doubleParam(Map<String, Object> map, String key, double fallback) {
        Object value = map.get(key);
        if (value instanceof Number number) {
            return number.doubleValue();
        }
        if (value instanceof String text) {
            try {
                return Double.parseDouble(text);
            } catch (NumberFormatException ignored) {
            }
        }
        return fallback;
    }

    private boolean booleanParam(Map<String, Object> map, String key, boolean fallback) {
        Object value = map.get(key);
        if (value instanceof Boolean bool) {
            return bool;
        }
        if (value instanceof Number number) {
            return number.intValue() != 0;
        }
        if (value instanceof String text) {
            if ("true".equalsIgnoreCase(text) || "yes".equalsIgnoreCase(text) || "1".equals(text)) {
                return true;
            }
            if ("false".equalsIgnoreCase(text) || "no".equalsIgnoreCase(text) || "0".equals(text)) {
                return false;
            }
        }
        return fallback;
    }

    private boolean hasResolvedParam(Map<String, Object> map, String key) {
        if (!map.containsKey(key)) {
            return false;
        }
        Object value = map.get(key);
        if (value == null) {
            return false;
        }
        String text = String.valueOf(value);
        return !text.isBlank() && !(text.startsWith("${") && text.endsWith("}"));
    }

    private int intState(Map<String, Object> state, String key, int fallback) {
        Object value = state.get(key);
        if (value instanceof Number number) {
            return number.intValue();
        }
        if (value instanceof String text) {
            try {
                return Integer.parseInt(text);
            } catch (NumberFormatException ignored) {
            }
        }
        return fallback;
    }

    private double doubleState(Map<String, Object> state, String key, double fallback) {
        Object value = state.get(key);
        if (value instanceof Number number) {
            return number.doubleValue();
        }
        if (value instanceof String text) {
            try {
                return Double.parseDouble(text);
            } catch (NumberFormatException ignored) {
            }
        }
        return fallback;
    }

    private boolean hasTargetPosition(Map<String, Object> state) {
        return state.containsKey("current.target.x") && state.containsKey("current.target.y") && state.containsKey("current.target.z");
    }

    private class_2338 targetBlockPos(Map<String, Object> state) {
        return new class_2338(
                (int) Math.floor(doubleState(state, "current.target.x", 0.0D)),
                (int) Math.floor(doubleState(state, "current.target.y", 0.0D)),
                (int) Math.floor(doubleState(state, "current.target.z", 0.0D))
        );
    }

    private class_243 resolveStandablePosition(class_638 world, class_746 player, double x, double z, boolean allowSwim) {
        int baseX = class_3532.method_15357(x);
        int baseZ = class_3532.method_15357(z);
        class_2338 playerPos = player.method_24515();
        class_243 best = null;
        double bestScore = Double.MAX_VALUE;
        for (int radius = 0; radius <= 3; radius++) {
            for (int dx = -radius; dx <= radius; dx++) {
                for (int dz = -radius; dz <= radius; dz++) {
                    if (Math.max(Math.abs(dx), Math.abs(dz)) != radius) {
                        continue;
                    }
                    for (int y = playerPos.method_10264() + 8; y >= playerPos.method_10264() - 16; y--) {
                        class_2338 feet = new class_2338(baseX + dx, y, baseZ + dz);
                        if (!canStandAt(world, feet) && !(allowSwim && isWaterBlock(world, feet))) {
                            continue;
                        }
                        MovementSafety safety = movementSafetyAt(world, feet, 3);
                        if (!allowSwim && safety.water()) {
                            continue;
                        }
                        if (!safety.safe()) {
                            continue;
                        }
                        double elevationCost = Math.abs(y - playerPos.method_10264()) * 0.9D;
                        double offsetCost = Math.sqrt(dx * dx + dz * dz) * 2.0D;
                        double pocketCost = pocketRisk(world, feet) * 8.0D;
                        double score = elevationCost + offsetCost + pocketCost;
                        if (score < bestScore) {
                            bestScore = score;
                            best = radius == 0 ? new class_243(x, feet.method_10264(), z) : new class_243(feet.method_10263() + 0.5D, feet.method_10264(), feet.method_10260() + 0.5D);
                        }
                    }
                }
            }
            if (best != null) {
                return best;
            }
        }
        return null;
    }

    private class_243 resolveStandablePositionNearY(class_638 world, class_746 player, double x, double y, double z, boolean allowSwim) {
        int baseX = class_3532.method_15357(x);
        int baseY = class_3532.method_15357(y);
        int baseZ = class_3532.method_15357(z);
        class_243 best = null;
        double bestScore = Double.MAX_VALUE;
        for (int radius = 0; radius <= 3; radius++) {
            for (int dx = -radius; dx <= radius; dx++) {
                for (int dz = -radius; dz <= radius; dz++) {
                    if (Math.max(Math.abs(dx), Math.abs(dz)) != radius) {
                        continue;
                    }
                    for (int dy = -4; dy <= 4; dy++) {
                        class_2338 feet = new class_2338(baseX + dx, baseY + dy, baseZ + dz);
                        if (!canStandAt(world, feet) && !(allowSwim && isWaterBlock(world, feet))) {
                            continue;
                        }
                        MovementSafety safety = movementSafetyAt(world, feet, 3);
                        if (!allowSwim && safety.water()) {
                            continue;
                        }
                        if (!safety.safe()) {
                            continue;
                        }
                        double verticalCost = Math.abs(dy) * 1.7D;
                        double offsetCost = Math.sqrt(dx * dx + dz * dz) * 2.0D;
                        double playerCost = player.method_19538().method_1025(class_243.method_24955(feet)) * 0.001D;
                        double score = verticalCost + offsetCost + playerCost + pocketRisk(world, feet) * 8.0D;
                        if (score < bestScore) {
                            bestScore = score;
                            best = radius == 0 ? new class_243(x, feet.method_10264(), z) : new class_243(feet.method_10263() + 0.5D, feet.method_10264(), feet.method_10260() + 0.5D);
                        }
                    }
                }
            }
            if (best != null) {
                return best;
            }
        }
        return null;
    }

    private class_243 resolveApproachPosition(class_638 world, class_746 player, class_2338 target, boolean allowSwim) {
        List<class_2338> candidates = new ArrayList<>();
        candidates.add(target.method_10095());
        candidates.add(target.method_10072());
        candidates.add(target.method_10078());
        candidates.add(target.method_10067());
        candidates.add(target.method_10095().method_10078());
        candidates.add(target.method_10095().method_10067());
        candidates.add(target.method_10072().method_10078());
        candidates.add(target.method_10072().method_10067());
        class_243 best = null;
        double bestScore = Double.MAX_VALUE;
        for (class_2338 candidate : candidates) {
            class_243 stand = resolveStandablePosition(world, player, candidate.method_10263() + 0.5D, candidate.method_10260() + 0.5D, allowSwim);
            if (stand == null) {
                continue;
            }
            double score = player.method_19538().method_1025(stand) + pocketRisk(world, class_2338.method_49638(stand)) * 16.0D;
            if (score < bestScore) {
                bestScore = score;
                best = stand;
            }
        }
        return best;
    }

    private boolean canStandAt(class_638 world, class_2338 feet) {
        class_2338 below = feet.method_10074();
        return canPassThrough(world, feet)
                && canPassThrough(world, feet.method_10084())
                && supportsStanding(world, below);
    }

    private boolean canPassThrough(class_638 world, class_2338 pos) {
        class_2680 state = world.method_8320(pos);
        return state.method_26215() || state.method_26220(world, pos).method_1110() || !world.method_8316(pos).method_15769();
    }

    private boolean supportsStanding(class_638 world, class_2338 pos) {
        class_2680 state = world.method_8320(pos);
        return !state.method_26215() && !state.method_26220(world, pos).method_1110() && !isDangerBlock(world, pos);
    }

    private double pocketRisk(class_638 world, class_2338 feet) {
        if (!canPassThrough(world, feet) || !canPassThrough(world, feet.method_10084())) {
            return 1.0D;
        }
        int exits = safeExitCount(world, feet);
        int blocked = 4 - exits;
        boolean corridor = hasOpposingSafeExits(world, feet);
        boolean lowCeiling = !canPassThrough(world, feet.method_10086(2));
        boolean deepDrop = isUnsafeDrop(world, feet.method_10074(), 4);
        double risk = corridor ? 0.08D : blocked * 0.18D;
        if (exits == 0) {
            risk += 0.75D;
        } else if (exits == 1) {
            risk += 0.28D;
        } else if (exits >= 3) {
            risk -= 0.22D;
        }
        if (lowCeiling && exits <= 1) {
            risk += 0.25D;
        } else if (lowCeiling && !corridor) {
            risk += 0.08D;
        }
        if (deepDrop) {
            risk += 0.35D;
        }
        if (isWaterBlock(world, feet) && exits <= 2) {
            risk += 0.18D;
        }
        if (corridor) {
            risk = Math.min(risk, NAV_CORRIDOR_POCKET_LIMIT);
        }
        return class_3532.method_15350(risk, 0.0D, 1.0D);
    }

    private int safeExitCount(class_638 world, class_2338 feet) {
        int exits = 0;
        for (class_2350 direction : class_2350.class_2353.field_11062) {
            if (isSafeExit(world, feet.method_10093(direction))) {
                exits++;
            }
        }
        return exits;
    }

    private boolean hasOpposingSafeExits(class_638 world, class_2338 feet) {
        boolean north = isSafeExit(world, feet.method_10095());
        boolean south = isSafeExit(world, feet.method_10072());
        boolean east = isSafeExit(world, feet.method_10078());
        boolean west = isSafeExit(world, feet.method_10067());
        return north && south || east && west;
    }

    private boolean isSafeExit(class_638 world, class_2338 feet) {
        if (canStandAt(world, feet) && !isUnsafeDrop(world, feet.method_10074(), 4) && !isDangerBlock(world, feet) && !isDangerBlock(world, feet.method_10074())) {
            return true;
        }
        class_2338 stepUp = feet.method_10084();
        return canStandAt(world, stepUp) && canPassThrough(world, stepUp.method_10084()) && !isUnsafeDrop(world, stepUp.method_10074(), 4) && !isDangerBlock(world, stepUp);
    }

    private boolean isDangerBlock(class_638 world, class_2338 pos) {
        class_2960 id = class_7923.field_41175.method_10221(world.method_8320(pos).method_26204());
        if (id == null) {
            return false;
        }
        String value = id.toString();
        return value.contains("lava") || value.contains("fire") || value.contains("cactus") || value.contains("magma") || value.contains("campfire") || value.contains("powder_snow");
    }

    private Object readStatValue(class_746 player, String statRef) {
        String normalized = statRef == null ? "" : statRef.trim();
        if (normalized.startsWith("ref.stat.")) {
            normalized = normalized.substring("ref.stat.".length());
        }
        return switch (normalized) {
            case "self.health" -> player.method_6032();
            case "self.max_health" -> player.method_6063();
            case "self.hunger" -> player.method_7344().method_7586();
            case "self.saturation" -> player.method_7344().method_7589();
            case "self.air" -> player.method_5669();
            case "self.x" -> player.method_23317();
            case "self.y" -> player.method_23318();
            case "self.z" -> player.method_23321();
            case "self.yaw" -> player.method_36454();
            case "self.pitch" -> player.method_36455();
            case "self.velocity_x" -> player.method_18798().field_1352;
            case "self.velocity_y" -> player.method_18798().field_1351;
            case "self.velocity_z" -> player.method_18798().field_1350;
            case "self.speed_horizontal" -> Math.sqrt(player.method_18798().field_1352 * player.method_18798().field_1352 + player.method_18798().field_1350 * player.method_18798().field_1350);
            case "self.fall_distance" -> player.field_6017;
            case "self.fire_ticks" -> player.method_20802();
            case "self.on_ground" -> player.method_24828();
            case "self.sneaking" -> player.method_5715();
            case "self.sprinting" -> player.method_5624();
            case "self.swimming" -> player.method_5681();
            case "self.touching_water" -> player.method_5799();
            case "self.submerged_water" -> player.method_5869();
            case "self.in_lava" -> player.method_5771();
            case "self.has_vehicle" -> player.method_5765();
            case "self.creative" -> player.method_7337();
            case "self.spectator" -> player.method_7325();
            case "self.using_item" -> player.method_6115();
            default -> null;
        };
    }

    private boolean removeInventoryItems(class_1661 inventory, String itemId, int amount) {
        int remaining = amount;
        for (int i = 0; i < inventory.method_5439() && remaining > 0; i++) {
            class_1799 stack = inventory.method_5438(i);
            if (stack.method_7960() || !itemMatches(stack, itemId)) {
                continue;
            }
            int removed = Math.min(remaining, stack.method_7947());
            stack.method_7934(removed);
            remaining -= removed;
        }
        return remaining == 0;
    }

    private int findHotbarSlot(class_1661 inventory, String itemId) {
        for (int i = 0; i < 9; i++) {
            class_1799 stack = inventory.method_5438(i);
            if (!stack.method_7960() && itemMatches(stack, itemId)) {
                return i;
            }
        }
        return -1;
    }

    private int moveInventoryItemToSelectedHotbar(class_1661 inventory, String itemId) {
        int selected = Math.max(0, Math.min(8, inventory.field_7545));
        for (int i = 9; i < inventory.method_5439(); i++) {
            class_1799 stack = inventory.method_5438(i);
            if (stack.method_7960() || !itemMatches(stack, itemId)) {
                continue;
            }
            class_1799 selectedStack = inventory.method_5438(selected).method_7972();
            inventory.method_5447(selected, stack.method_7972());
            inventory.method_5447(i, selectedStack);
            return selected;
        }
        return -1;
    }

    private boolean startContainerTransfer(class_636 interactionManager, class_746 player, int slotIndex, Map<String, Object> params, Map<String, Object> state, String direction) {
        if (player == null || player.field_7512 == null || interactionManager == null) {
            state.put("container.transfer.failure_reason", "no_open_container");
            return false;
        }
        class_1735 sourceSlot = player.field_7512.field_7761.get(slotIndex);
        if (sourceSlot == null || !sourceSlot.method_7681() || sourceSlot.method_7677().method_7960()) {
            state.put("container.transfer.failure_reason", "empty_source_slot");
            return false;
        }
        class_1799 sourceStack = sourceSlot.method_7677().method_7972();
        String itemId = stringParam(params, "item.id", "");
        if (!itemId.isBlank() && !itemMatches(sourceStack, itemId)) {
            state.put("container.transfer.failure_reason", "source_item_mismatch");
            return false;
        }
        if (itemId.isBlank()) {
            class_2960 sourceId = class_7923.field_41178.method_10221(sourceStack.method_7909());
            itemId = sourceId == null ? "" : sourceId.toString();
        }
        if (itemId.isBlank()) {
            state.put("container.transfer.failure_reason", "unknown_item_id");
            return false;
        }
        int totalSlots = player.field_7512.field_7761.size();
        int playerInventoryStart = Math.max(0, totalSlots - 36);
        boolean sourceIsPlayer = slotIndex >= playerInventoryStart;
        boolean destinationPlayer = !sourceIsPlayer;
        int requested = intParam(params, "count.value", 0);
        int counter = intParam(params, "state.counter", 0);
        int remaining = requested > 0 ? Math.max(1, requested - counter) : sourceStack.method_7947();
        int transferCount = Math.min(sourceStack.method_7947(), remaining);
        int beforeInventoryCount = countInventory(player.method_31548(), itemId);
        state.put("container.transfer.active", true);
        state.put("container.transfer.phase", "await_screen_sync");
        state.put("container.transfer.wait_ticks", 3);
        state.put("container.transfer.slot", slotIndex);
        state.put("container.transfer.sync_id", player.field_7512.field_7763);
        state.put("container.transfer.item_id", itemId);
        state.put("container.transfer.source_count", sourceStack.method_7947());
        state.put("container.transfer.expected_count", transferCount);
        state.put("container.transfer.direction", direction);
        state.put("container.transfer.before_inventory_count", beforeInventoryCount);
        state.put("container.transfer.source_region", sourceIsPlayer ? "player" : "container");
        state.put("result.action", "STARTED");
        AutomationReporter.mem("container.transfer.slot", slotIndex);
        AutomationReporter.mem("container.transfer.item_id", itemId);
        AutomationReporter.mem("container.transfer.expected_count", transferCount);
        AutomationReporter.mem("container.transfer.direction", direction);
        boolean precise = transferCount > 0 && transferCount < sourceStack.method_7947();
        boolean clicked = precise
                ? clickExactContainerTransfer(interactionManager, player, slotIndex, itemId, transferCount, destinationPlayer)
                : clickQuickContainerTransfer(interactionManager, player, slotIndex);
        if (!clicked) {
            clearContainerTransferState(state);
            state.put("container.transfer.failure_reason", precise ? "no_precise_destination_slot" : "click_failed");
            return false;
        }
        state.put("container.transfer.mode", precise ? "precise_pickup" : "quick_move");
        return true;
    }

    private boolean clickQuickContainerTransfer(class_636 interactionManager, class_746 player, int slotIndex) {
        interactionManager.method_2906(player.field_7512.field_7763, slotIndex, 0, class_1713.field_7794, player);
        return true;
    }

    private boolean clickExactContainerTransfer(class_636 interactionManager, class_746 player, int sourceSlot, String itemId, int transferCount, boolean destinationPlayer) {
        if (transferCount <= 0 || player.field_7512.method_34255() == null || !player.field_7512.method_34255().method_7960()) {
            return false;
        }
        int destinationSlot = findTransferDestinationSlot(player, itemId, destinationPlayer, transferCount);
        if (destinationSlot < 0) {
            return false;
        }
        int syncId = player.field_7512.field_7763;
        interactionManager.method_2906(syncId, sourceSlot, 0, class_1713.field_7790, player);
        for (int i = 0; i < transferCount; i++) {
            interactionManager.method_2906(syncId, destinationSlot, 1, class_1713.field_7790, player);
        }
        interactionManager.method_2906(syncId, sourceSlot, 0, class_1713.field_7790, player);
        return true;
    }

    private int findTransferDestinationSlot(class_746 player, String itemId, boolean playerInventory, int count) {
        int totalSlots = player.field_7512.field_7761.size();
        int playerInventoryStart = Math.max(0, totalSlots - 36);
        int start = playerInventory ? playerInventoryStart : 0;
        int end = playerInventory ? totalSlots : playerInventoryStart;
        for (int i = start; i < end; i++) {
            class_1735 slot = player.field_7512.field_7761.get(i);
            if (slot == null || !slot.method_7681()) {
                continue;
            }
            class_1799 stack = slot.method_7677();
            if (itemMatches(stack, itemId) && stack.method_7914() - stack.method_7947() >= count) {
                return i;
            }
        }
        for (int i = start; i < end; i++) {
            class_1735 slot = player.field_7512.field_7761.get(i);
            if (slot != null && !slot.method_7681()) {
                return i;
            }
        }
        return -1;
    }

    private int openScreenHotbarSlot(class_746 player) {
        if (player == null || player.field_7512 == null) {
            return -1;
        }
        int totalSlots = player.field_7512.field_7761.size();
        return totalSlots - 9 + Math.max(0, Math.min(8, player.method_31548().field_7545));
    }

    private void updateActiveContainerTransfer(ActiveExecution execution, class_746 player) {
        Map<String, Object> state = execution.state;
        if (!Boolean.TRUE.equals(state.get("container.transfer.active"))) {
            return;
        }
        int remaining = intState(state, "container.transfer.wait_ticks", 0);
        if (remaining > 0) {
            remaining--;
            state.put("container.transfer.wait_ticks", remaining);
            if (execution.activeNodeId != null) {
                AutomationCliViewModel.runtimeFlow(execution.frameId, execution.activeNodeId, "container.transfer.phase", "flow_phase", "[wait]", "container.transfer.phase", "await_screen_sync");
                AutomationCliViewModel.runtimeFlow(execution.frameId, execution.activeNodeId, "container.transfer.wait", "flow_metric", "[info]", "container.transfer.wait_ticks", remaining);
            }
            return;
        }
        String itemId = stringParam(state, "container.transfer.item_id", "");
        int before = intState(state, "container.transfer.before_inventory_count", 0);
        int expected = intState(state, "container.transfer.expected_count", 1);
        String sourceRegion = stringParam(state, "container.transfer.source_region", "");
        int after = player == null || itemId.isBlank() ? before : countInventory(player.method_31548(), itemId);
        int moved = "player".equals(sourceRegion) ? Math.max(0, before - after) : Math.max(0, after - before);
        boolean success = moved >= expected;
        state.put("container.transfer.after_inventory_count", after);
        state.put("result.transfer.moved_count", moved);
        state.put("result.action", success ? "SUCCESS" : "FAIL");
        AutomationReporter.mem("container.transfer.after_inventory_count", after);
        AutomationReporter.mem("result.transfer.moved_count", moved);
        AutomationReporter.mem("result.action", success ? "SUCCESS" : "FAIL");
        if (execution.activeNodeId != null) {
            AutomationCliViewModel.runtimeFlow(execution.frameId, execution.activeNodeId, "container.transfer.before", "flow_metric", "[info]", "container.transfer.before_inventory_count", before);
            AutomationCliViewModel.runtimeFlow(execution.frameId, execution.activeNodeId, "container.transfer.after", "flow_metric", "[info]", "container.transfer.after_inventory_count", after);
            AutomationCliViewModel.runtimeFlow(execution.frameId, execution.activeNodeId, "container.transfer.moved", "flow_metric", success ? "[done]" : "[fail]", "container.transfer.moved_count", moved + " / " + expected);
        }
        clearContainerTransferState(state);
        if (!success) {
            state.put("container.transfer.failed", true);
            state.put("container.transfer.failure_reason", "server_inventory_delta_not_confirmed");
        }
        execution.activeNodeId = null;
        execution.activeNodeLabel = null;
        execution.activeAction = null;
    }

    private void clearContainerTransferState(Map<String, Object> state) {
        state.remove("container.transfer.active");
        state.remove("container.transfer.phase");
        state.remove("container.transfer.wait_ticks");
    }

    private boolean itemMatches(class_1799 stack, String itemId) {
        class_2960 id = class_7923.field_41178.method_10221(stack.method_7909());
        return id != null && itemId.equals(id.toString());
    }

    private void writeEntityState(Map<String, Object> state, class_1297 entity, String entityId) {
        state.put("current.target.kind", entity instanceof class_1542 ? "item" : entity instanceof class_1657 ? "player" : "entity");
        state.put("current.target.id", entityId);
        state.put("current.target.uuid", entity.method_5845());
        state.put("current.target.name", entity.method_5477().getString());
        state.put("current.target.x", entity.method_23317());
        state.put("current.target.y", entity.method_23318());
        state.put("current.target.z", entity.method_23321());
        AutomationReporter.mem("current.target.id", entityId);
        AutomationReporter.mem("current.target.uuid", entity.method_5845());
        AutomationReporter.mem("current.target.name", entity.method_5477().getString());
        AutomationReporter.mem("current.target.x", entity.method_23317());
        AutomationReporter.mem("current.target.y", entity.method_23318());
        AutomationReporter.mem("current.target.z", entity.method_23321());
    }

    private void writeScanTelemetry(Map<String, Object> state, String kind, String id, String selector, double radius, int candidates) {
        state.put("scan.kind", kind);
        state.put("scan.target.id", id);
        state.put("scan.selector", selector);
        state.put("scan.radius", radius);
        state.put("scan.candidates", candidates);
        state.remove("scan.failure_reason");
        AutomationReporter.mem("scan.kind", kind);
        AutomationReporter.mem("scan.target.id", id);
        AutomationReporter.mem("scan.selector", selector);
        AutomationReporter.mem("scan.radius", radius);
        AutomationReporter.mem("scan.candidates", candidates);
    }

    private void writeSelectedTargetTelemetry(Map<String, Object> state, class_746 player, class_243 selectedPos) {
        double distance = round(player.method_19538().method_1022(selectedPos));
        state.put("scan.selected.distance", distance);
        state.put("scan.selected.x", selectedPos.field_1352);
        state.put("scan.selected.y", selectedPos.field_1351);
        state.put("scan.selected.z", selectedPos.field_1350);
        AutomationReporter.mem("scan.selected.distance", distance);
        AutomationReporter.mem("scan.selected.x", selectedPos.field_1352);
        AutomationReporter.mem("scan.selected.y", selectedPos.field_1351);
        AutomationReporter.mem("scan.selected.z", selectedPos.field_1350);
    }

    private class_1297 findEntityByUuid(class_1937 world, String uuid) {
        if (uuid == null || uuid.isBlank()) {
            return null;
        }
        CachedEntityRef cached = this.cachedEntities.get(uuid);
        if (cached != null && cached.matches(world)) {
            return cached.entity();
        }
        UUID targetUuid;
        try {
            targetUuid = UUID.fromString(uuid);
        } catch (IllegalArgumentException ignored) {
            return null;
        }
        class_1297 found = findEntityByUuidNear(world, targetUuid, ENTITY_LOOKUP_RADIUS);
        if (found == null) {
            found = findEntityByUuidNear(world, targetUuid, ENTITY_LOOKUP_FALLBACK_RADIUS);
        }
        if (found != null) {
            this.cachedEntities.put(uuid, new CachedEntityRef(found, world));
        } else {
            this.cachedEntities.remove(uuid);
        }
        return found;
    }

    private class_1297 findEntityByUuidNear(class_1937 world, UUID targetUuid, double radius) {
        class_310 client = class_310.method_1551();
        class_746 player = client == null ? null : client.field_1724;
        if (player == null) {
            return null;
        }
        class_238 searchBox = player.method_5829().method_1014(radius);
        for (class_1297 entity : world.method_8335(player, searchBox)) {
            if (targetUuid.equals(entity.method_5667())) {
                return entity;
            }
        }
        for (class_1657 entity : world.method_18456()) {
            if (targetUuid.equals(entity.method_5667())) {
                return entity;
            }
        }
        return null;
    }

    private boolean canReuseCurrentTarget(class_746 player, class_638 world, Map<String, Object> state, String targetKind, String targetId) {
        if (targetKind.isBlank() || targetId.isBlank() || !targetKind.equalsIgnoreCase(stringParam(state, "current.target.kind", ""))) {
            return false;
        }
        double radius = doubleState(state, "scan.cache.radius", 48.0D);
        if (hasTargetPosition(state)) {
            class_243 target = new class_243(doubleState(state, "current.target.x", player.method_23317()), doubleState(state, "current.target.y", player.method_23318()), doubleState(state, "current.target.z", player.method_23321()));
            if (player.method_19538().method_1025(target) > radius * radius) {
                return false;
            }
        }
        return switch (targetKind.toLowerCase(Locale.ROOT)) {
            case "block" -> {
                if (!hasTargetPosition(state)) {
                    yield false;
                }
                class_2960 found = class_7923.field_41175.method_10221(world.method_8320(targetBlockPos(state)).method_26204());
                yield found != null && targetId.equals(found.toString());
            }
            case "item" -> {
                class_1297 entity = findEntityByUuid(world, stringParam(state, "current.target.uuid", ""));
                yield entity instanceof class_1542 itemEntity && entity.method_5805() && itemMatches(itemEntity.method_6983(), targetId);
            }
            case "entity" -> {
                class_1297 entity = findEntityByUuid(world, stringParam(state, "current.target.uuid", ""));
                class_2960 found = entity == null ? null : class_7923.field_41177.method_10221(entity.method_5864());
                yield entity != null && entity.method_5805() && found != null && targetId.equals(found.toString());
            }
            case "player" -> {
                class_1297 entity = findEntityByUuid(world, stringParam(state, "current.target.uuid", ""));
                yield entity instanceof class_1657 && entity.method_5805() && (targetId.equalsIgnoreCase(stringParam(state, "current.target.name", "")) || targetId.equals(entity.method_5845()));
            }
            default -> false;
        };
    }

    private class_1657 findPlayerByName(class_746 player, String name, double radius, String selectorId) {
        class_238 box = player.method_5829().method_1014(radius);
        class_1657 best = null;
        boolean farthest = "farthest".equalsIgnoreCase(selectorId) || "furthest".equalsIgnoreCase(selectorId);
        double bestDistance = farthest ? Double.MIN_VALUE : Double.MAX_VALUE;
        for (class_1657 other : player.method_37908().method_8390(class_1657.class, box, entity -> entity != null && entity.method_5805() && entity.method_5477().getString().equalsIgnoreCase(name))) {
            double distance = player.method_5858(other);
            if ((!farthest && distance < bestDistance) || (farthest && distance > bestDistance)) {
                bestDistance = distance;
                best = other;
            }
        }
        return best;
    }

    private class_2338 findNearestBlock(class_746 player, String blockId, int radius) {
        class_1937 world = player.method_37908();
        class_2960 wanted = class_2960.method_12829(blockId);
        if (world == null || wanted == null) {
            return null;
        }
        class_2338 origin = player.method_24515();
        class_2338 bestPos = null;
        double bestDistance = Double.MAX_VALUE;
        for (int x = -radius; x <= radius; x++) {
            for (int y = -radius; y <= radius; y++) {
                for (int z = -radius; z <= radius; z++) {
                    class_2338 pos = origin.method_10069(x, y, z);
                    class_2680 state = world.method_8320(pos);
                    class_2960 found = class_7923.field_41175.method_10221(state.method_26204());
                    if (found == null || !wanted.equals(found)) {
                        continue;
                    }
                    double distance = pos.method_10262(origin);
                    if (distance < bestDistance) {
                        bestDistance = distance;
                        bestPos = pos.method_10062();
                    }
                }
            }
        }
        return bestPos;
    }

    private void facePosition(class_746 player, class_243 target) {
        class_243 eye = player.method_33571();
        double dx = target.field_1352 - eye.field_1352;
        double dy = target.field_1351 - eye.field_1351;
        double dz = target.field_1350 - eye.field_1350;
        double horizontal = Math.sqrt(dx * dx + dz * dz);
        float yaw = (float) (Math.toDegrees(Math.atan2(dz, dx)) - 90.0D);
        float pitch = (float) (-Math.toDegrees(Math.atan2(dy, horizontal)));
        smoothYawToward(player, yaw, LOOK_MAX_YAW_STEP);
        smoothPitchToward(player, pitch, LOOK_MAX_PITCH_STEP);
    }

    private void facePositionHorizontal(class_746 player, class_243 target) {
        facePositionHorizontal(player, target, LOOK_MAX_YAW_STEP);
    }

    private void facePositionHorizontal(class_746 player, class_243 target, float maxYawStep) {
        class_243 origin = player.method_19538();
        double dx = target.field_1352 - origin.field_1352;
        double dz = target.field_1350 - origin.field_1350;
        float yaw = (float) (Math.toDegrees(Math.atan2(dz, dx)) - 90.0D);
        smoothYawToward(player, yaw, maxYawStep);
    }

    private void faceNavigationLook(class_746 player, NavigatorDecision decision, double distance, int blockedTicks, int stallTicks) {
        class_243 target = decision.lookTarget();
        float desiredYaw = yawToHorizontal(player.method_19538(), target);
        float yawDelta = Math.abs(class_3532.method_15393(desiredYaw - player.method_36454()));
        float maxStep = NAV_LOOK_MAX_YAW_STEP;
        if ("advance".equals(decision.phase()) || "step_up".equals(decision.phase()) || "advance_interval".equals(decision.phase())) {
            maxStep = yawDelta > 55.0F ? 58.0F : yawDelta > 22.0F ? 42.0F : 24.0F;
        }
        if (blockedTicks > NAV_STUCK_TICKS / 2 || stallTicks > NAV_STUCK_TICKS / 2) {
            maxStep = 60.0F;
        }
        if (distance < 1.4D) {
            maxStep = Math.min(maxStep, 26.0F);
        }
        smoothYawToward(player, desiredYaw, maxStep);
    }

    private float yawToHorizontal(class_243 origin, class_243 target) {
        double dx = target.field_1352 - origin.field_1352;
        double dz = target.field_1350 - origin.field_1350;
        return (float) (Math.toDegrees(Math.atan2(dz, dx)) - 90.0D);
    }

    private void smoothYawToward(class_746 player, float targetYaw, float maxStep) {
        float delta = class_3532.method_15393(targetYaw - player.method_36454());
        if (Math.abs(delta) <= LOOK_SNAP_EPSILON) {
            player.method_36456(targetYaw);
            return;
        }
        player.method_36456(player.method_36454() + class_3532.method_15363(delta, -maxStep, maxStep));
    }

    private void smoothPitchToward(class_746 player, float targetPitch, float maxStep) {
        float clampedTarget = class_3532.method_15363(targetPitch, -90.0F, 90.0F);
        float delta = clampedTarget - player.method_36455();
        if (Math.abs(delta) <= LOOK_SNAP_EPSILON) {
            player.method_36457(clampedTarget);
            return;
        }
        player.method_36457(class_3532.method_15363(player.method_36455() + class_3532.method_15363(delta, -maxStep, maxStep), -90.0F, 90.0F));
    }

    private class_3965 createCenterHit(class_746 player, class_2338 pos) {
        class_2350 side = class_2350.field_11036;
        class_243 hitPos = class_243.method_24953(pos);
        boolean insideBlock = false;
        return new class_3965(hitPos, side, pos, insideBlock);
    }

    private void updateActiveConsumption(ActiveExecution execution) {
        Map<String, Object> state = execution.state;
        if (!Boolean.TRUE.equals(state.get("consume.active"))) {
            return;
        }
        class_310 client = class_310.method_1551();
        class_746 player = client == null ? null : client.field_1724;
        if (player == null) {
            setHeldInput("use", false);
            state.remove("consume.active");
            return;
        }

        class_1799 stack = player.method_6047();
        String trackedItemId = stringParam(state, "consume.item.id", "");
        int beforeCount = intState(state, "consume.before_count", 0);
        int beforeTotalCount = intState(state, "consume.before_total_count", beforeCount);
        int beforeHunger = intState(state, "consume.before_hunger", player.method_7344().method_7586());
        float beforeSaturation = floatState(state, "consume.before_saturation", player.method_7344().method_7589());
        boolean started = Boolean.TRUE.equals(state.get("consume.started"));
        int ticks = intState(state, "consume.ticks", 0) + 1;
        int maxTicks = intState(state, "consume.max_ticks", 80);
        state.put("consume.ticks", ticks);
        AutomationCliViewModel.runtimeFlow(execution.frameId, execution.activeNodeId, "consume.phase", "flow_phase", "[run ]", "consume.phase", started ? "using_item" : "await_use_start");
        AutomationCliViewModel.runtimeFlow(execution.frameId, execution.activeNodeId, "consume.ticks", "flow_metric", "[info]", "consume.ticks", ticks);
        AutomationCliViewModel.runtimeFlow(execution.frameId, execution.activeNodeId, "consume.before_count", "flow_metric", "[info]", "consume.before_count", beforeCount);

        if (player.method_6115()) {
            if (!started) {
                state.put("consume.started", true);
                AutomationReporter.mem("consume.started", true);
                AutomationCliViewModel.runtimeFlow(execution.frameId, execution.activeNodeId, "consume.phase", "flow_phase", "[branch]", "consume.phase", "use_started");
            }
            return;
        }

        if (!started && ticks < 8) {
            return;
        }

        int afterCount = 0;
        if (!stack.method_7960()) {
            class_2960 currentId = class_7923.field_41178.method_10221(stack.method_7909());
            if (currentId != null && trackedItemId.equals(currentId.toString())) {
                afterCount = stack.method_7947();
            }
        }

        int consumed = Math.max(0, beforeCount - afterCount);
        int afterTotalCount = trackedItemId.isBlank() ? afterCount : countInventory(player.method_31548(), trackedItemId);
        consumed = Math.max(consumed, Math.max(0, beforeTotalCount - afterTotalCount));
        boolean hungerChanged = player.method_7344().method_7586() > beforeHunger || player.method_7344().method_7589() > beforeSaturation;

        if (consumed > 0 || hungerChanged) {
            String resultKey = stringParam(state, "consume.result.key", "result.consumed");
            if (consumed <= 0) {
                consumed = 1;
            }
            state.put(resultKey, Math.min(1, consumed));
            state.put("result.action", "SUCCESS");
            AutomationReporter.mem(resultKey, Math.min(1, consumed));
            AutomationReporter.mem("result.action", "SUCCESS");
            AutomationCliViewModel.runtimeFlow(execution.frameId, execution.activeNodeId, "consume.outcome", "flow_decision", "[done]", "consume.outcome", "consumed=1 hunger_changed=" + hungerChanged);
        } else {
            if (ticks < maxTicks) {
                setHeldInput("use", true);
                if (ticks % 4 == 0) {
                    if (client.field_1761 != null) {
                        client.field_1761.method_2919(player, class_1268.field_5808);
                    }
                }
                state.put("consume.started", started || player.method_6115());
                AutomationCliViewModel.runtimeFlow(execution.frameId, execution.activeNodeId, "consume.outcome", "flow_decision", "[wait]", "consume.outcome", "awaiting_vanilla_consume");
                return;
            }
            state.put(stringParam(state, "consume.result.key", "result.consumed"), 0);
            state.put("result.action", "FAIL");
            state.put("consume.failed", true);
            state.put("consume.failure_reason", started ? "item_not_consumed" : "item_use_never_started");
            AutomationReporter.mem("result.action", "FAIL");
            AutomationCliViewModel.runtimeFlow(execution.frameId, execution.activeNodeId, "consume.outcome", "flow_decision", "[fail]", "consume.outcome", stringParam(state, "consume.failure_reason", "fail"));
        }

        state.remove("consume.active");
        state.remove("consume.item.id");
        state.remove("consume.before_count");
        state.remove("consume.before_total_count");
        state.remove("consume.before_hunger");
        state.remove("consume.before_saturation");
        state.remove("consume.result.key");
        state.remove("consume.started");
        state.remove("consume.ticks");
        state.remove("consume.max_ticks");
        state.remove("consume.hold_use");
        setHeldInput("use", false);
        execution.activeNodeId = null;
        execution.activeNodeLabel = null;
        execution.activeAction = null;
    }

    private float floatState(Map<String, Object> state, String key, float fallback) {
        Object value = state.get(key);
        return value instanceof Number number ? number.floatValue() : fallback;
    }

    private double numberFromStateOrLiteral(Map<String, Object> state, String key, double fallback) {
        Object value = state.get(key);
        if (value instanceof Number number) {
            return number.doubleValue();
        }
        if (value instanceof Boolean bool) {
            return bool ? 1.0D : 0.0D;
        }
        if (value instanceof String text) {
            Object indirect = state.get(text);
            if (indirect instanceof Number number) {
                return number.doubleValue();
            }
            if (indirect instanceof Boolean bool) {
                return bool ? 1.0D : 0.0D;
            }
            try {
                return Double.parseDouble(text);
            } catch (NumberFormatException ignored) {
            }
        }
        return fallback;
    }

    private boolean compareNumbers(double left, double right, String op) {
        return switch (op) {
            case "lt" -> left < right;
            case "lte" -> left <= right;
            case "gt" -> left > right;
            case "gte" -> left >= right;
            case "neq" -> Double.compare(left, right) != 0;
            default -> Double.compare(left, right) == 0;
        };
    }

    private int gotoIndex(List<KtlCompilerService.CompiledStep> steps, String label) {
        for (int i = 0; i < steps.size(); i++) {
            if (label.equals(steps.get(i).label())) {
                return i;
            }
        }
        throw new IllegalStateException("Unknown goto label: " + label);
    }

    private void emitPrimitiveStateDiff(String frameId, String nodeId, Map<String, Object> beforeState, Map<String, Object> afterState) {
        Set<String> orderedKeys = new LinkedHashSet<>(beforeState.keySet());
        orderedKeys.addAll(afterState.keySet());
        for (String key : orderedKeys) {
            boolean hadBefore = beforeState.containsKey(key);
            boolean hasAfter = afterState.containsKey(key);
            Object before = beforeState.get(key);
            Object after = afterState.get(key);
            if (!hasAfter && hadBefore) {
                AutomationCliViewModel.primitiveStateRemove(frameId, nodeId, key, before);
                continue;
            }
            if (!Objects.equals(before, after)) {
                AutomationCliViewModel.primitiveStateWrite(frameId, nodeId, key, hadBefore ? before : null, after);
            }
        }
    }

    private static Map<String, Object> resolveParams(Map<String, Object> params, Map<String, Object> state) {
        Map<String, Object> resolved = new LinkedHashMap<>();
        for (Map.Entry<String, Object> entry : params.entrySet()) {
            if (entry.getValue() instanceof String stringValue) {
                String resolvedValue = resolveString(stringValue, state);
                if (resolvedValue.startsWith("${") && resolvedValue.endsWith("}")) {
                    continue;
                }
                resolved.put(entry.getKey(), resolvedValue);
            } else {
                resolved.put(entry.getKey(), entry.getValue());
            }
        }
        return resolved;
    }

    private static String resolveString(String value, Map<String, Object> state) {
        String result = value;
        for (Map.Entry<String, Object> entry : state.entrySet()) {
            result = result.replace("${" + entry.getKey() + "}", String.valueOf(entry.getValue()));
        }
        return result;
    }

    private static int countInventory(class_1661 inventory, String itemId) {
        int count = 0;
        for (int slot = 0; slot < inventory.method_5439(); slot++) {
            class_1799 stack = inventory.method_5438(slot);
            if (stack.method_7960()) {
                continue;
            }
            if (class_7923.field_41178.method_10221(stack.method_7909()).toString().equals(itemId)) {
                count += stack.method_7947();
            }
        }
        return count;
    }

    private static class_1297 findEntityBySelector(class_746 player, String entityId, double range, String selectorId) {
        class_1297 best = null;
        boolean farthest = "farthest".equalsIgnoreCase(selectorId) || "furthest".equalsIgnoreCase(selectorId);
        double bestDistance = farthest ? Double.MIN_VALUE : Double.MAX_VALUE;
        for (class_1297 entity : player.method_37908().method_8335(player, player.method_5829().method_1014(range))) {
            if (entity == player || entity.method_31481()) {
                continue;
            }
            class_2960 currentId = class_7923.field_41177.method_10221(entity.method_5864());
            if (currentId == null || !currentId.toString().equals(entityId)) {
                continue;
            }
            double distance = entity.method_5858(player);
            if (distance <= range * range && ((!farthest && distance < bestDistance) || (farthest && distance > bestDistance))) {
                best = entity;
                bestDistance = distance;
            }
        }
        return best;
    }

    private static int countMatchingEntities(class_746 player, String entityId, double range) {
        int count = 0;
        for (class_1297 entity : player.method_37908().method_8335(player, player.method_5829().method_1014(range))) {
            if (entity == player || entity.method_31481()) {
                continue;
            }
            class_2960 currentId = class_7923.field_41177.method_10221(entity.method_5864());
            if (currentId != null && currentId.toString().equals(entityId) && entity.method_5858(player) <= range * range) {
                count++;
            }
        }
        return count;
    }

    private static int countMatchingPlayers(class_746 player, String name, double range) {
        int count = 0;
        class_238 box = player.method_5829().method_1014(range);
        for (class_1657 other : player.method_37908().method_8390(class_1657.class, box, entity -> entity != null && entity.method_5805() && entity.method_5477().getString().equalsIgnoreCase(name))) {
            if (other.method_5858(player) <= range * range) {
                count++;
            }
        }
        return count;
    }

    private class_1542 findItemEntityBySelector(class_746 player, String itemId, double range, String selectorId) {
        if (player.method_37908() == null) {
            return null;
        }
        class_1542 best = null;
        boolean farthest = "farthest".equalsIgnoreCase(selectorId) || "furthest".equalsIgnoreCase(selectorId);
        double bestDistance = farthest ? Double.MIN_VALUE : Double.MAX_VALUE;
        for (class_1542 itemEntity : player.method_37908().method_8390(class_1542.class, player.method_5829().method_1014(range), entity -> true)) {
            class_1799 stack = itemEntity.method_6983();
            if (stack.method_7960() || !itemMatches(stack, itemId)) {
                continue;
            }
            double distance = itemEntity.method_5858(player);
            if (distance <= range * range && ((!farthest && distance < bestDistance) || (farthest && distance > bestDistance))) {
                best = itemEntity;
                bestDistance = distance;
            }
        }
        return best;
    }

    private int countMatchingItems(class_746 player, String itemId, double range) {
        if (player.method_37908() == null) {
            return 0;
        }
        int count = 0;
        for (class_1542 itemEntity : player.method_37908().method_8390(class_1542.class, player.method_5829().method_1014(range), entity -> true)) {
            class_1799 stack = itemEntity.method_6983();
            if (!stack.method_7960() && itemMatches(stack, itemId) && itemEntity.method_5858(player) <= range * range) {
                count++;
            }
        }
        return count;
    }

    private int countMatchingBlocks(class_746 player, String blockId, int radius) {
        class_1937 world = player.method_37908();
        class_2960 wanted = class_2960.method_12829(blockId);
        if (world == null || wanted == null) {
            return 0;
        }
        class_2338 origin = player.method_24515();
        int count = 0;
        for (int x = -radius; x <= radius; x++) {
            for (int y = -radius; y <= radius; y++) {
                for (int z = -radius; z <= radius; z++) {
                    class_2338 pos = origin.method_10069(x, y, z);
                    class_2960 found = class_7923.field_41175.method_10221(world.method_8320(pos).method_26204());
                    if (found != null && wanted.equals(found)) {
                        count++;
                    }
                }
            }
        }
        return count;
    }

    private int findMatchingOpenScreenSlot(class_746 player, String itemId, boolean containerOnly) {
        if (player == null || player.field_7512 == null) {
            return -1;
        }
        int totalSlots = player.field_7512.field_7761.size();
        int playerInventoryStart = Math.max(0, totalSlots - 36);
        for (int i = 0; i < totalSlots; i++) {
            if (containerOnly && i >= playerInventoryStart) {
                continue;
            }
            class_1735 slot = player.field_7512.field_7761.get(i);
            if (slot == null || !slot.method_7681()) {
                continue;
            }
            class_1799 stack = slot.method_7677();
            if (stack.method_7960()) {
                continue;
            }
            if (itemMatches(stack, itemId)) {
                return i;
            }
        }
        return -1;
    }

    private static final class ActiveExecution {
        private final String frameId;
        private final String parentFrameId;
        private final String resumeLabel;
        private final InterpretationResult interpretationResult;
        private final List<KtlCompilerService.CompiledStep> steps;
        private final Map<String, Object> state;
        private int index;
        private String activeNodeId;
        private String activeNodeLabel;
        private String activeAction;

        private ActiveExecution(String frameId, String parentFrameId, String resumeLabel, InterpretationResult interpretationResult, List<KtlCompilerService.CompiledStep> steps, Map<String, Object> state) {
            this.frameId = frameId;
            this.parentFrameId = parentFrameId;
            this.resumeLabel = resumeLabel;
            this.interpretationResult = interpretationResult;
            this.steps = steps;
            this.state = state;
            this.index = 0;
            this.activeNodeId = null;
            this.activeNodeLabel = null;
            this.activeAction = null;
        }
    }

    private static final class HeldInput {
        private boolean pressed;
        private int tapTicks;
        private float yawDelta;
        private float pitchDelta;
    }

    private class_243 chooseNavigationWaypoint(class_638 world, class_746 player, class_243 finalTarget, Map<String, Object> state, boolean useY, int blockedTicks, int stallTicks, int escapeTicks) {
        class_2338 feet = player.method_24515();
        class_2338 finalFeet = class_2338.method_49638(finalTarget);
        double finalDistance = navigationDistance(player.method_19538(), finalTarget, useY);
        boolean escaping = escapeTicks > 0 || blockedTicks >= NAV_STUCK_TICKS || stallTicks >= NAV_STUCK_TICKS || Boolean.TRUE.equals(state.get("move.progress.oscillating"));
        boolean directSafe = hasSafeDirectCorridor(world, feet, finalFeet, finalDistance > 6.0D ? 6 : 4);
        if (!escaping && directSafe && finalDistance <= 7.0D) {
            writeStateValue(state, "move.nav.waypoint.active", false);
            writeStateValue(state, "move.nav.path_style", "direct");
            return finalTarget;
        }

        class_243 targetDirection = new class_243(finalTarget.field_1352 - player.method_23317(), 0.0D, finalTarget.field_1350 - player.method_23321());
        if (targetDirection.method_1027() < 1.0E-4D) {
            writeStateValue(state, "move.nav.waypoint.active", false);
            writeStateValue(state, "move.nav.path_style", "arrive");
            return finalTarget;
        }
        targetDirection = targetDirection.method_1029();

        class_243 routeWaypoint = chooseRoutePlannerWaypoint(world, player, finalTarget, state, useY, escaping);
        if (routeWaypoint != null) {
            writeStateValue(state, "move.nav.waypoint.active", true);
            writeStateValue(state, "move.nav.waypoint.x", round(routeWaypoint.field_1352));
            writeStateValue(state, "move.nav.waypoint.y", round(routeWaypoint.field_1351));
            writeStateValue(state, "move.nav.waypoint.z", round(routeWaypoint.field_1350));
            writeStateValue(state, "move.nav.waypoint.reason", "route_planner");
            writeStateValue(state, "move.nav.path_style", "route_planner");
            return routeWaypoint;
        }

        class_243 best = null;
        double bestScore = Double.NEGATIVE_INFINITY;
        String bestReason = "none";
        double currentDistance = navigationDistance(player.method_19538(), finalTarget, useY);
        for (int radius = 1; radius <= NAV_WAYPOINT_RADIUS; radius++) {
            for (int dx = -radius; dx <= radius; dx++) {
                for (int dz = -radius; dz <= radius; dz++) {
                    if (dx == 0 && dz == 0 || Math.max(Math.abs(dx), Math.abs(dz)) != radius) {
                        continue;
                    }
                    int x = feet.method_10263() + dx;
                    int z = feet.method_10260() + dz;
                    class_243 stand = resolveLocalStandable(world, feet, x, z);
                    if (stand == null) {
                        continue;
                    }
                    class_2338 standFeet = class_2338.method_49638(stand);
                    MovementSafety safety = movementSafetyAt(world, standFeet, 4);
                    if (safety.danger() || safety.drop() && !escaping) {
                        continue;
                    }
                    boolean tightPassage = isEfficientTightPassage(world, standFeet, targetDirection);
                    if (safety.pocketRisk() >= NAV_POCKET_LIMIT && !escaping && !tightPassage) {
                        continue;
                    }
                    if (isTreePocket(world, standFeet) && !escaping && !tightPassage) {
                        continue;
                    }
                    if (!canTraverseRouteStep(world, feet, standFeet, finalTarget, escaping)) {
                        continue;
                    }
                    if (!hasSafeDirectCorridor(world, feet, standFeet, Math.min(6, radius + 1))) {
                        continue;
                    }
                    double candidateDistance = navigationDistance(stand, finalTarget, useY);
                    double improvement = currentDistance - candidateDistance;
                    if (!escaping && improvement < -0.35D) {
                        continue;
                    }
                    class_243 toCandidate = new class_243(stand.field_1352 - player.method_23317(), 0.0D, stand.field_1350 - player.method_23321());
                    if (toCandidate.method_1027() < 1.0E-4D) {
                        continue;
                    }
                    CandidateSafety candidateSafety = candidateSafety(world, feet, toCandidate.method_1029());
                    double forwardScore = toCandidate.method_1029().method_1026(targetDirection);
                    double distanceCost = player.method_19538().method_1022(stand) * 0.45D;
                    double score = improvement * 6.0D + forwardScore * 3.2D + candidateSafety.clearance() * 0.75D;
                    score -= distanceCost;
                    score -= navigationAvoidancePenalty(state, standFeet) * 1.25D;
                    score -= safety.pocketRisk() * (tightPassage ? 4.0D : 10.0D);
                    score -= candidateSafety.pocketRisk() * (tightPassage ? 3.0D : 8.0D);
                    score -= naturalPocketPressure(world, standFeet) * (tightPassage ? 0.45D : 1.2D);
                    score -= Math.abs(stand.field_1351 - player.method_23318()) * 0.35D;
                    score -= radius * 0.18D;
                    if (hasSafeDirectCorridor(world, standFeet, finalFeet, 5)) {
                        score += 3.0D;
                    }
                    if (tightPassage) {
                        score += 4.0D;
                    }
                    if (candidateSafety.stepUp() > 0 && candidateSafety.clearance() >= 2) {
                        score += 2.4D;
                    }
                    if (escaping) {
                        score += candidateSafety.safe() ? 2.5D : -2.0D;
                        score += improvement > -1.0D ? 1.25D : 0.0D;
                    }
                    if (score > bestScore) {
                        bestScore = score;
                        best = stand;
                        bestReason = escaping ? "recovery_waypoint" : directSafe ? "global_arc" : "obstacle_avoidance";
                    }
                }
            }
            if (best != null && bestScore > 2.5D) {
                break;
            }
        }

        if (best == null) {
            writeStateValue(state, "move.nav.waypoint.active", false);
            writeStateValue(state, "move.nav.path_style", escaping ? "escape_direct" : "direct_fallback");
            return finalTarget;
        }
        writeStateValue(state, "move.nav.waypoint.active", true);
        writeStateValue(state, "move.nav.waypoint.x", round(best.field_1352));
        writeStateValue(state, "move.nav.waypoint.y", round(best.field_1351));
        writeStateValue(state, "move.nav.waypoint.z", round(best.field_1350));
        writeStateValue(state, "move.nav.waypoint.reason", bestReason);
        writeStateValue(state, "move.nav.waypoint.score", round(bestScore));
        writeStateValue(state, "move.nav.path_style", bestReason);
        return best;
    }

    private class_243 resolveLocalStandable(class_638 world, class_2338 origin, int x, int z) {
        for (int y = origin.method_10264() + NAV_WAYPOINT_VERTICAL_UP; y >= origin.method_10264() - NAV_WAYPOINT_VERTICAL_DOWN; y--) {
            class_2338 pos = new class_2338(x, y, z);
            if (!canStandAt(world, pos)) {
                continue;
            }
            MovementSafety safety = movementSafetyAt(world, pos, 4);
            if (safety.danger() || safety.drop() || safety.pocketRisk() >= 0.9D) {
                continue;
            }
            return new class_243(pos.method_10263() + 0.5D, pos.method_10264(), pos.method_10260() + 0.5D);
        }
        return null;
    }

    private class_243 chooseRoutePlannerWaypoint(class_638 world, class_746 player, class_243 finalTarget, Map<String, Object> state, boolean useY, boolean escaping) {
        class_2338 start = player.method_24515();
        class_2338 targetFeet = class_2338.method_49638(finalTarget);
        double directDistance = navigationDistance(player.method_19538(), finalTarget, useY);
        if (hasSafeDirectCorridor(world, start, targetFeet, directDistance > 8.0D ? 8 : 5)) {
            writeStateValue(state, "move.nav.route.active", false);
            return null;
        }

        PriorityQueue<RouteNode> open = new PriorityQueue<>(Comparator.comparingDouble(RouteNode::fScore));
        Map<Long, Double> bestCost = new HashMap<>();
        Map<Long, Long> previous = new HashMap<>();
        Map<Long, class_2338> positions = new HashMap<>();
        long startKey = start.method_10063();
        double startHeuristic = routeHeuristic(start, finalTarget, useY);
        open.add(new RouteNode(start, 0.0D, startHeuristic));
        bestCost.put(startKey, 0.0D);
        positions.put(startKey, start);

        long bestKey = startKey;
        double bestHeuristic = startHeuristic;
        int expansions = 0;
        while (!open.isEmpty() && expansions++ < NAV_ROUTE_MAX_EXPANSIONS) {
            RouteNode current = open.poll();
            long currentKey = current.pos().method_10063();
            double known = bestCost.getOrDefault(currentKey, Double.MAX_VALUE);
            if (current.gScore() > known + 0.001D) {
                continue;
            }
            double heuristic = routeHeuristic(current.pos(), finalTarget, useY);
            if (heuristic < bestHeuristic) {
                bestHeuristic = heuristic;
                bestKey = currentKey;
            }
            if (heuristic <= 1.35D || current.pos().equals(targetFeet)) {
                bestKey = currentKey;
                break;
            }
            for (int dx = -1; dx <= 1; dx++) {
                for (int dz = -1; dz <= 1; dz++) {
                    if (dx == 0 && dz == 0) {
                        continue;
                    }
                    int nx = current.pos().method_10263() + dx;
                    int nz = current.pos().method_10260() + dz;
                    if (Math.abs(nx - start.method_10263()) > NAV_ROUTE_RADIUS || Math.abs(nz - start.method_10260()) > NAV_ROUTE_RADIUS) {
                        continue;
                    }
                    class_243 stand = resolveRouteStandable(world, current.pos(), nx, nz, finalTarget, escaping);
                    if (stand == null) {
                        continue;
                    }
                    class_2338 next = class_2338.method_49638(stand);
                    if (Math.abs(next.method_10264() - start.method_10264()) > NAV_WAYPOINT_VERTICAL_UP + NAV_WAYPOINT_VERTICAL_DOWN) {
                        continue;
                    }
                    if (!canTraverseRouteStep(world, current.pos(), next, finalTarget, escaping)) {
                        continue;
                    }
                    long nextKey = next.method_10063();
                    double stepCost = dx != 0 && dz != 0 ? 1.42D : 1.0D;
                    double verticalCost = Math.max(0.0D, next.method_10264() - current.pos().method_10264()) * 0.55D + Math.max(0.0D, current.pos().method_10264() - next.method_10264()) * 0.32D;
                    double pocketCost = Math.max(0.0D, pocketRisk(world, next) - NAV_CORRIDOR_POCKET_LIMIT) * (isEfficientTightPassage(world, next, horizontalDirection(class_243.method_24953(current.pos()), class_243.method_24953(next))) ? 0.6D : 3.4D);
                    double turnCost = routeTurnCost(previous, positions, currentKey, current.pos(), next);
                    double clearanceCost = routeClearanceCost(world, current.pos(), next, finalTarget, escaping);
                    double avoidanceCost = navigationAvoidancePenalty(state, next);
                    double humanCost = routeHumanCost(world, current.pos(), next, finalTarget);
                    double newCost = current.gScore() + stepCost + verticalCost + pocketCost + turnCost + clearanceCost + avoidanceCost + humanCost;
                    if (newCost >= bestCost.getOrDefault(nextKey, Double.MAX_VALUE)) {
                        continue;
                    }
                    bestCost.put(nextKey, newCost);
                    previous.put(nextKey, currentKey);
                    positions.put(nextKey, next);
                    open.add(new RouteNode(next, newCost, newCost + routeHeuristic(next, finalTarget, useY)));
                }
            }
        }

        if (bestKey == startKey || !positions.containsKey(bestKey)) {
            writeStateValue(state, "move.nav.route.active", false);
            writeStateValue(state, "move.nav.route.expansions", expansions);
            return null;
        }
        List<class_2338> path = new ArrayList<>();
        long key = bestKey;
        while (positions.containsKey(key)) {
            path.add(positions.get(key));
            Long parent = previous.get(key);
            if (parent == null) {
                break;
            }
            key = parent;
        }
        Collections.reverse(path);
        if (path.size() < 2) {
            writeStateValue(state, "move.nav.route.active", false);
            return null;
        }
        int waypointIndex = Math.min(path.size() - 1, Math.max(1, directDistance > 10.0D ? NAV_ROUTE_LOOKAHEAD_LONG : NAV_ROUTE_LOOKAHEAD_SHORT));
        class_2338 waypoint = path.get(waypointIndex);
        writeStateValue(state, "move.nav.route.active", true);
        writeStateValue(state, "move.nav.route.x", waypoint.method_10263());
        writeStateValue(state, "move.nav.route.y", waypoint.method_10264());
        writeStateValue(state, "move.nav.route.z", waypoint.method_10260());
        writeStateValue(state, "move.nav.route.nodes", path.size());
        writeStateValue(state, "move.nav.route.expansions", expansions);
        writeStateValue(state, "move.nav.route.reason", bestHeuristic <= 1.35D ? "goal_reached" : "best_local_route");
        return class_243.method_24953(waypoint);
    }

    private class_243 resolveRouteStandable(class_638 world, class_2338 origin, int x, int z, class_243 finalTarget, boolean escaping) {
        class_243 direction = horizontalDirection(class_243.method_24953(origin), finalTarget);
        for (int y = origin.method_10264() + 1; y >= origin.method_10264() - 2; y--) {
            class_2338 pos = new class_2338(x, y, z);
            boolean standable = canStandAt(world, pos);
            boolean stepUp = canStandAt(world, pos.method_10084()) && canPassThrough(world, pos.method_10086(2));
            class_2338 feet = standable ? pos : stepUp ? pos.method_10084() : null;
            if (feet == null) {
                continue;
            }
            MovementSafety safety = movementSafetyAt(world, feet, 4);
            boolean tight = isEfficientTightPassage(world, feet, direction);
            boolean trustedEdge = isTrustedEdgePass(world, feet, direction);
            if (safety.danger()) {
                continue;
            }
            if (safety.drop() && !trustedEdge && !escaping) {
                continue;
            }
            if (safety.pocketRisk() >= 0.92D && !tight && !escaping) {
                continue;
            }
            return class_243.method_24953(feet);
        }
        return null;
    }

    private boolean canTraverseRouteStep(class_638 world, class_2338 from, class_2338 to, class_243 finalTarget, boolean escaping) {
        int dx = Integer.compare(to.method_10263(), from.method_10263());
        int dz = Integer.compare(to.method_10260(), from.method_10260());
        if (dx == 0 && dz == 0) {
            return true;
        }
        class_243 stepDirection = horizontalDirection(class_243.method_24953(from), class_243.method_24953(to));
        if (isDangerBlock(world, to) || isDangerBlock(world, to.method_10074())) {
            return false;
        }
        MovementSafety targetSafety = movementSafetyAt(world, to, 4);
        if (targetSafety.drop() && !isTrustedEdgePass(world, from, stepDirection) && !escaping) {
            return false;
        }
        if (dx != 0 && dz != 0) {
            class_2338 sideX = new class_2338(from.method_10263() + dx, from.method_10264(), from.method_10260());
            class_2338 sideZ = new class_2338(from.method_10263(), from.method_10264(), from.method_10260() + dz);
            boolean xTraversable = isRouteShoulderTraversable(world, sideX, stepDirection, escaping);
            boolean zTraversable = isRouteShoulderTraversable(world, sideZ, stepDirection, escaping);
            if (!xTraversable && !zTraversable) {
                return false;
            }
            if ((targetSafety.drop() || isUnsafeDrop(world, to.method_10074(), 3)) && (!xTraversable || !zTraversable)) {
                return false;
            }
        }
        class_243 goalDirection = horizontalDirection(class_243.method_24953(to), finalTarget);
        return escaping || targetSafety.pocketRisk() < 0.96D || isEfficientTightPassage(world, to, goalDirection);
    }

    private boolean isRouteShoulderTraversable(class_638 world, class_2338 pos, class_243 direction, boolean escaping) {
        if (canStandAt(world, pos) || canStandAt(world, pos.method_10084())) {
            if (escaping) {
                return true;
            }
            return !isUnsafeDrop(world, pos.method_10074(), 3) || isTrustedEdgePass(world, pos, direction);
        }
        if (!canPassThrough(world, pos) || !canPassThrough(world, pos.method_10084()) || !canPassThrough(world, pos.method_10086(2))) {
            return false;
        }
        if (escaping) {
            return true;
        }
        return !isUnsafeDrop(world, pos.method_10074(), 3) && isEfficientTightPassage(world, pos, direction);
    }

    private double routeHeuristic(class_2338 pos, class_243 target, boolean useY) {
        class_243 center = class_243.method_24953(pos);
        return navigationDistance(center, target, useY);
    }

    private double routeTurnCost(Map<Long, Long> previous, Map<Long, class_2338> positions, long currentKey, class_2338 current, class_2338 next) {
        Long parentKey = previous.get(currentKey);
        if (parentKey == null || !positions.containsKey(parentKey)) {
            return 0.0D;
        }
        class_2338 parent = positions.get(parentKey);
        class_243 before = horizontalDirection(class_243.method_24953(parent), class_243.method_24953(current));
        class_243 after = horizontalDirection(class_243.method_24953(current), class_243.method_24953(next));
        if (before.method_1027() < 1.0E-4D || after.method_1027() < 1.0E-4D) {
            return 0.0D;
        }
        double dot = class_3532.method_15350(before.method_1029().method_1026(after.method_1029()), -1.0D, 1.0D);
        return (1.0D - dot) * 0.35D;
    }

    private boolean hasSafeDirectCorridor(class_638 world, class_2338 from, class_2338 to, int maxSteps) {
        int steps = Math.max(Math.abs(to.method_10263() - from.method_10263()), Math.abs(to.method_10260() - from.method_10260()));
        if (steps <= 0) {
            return true;
        }
        steps = Math.min(Math.max(1, maxSteps), steps);
        class_2338 previous = from;
        for (int i = 1; i <= steps; i++) {
            double t = (double) i / (double) steps;
            int x = class_3532.method_15357(class_3532.method_16436(t, from.method_10263(), to.method_10263()));
            int z = class_3532.method_15357(class_3532.method_16436(t, from.method_10260(), to.method_10260()));
            class_243 stand = resolveLocalStandable(world, previous, x, z);
            if (stand == null) {
                return false;
            }
            class_2338 pos = class_2338.method_49638(stand);
            MovementSafety safety = movementSafetyAt(world, pos, 4);
            class_243 corridorDirection = horizontalDirection(class_243.method_24953(previous), class_243.method_24953(pos));
            boolean tight = isEfficientTightPassage(world, pos, corridorDirection);
            boolean trustedEdge = isTrustedEdgePass(world, previous, corridorDirection);
            if (safety.danger()) {
                return false;
            }
            if (safety.drop() && !trustedEdge) {
                return false;
            }
            if ((!safety.safe() || safety.pocketRisk() >= NAV_POCKET_LIMIT || isTreePocket(world, pos)) && !tight && !hasOpposingSafeExits(world, pos)) {
                return false;
            }
            previous = pos;
        }
        return true;
    }

    private boolean isEfficientTightPassage(class_638 world, class_2338 feet, class_243 targetDirection) {
        if (!canStandAt(world, feet) && !isSafeExit(world, feet)) {
            return false;
        }
        class_2350 forward = class_2350.method_10142(targetDirection.field_1352, 0.0D, targetDirection.field_1350);
        class_2350 back = forward.method_10153();
        boolean forwardExit = isSafeExit(world, feet.method_10093(forward)) || canStandAt(world, feet.method_10093(forward).method_10084());
        boolean backExit = isSafeExit(world, feet.method_10093(back)) || canStandAt(world, feet.method_10093(back).method_10084());
        boolean throughLine = forwardExit && backExit;
        boolean sideBlocked = !isSafeExit(world, feet.method_10093(forward.method_10170())) || !isSafeExit(world, feet.method_10093(forward.method_10160()));
        boolean headClear = canPassThrough(world, feet.method_10084()) && canPassThrough(world, feet.method_10086(2));
        boolean doorwayStep = forwardExit || canPassThrough(world, feet.method_10093(forward)) && canPassThrough(world, feet.method_10093(forward).method_10084());
        return headClear && doorwayStep && (throughLine || sideBlocked && safeExitCount(world, feet) >= 1);
    }

    private boolean isTrustedEdgePass(class_638 world, class_2338 feet, class_243 targetDirection) {
        if (targetDirection.method_1027() < 1.0E-4D) {
            return false;
        }
        if (isUnsafeDrop(world, feet.method_10074(), 3) || isDangerBlock(world, feet) || isDangerBlock(world, feet.method_10074())) {
            return false;
        }
        class_2350 forward = class_2350.method_10142(targetDirection.field_1352, 0.0D, targetDirection.field_1350);
        class_2338 next = feet.method_10093(forward);
        class_2338 second = next.method_10093(forward);
        if (isDangerBlock(world, next) || isDangerBlock(world, next.method_10074())) {
            return false;
        }
        boolean immediateStand = canStandAt(world, next) || canStandAt(world, next.method_10084());
        boolean shortLanding = canStandAt(world, second) || canStandAt(world, second.method_10084()) || canStandAt(world, second.method_10074());
        boolean narrowButOpen = canPassThrough(world, next) && canPassThrough(world, next.method_10084()) && safeExitCount(world, feet) >= 2;
        boolean wallRail = isSolidBlocking(world, feet.method_10093(forward.method_10170())) || isSolidBlocking(world, feet.method_10093(forward.method_10160()));
        return immediateStand || shortLanding && narrowButOpen && wallRail;
    }

    private void rememberNavigationAvoidance(Map<String, Object> state, class_746 player, class_638 world, class_243 target) {
        class_243 direction = horizontalDirection(player.method_19538(), target);
        class_2338 feet = player.method_24515();
        class_2338 avoid = feet;
        if (direction.method_1027() > 1.0E-4D) {
            class_2350 facing = class_2350.method_10142(direction.field_1352, 0.0D, direction.field_1350);
            class_2338 ahead = feet.method_10093(facing);
            if (!canStandAt(world, ahead) || isSolidBlocking(world, ahead) || isSolidBlocking(world, ahead.method_10084()) || isUnsafeDrop(world, ahead.method_10074(), 3)) {
                avoid = ahead;
            }
        }
        state.put("move.nav.avoid.x", avoid.method_10263());
        state.put("move.nav.avoid.y", avoid.method_10264());
        state.put("move.nav.avoid.z", avoid.method_10260());
        state.put("move.nav.avoid.ticks", NAV_AVOID_MEMORY_TICKS);
        writeStateValue(state, "move.nav.avoid", avoid.method_10263() + "," + avoid.method_10264() + "," + avoid.method_10260());
    }

    private double navigationAvoidancePenalty(Map<String, Object> state, class_2338 pos) {
        int ticks = intState(state, "move.nav.avoid.ticks", 0);
        if (ticks <= 0 || !state.containsKey("move.nav.avoid.x")) {
            return 0.0D;
        }
        int x = intState(state, "move.nav.avoid.x", pos.method_10263());
        int y = intState(state, "move.nav.avoid.y", pos.method_10264());
        int z = intState(state, "move.nav.avoid.z", pos.method_10260());
        double horizontal = Math.sqrt(Math.pow(pos.method_10263() - x, 2.0D) + Math.pow(pos.method_10260() - z, 2.0D));
        double vertical = Math.abs(pos.method_10264() - y);
        if (horizontal > 3.5D || vertical > 2.0D) {
            return 0.0D;
        }
        return (3.5D - horizontal) * 2.0D + Math.max(0.0D, 2.0D - vertical);
    }

    private double routeClearanceCost(class_638 world, class_2338 from, class_2338 to, class_243 finalTarget, boolean escaping) {
        class_243 direction = horizontalDirection(class_243.method_24953(from), class_243.method_24953(to));
        MovementSafety safety = movementSafetyAt(world, to, 4);
        boolean tight = isEfficientTightPassage(world, to, horizontalDirection(class_243.method_24953(to), finalTarget));
        double cost = 0.0D;
        if (!canPassThrough(world, to.method_10084()) || !canPassThrough(world, to.method_10086(2))) {
            cost += 8.0D;
        }
        if (isTreePocket(world, to) && !tight && !escaping) {
            cost += 6.0D;
        }
        if (safety.drop() && !isTrustedEdgePass(world, from, direction) && !escaping) {
            cost += 10.0D;
        }
        int exits = safeExitCount(world, to);
        if (exits <= 1 && !tight && !escaping) {
            cost += 3.0D;
        }
        return cost;
    }

    private double routeHumanCost(class_638 world, class_2338 from, class_2338 to, class_243 finalTarget) {
        int vertical = to.method_10264() - from.method_10264();
        double cost = 0.0D;
        class_243 direction = horizontalDirection(class_243.method_24953(from), class_243.method_24953(to));
        if (vertical > 0) {
            cost += vertical * 0.9D;
        }
        if (vertical < 0) {
            cost += Math.abs(vertical) * 0.35D;
        }
        if (direction.method_1027() > 1.0E-4D) {
            class_2350 facing = class_2350.method_10142(direction.field_1352, 0.0D, direction.field_1350);
            boolean railLeft = isSolidBlocking(world, to.method_10093(facing.method_10170()));
            boolean railRight = isSolidBlocking(world, to.method_10093(facing.method_10160()));
            if (railLeft || railRight) {
                cost -= 0.45D;
            }
            class_243 goal = horizontalDirection(class_243.method_24953(to), finalTarget);
            if (goal.method_1027() > 1.0E-4D) {
                cost += Math.max(0.0D, 1.0D - direction.method_1026(goal)) * 0.4D;
            }
        }
        return cost;
    }

    private boolean hasParkourHeadHitAssist(class_638 world, class_2338 feet, class_243 landing) {
        class_243 direction = horizontalDirection(class_243.method_24953(feet), landing);
        if (direction.method_1027() < 1.0E-4D) {
            return false;
        }
        class_2350 facing = class_2350.method_10142(direction.field_1352, 0.0D, direction.field_1350);
        class_2338 head = feet.method_10086(2);
        class_2338 aheadHead = feet.method_10093(facing).method_10086(2);
        return isSolidBlocking(world, head) || isSolidBlocking(world, aheadHead);
    }

    private boolean tryBreakNavigationBlock(class_746 player, class_638 world, class_243 target, Map<String, Object> state) {
        class_310 client = class_310.method_1551();
        class_636 interactionManager = client == null ? null : client.field_1761;
        if (interactionManager == null || player == null || world == null) {
            return false;
        }
        class_243 direction = horizontalDirection(player.method_19538(), target);
        if (direction.method_1027() < 1.0E-4D) {
            return false;
        }
        class_2350 facing = class_2350.method_10142(direction.field_1352, 0.0D, direction.field_1350);
        class_2338 feet = player.method_24515();
        class_2338[] checks = {
                feet.method_10093(facing),
                feet.method_10093(facing).method_10084(),
                feet.method_10093(facing).method_10086(2)
        };
        class_2338 targetBlock = null;
        for (class_2338 pos : checks) {
            class_2680 blockState = world.method_8320(pos);
            if (!blockState.method_26215() && !blockState.method_26220(world, pos).method_1110() && !isDangerBlock(world, pos)) {
                targetBlock = pos;
                break;
            }
        }
        if (targetBlock == null || player.method_19538().method_1022(class_243.method_24953(targetBlock)) > 5.2D) {
            return false;
        }
        class_2338 active = state.containsKey("move.nav.clear_block.x")
                ? new class_2338(intState(state, "move.nav.clear_block.x", targetBlock.method_10263()), intState(state, "move.nav.clear_block.y", targetBlock.method_10264()), intState(state, "move.nav.clear_block.z", targetBlock.method_10260()))
                : null;
        if (active == null || !active.equals(targetBlock)) {
            state.put("move.nav.clear_block.x", targetBlock.method_10263());
            state.put("move.nav.clear_block.y", targetBlock.method_10264());
            state.put("move.nav.clear_block.z", targetBlock.method_10260());
            state.put("move.nav.clear_block.started", false);
            state.put("move.nav.clear_block.ticks", 0);
        }
        facePosition(player, class_243.method_24953(targetBlock));
        boolean started = Boolean.TRUE.equals(state.get("move.nav.clear_block.started"));
        if (!started) {
            boolean began = interactionManager.method_2910(targetBlock, facing.method_10153());
            player.method_6104(class_1268.field_5808);
            state.put("move.nav.clear_block.started", began);
        } else {
            interactionManager.method_2902(targetBlock, facing.method_10153());
            int ticks = intState(state, "move.nav.clear_block.ticks", 0) + 1;
            state.put("move.nav.clear_block.ticks", ticks);
            if (ticks % 4 == 0) {
                player.method_6104(class_1268.field_5808);
            }
        }
        writeStateValue(state, "move.nav.clear_block", targetBlock.method_10263() + "," + targetBlock.method_10264() + "," + targetBlock.method_10260());
        return true;
    }

    private boolean isTreePocket(class_638 world, class_2338 feet) {
        if (hasOpposingSafeExits(world, feet) || safeExitCount(world, feet) >= 3) {
            return false;
        }
        int natural = naturalPocketPressure(world, feet);
        int exits = 0;
        for (class_2350 direction : class_2350.class_2353.field_11062) {
            class_2338 next = feet.method_10093(direction);
            if (isSafeExit(world, next) && pocketRisk(world, next) < NAV_POCKET_LIMIT && naturalPocketPressure(world, next) < 7) {
                exits++;
            }
        }
        boolean lowNaturalCeiling = isNaturalBlocker(world, feet.method_10086(2)) || isNaturalBlocker(world, feet.method_10084());
        return natural >= 7 && exits <= 1 || natural >= 4 && lowNaturalCeiling && exits <= 1;
    }

    private int naturalPocketPressure(class_638 world, class_2338 center) {
        int pressure = 0;
        for (int dx = -1; dx <= 1; dx++) {
            for (int dz = -1; dz <= 1; dz++) {
                for (int dy = 0; dy <= 2; dy++) {
                    if (dx == 0 && dz == 0 && dy == 0) {
                        continue;
                    }
                    if (isNaturalBlocker(world, center.method_10069(dx, dy, dz))) {
                        pressure++;
                    }
                }
            }
        }
        return pressure;
    }

    private boolean isNaturalBlocker(class_638 world, class_2338 pos) {
        class_2680 state = world.method_8320(pos);
        if (state.method_26215() || state.method_26220(world, pos).method_1110()) {
            return false;
        }
        class_2960 id = class_7923.field_41175.method_10221(state.method_26204());
        if (id == null) {
            return false;
        }
        String value = id.toString();
        return value.contains("log") || value.contains("wood") || value.contains("leaves") || value.contains("root") || value.contains("vine") || value.contains("bamboo") || value.contains("mushroom") || value.contains("azalea");
    }


    private NavigatorDecision buildNavigationDecision(class_746 player, class_638 world, class_243 target, Map<String, Object> state, boolean sprint, double stopDistance, int blockedTicks, int stallTicks, int escapeTicks, String escapeSide) {
        class_243 playerPos = player.method_19538();
        class_243 horizontal = new class_243(target.field_1352 - playerPos.field_1352, 0.0D, target.field_1350 - playerPos.field_1350);
        class_243 moveDirection = horizontal.method_1027() < 1.0E-4D ? class_243.field_1353 : horizontal.method_1029();

        boolean inWater = player.method_5799() || player.method_5869();
        boolean lava = player.method_5771();
        boolean swim = inWater || lava;

        class_2338 feet = player.method_24515();
        class_2338 ahead = feet.method_10069((int) Math.signum(moveDirection.field_1352), 0, (int) Math.signum(moveDirection.field_1350));
        class_2338 aheadUp = ahead.method_10084();
        class_2338 belowAhead = ahead.method_10074();

        boolean stepUpAhead = canStandAt(world, ahead.method_10084()) && canPassThrough(world, ahead.method_10086(2));
        boolean blockedAhead = (isSolidBlocking(world, ahead) || isSolidBlocking(world, aheadUp)) && !stepUpAhead;
        boolean trustedEdge = isTrustedEdgePass(world, feet, moveDirection);
        boolean dropAhead = isUnsafeDrop(world, belowAhead, 3) && !trustedEdge;
        boolean waterAhead = isWaterBlock(world, ahead) || isWaterBlock(world, belowAhead);

        String phase = "advance";
        String strafeMode = "none";
        class_243 lookTarget = target;
        class_243 finalDirection = moveDirection;
        boolean jump = false;

        if (swim) {
            class_243 swimDir = new class_243(target.field_1352 - playerPos.field_1352, target.field_1351 - playerPos.field_1351, target.field_1350 - playerPos.field_1350);
            finalDirection = swimDir.method_1027() < 1.0E-4D ? class_243.field_1353 : swimDir.method_1029();
            phase = "swim";
            return new NavigatorDecision(finalDirection, target, false, true, false, phase, strafeMode);
        }

        NavigationCandidate best = bestNavigationCandidate(world, feet, moveDirection, state, blockedTicks, stallTicks, escapeTicks, escapeSide);
        if (best != null) {
            finalDirection = best.direction();
            phase = best.phase();
            strafeMode = best.strafeMode();
            jump = best.jump();
        } else if (stepUpAhead && player.method_24828()) {
            jump = true;
            phase = "step_up";
        } else if (blockedAhead) {
            jump = player.method_24828();
            phase = jump ? "jump_obstacle" : "blocked";
        } else if (dropAhead && !waterAhead) {
            phase = "drop_blocked";
            finalDirection = class_243.field_1353;
        }

        return new NavigatorDecision(finalDirection, lookTarget, sprint, false, jump, phase, strafeMode);
    }

    private NavigationCandidate bestNavigationCandidate(class_638 world, class_2338 feet, class_243 targetDirection, Map<String, Object> state, int blockedTicks, int stallTicks, int escapeTicks, String escapeSide) {
        if (targetDirection.method_1027() < 1.0E-4D) {
            return null;
        }
        boolean escaping = escapeTicks > 0 || blockedTicks >= NAV_STUCK_TICKS || stallTicks >= NAV_STUCK_TICKS;
        String lockedStrafe = stringParam(state, "move.nav.strafe_mode", "none");
        class_243 left = rotateLeft(targetDirection);
        class_243 right = rotateRight(targetDirection);
        List<NavigationCandidate> candidates = new ArrayList<>();
        addNavigationCandidate(candidates, world, feet, targetDirection, targetDirection, 0.0D, escaping, escapeSide, lockedStrafe, "advance", "none", false);
        addNavigationCandidate(candidates, world, feet, rotateYaw(targetDirection, 18.0D), targetDirection, 18.0D, escaping, escapeSide, lockedStrafe, "arc_right", "right", false);
        addNavigationCandidate(candidates, world, feet, rotateYaw(targetDirection, -18.0D), targetDirection, -18.0D, escaping, escapeSide, lockedStrafe, "arc_left", "left", false);
        addNavigationCandidate(candidates, world, feet, rotateYaw(targetDirection, 38.0D), targetDirection, 38.0D, escaping, escapeSide, lockedStrafe, "wide_right", "right", false);
        addNavigationCandidate(candidates, world, feet, rotateYaw(targetDirection, -38.0D), targetDirection, -38.0D, escaping, escapeSide, lockedStrafe, "wide_left", "left", false);
        addNavigationCandidate(candidates, world, feet, right, targetDirection, 90.0D, escaping, escapeSide, lockedStrafe, "strafe_right", "right", false);
        addNavigationCandidate(candidates, world, feet, left, targetDirection, -90.0D, escaping, escapeSide, lockedStrafe, "strafe_left", "left", false);
        boolean severeEscape = blockedTicks >= NAV_STUCK_TICKS + 8 || stallTicks >= NAV_STUCK_TICKS + 8;
        if (escaping) {
            addNavigationCandidate(candidates, world, feet, rotateYaw(targetDirection, 130.0D), targetDirection, 130.0D, true, escapeSide, lockedStrafe, "escape_back_right", "right", true);
            addNavigationCandidate(candidates, world, feet, rotateYaw(targetDirection, -130.0D), targetDirection, -130.0D, true, escapeSide, lockedStrafe, "escape_back_left", "left", true);
            if (severeEscape) {
                addNavigationCandidate(candidates, world, feet, targetDirection.method_1021(-1.0D), targetDirection, 180.0D, true, escapeSide, lockedStrafe, "escape_reverse", "back", true);
            }
        }
        return candidates.stream().max(Comparator.comparingDouble(NavigationCandidate::score)).orElse(null);
    }

    private void addNavigationCandidate(List<NavigationCandidate> candidates, class_638 world, class_2338 feet, class_243 direction, class_243 targetDirection, double yawOffset, boolean escaping, String escapeSide, String lockedStrafe, String phase, String strafeMode, boolean escapeMove) {
        if (direction.method_1027() < 1.0E-4D) {
            return;
        }
        class_243 normalized = direction.method_1029();
        CandidateSafety safety = candidateSafety(world, feet, normalized);
        if (!safety.safe() && !escapeMove) {
            return;
        }
        double score = normalized.method_1026(targetDirection) * 5.0D;
        score += safety.clearance() * 1.6D;
        score += safety.stepUp() * 2.6D;
        score -= safety.blocked() * 5.0D;
        score -= safety.drop() * 8.0D;
        boolean tightPassage = isEfficientTightPassage(world, feet.method_10093(class_2350.method_10142(normalized.field_1352, 0.0D, normalized.field_1350)), targetDirection);
        score -= safety.pocketRisk() * (tightPassage ? 3.0D : 9.0D);
        score -= safety.naturalBlockers() * (tightPassage ? 0.35D : 0.95D);
        score -= Math.abs(yawOffset) * 0.012D;
        if (tightPassage) {
            score += 3.4D;
        }
        if (!escaping && !lockedStrafe.isBlank() && !"none".equals(lockedStrafe)) {
            if (lockedStrafe.equals(strafeMode)) {
                score += 2.4D;
            } else if (!"none".equals(strafeMode)) {
                score -= 2.2D;
            }
        }
        if (escaping) {
            score += escapeMove ? 3.5D : 0.75D;
            if ("left".equals(escapeSide) && strafeMode.contains("left")) {
                score += 2.0D;
            }
            if ("right".equals(escapeSide) && strafeMode.contains("right")) {
                score += 2.0D;
            }
            if ("back".equals(strafeMode)) {
                score -= 4.5D;
            }
        }
        boolean jump = safety.blocked() > 0 && safety.headClear();
        candidates.add(new NavigationCandidate(normalized, score, phase, strafeMode, jump));
    }

    private CandidateSafety candidateSafety(class_638 world, class_2338 feet, class_243 direction) {
        int blocked = 0;
        int drop = 0;
        int clearance = 0;
        int stepUpCount = 0;
        int naturalBlockers = 0;
        double maxPocketRisk = 0.0D;
        boolean headClear = true;
        class_243 normalized = direction.method_1027() < 1.0E-4D ? class_243.field_1353 : direction.method_1029();
        class_243 origin = class_243.method_24953(feet);
        Set<class_2338> visited = new LinkedHashSet<>();
        for (int step = 1; step <= 4; step++) {
            class_243 sample = origin.method_1019(normalized.method_1021(step * 0.75D));
            class_2338 pos = new class_2338(class_3532.method_15357(sample.field_1352), feet.method_10264(), class_3532.method_15357(sample.field_1350));
            if (!visited.add(pos)) {
                continue;
            }
            boolean standable = canStandAt(world, pos);
            boolean stepUp = canStandAt(world, pos.method_10084()) && canPassThrough(world, pos.method_10086(2));
            boolean bodyBlocked = !standable && !stepUp;
            boolean headBlocked = !canPassThrough(world, pos.method_10084()) || !canPassThrough(world, pos.method_10086(2));
            MovementSafety safety = movementSafetyAt(world, standable ? pos : stepUp ? pos.method_10084() : pos, 3);
            maxPocketRisk = Math.max(maxPocketRisk, safety.pocketRisk());
            naturalBlockers += naturalPocketPressure(world, pos);
            if (bodyBlocked || headBlocked || safety.danger()) {
                blocked++;
            } else {
                clearance++;
                if (stepUp) {
                    stepUpCount++;
                }
            }
            if (headBlocked) {
                headClear = false;
            }
            if (safety.drop() && !safety.water()) {
                drop++;
            }
        }
        boolean safe = blocked == 0 && drop == 0 && (maxPocketRisk < NAV_POCKET_LIMIT || clearance >= 2 && stepUpCount > 0);
        return new CandidateSafety(safe, blocked, drop, clearance, stepUpCount, headClear, maxPocketRisk, naturalBlockers);
    }

    private String chooseEscapeSide(class_746 player, class_638 world, class_243 target, String previous) {
        class_243 horizontal = new class_243(target.field_1352 - player.method_23317(), 0.0D, target.field_1350 - player.method_23321());
        if (horizontal.method_1027() < 1.0E-4D) {
            return "none";
        }
        class_243 direction = horizontal.method_1029();
        class_2338 feet = player.method_24515();
        CandidateSafety left = candidateSafety(world, feet, rotateLeft(direction));
        CandidateSafety right = candidateSafety(world, feet, rotateRight(direction));
        if (left.safe() && !right.safe()) {
            return "left";
        }
        if (right.safe() && !left.safe()) {
            return "right";
        }
        if (left.clearance() - left.naturalBlockers() > right.clearance() - right.naturalBlockers()) {
            return "left";
        }
        if (right.clearance() - right.naturalBlockers() > left.clearance() - left.naturalBlockers()) {
            return "right";
        }
        return "left".equals(previous) ? "right" : "left";
    }

    private NavigatorDecision stabilizeNavigationDecision(Map<String, Object> state, class_746 player, class_638 world, NavigatorDecision decision, int blockedTicks, int stallTicks, int escapeTicks) {
        if (decision.swim() || decision.moveDirection().method_1027() < 1.0E-4D) {
            writeStateValue(state, "move.nav.steer_x", 0.0D);
            writeStateValue(state, "move.nav.steer_z", 0.0D);
            writeStateValue(state, "move.nav.steer_lock_ticks", 0);
            return decision;
        }

        class_243 requested = decision.moveDirection().method_1029();
        class_243 previous = new class_243(
                doubleState(state, "move.nav.steer_x", 0.0D),
                0.0D,
                doubleState(state, "move.nav.steer_z", 0.0D)
        );
        if (previous.method_1027() > 1.0E-4D) {
            previous = previous.method_1029();
        }

        boolean escaping = escapeTicks > 0 || blockedTicks >= NAV_STUCK_TICKS || stallTicks >= NAV_STUCK_TICKS;
        int lockTicks = intState(state, "move.nav.steer_lock_ticks", 0);
        String previousStrafe = stringParam(state, "move.nav.strafe_mode", "none");
        String requestedStrafe = decision.strafeMode();
        boolean sideChanged = !previousStrafe.equals(requestedStrafe)
                && !"none".equals(previousStrafe)
                && !"none".equals(requestedStrafe);

        class_243 stabilized = requested;
        if (previous.method_1027() > 1.0E-4D && !escaping) {
            double dot = previous.method_1026(requested);
            if (sideChanged && lockTicks > 0 && candidateSafety(world, player.method_24515(), previous).safe()) {
                stabilized = previous.method_1021(0.82D).method_1019(requested.method_1021(0.18D)).method_1029();
                requestedStrafe = previousStrafe;
                lockTicks--;
            } else if (dot > 0.15D) {
                stabilized = previous.method_1021(0.62D).method_1019(requested.method_1021(0.38D)).method_1029();
                lockTicks = Math.max(lockTicks - 1, 0);
            } else if (lockTicks > 0 && candidateSafety(world, player.method_24515(), previous).safe()) {
                stabilized = previous;
                requestedStrafe = previousStrafe;
                lockTicks--;
            } else {
                lockTicks = NAV_STEER_LOCK_TICKS;
            }
        } else if (!"none".equals(requestedStrafe)) {
            lockTicks = NAV_STEER_LOCK_TICKS;
        }

        class_243 lookTarget = player.method_19538().method_1019(stabilized.method_1021(5.0D));
        writeStateValue(state, "move.nav.steer_x", stabilized.field_1352);
        writeStateValue(state, "move.nav.steer_z", stabilized.field_1350);
        writeStateValue(state, "move.nav.steer_lock_ticks", Math.max(0, lockTicks));
        return new NavigatorDecision(stabilized, lookTarget, decision.sprint(), decision.swim(), decision.jump(), decision.phase(), requestedStrafe);
    }

    private void applyNavigationDecision(class_746 player, NavigatorDecision decision) {
        applyNavigationDecision(player, decision, 1.0D);
    }

    private void applyNavigationDecision(class_746 player, NavigatorDecision decision, double speedScale) {
        if (decision.swim()) {
            applySwimToward(player, decision.moveDirection(), decision.lookTarget());
            return;
        }

        if (decision.jump() && player.method_24828()) {
            player.method_6043();
        }

        if (decision.moveDirection().method_1027() < 1.0E-4D) {
            releaseMovementInputs();
            return;
        }

        applyHorizontalMotion(player, decision.moveDirection(), decision.sprint(), speedScale, false);
    }

    private void applySwimToward(class_746 player, class_243 direction, class_243 lookTarget) {
        class_243 normalized = direction.method_1027() < 1.0E-4D ? class_243.field_1353 : direction.method_1029();
        player.method_5728(false);
        setHeldInput("forward", normalized.method_37268() > 1.0E-4D);
        setHeldInput("sprint", false);
        facePosition(player, lookTarget);
        if (normalized.field_1351 > 0.08D) {
            setHeldInput("jump", true);
        } else {
            setHeldInput("jump", false);
        }
        setHeldInput("sneak", normalized.field_1351 < -0.08D);
        applyPlayerInputState(player);
    }

    private double navigationStopDistance(Map<String, Object> params, Map<String, Object> state, double fallback) {
        if (hasResolvedParam(params, "stop.distance")) {
            return Math.max(0.12D, doubleParam(params, "stop.distance", fallback));
        }
        return isCoordinateTarget(state, params) ? NAV_PRECISE_STOP_DISTANCE : fallback;
    }

    private boolean isCoordinateTarget(Map<String, Object> state, Map<String, Object> params) {
        String paramKind = stringParam(params, "target.kind", "");
        String stateKind = stringParam(state, "current.target.kind", "");
        String paramId = stringParam(params, "target.id", "");
        String stateId = stringParam(state, "current.target.id", "");
        boolean hasCoordinateParams = hasResolvedParam(params, "target.x") && hasResolvedParam(params, "target.z");
        return hasCoordinateParams || "location".equalsIgnoreCase(paramKind) || "location".equalsIgnoreCase(stateKind) || "coordinate".equalsIgnoreCase(paramId) || "coordinate".equalsIgnoreCase(stateId);
    }

    private double precisionSpeedScale(double distance, double stopDistance) {
        double activeDistance = Math.max(0.01D, distance - stopDistance);
        if (activeDistance <= 0.18D) {
            return 0.18D;
        }
        if (activeDistance <= 0.45D) {
            return 0.28D;
        }
        if (activeDistance <= 0.85D) {
            return 0.45D;
        }
        if (activeDistance <= NAV_PRECISE_SLOW_DISTANCE) {
            return 0.65D;
        }
        return 1.0D;
    }

    private double navigationDistance(class_243 from, class_243 to, boolean useY) {
        if (useY) {
            return from.method_1022(to);
        }
        double dx = from.field_1352 - to.field_1352;
        double dz = from.field_1350 - to.field_1350;
        return Math.sqrt(dx * dx + dz * dz);
    }

    private class_243 rotateLeft(class_243 vec) {
        return new class_243(-vec.field_1350, 0.0D, vec.field_1352).method_1029();
    }

    private class_243 rotateRight(class_243 vec) {
        return new class_243(vec.field_1350, 0.0D, -vec.field_1352).method_1029();
    }

    private class_243 rotateYaw(class_243 vec, double degrees) {
        double radians = Math.toRadians(degrees);
        double cos = Math.cos(radians);
        double sin = Math.sin(radians);
        return new class_243(vec.field_1352 * cos - vec.field_1350 * sin, 0.0D, vec.field_1352 * sin + vec.field_1350 * cos).method_1029();
    }

    private boolean canMoveThrough(class_638 world, class_2338 origin, class_243 dir) {
        class_2338 next = origin.method_10069((int) Math.signum(dir.field_1352), 0, (int) Math.signum(dir.field_1350));
        return !isSolidBlocking(world, next) && !isSolidBlocking(world, next.method_10084());
    }

    private boolean isDirectionSafe(class_638 world, class_2338 origin, class_243 dir) {
        class_2338 next = origin.method_10069((int) Math.signum(dir.field_1352), 0, (int) Math.signum(dir.field_1350));
        return !isUnsafeDrop(world, next.method_10074(), 3);
    }

    private boolean isSolidBlocking(class_638 world, class_2338 pos) {
        class_2680 state = world.method_8320(pos);
        return !state.method_26215() && !state.method_26220(world, pos).method_1110();
    }

    private boolean isRayPassThrough(class_638 world, class_2338 pos) {
        class_2680 state = world.method_8320(pos);
        return state.method_26215() || state.method_26220(world, pos).method_1110();
    }

    private PiercingRayResult piercingRaycast(class_310 client, double maxDistance) {
        class_746 player = client == null ? null : client.field_1724;
        class_638 world = client == null ? null : client.field_1687;
        if (player == null || world == null) {
            return new PiercingRayResult(client == null ? null : client.field_1765, 0, "");
        }
        class_243 start = player.method_33571();
        class_243 direction = player.method_5828(1.0F).method_1029();
        class_243 end = start.method_1019(direction.method_1021(maxDistance));
        BlockTrace blockTrace = traceSolidBlockThroughPassables(world, player, start, direction, maxDistance);
        class_3966 entityHit = traceEntityAlongRay(world, player, start, end, blockTrace.distance());
        if (entityHit != null) {
            return new PiercingRayResult(entityHit, blockTrace.piercedBlocks(), blockTrace.lastPassThroughBlock());
        }
        class_239 hit = blockTrace.hit() == null ? class_3965.method_17778(end, class_2350.method_10142(direction.field_1352, direction.field_1351, direction.field_1350), class_2338.method_49638(end)) : blockTrace.hit();
        return new PiercingRayResult(hit, blockTrace.piercedBlocks(), blockTrace.lastPassThroughBlock());
    }

    private BlockTrace traceSolidBlockThroughPassables(class_638 world, class_746 player, class_243 start, class_243 direction, double maxDistance) {
        Set<class_2338> visited = new HashSet<>();
        int pierced = 0;
        String lastPass = "";
        for (double distance = 0.0D; distance <= maxDistance; distance += AUTOMATION_RAY_STEP) {
            class_243 point = start.method_1019(direction.method_1021(distance));
            class_2338 pos = class_2338.method_49638(point);
            if (!visited.add(pos)) {
                continue;
            }
            class_2680 state = world.method_8320(pos);
            if (isRayPassThrough(world, pos)) {
                if (!state.method_26215()) {
                    pierced++;
                    class_2960 blockId = class_7923.field_41175.method_10221(state.method_26204());
                    lastPass = blockId == null ? state.method_26204().toString() : blockId.toString();
                }
                continue;
            }
            class_265 shape = state.method_26220(world, pos);
            class_3965 shapeHit = shape.method_1092(start, start.method_1019(direction.method_1021(maxDistance)), pos);
            if (shapeHit != null) {
                return new BlockTrace(shapeHit, start.method_1022(shapeHit.method_17784()), pierced, lastPass);
            }
            class_2350 side = class_2350.method_10142(direction.field_1352, direction.field_1351, direction.field_1350).method_10153();
            return new BlockTrace(new class_3965(point, side, pos, false), distance, pierced, lastPass);
        }
        return new BlockTrace(null, maxDistance, pierced, lastPass);
    }

    private class_3966 traceEntityAlongRay(class_638 world, class_746 player, class_243 start, class_243 end, double blockDistance) {
        class_1297 best = null;
        class_243 bestHit = null;
        double bestDistance = blockDistance * blockDistance;
        class_238 searchBox = player.method_5829().method_18804(end.method_1020(start)).method_1014(1.0D);
        for (class_1297 entity : world.method_8333(player, searchBox, entity -> entity != null && entity.method_5805() && !entity.method_7325() && entity.method_5863())) {
            Optional<class_243> hit = entity.method_5829().method_1014(entity.method_5871()).method_992(start, end);
            if (hit.isEmpty()) {
                continue;
            }
            double distance = start.method_1025(hit.get());
            if (distance < bestDistance) {
                best = entity;
                bestHit = hit.get();
                bestDistance = distance;
            }
        }
        return best == null ? null : new class_3966(best, bestHit);
    }

    private PiercingVisibilityResult piercingVisibility(class_638 world, class_746 player, class_243 target) {
        class_243 start = player.method_33571();
        class_243 delta = target.method_1020(start);
        double distance = delta.method_1033();
        if (distance <= 0.001D) {
            return new PiercingVisibilityResult(true, "", 0);
        }
        BlockTrace trace = traceSolidBlockThroughPassables(world, player, start, delta.method_1029(), distance);
        if (trace.hit() == null || trace.distance() >= distance - 0.2D || trace.hit().method_17777().method_19769(target, 1.1D)) {
            return new PiercingVisibilityResult(true, "", trace.piercedBlocks());
        }
        class_2680 state = world.method_8320(trace.hit().method_17777());
        class_2960 blocker = class_7923.field_41175.method_10221(state.method_26204());
        return new PiercingVisibilityResult(false, blocker == null ? state.method_26204().toString() : blocker.toString(), trace.piercedBlocks());
    }

    private boolean isWaterBlock(class_638 world, class_2338 pos) {
        return !world.method_8316(pos).method_15769() && world.method_8316(pos).method_15771();
    }

    private boolean isUnsafeDrop(class_638 world, class_2338 start, int maxDepth) {
        class_2338 cursor = start;
        for (int i = 0; i < maxDepth; i++) {
            class_2680 state = world.method_8320(cursor);
            if (!state.method_26215() && state.method_26216(world, cursor)) {
                return false;
            }
            if (isWaterBlock(world, cursor)) {
                return false;
            }
            cursor = cursor.method_10074();
        }
        return true;
    }

    private record CachedEntityRef(class_1297 entity, class_1937 world) {
        private boolean matches(class_1937 expectedWorld) {
            return this.entity != null && !this.entity.method_31481() && this.entity.method_5805() && this.world == expectedWorld;
        }
    }

    private record PrimitiveRunResult(boolean success, Map<String, Object> resolvedParams) {
    }

    private record NavigatorDecision(class_243 moveDirection, class_243 lookTarget, boolean sprint, boolean swim, boolean jump,
                                     String phase, String strafeMode) {
    }

    private record NavigationCandidate(class_243 direction, double score, String phase, String strafeMode, boolean jump) {
    }

    private record CandidateSafety(boolean safe, int blocked, int drop, int clearance, int stepUp, boolean headClear,
                                   double pocketRisk, int naturalBlockers) {
    }

    private record RouteNode(class_2338 pos, double gScore, double fScore) {
    }

    private record MovementProgress(boolean ok, String reason, boolean distanceImproved, boolean positionChanged,
                                    boolean oscillating, int noProgressTicks) {
    }

    private record MovementSafety(boolean safe, String reason, boolean danger, boolean drop, boolean water,
                                  double pocketRisk) {
    }

    private record MovementPlan(boolean ok, String segment, boolean sprint, String reason, double danger,
                                double horizontal, double vertical) {
    }

    private record ParkourAnalysis(boolean ok, String reason, boolean sprint, double horizontal, double vertical,
                                   double landingRisk) {
    }

    private record PiercingRayResult(class_239 hit, int piercedBlocks, String lastPassThroughBlock) {
    }

    private record PiercingVisibilityResult(boolean visible, String blocker, int piercedBlocks) {
    }

    private record BlockTrace(class_3965 hit, double distance, int piercedBlocks, String lastPassThroughBlock) {
    }
}
