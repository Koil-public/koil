package com.spirit.koil.api.automation;

import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.class_2540;
import net.minecraft.class_3222;
import net.minecraft.server.MinecraftServer;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public final class AutomationPresenceServerBridge {
    private static final Map<UUID, PresenceSnapshot> STATES = new ConcurrentHashMap<>();

    private AutomationPresenceServerBridge() {
    }

    public static void register() {
        ServerPlayNetworking.registerGlobalReceiver(AutomationPresenceNetwork.STATE_SYNC_PACKET, (server, player, handler, buffer, responseSender) -> {
            boolean automationMode = buffer.readBoolean();
            String state = buffer.method_10800(64);
            String detail = buffer.method_10800(256);
            long updatedAt = buffer.readLong();
            server.execute(() -> {
                PresenceSnapshot snapshot = new PresenceSnapshot(player.method_5667(), automationMode, state, detail, updatedAt <= 0L ? System.currentTimeMillis() : updatedAt);
                if (automationMode) {
                    STATES.put(player.method_5667(), snapshot);
                } else {
                    STATES.remove(player.method_5667());
                }
                broadcast(server, snapshot);
            });
        });
        ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> {
            class_3222 joining = handler.field_14140;
            server.execute(() -> STATES.values().forEach(snapshot -> ServerPlayNetworking.send(joining, AutomationPresenceNetwork.STATE_BROADCAST_PACKET, packet(snapshot))));
        });
        ServerPlayConnectionEvents.DISCONNECT.register((handler, server) -> {
            class_3222 player = handler.field_14140;
            server.execute(() -> {
                STATES.remove(player.method_5667());
                broadcast(server, new PresenceSnapshot(player.method_5667(), false, "idle", "", System.currentTimeMillis()));
            });
        });
    }

    private static void broadcast(MinecraftServer server, PresenceSnapshot snapshot) {
        for (class_3222 target : server.method_3760().method_14571()) {
            ServerPlayNetworking.send(target, AutomationPresenceNetwork.STATE_BROADCAST_PACKET, packet(snapshot));
        }
    }

    private static class_2540 packet(PresenceSnapshot snapshot) {
        class_2540 buffer = PacketByteBufs.create();
        buffer.method_10788(snapshot.uuid().toString(), 64);
        buffer.writeBoolean(snapshot.automationMode());
        buffer.method_10788(snapshot.state(), 64);
        buffer.method_10788(snapshot.detail(), 256);
        buffer.writeLong(snapshot.updatedAt());
        return buffer;
    }

    private record PresenceSnapshot(UUID uuid, boolean automationMode, String state, String detail, long updatedAt) {
    }
}
