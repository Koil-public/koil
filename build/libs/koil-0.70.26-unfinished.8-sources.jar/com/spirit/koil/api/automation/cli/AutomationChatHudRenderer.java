package com.spirit.koil.api.automation.cli;

import com.spirit.client.gui.console.ConsoleScreen;
import com.spirit.koil.api.automation.AutomationModeController;
import com.spirit.koil.api.automation.feedback.AutomationFeedbackService;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_408;
import net.minecraft.class_5481;

public final class AutomationChatHudRenderer {
    private static final int VANILLA_CHAT_OFFSET_FROM_BOTTOM = 40;

    private AutomationChatHudRenderer() {
    }

    public static int reservedHeight(class_310 client) {
        int panelReservedHeight = panelReservedHeight(client);
        if (panelReservedHeight <= 0) {
            return 0;
        }
        return Math.max(0, panelReservedHeight - VANILLA_CHAT_OFFSET_FROM_BOTTOM);
    }

    public static int occupiedHeight(class_310 client) {
        return panelReservedHeight(client);
    }

    private static int panelReservedHeight(class_310 client) {
        AutomationHudBlock block = buildBlock(client);
        if (block == null || client == null) {
            return 0;
        }
        return block.height + bottomOffset(client);
    }

    public static void render(class_332 context, class_310 client) {
        AutomationHudBlock block = buildBlock(client);
        if (block == null || client == null) {
            return;
        }
        int x = 0;
        int y = client.method_22683().method_4502() - bottomOffset(client) - block.height;
        int background = chatBackgroundColor(client);
        int stateColor = withAlpha(AutomationStateColors.color(AutomationChatHudState.state()), Math.min(255, alpha(background) + 48));
        context.method_25294(x, y, x + block.width, y + block.height, background);
        context.method_25294(x, y, x + 2, y + block.height, stateColor);
        int textY = y + block.paddingY;
        for (class_5481 line : block.lines) {
            context.method_35720(client.field_1772, line, x + block.paddingX, textY, 0xFFFFFF);
            textY += block.lineHeight;
        }
        List<ActionRect> rects = actionRects(client, block, x, y);
        for (ActionRect rect : rects) {
            int fill = fillFor(rect.action().kind(), background);
            context.method_25294(rect.x1(), rect.y1(), rect.x2(), rect.y2(), fill);
            context.method_25294(rect.x1(), rect.y1(), rect.x2(), rect.y1() + 1, withAlpha(0x00FFFFFF, Math.min(120, alpha(background) + 40)));
            context.method_27535(client.field_1772, class_2561.method_43470(rect.action().label()), rect.x1() + 5, rect.y1() + 3, 0xFFFFFF);
        }
    }

    public static boolean mouseClicked(class_310 client, double mouseX, double mouseY, int button) {
        if (button != 0 || client == null) {
            return false;
        }
        AutomationHudBlock block = buildBlock(client);
        if (block == null) {
            return false;
        }
        int x = 0;
        int y = client.method_22683().method_4502() - bottomOffset(client) - block.height;
        for (ActionRect rect : actionRects(client, block, x, y)) {
            if (!rect.contains(mouseX, mouseY)) {
                continue;
            }
            String command = rect.action().command();
            if (command.isBlank()) {
                return false;
            }
            AutomationFeedbackService.handleConsoleInput(command.startsWith("/") ? command : "/" + command);
            return true;
        }
        return false;
    }

    private static AutomationHudBlock buildBlock(class_310 client) {
        if (client == null || client.field_1724 == null || client.field_1755 instanceof ConsoleScreen) {
            return null;
        }
        if (!(client.field_1755 == null || client.field_1755 instanceof class_408)) {
            return null;
        }
        if (!AutomationChatHudState.visible()) {
            return null;
        }
        if (!AutomationModeController.isAutomationMode() && !isFeedbackState(AutomationChatHudState.state())) {
            AutomationChatHudState.hide();
            return null;
        }
        int chatWidth = client.field_1705 == null ? 0 : client.field_1705.method_1743().method_1811();
        int maxWidth = Math.min(client.method_22683().method_4486(), Math.max(190, chatWidth + 12));
        int innerWidth = maxWidth - 12;
        List<class_5481> lines = new ArrayList<>();
        lines.addAll(wrappedLines(client, AutomationChatHudState.header(), innerWidth, 1));
        lines.addAll(wrappedLines(client, AutomationChatHudState.prompt(), innerWidth, 2));
        lines.addAll(wrappedLines(client, AutomationChatHudState.active(), innerWidth, 2));
        int paddingX = 6;
        int paddingY = 3;
        int lineHeight = client.field_1772.field_2000 + 1;
        int actionRows = countActionRows(client, maxWidth - paddingX * 2);
        int actionHeight = actionRows == 0 ? 0 : actionRows * (client.field_1772.field_2000 + 7) + 3;
        int height = Math.max(lineHeight, lines.size() * lineHeight) + paddingY * 2 + actionHeight;
        return new AutomationHudBlock(lines, maxWidth, height, paddingX, paddingY, lineHeight);
    }

    private static List<ActionRect> actionRects(class_310 client, AutomationHudBlock block, int x, int y) {
        List<AutomationChatHudState.Action> actions = AutomationChatHudState.actions();
        if (actions.isEmpty()) {
            return List.of();
        }
        List<ActionRect> rects = new ArrayList<>();
        int maxX = x + block.width - block.paddingX;
        int rowHeight = client.field_1772.field_2000 + 6;
        int cursorX = x + block.paddingX;
        int cursorY = y + block.paddingY + block.lines.size() * block.lineHeight + 3;
        for (AutomationChatHudState.Action action : actions) {
            if (action.label().isBlank()) {
                continue;
            }
            int width = Math.min(block.width - block.paddingX * 2, client.field_1772.method_1727(action.label()) + 10);
            if (cursorX + width > maxX && cursorX > x + block.paddingX) {
                cursorX = x + block.paddingX;
                cursorY += rowHeight + 1;
            }
            rects.add(new ActionRect(action, cursorX, cursorY, cursorX + width, cursorY + rowHeight));
            cursorX += width + 5;
        }
        return rects;
    }

    private static int countActionRows(class_310 client, int width) {
        List<AutomationChatHudState.Action> actions = AutomationChatHudState.actions();
        if (actions.isEmpty() || !hasVisibleAction(actions)) {
            return 0;
        }
        int rows = 1;
        int cursor = 0;
        for (AutomationChatHudState.Action action : actions) {
            if (action.label().isBlank()) {
                continue;
            }
            int buttonWidth = Math.min(width, client.field_1772.method_1727(action.label()) + 15);
            if (cursor + buttonWidth > width && cursor > 0) {
                rows++;
                cursor = 0;
            }
            cursor += buttonWidth + 5;
        }
        return rows;
    }

    private static int bottomOffset(class_310 client) {
        if (client.field_1755 instanceof class_408) {
            return 22;
        }
        return 8;
    }

    private static boolean hasVisibleAction(List<AutomationChatHudState.Action> actions) {
        for (AutomationChatHudState.Action action : actions) {
            if (!action.label().isBlank()) {
                return true;
            }
        }
        return false;
    }

    private static List<class_5481> wrappedLines(class_310 client, class_2561 text, int width, int maxLines) {
        if (text == null || text.getString().isBlank()) {
            return List.of();
        }
        List<class_5481> lines = new ArrayList<>();
        List<class_5481> wrapped = client.field_1772.method_1728(text, width);
        for (int i = 0; i < wrapped.size() && i < maxLines; i++) {
            lines.add(wrapped.get(i));
        }
        return lines;
    }

    private static int chatBackgroundColor(class_310 client) {
        double opacity = client.field_1690.method_42550().method_41753();
        int value = Math.max(0, Math.min(255, (int) (255.0D * opacity)));
        return value << 24;
    }

    private static int fillFor(String kind, int background) {
        int alpha = Math.min(230, Math.max(90, alpha(background) + 30));
        String normalized = kind == null ? "" : kind.toLowerCase(Locale.ROOT);
        if (normalized.contains("good")) {
            return withAlpha(0x00143A21, alpha);
        }
        if (normalized.contains("bad") || normalized.contains("failure")) {
            return withAlpha(0x004A1717, alpha);
        }
        if (normalized.contains("node")) {
            return withAlpha(0x001A273A, alpha);
        }
        if (normalized.contains("file")) {
            return withAlpha(0x001D1D2E, alpha);
        }
        return withAlpha(0x00222222, alpha);
    }

    private static boolean isFeedbackState(String value) {
        String normalized = value == null ? "" : value.toLowerCase(Locale.ROOT);
        return normalized.startsWith("feedback") || normalized.equals("complete") || normalized.equals("failed") || normalized.equals("blocked") || normalized.equals("canceled") || normalized.startsWith("improvement");
    }

    private static int withAlpha(int color, int alpha) {
        return (Math.max(0, Math.min(255, alpha)) << 24) | (color & 0x00FFFFFF);
    }

    private static int alpha(int color) {
        return color >>> 24;
    }

    private record ActionRect(AutomationChatHudState.Action action, int x1, int y1, int x2, int y2) {
        private boolean contains(double x, double y) {
            return x >= x1 && x <= x2 && y >= y1 && y <= y2;
        }
    }
}
